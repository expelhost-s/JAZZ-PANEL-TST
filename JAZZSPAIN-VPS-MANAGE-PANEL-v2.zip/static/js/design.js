/* =====================================================================
   JAZZ DESIGN ENGINE
   - per-design entrance / modal motion, powered by Motion (the vanilla build
     of Framer Motion: https://motion.dev). If the library could not be loaded
     (offline / CDN blocked) everything falls back to the Web Animations API,
     so the panel never breaks.
   - the iOS 26-style "liquid" switch: the new design is revealed through a
     wobbling, organic blob that grows out of the click point.
   - live sync: when an admin changes the design, every open tab / every user
     picks it up within seconds and plays the same liquid transition.
   ===================================================================== */
(function () {
  'use strict';
  var root = document.documentElement;
  var M = window.Motion || window.FramerMotion || null;
  var hasMotion = !!(M && typeof M.animate === 'function');
  var reduce = false;
  try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
  var busy = false;
  var version = root.getAttribute('data-design-v') || '';

  function cur() { return root.getAttribute('data-design') || 'default'; }

  /* ---------- tiny animation helper: Motion first, WAAPI fallback ---------- */
  var SPRINGS = {
    default: { type: 'spring', stiffness: 260, damping: 28 },
    glass:   { type: 'spring', stiffness: 150, damping: 17, mass: 1 },
    minimal: { duration: 0.28, ease: 'easeOut' }
  };
  SPRINGS.glassmorphism = { type: 'spring', stiffness: 200, damping: 24 };

  function cleanup(el) {
    el.style.removeProperty('transform'); el.style.removeProperty('opacity');
    el.style.removeProperty('filter'); el.style.removeProperty('translate');
    el.style.removeProperty('scale'); el.classList.remove('jazz-motion-in');
  }

  function run(els, spec, opts, stagger) {
    // spec: {opacity:[a,b], y:[a,b], x:[..], scale:[..], blur:[a,b]}
    if (!els.length) return;
    els.forEach(function (el) { el.classList.add('jazz-motion-in'); });
    if (hasMotion) {
      var kf = {};
      if (spec.opacity) kf.opacity = spec.opacity;
      if (spec.x) kf.x = spec.x;
      if (spec.y) kf.y = spec.y;
      if (spec.scale) kf.scale = spec.scale;
      if (spec.blur) kf.filter = ['blur(' + spec.blur[0] + 'px)', 'blur(' + spec.blur[1] + 'px)'];
      var o = Object.assign({}, opts);
      if (stagger && typeof M.stagger === 'function') o.delay = M.stagger(stagger, { startDelay: opts.delay || 0 });
      try {
        var ctl = M.animate(els, kf, o);
        var done = ctl && (ctl.finished || ctl);
        if (done && typeof done.then === 'function') {
          done.then(function () { els.forEach(cleanup); }, function () { els.forEach(cleanup); });
        } else { setTimeout(function () { els.forEach(cleanup); }, 1600); }
        return;
      } catch (e) { /* fall through to WAAPI */ }
    }
    els.forEach(function (el, i) {
      var from = [], to = [];
      var t0 = [], t1 = [];
      if (spec.x) { t0.push('translateX(' + spec.x[0] + 'px)'); t1.push('translateX(' + spec.x[1] + 'px)'); }
      if (spec.y) { t0.push('translateY(' + spec.y[0] + 'px)'); t1.push('translateY(' + spec.y[1] + 'px)'); }
      if (spec.scale) { t0.push('scale(' + spec.scale[0] + ')'); t1.push('scale(' + spec.scale[1] + ')'); }
      from = { opacity: spec.opacity ? spec.opacity[0] : 1, transform: t0.join(' ') || 'none' };
      to = { opacity: spec.opacity ? spec.opacity[1] : 1, transform: t1.join(' ') || 'none' };
      if (spec.blur) { from.filter = 'blur(' + spec.blur[0] + 'px)'; to.filter = 'blur(' + spec.blur[1] + 'px)'; }
      var a = el.animate([from, to], { duration: 650, delay: (opts.delay || 0) * 1000 + i * (stagger ? stagger * 1000 : 0),
        easing: 'cubic-bezier(.16,1,.3,1)', fill: 'backwards' });
      a.onfinish = a.oncancel = function () { cleanup(el); };
    });
  }

  /* ---------- entrance choreography per design ---------- */
  function uniqueOuter(list) {
    var arr = Array.prototype.slice.call(list);
    return arr.filter(function (el) {
      return !arr.some(function (o) { return o !== el && o.contains(el); });
    });
  }
  function q(sel) { return uniqueOuter(document.querySelectorAll(sel)).slice(0, 48); }

  function entrance() {
    navPill();
    if (reduce || cur() === 'glass') return;   // liquid glass: no entrance animation
    var d = cur();
    if (window.JAZZ_MAIN && window.JAZZ_MAIN.m_preset && window.JAZZ_MAIN.m_preset !== 'auto') { authIn(); return; }   // Admin -> Main Pages -> Motion: static/js/main-motion.js plays it
    if (d === 'glassmorphism' && window.JAZZGlass) {   // dedicated Motion choreography (design-glassmorphism.js)
      if (authIn()) { /* auth card handled below */ }
      window.JAZZGlass.entrance();
      return;
    }
    if (d === 'studio' && window.JAZZStudio) {   // dedicated Motion choreography (design-studio.js)
      authIn();
      window.JAZZStudio.entrance();
      return;
    }
    if (authIn()) { /* sign in / register card animates itself */ }
    var blocks = q('.main-content .page-header, .main-content .stat-card, .main-content .card, .main-content .table-responsive, .main-content .alert, .main-content .empty-state');
    var nav = q('.sidebar .nav-item');
    if (d === 'glass') {
      run(blocks, { opacity: [0, 1], y: [28, 0], scale: [0.95, 1], blur: [14, 0] }, SPRINGS.glass, 0.065);
      run(nav, { opacity: [0, 1], x: [-18, 0] }, SPRINGS.glass, 0.035);
      run(q('.header'), { opacity: [0, 1], y: [-18, 0], scale: [0.97, 1] }, SPRINGS.glass);
    } else if (d === 'minimal') {
      run(blocks, { opacity: [0, 1] }, SPRINGS.minimal, 0.025);
      run(nav, { opacity: [0, 1] }, SPRINGS.minimal, 0.015);
    } else {
      run(blocks, { opacity: [0, 1], y: [14, 0] }, SPRINGS.default, 0.04);
    }
  }

  /* ---------- modals get a design-specific entrance ---------- */
  function watchModals() {
    if (!window.MutationObserver) return;
    var seen = (typeof WeakSet === 'function') ? new WeakSet() : null;
    var POP = '.user-dropdown, .notifications-panel, .dropdown-menu';
    new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        var el = m.target;
        if (m.attributeName !== 'class' || !el.classList) return;
        var isModal = el.classList.contains('modal');
        var isPop = !isModal && el.matches && el.matches(POP);
        if (!isModal && !isPop) return;
        if (!el.classList.contains('show')) { if (seen) seen.delete(el); return; }
        if (seen && seen.has(el)) return;
        if (seen) seen.add(el);
        if (reduce) return;
        var d = cur();
        if (d === 'glassmorphism' && window.JAZZGlass) { window.JAZZGlass.pop(el, isModal); return; }
        if (d === 'studio' && window.JAZZStudio) { window.JAZZStudio.pop(el, isModal); return; }
        if (isModal) {
          var box = el.querySelector('.modal-content'); if (!box) return;
          if (d === 'minimal') run([box], { opacity: [0, 1] }, { duration: 0.18, ease: 'easeOut' });
        }
      });
    }).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['class'] });
  }

  /* ---------- sidebar: one glass pill glides from the old page's item to the new one ---------- */
  function navPill() {
    var sb = document.querySelector('.sidebar'), nav = document.querySelector('.sidebar-nav');
    if (!sb || !nav) return;
    var pill = nav.querySelector('.nav-pill');
    var act = nav.querySelector('.nav-item.active');
    if (cur() !== 'glass' || !act) { sb.classList.remove('has-pill'); if (pill) pill.remove(); return; }
    if (!pill) { pill = document.createElement('span'); pill.className = 'nav-pill'; nav.insertBefore(pill, nav.firstChild); }
    var top = act.getBoundingClientRect().top - nav.getBoundingClientRect().top + nav.scrollTop;
    pill.style.height = act.offsetHeight + 'px';
    sb.classList.add('has-pill');
    pill.style.transform = 'translateY(' + top + 'px)';
    try { sessionStorage.setItem('jazzNavTop', String(top)); } catch (e) {}
  }

  /* ---------- Sign in <-> Register: directional card transition (all designs) ---------- */
  function authDir() { var d = 0; try { d = parseInt(sessionStorage.getItem('jazzAuthDir') || '0', 10) || 0; sessionStorage.removeItem('jazzAuthDir'); } catch (e) {} return d; }

  function authIn() {
    var card = document.querySelector('.auth-card');
    if (!card || reduce) return false;
    var d = cur(), dir = authDir() || 1;
    var kids = uniqueOuter(card.querySelectorAll(':scope > *, :scope form > *')).slice(0, 24);
    var aw = document.querySelector('.auth-wrap'), am = aw && aw.getAttribute('data-anim');   // Admin -> Login Page -> Motion
    window.__jazzAuthDir = dir;                       // slide direction for login-motion.js
    if (am && am !== 'auto') return true;            // 'none' or a custom entrance: static/js/login-motion.js plays it
    if (d === 'glass') {
      /* liquid glass: no animation */
    } else if (d === 'glassmorphism' && window.JAZZGlass) {
      window.JAZZGlass.auth(card, kids, dir);
    } else if (d === 'studio' && window.JAZZStudio) {
      window.JAZZStudio.auth(card, kids, dir);
    } else if (d === 'minimal') {
      run([card], { opacity: [0, 1] }, { duration: 0.3, ease: 'easeOut' });
      run(kids, { opacity: [0, 1] }, { duration: 0.3, ease: 'easeOut', delay: 0.05 }, 0.03);
    } else {
      run([card], { opacity: [0, 1], x: [dir * 50, 0], scale: [0.97, 1] }, { type: 'spring', stiffness: 220, damping: 24 });
      run(kids, { opacity: [0, 1], y: [12, 0] }, { type: 'spring', stiffness: 240, damping: 24, delay: 0.1 }, 0.04);
    }
    return true;
  }

  // plays an exit animation, resolves when done (never hangs)
  function leave(el, spec, mo, ms) {
    return new Promise(function (res) {
      var done = false, fin = function () { if (!done) { done = true; res(); } };
      setTimeout(fin, ms + 220);
      if (hasMotion) {
        try {
          var kf = {};
          if (spec.opacity) kf.opacity = spec.opacity; if (spec.x) kf.x = spec.x;
          if (spec.scale) kf.scale = spec.scale; if (spec.blur) kf.filter = ['blur(' + spec.blur[0] + 'px)', 'blur(' + spec.blur[1] + 'px)'];
          var c = M.animate(el, kf, mo); (c.finished || c).then(fin, fin); return;
        } catch (e) {}
      }
      var t0 = [], t1 = [];
      if (spec.x) { t0.push('translateX(' + spec.x[0] + 'px)'); t1.push('translateX(' + spec.x[1] + 'px)'); }
      if (spec.scale) { t0.push('scale(' + spec.scale[0] + ')'); t1.push('scale(' + spec.scale[1] + ')'); }
      var f0 = { opacity: spec.opacity[0], transform: t0.join(' ') || 'none' }, f1 = { opacity: spec.opacity[1], transform: t1.join(' ') || 'none' };
      if (spec.blur) { f0.filter = 'blur(' + spec.blur[0] + 'px)'; f1.filter = 'blur(' + spec.blur[1] + 'px)'; }
      var a = el.animate([f0, f1], { duration: ms, easing: 'ease-in', fill: 'forwards' });
      a.onfinish = fin;
    });
  }

  // if the navigation turns out to be a file download (page never unloads) bring the page back
  function restoreLater(el) {
    setTimeout(function () {
      document.documentElement.classList.remove('page-leaving');
      if (el.getAnimations) el.getAnimations().forEach(function (a) { a.cancel(); });
      cleanup(el);
    }, 2500);
  }

  function linkTransitions() {
    document.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || reduce) return;
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download') || a.hasAttribute('onclick')) return;
      var href = a.getAttribute('href');
      if (!href || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href)) return;
      var u; try { u = new URL(a.href, location.href); } catch (x) { return; }
      if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search)) return;

      var d = cur(), card = a.closest('.auth-card');
      if (d === 'glass') return;   // liquid glass: plain navigation, no exit animation
      var toAuth = /\/(login|register)\/?$/.test(u.pathname);
      if (card && toAuth) {                       // Sign in <-> Register
        e.preventDefault();
        var dir = /register/.test(u.pathname) ? 1 : -1;
        try { sessionStorage.setItem('jazzAuthDir', String(dir)); } catch (x) {}
        var spec, mo, ms;
        if (d === 'glassmorphism') { spec = { opacity: [1, 0], x: [0, -dir * 70], scale: [1, 0.94], blur: [0, 14] }; mo = { duration: 0.3, ease: 'easeIn' }; ms = 300; }
        else if (d === 'studio') { spec = { opacity: [1, 0], x: [0, -dir * 24] }; mo = { duration: 0.16, ease: 'easeIn' }; ms = 160; }
        else if (d === 'glass') { spec = { opacity: [1, 0], x: [0, -dir * 90], scale: [1, 0.92], blur: [0, 16] }; mo = { duration: 0.32, ease: 'easeIn' }; ms = 320; }
        else if (d === 'minimal') { spec = { opacity: [1, 0] }; mo = { duration: 0.18, ease: 'easeIn' }; ms = 180; }
        else { spec = { opacity: [1, 0], x: [0, -dir * 50], scale: [1, 0.97] }; mo = { duration: 0.26, ease: 'easeIn' }; ms = 260; }
        document.documentElement.classList.add('page-leaving');
        leave(card, spec, mo, ms).then(function () { location.href = u.href; restoreLater(card); });
        return;
      }
      if (d === 'studio' && !a.closest('.modal') && !a.closest('.auth-card')) {   // sidebar pill glides, then a short fade
        var sm = document.querySelector('.main-content') || document.body;
        e.preventDefault();
        if (window.JAZZStudio && a.closest('.sidebar-nav')) window.JAZZStudio.hint(a);
        document.documentElement.classList.add('page-leaving');
        leave(sm, { opacity: [1, 0] }, { duration: 0.14, ease: 'easeIn' }, 140).then(function () { location.href = u.href; restoreLater(sm); });
        return;
      }
      if (d === 'glassmorphism' && !a.closest('.modal')) {   // frosted page exit
        var mc = document.querySelector('.main-content') || document.body;
        e.preventDefault();
        document.documentElement.classList.add('page-leaving');
        leave(mc, { opacity: [1, 0], scale: [1, 0.975], blur: [0, 10] }, { duration: 0.22, ease: 'easeIn' }, 220).then(function () { location.href = u.href; restoreLater(mc); });
      }
    });
    // back/forward cache: never come back to a half-faded page
    window.addEventListener('pageshow', function (e) {
      if (!e.persisted) return;
      document.documentElement.classList.remove('page-leaving');
      document.querySelectorAll('.main-content, .auth-card').forEach(function (n) {
        n.getAnimations && n.getAnimations().forEach(function (a) { a.cancel(); }); cleanup(n);
      });
    });
  }

  /* ---------- the liquid blob ---------- */
  function blobClip(cx, cy, R, t, amp) {
    var N = 128, pts = [];
    for (var i = 0; i < N; i++) {
      var a = (i / N) * Math.PI * 2;
      var w = 1 + amp * (0.55 * Math.sin(3 * a + t * 5.2) + 0.3 * Math.sin(5 * a - t * 7.4) + 0.15 * Math.sin(9 * a + t * 3.3));
      pts.push((cx + Math.cos(a) * R * w).toFixed(1) + 'px ' + (cy + Math.sin(a) * R * w).toFixed(1) + 'px');
    }
    return 'polygon(' + pts.join(',') + ')';
  }

  // 0..1 progress -> drives the growing, wobbling blob
  function liquid(x, y, duration, onFrame) {
    var W = window.innerWidth, H = window.innerHeight;
    var far = Math.hypot(Math.max(x, W - x), Math.max(y, H - y));
    var Rmax = far * 1.4;
    return new Promise(function (resolve) {
      var start = null;
      function ease(p) { return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; } // easeInOutCubic
      function frame(ts) {
        if (start === null) start = ts;
        var p = Math.min(1, (ts - start) / duration);
        var e = ease(p);
        // wobble is strongest mid-flight and settles to a perfect circle
        var amp = 0.16 * Math.pow(Math.sin(Math.PI * Math.min(1, p * 1.05)), 1.4) + 0.012 * (1 - p);
        onFrame(blobClip(x, y, Rmax * e, p * (duration / 1000), amp));
        if (p < 1) requestAnimationFrame(frame); else resolve();
      }
      requestAnimationFrame(frame);
    });
  }

  var OVERLAY_BG = {
    default: { dark: '#0A0A0A', light: '#F3F4F7' },
    minimal: { dark: '#0C0C0D', light: '#FFFFFF' },
    glass:   { dark: 'linear-gradient(135deg,#1b1410,#3a2314 55%,#a8541c)', light: 'linear-gradient(135deg,#f4efe9,#f7e6d6 55%,#ffd9b8)' },
    studio: { dark: '#131211', light: '#F5F3EF' },
    glassmorphism: { dark: 'linear-gradient(135deg,#1a1245,#5b2a8c 50%,#1d6fa5)', light: 'linear-gradient(135deg,#dfe7ff,#f3d9ff 50%,#cdf1ff)' }
  };

  function switchTo(next, origin) {
    if (next === cur()) return Promise.resolve();
    if (['default', 'minimal', 'glass', 'glassmorphism', 'studio'].indexOf(next) < 0) return Promise.resolve();
    var apply = function () {
      if (cur() === 'glassmorphism' && next !== 'glassmorphism' && window.JAZZGlass) window.JAZZGlass.stop();
      if (cur() === 'studio' && next !== 'studio' && window.JAZZStudio) window.JAZZStudio.stop();
      root.setAttribute('data-design', next);
      requestAnimationFrame(function () { requestAnimationFrame(entrance); });
    };
    if (reduce || busy) { apply(); return Promise.resolve(); }
    busy = true;
    var x = origin && origin.x != null ? origin.x : window.innerWidth / 2;
    var y = origin && origin.y != null ? origin.y : window.innerHeight / 2;
    var dur = (next === 'glass' ? 1250 : 950) * (window.JAZZ_DESIGN_SLOW || 1);
    var start = 'circle(0px at ' + x + 'px ' + y + 'px)';
    var finish = function () {
      root.classList.remove('design-switching');
      root.style.removeProperty('--jazz-clip');
      var ov = document.getElementById('jazzLiquid'); if (ov) ov.remove();
      busy = false;
    };

    if (typeof document.startViewTransition === 'function') {
      root.classList.add('design-switching');
      root.style.setProperty('--jazz-clip', start);
      var vt;
      try { vt = document.startViewTransition(apply); }
      catch (e) { finish(); apply(); return Promise.resolve(); }
      return vt.ready.then(function () {
        return liquid(x, y, dur, function (clip) { root.style.setProperty('--jazz-clip', clip); });
      }).catch(function () { /* transition skipped */ })
        .then(function () { return vt.finished.catch(function () {}); })
        .then(finish, finish);
    }

    // Fallback (no View Transitions API): a coloured liquid blob covers the page, we swap, then it fades.
    var mode = root.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
    var ov = document.createElement('div');
    ov.id = 'jazzLiquid';
    ov.style.background = (OVERLAY_BG[next] || OVERLAY_BG.default)[mode];
    ov.style.setProperty('--jazz-clip', start);
    document.body.appendChild(ov);
    return liquid(x, y, dur * 0.7, function (clip) { ov.style.setProperty('--jazz-clip', clip); })
      .then(function () {
        apply();
        return new Promise(function (res) {
          var a = ov.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 380, easing: 'ease-out', fill: 'forwards' });
          a.onfinish = res; a.oncancel = res;
        });
      }).then(finish, finish);
  }

  /* ---------- live sync with the admin's choice ---------- */
  function poll() {
    if (document.hidden || busy) return;
    fetch('/api/design', { cache: 'no-store', credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (!d || !d.design || d.version === version) return;
        version = d.version;
        if (d.design !== cur()) switchTo(d.design, null);
      }).catch(function () {});
  }

  function init() {
    linkTransitions(); watchModals(); entrance();
    setInterval(poll, 12000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(); });
    window.addEventListener('focus', poll);
  }

  window.JAZZDesign = {
    run: run,
    current: cur,
    switchTo: switchTo,
    replay: entrance,
    setVersion: function (v) { version = v || ''; root.setAttribute('data-design-v', version); },
    usingMotion: function () { return hasMotion; }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
