/* ==========================================================================
   Login / Register motion engine  (Admin -> Login Page -> Motion)
   Same engine as the landing page: Motion (the vanilla build of Framer Motion)
   with springs and staggered orchestration, falling back to the Web Animations
   API if the library can't load. Config comes from window.JAZZ_LOGIN
   (see get_login_view in jazz.py). "Follow design" (anim = auto) leaves the
   built-in per-design animation in design.js untouched.
   ========================================================================== */
(function () {
  'use strict';
  var C = window.JAZZ_LOGIN || {};
  var wrap = document.querySelector('.auth-wrap');
  if (!wrap) return;

  var M = window.Motion || window.FramerMotion || null;
  var hasMotion = !!(M && typeof M.animate === 'function');
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var preset = wrap.getAttribute('data-anim') || 'auto';

  function spec(extra) {
    var o = C.m_type === 'tween'
      ? { duration: (C.m_duration || 700) / 1000, ease: [0.16, 1, 0.3, 1] }
      : { type: 'spring', stiffness: C.m_stiffness || 220, damping: C.m_damping || 24 };
    for (var k in (extra || {})) o[k] = extra[k];
    return o;
  }

  /* keyframes: the card moves with full strength, the fields inside with a gentler version */
  function frames(kind, d, dir, soft) {
    var f = soft ? 0.4 : 1;
    switch (kind) {
      case 'fade':  return { opacity: [0, 1] };
      case 'rise':  return { opacity: [0, 1], y: [d * (soft ? 0.4 : 0.7), 0] };
      case 'pop':   return { opacity: [0, 1], scale: [soft ? 0.94 : 0.86, 1], y: [d * 0.25, 0] };
      case 'zoom':  return { opacity: [0, 1], scale: [soft ? 0.96 : 0.9, 1] };
      case 'blur':  return { opacity: [0, 1], filter: ['blur(' + (soft ? 8 : 14) + 'px)', 'blur(0px)'], y: [d * 0.3, 0] };
      case 'slide': return { opacity: [0, 1], x: [dir * Math.max(d, 24) * (soft ? 0.6 : 1.6), 0] };
      case 'flip':  return { opacity: [0, 1], rotateX: [soft ? 28 : 45, 0], y: [d * 0.4 * f, 0], transformPerspective: 900 };
      default:      return { opacity: [0, 1] };
    }
  }

  function run(el, kf, opts, onEnd) {
    function fin() { el.style.willChange = ''; onEnd && onEnd(); }
    if (hasMotion) {
      try {
        var ctl = M.animate(el, kf, opts);
        if (ctl && ctl.finished) ctl.finished.then(fin, fin); else if (ctl && ctl.then) ctl.then(fin, fin); else fin();
        return;
      } catch (e) { /* fall through */ }
    }
    var from = {}, to = {}, t0 = [], t1 = [];
    Object.keys(kf).forEach(function (k) {
      var v = kf[k]; if (!Array.isArray(v)) return;
      if (k === 'opacity' || k === 'filter') { from[k] = v[0]; to[k] = v[1]; }
      else if (k === 'y') { t0.push('translateY(' + v[0] + 'px)'); t1.push('translateY(' + v[1] + 'px)'); }
      else if (k === 'x') { t0.push('translateX(' + v[0] + 'px)'); t1.push('translateX(' + v[1] + 'px)'); }
      else if (k === 'scale') { t0.push('scale(' + v[0] + ')'); t1.push('scale(' + v[1] + ')'); }
      else if (k === 'rotateX') { t0.unshift('perspective(900px)'); t1.unshift('perspective(900px)'); t0.push('rotateX(' + v[0] + 'deg)'); t1.push('rotateX(' + v[1] + 'deg)'); }
    });
    if (t0.length) { from.transform = t0.join(' '); to.transform = t1.join(' '); }
    var a = el.animate([from, to], { duration: C.m_type === 'tween' ? (C.m_duration || 700) : 800, delay: (opts.delay || 0) * 1000,
      easing: C.m_type === 'tween' ? 'cubic-bezier(.16,1,.3,1)' : 'cubic-bezier(.34,1.3,.5,1)', fill: 'backwards' });
    a.onfinish = fin; a.oncancel = fin;
  }

  /* headline word by word (same technique as the landing page) */
  function splitWords(h) {
    var out = [];
    (function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (n) {
        if (n.nodeType === 3) {
          if (!n.nodeValue.trim()) return;
          var frag = document.createDocumentFragment();
          n.nodeValue.split(/(\s+)/).forEach(function (part) {
            if (!part) return;
            if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(' ')); return; }
            var w = document.createElement('span'); w.className = 'au-w';
            var i = document.createElement('span'); i.className = 'au-wi'; i.textContent = part;
            w.appendChild(i); frag.appendChild(w); out.push(i);
          });
          n.parentNode.replaceChild(frag, n);
        } else if (n.nodeType === 1 && n.tagName !== 'BR') walk(n);
      });
    })(h);
    return out;
  }

  function start() {
    var card = wrap.querySelector('.auth-card');
    if (!card) return;
    window.__auStarted = true;

    var kids = [];
    Array.prototype.forEach.call(card.children, function (el) {
      if (el.tagName === 'FORM') Array.prototype.forEach.call(el.children, function (c) { kids.push(c); });
      else kids.push(el);
    });
    var title = card.querySelector('.auth-title');
    var words = (C.m_text === 'words' && !reduce && title) ? splitWords(title) : null;

    function revealAll() { kids.forEach(function (k) { k.classList.add('au-in'); }); }
    if (reduce) { revealAll(); return; }

    function playWords(delay) {
      if (!words || !words.length) return;
      title.classList.add('au-in');
      words.forEach(function (w, i) {
        w.style.transform = 'translateY(115%)';
        run(w, { y: ['115%', '0%'] }, spec({ delay: delay + i * 0.07 }), function () { w.style.transform = ''; });
      });
    }

    if (preset === 'auto') {                 // design.js animates the card; we only add the extras
      if (words) playWords(0.1); else if (title) title.classList.add('au-in');
    } else if (preset === 'none') {
      revealAll();
    } else {
      var d = C.m_distance == null ? 28 : C.m_distance;
      var dir = window.__jazzAuthDir || 1;
      var stag = (C.m_stagger || 0) / 1000, base = 0.12;
      card.style.willChange = 'transform,opacity';
      run(card, frames(preset, d, dir, false), spec(), function () {
        card.style.transform = ''; card.style.filter = ''; card.style.opacity = '';
      });
      kids.forEach(function (el, i) {
        if (el === title && words) { playWords(base + i * stag); return; }
        el.style.willChange = 'transform,opacity';
        run(el, frames(preset, d, dir, true), spec({ delay: base + i * stag }), function () {
          el.style.transform = ''; el.style.filter = '';
        });
        el.classList.add('au-in');
      });
    }

    /* magnetic buttons */
    if (C.m_magnetic && matchMedia('(hover:hover)').matches) {
      Array.prototype.forEach.call(card.querySelectorAll('.btn'), function (b) {
        var spr = { type: 'spring', stiffness: 260, damping: 18, mass: 0.6 };
        b.addEventListener('pointermove', function (e) {
          var r = b.getBoundingClientRect();
          var dx = (e.clientX - (r.left + r.width / 2)) * 0.18, dy = (e.clientY - (r.top + r.height / 2)) * 0.3;
          if (hasMotion) M.animate(b, { x: dx, y: dy }, spr); else b.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
        });
        b.addEventListener('pointerleave', function () {
          if (hasMotion) M.animate(b, { x: 0, y: 0 }, spr); else b.style.transform = '';
        });
      });
    }
  }

  /* runs after design.js has handled (or skipped) its own card animation */
  if (document.readyState === 'complete') start();
  else document.addEventListener('DOMContentLoaded', start);
})();
