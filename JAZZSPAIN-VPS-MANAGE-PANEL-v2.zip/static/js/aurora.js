/* AURORA — Jazz Panel UI engine: motion, command palette, toasts, copy, pins */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- background + scroll bar ---------- */
  function mountBackground() {
    if ($('.aurora-bg')) return;
    const bg = document.createElement('div');
    bg.className = 'aurora-bg';
    bg.setAttribute('aria-hidden', 'true');
    bg.innerHTML = '<span class="aurora-noise"></span>';
    document.body.prepend(bg);
    const bar = document.createElement('div');
    bar.id = 'scrollBar';
    document.body.appendChild(bar);
    const upd = () => {
      const h = document.documentElement;
      const p = h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight);
      bar.style.transform = 'scaleX(' + Math.min(1, Math.max(0, p)) + ')';
    };
    addEventListener('scroll', upd, { passive: true }); upd();
  }

  /* ---------- robust copy (full text, https + http fallback) ---------- */
  async function copyText(text, el) {
    text = String(text == null ? '' : text);
    let ok = false;
    try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); ok = true; } } catch (e) {}
    if (!ok) {
      const ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
      document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, ta.value.length);
      try { ok = document.execCommand('copy'); } catch (e) {}
      ta.remove();
    }
    if (el) { el.classList.remove('copied-flash'); void el.offsetWidth; el.classList.add('copied-flash'); }
    toast(ok ? 'Copied to clipboard' : 'Copy failed — select and copy manually', ok ? 'success' : 'danger');
    return ok;
  }
  window.copyText = copyText;
  document.addEventListener('click', (e) => {
    const c = e.target.closest('[data-copy]');
    if (c) { e.preventDefault(); copyText(c.getAttribute('data-copy'), c); }
  });

  /* ---------- toasts (replaces base showToast, same signature) ---------- */
  function toast(message, type, title) {
    type = type || 'info';
    let stack = $('#toastStack');
    if (!stack) { stack = document.createElement('div'); stack.id = 'toastStack'; document.body.appendChild(stack); }
    const icons = { success: 'check-circle', danger: 'circle-exclamation', warning: 'triangle-exclamation', info: 'circle-info' };
    const t = document.createElement('div');
    t.className = 'tst ' + type;
    const dur = type === 'danger' ? 7000 : 4500;
    t.style.setProperty('--dur', dur + 'ms');
    t.innerHTML = '<i class="fas fa-' + (icons[type] || icons.info) + ' ic"></i><div class="tx">' + (title ? '<b></b>' : '') + '<span class="m"></span></div><button class="x" aria-label="Close"><i class="fas fa-xmark"></i></button>';
    if (title) $('b', t).textContent = title;
    $('.m', t).textContent = String(message == null ? '' : message);
    const kill = () => { t.classList.add('out'); setTimeout(() => t.remove(), 300); };
    $('.x', t).onclick = kill;
    stack.appendChild(t);
    while (stack.children.length > 4) stack.firstChild.remove();
    setTimeout(kill, dur);
  }
  window.showToast = toast;

  /* ---------- spotlight, ripple, counters ---------- */
  function bindSpotlight() { /* mouse-follow glow removed */ }
  function bindRipple() {
    document.addEventListener('pointerdown', (e) => {
      const b = e.target.closest('.btn');
      if (!b || b.disabled || reduce) return;
      const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height);
      const s = document.createElement('span');
      s.className = 'ripple';
      s.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (e.clientX - r.left - d / 2) + 'px;top:' + (e.clientY - r.top - d / 2) + 'px';
      b.appendChild(s); setTimeout(() => s.remove(), 650);
    });
  }
  function countUp() {
    if (reduce) return;
    $$('.dash-stat-value,.stat-value,[data-count]').forEach((el) => {
      if (el.dataset.counted) return;
      const node = Array.from(el.childNodes).find((n) => n.nodeType === 3 && /\d/.test(n.textContent));
      if (!node) return;
      const m = node.textContent.match(/(\d+(?:\.\d+)?)/); if (!m) return;
      const end = parseFloat(m[1]), dec = (m[1].split('.')[1] || '').length, pre = node.textContent.slice(0, m.index), post = node.textContent.slice(m.index + m[1].length);
      el.dataset.counted = '1';
      const t0 = performance.now(), D = 1100;
      (function f(t) {
        const p = Math.min(1, (t - t0) / D), v = end * (1 - Math.pow(1 - p, 4));
        node.textContent = pre + v.toFixed(dec) + post;
        if (p < 1) requestAnimationFrame(f);
      })(t0);
    });
  }

  /* ---------- page transitions ---------- */
  function bindTransitions() {
    document.addEventListener('click', (e) => {
      const a = e.target.closest('a[href]');
      if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;
      const h = a.getAttribute('href');
      if (!h || h[0] === '#' || a.target === '_blank' || a.hasAttribute('download') || /^(javascript|mailto|tel):/i.test(h) || a.origin !== location.origin) return;
      if (a.hasAttribute('onclick')) return;
      document.body.classList.add('leaving');
      setTimeout(() => document.body.classList.remove('leaving'), 1800);
    });
    addEventListener('pageshow', () => document.body.classList.remove('leaving'));
  }

  /* ---------- header extras: palette trigger + live pill ---------- */
  function mountHeader() {
    const right = $('.header-right'); if (!right || $('.cmdk-trigger')) return;
    const b = document.createElement('button');
    b.className = 'cmdk-trigger'; b.type = 'button'; b.setAttribute('aria-label', 'Search and commands');
    b.innerHTML = '<i class="fas fa-magnifying-glass"></i><span>Search or jump to…</span><kbd>Ctrl K</kbd>';
    b.onclick = () => openPalette();
    right.prepend(b);
    const p = document.createElement('div');
    p.className = 'net-pill'; p.innerHTML = '<i class="d"></i><span>Live</span>';
    right.prepend(p);
    const set = () => { p.classList.toggle('off', !navigator.onLine); $('span', p).textContent = navigator.onLine ? 'Live' : 'Offline'; };
    addEventListener('online', set); addEventListener('offline', set);
  }

  /* ---------- mobile dock ---------- */
  function mountDock() {
    if ($('#dock') || !$('.sidebar-nav')) return;
    const want = [['/dashboard', 'chart-pie', 'Home'], ['/vps', 'server', 'VPS'], ['/ports', 'plug', 'Ports'], ['/profile', 'user', 'Me']];
    const d = document.createElement('nav'); d.id = 'dock';
    d.innerHTML = want.map((w) => '<a href="' + w[0] + '" class="' + (location.pathname === w[0] || (w[0] === '/vps' && /^\/vps\//.test(location.pathname)) ? 'on' : '') + '"><i class="fas fa-' + w[1] + '"></i>' + w[2] + '</a>').join('');
    document.body.appendChild(d);
  }

  /* ---------- command palette ---------- */
  let pal, palIn, palList, items = [], sel = 0, vpsCache = null;
  function buildPalette() {
    pal = document.createElement('div'); pal.id = 'cmdk';
    pal.innerHTML = '<div class="cmdk-box" role="dialog" aria-label="Command palette"><div class="cmdk-in"><i class="fas fa-magnifying-glass"></i><input type="text" placeholder="Type a page, a VPS name, or a command…" autocomplete="off" spellcheck="false"><span class="kbd">Esc</span></div><div class="cmdk-list"></div><div class="cmdk-foot"><span><kbd>↑</kbd> <kbd>↓</kbd> navigate</span><span><kbd>↵</kbd> open</span><span><kbd>G</kbd> then <kbd>D</kbd>/<kbd>V</kbd>/<kbd>P</kbd> quick jump</span></div></div>';
    document.body.appendChild(pal);
    palIn = $('input', pal); palList = $('.cmdk-list', pal);
    pal.addEventListener('mousedown', (e) => { if (e.target === pal) closePalette(); });
    palIn.addEventListener('input', render);
    palIn.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
      else if (e.key === 'Enter') { e.preventDefault(); run(items[sel]); }
      else if (e.key === 'Escape') closePalette();
    });
  }
  function pageItems() {
    const out = [], seen = new Set();
    $$('.sidebar .nav-item[href]').forEach((a) => {
      const h = a.getAttribute('href'); if (!h || h[0] === '#' || h.startsWith('javascript') || seen.has(h)) return; seen.add(h);
      const ic = ($('i', a) || {}).className || 'fas fa-arrow-right';
      const sec = a.closest('.nav-section'), st = sec && sec.querySelector('.nav-section-title'), lb = a.querySelector('span');
      out.push({ g: st ? st.textContent.trim() : 'Go to', t: ((lb ? lb.textContent : a.textContent) || '').replace(/\s+/g, ' ').trim(), i: ic, href: h });
    });
    return out;
  }
  function actionItems() {
    const a = [
      { g: 'Actions', t: 'Reload page', i: 'fas fa-rotate', fn: () => location.reload() },
      { g: 'Actions', t: 'Toggle sidebar', i: 'fas fa-table-columns', fn: () => { const s = $('#sidebar'), m = $('.main-content'); if (s) { s.classList.toggle('collapsed'); m && m.classList.toggle('expanded'); } } },
      { g: 'Actions', t: 'Scroll to top', i: 'fas fa-arrow-up', fn: () => scrollTo({ top: 0, behavior: 'smooth' }) },
      { g: 'Actions', t: 'Copy current page URL', i: 'fas fa-link', fn: () => copyText(location.href) }
    ];
    const lo = $('a[href="/logout"]'); if (lo) a.push({ g: 'Actions', t: 'Log out', i: 'fas fa-right-from-bracket', href: '/logout' });
    return a;
  }
  async function loadVps() {
    if (vpsCache) return vpsCache;
    try {
      const r = await fetch('/api/palette', { credentials: 'same-origin' });
      const j = await r.json();
      vpsCache = (j.vps || []).map((v) => ({
        g: 'Your VPS', t: v.name, i: 'fas fa-server', href: '/vps/' + v.id, sub: (v.status || '') + (v.ip ? ' · ' + v.ip : ''),
        extra: [
          { g: 'Your VPS', t: v.name + ' — Console', i: 'fas fa-terminal', href: '/vps/' + v.id + '/console', sub: 'console', hidden: true },
          { g: 'Your VPS', t: v.name + ' — Files', i: 'fas fa-folder-open', href: '/vps/' + v.id + '/files', sub: 'files', hidden: true }
        ]
      }));
      vpsCache = vpsCache.reduce((acc, v) => { acc.push(v); v.extra.forEach((x) => acc.push(x)); return acc; }, []);
    } catch (e) { vpsCache = []; }
    return vpsCache;
  }
  function score(q, s) { s = s.toLowerCase(); if (!q) return 1; if (s.includes(q)) return 100 - s.indexOf(q); let i = 0; for (const c of s) if (c === q[i]) i++; return i === q.length ? 10 : 0; }
  async function render() {
    const q = palIn.value.trim().toLowerCase();
    const all = [].concat(pageItems(), actionItems(), await loadVps());
    items = all.filter((x) => !(x.hidden && !q)).map((x) => ({ x, s: score(q, x.t + ' ' + (x.sub || '')) })).filter((o) => o.s > 0).sort((a, b) => b.s - a.s).map((o) => o.x).slice(0, 40);
    sel = 0; palList.innerHTML = '';
    if (!items.length) { palList.innerHTML = '<div class="cmdk-empty">No results for “' + q.replace(/</g, '&lt;') + '”</div>'; return; }
    let last = '';
    items.forEach((it, idx) => {
      if (it.g !== last) { const g = document.createElement('div'); g.className = 'cmdk-grp'; g.textContent = it.g; palList.appendChild(g); last = it.g; }
      const d = document.createElement('div'); d.className = 'cmdk-it' + (idx === 0 ? ' sel' : ''); d.dataset.i = idx;
      d.innerHTML = '<i class="' + it.i + '"></i><span></span>' + (it.sub ? '<small></small>' : '');
      $('span', d).textContent = it.t; if (it.sub) $('small', d).textContent = it.sub;
      d.onmousemove = () => { sel = idx; mark(); };
      d.onclick = () => run(it);
      palList.appendChild(d);
    });
  }
  function mark() { $$('.cmdk-it', palList).forEach((n) => n.classList.toggle('sel', +n.dataset.i === sel)); const s = $('.cmdk-it.sel', palList); s && s.scrollIntoView({ block: 'nearest' }); }
  function move(d) { if (!items.length) return; sel = (sel + d + items.length) % items.length; mark(); }
  function run(it) { if (!it) return; closePalette(); if (it.fn) it.fn(); else if (it.href) { document.body.classList.add('leaving'); location.href = it.href; } }
  function openPalette() { if (!pal) buildPalette(); pal.classList.add('open'); palIn.value = ''; render(); setTimeout(() => palIn.focus(), 30); }
  function closePalette() { pal && pal.classList.remove('open'); }
  window.openPalette = openPalette;

  /* ---------- keyboard ---------- */
  let gTimer = null, gArm = false;
  document.addEventListener('keydown', (e) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName || '')) || e.target.isContentEditable || e.target.closest('.xterm');
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); pal && pal.classList.contains('open') ? closePalette() : openPalette(); return; }
    if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === '/') { e.preventDefault(); const s = $('#searchVPS'); s ? s.focus() : openPalette(); return; }
    if (e.key === '?') { openPalette(); return; }
    if (gArm) {
      const map = { d: '/dashboard', v: '/vps', p: '/ports', n: '/notifications', u: '/profile' };
      const k = e.key.toLowerCase(); gArm = false; clearTimeout(gTimer);
      if (map[k]) { e.preventDefault(); document.body.classList.add('leaving'); location.href = map[k]; }
      return;
    }
    if (e.key.toLowerCase() === 'g') { gArm = true; gTimer = setTimeout(() => (gArm = false), 900); }
  });

  /* ---------- pinned VPS (vps_list) ---------- */
  function pins() { try { return JSON.parse(localStorage.getItem('jazz_pins') || '[]'); } catch (e) { return []; } }
  function savePins(p) { try { localStorage.setItem('jazz_pins', JSON.stringify(p)); } catch (e) {} }
  function mountPins() {
    const cards = $$('.vps-item[data-id]'); if (!cards.length) return;
    const P = pins();
    cards.forEach((c) => {
      if ($('.pin-btn', c)) return;
      const id = c.dataset.id, b = document.createElement('button');
      b.type = 'button'; b.className = 'pin-btn' + (P.includes(id) ? ' on' : ''); b.title = 'Pin to top';
      b.innerHTML = '<i class="fas fa-thumbtack"></i>';
      b.onclick = (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        let p = pins(); p = p.includes(id) ? p.filter((x) => x !== id) : p.concat(id); savePins(p);
        b.classList.toggle('on'); sortPins(); toast(p.includes(id) ? 'Pinned to top' : 'Unpinned', 'info');
      };
      c.appendChild(b);
    });
    sortPins();
  }
  function sortPins() {
    const P = pins(); const first = $('.vps-item[data-id]'); if (!first) return;
    const host = first.parentElement;
    const cur = $$('.vps-item[data-id]', host);
    const want = cur.slice().sort((a, b) => (P.includes(b.dataset.id) ? 1 : 0) - (P.includes(a.dataset.id) ? 1 : 0));
    // only touch the DOM when the order actually changes (never loop)
    if (want.every((n, i) => n === cur[i])) return;
    want.forEach((n) => host.appendChild(n));
  }

  /* ---------- boot ---------- */
  function init() {
    if (!$('.sidebar-nav')) document.body.classList.add('no-sidebar'); mountBackground(); bindSpotlight(); bindRipple(); bindTransitions(); mountHeader(); mountDock(); mountPins();
    requestAnimationFrame(countUp);
    // click-to-copy for IP-like chips on VPS cards
    $$('.vps-item [data-ip]').forEach((n) => {});

  }
  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', init) : init();
})();

/* ---------- hero terminal typing ---------- */
(function () {
  const el = document.getElementById('heroTerm'); if (!el) return;
  let lines; try { lines = JSON.parse(el.getAttribute('data-lines')); } catch (e) { return; }
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const esc = (t) => t.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  const cls = (t) => (t.startsWith('$') ? 'cm' : t.startsWith('\u2714') ? (t.includes('http') ? 'ln' : 'ok') : '');
  function paint(n, partial) {
    el.innerHTML = lines.slice(0, n).map((t) => '<span class="l ' + cls(t) + '">' + esc(t) + '</span>').join('') +
      (partial != null ? '<span class="l ' + cls(lines[n]) + '">' + esc(partial) + '<i class="cur"></i></span>' : '');
  }
  if (reduce) { paint(lines.length); return; }
  (async function loop() {
    for (;;) {
      for (let i = 0; i < lines.length; i++) {
        const t = lines[i];
        if (t.startsWith('$')) { for (let c = 1; c <= t.length; c++) { paint(i, t.slice(0, c)); await new Promise((r) => setTimeout(r, 26)); } }
        else { paint(i, ''); await new Promise((r) => setTimeout(r, 420)); }
        paint(i + 1); await new Promise((r) => setTimeout(r, t.startsWith('$') ? 380 : 650));
      }
      await new Promise((r) => setTimeout(r, 3500));
    }
  })();
})();

/* AURORA — custom dropdown: replaces native <select class="form-control"> popups */
(function () {
  'use strict';
  const CHEV = '<svg class="ad-chev" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 7.5l5 5 5-5"/></svg>';
  const CK = '<svg class="ck" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10.5l4 4 8-9"/></svg>';
  let openDd = null;

  function close(dd) { if (!dd) return; dd.classList.remove('open'); dd.menu.classList.remove('show'); dd.btn.setAttribute('aria-expanded', 'false'); if (openDd === dd) openDd = null; }

  function build(sel) {
    if (sel.dataset.ad || sel.multiple || sel.size > 1) return;
    sel.dataset.ad = '1';
    const dd = document.createElement('div');
    dd.className = 'ad';
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'ad-btn';
    btn.setAttribute('aria-haspopup', 'listbox'); btn.setAttribute('aria-expanded', 'false');
    const label = document.createElement('span'); label.className = 'ad-label';
    btn.appendChild(label); btn.insertAdjacentHTML('beforeend', CHEV);
    const menu = document.createElement('div'); menu.className = 'ad-menu'; menu.setAttribute('role', 'listbox');
    dd.btn = btn; dd.menu = menu;
    sel.parentNode.insertBefore(dd, sel);
    dd.append(btn, sel); document.body.appendChild(menu);
    sel.classList.add('ad-native'); sel.tabIndex = -1;

    function render() {
      menu.innerHTML = '';
      Array.from(sel.options).forEach((o, i) => {
        const d = document.createElement('div');
        d.className = 'ad-opt' + (o.disabled ? ' dis' : '') + (i === sel.selectedIndex ? ' sel' : '');
        d.style.setProperty('--i', i); d.dataset.i = i; d.setAttribute('role', 'option');
        d.innerHTML = '<span></span>' + CK; d.firstChild.textContent = o.textContent;
        menu.appendChild(d);
      });
      sync();
    }
    function sync() {
      const o = sel.options[sel.selectedIndex];
      label.textContent = o ? o.textContent : '';
      label.classList.toggle('ph', !!o && o.value === '');
      Array.from(menu.children).forEach((c, i) => c.classList.toggle('sel', i === sel.selectedIndex));
    }
    function pick(i) {
      if (sel.options[i].disabled) return;
      sel.selectedIndex = i; sync();
      sel.dispatchEvent(new Event('input', { bubbles: true }));
      sel.dispatchEvent(new Event('change', { bubbles: true }));
      close(dd); btn.focus();
    }
    function place() {
      const r = btn.getBoundingClientRect();
      const below = innerHeight - r.bottom - 16, above = r.top - 16;
      const up = below < 220 && above > below;
      const room = Math.max(120, up ? above : below);
      menu.style.left = r.left + 'px'; menu.style.width = r.width + 'px';
      menu.style.maxHeight = Math.min(280, room - 8) + 'px';
      menu.classList.toggle('up', up);
      if (up) { menu.style.top = 'auto'; menu.style.bottom = (innerHeight - r.top + 8) + 'px'; }
      else { menu.style.bottom = 'auto'; menu.style.top = (r.bottom + 8) + 'px'; }
    }
    dd.place = place;
    function open() {
      if (openDd && openDd !== dd) close(openDd);
      place();
      dd.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); openDd = dd;
      requestAnimationFrame(() => menu.classList.add('show'));
      const s = menu.querySelector('.sel'); setAct(s || menu.firstChild);
      if (s) s.scrollIntoView({ block: 'nearest' });
    }
    function setAct(el) {
      menu.querySelectorAll('.act').forEach((x) => x.classList.remove('act'));
      if (el) { el.classList.add('act'); el.scrollIntoView({ block: 'nearest' }); }
    }
    function move(dir) {
      const items = Array.from(menu.children).filter((x) => !x.classList.contains('dis'));
      const cur = items.indexOf(menu.querySelector('.act'));
      setAct(items[Math.max(0, Math.min(items.length - 1, cur + dir))]);
    }

    btn.addEventListener('click', () => (dd.classList.contains('open') ? close(dd) : open()));
    menu.addEventListener('click', (e) => { const o = e.target.closest('.ad-opt'); if (o) pick(+o.dataset.i); });
    menu.addEventListener('mousemove', (e) => { const o = e.target.closest('.ad-opt'); if (o && !o.classList.contains('act')) setAct(o); });
    btn.addEventListener('keydown', (e) => {
      const isOpen = dd.classList.contains('open');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); isOpen ? move(e.key === 'ArrowDown' ? 1 : -1) : open(); }
      else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (isOpen) { const a = menu.querySelector('.act'); a ? pick(+a.dataset.i) : close(dd); } else open(); }
      else if (e.key === 'Escape' || e.key === 'Tab') close(dd);
    });
    sel.addEventListener('change', sync);
    new MutationObserver(render).observe(sel, { childList: true, subtree: true, characterData: true });
    const f = sel.form; if (f) f.addEventListener('reset', () => setTimeout(sync, 0));
    render();
  }

  function init() { document.querySelectorAll('select.form-control').forEach(build); }
  document.addEventListener('click', (e) => { if (openDd && !openDd.contains(e.target) && !openDd.menu.contains(e.target)) close(openDd); });
  addEventListener('resize', () => close(openDd));
  addEventListener('scroll', (e) => { if (openDd && !openDd.menu.contains(e.target)) openDd.place(); }, true);
  new MutationObserver(init).observe(document.documentElement, { childList: true, subtree: true });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

/* AURORA — theme controller (dark "black" / light), persisted in localStorage.
   Lag-free: no per-element transitions. Uses the View Transitions API (one GPU
   snapshot cross-fade with a circular reveal); browsers without it switch instantly. */
(function () {
  'use strict';
  const root = document.documentElement;
  const get = () => (root.getAttribute('data-theme') === 'light' ? 'light' : 'dark');
  const reduce = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let busy = false;

  function paint(t) {
    root.setAttribute('data-theme', t);
    try { localStorage.setItem('theme', t); } catch (e) {}
    document.querySelectorAll('.theme-switch').forEach((b) => {
      b.setAttribute('aria-pressed', t === 'light' ? 'true' : 'false');
      b.title = t === 'light' ? 'Switch to black theme' : 'Switch to light theme';
    });
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'light' ? '#F3F4F7' : '#0A0A0A');
  }

  function apply(t, animate, origin) {
    if (t === get()) return;
    if (!animate || reduce() || busy) { paint(t); return; }
    root.classList.add('theme-switching');          // kills every transition => zero style-recalc cost
    if (typeof document.startViewTransition !== 'function') {
      paint(t);
      requestAnimationFrame(() => requestAnimationFrame(() => root.classList.remove('theme-switching')));
      return;
    }
    busy = true;
    const x = origin ? origin.x : innerWidth - 60, y = origin ? origin.y : 40;
    const r = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    let vt;
    try { vt = document.startViewTransition(() => paint(t)); }
    catch (e) { paint(t); root.classList.remove('theme-switching'); busy = false; return; }
    const done = () => { root.classList.remove('theme-switching'); busy = false; };
    vt.ready.then(() => {
      root.animate(
        { clipPath: ['circle(0px at ' + x + 'px ' + y + 'px)', 'circle(' + r + 'px at ' + x + 'px ' + y + 'px)'] },
        { duration: 520, easing: 'cubic-bezier(.4,0,.2,1)', pseudoElement: '::view-transition-new(root)' }
      );
    }).catch(done);
    vt.finished.then(done, done);
  }

  function originOf(e) {
    const b = e && e.currentTarget && e.currentTarget.getBoundingClientRect ? e.currentTarget.getBoundingClientRect() : null;
    return b ? { x: b.left + b.width / 2, y: b.top + b.height / 2 } : null;
  }
  window.jazzToggleTheme = (e) => apply(get() === 'light' ? 'dark' : 'light', true, originOf(e));
  window.toggleTheme = window.jazzToggleTheme;
  window.jazzSetTheme = (t) => apply(t === 'light' ? 'light' : 'dark', true, null);

  function init() {
    let t = 'dark';
    try { const v = localStorage.getItem('theme'); if (v === 'light' || v === 'dark') t = v; } catch (e) {}
    paint(t);
    document.querySelectorAll('.theme-switch').forEach((b) => {
      if (b.__tsBound) return; b.__tsBound = true;
      b.addEventListener('click', window.jazzToggleTheme);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
