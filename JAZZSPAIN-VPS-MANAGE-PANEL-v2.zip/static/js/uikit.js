/* UIKIT — in-page dialogs (replace native confirm/alert/prompt) + reusable installer overlay.
   Everything is async and non-blocking: await uiConfirm('Sure?') -> true/false. */
(function () {
  'use strict';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const DANGER = /delet|erase|remov|destroy|cannot be undone|can't be undone|wipe|overwrite|stop all|suspend|clear|reset|unlink|regenerate|invalid|lost/i;

  /* ======================= dialogs ======================= */
  const queue = [];
  let busy = false;

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function show(kind, message, opts) {
    return new Promise((resolve) => {
      queue.push({ kind, message: String(message == null ? '' : message), opts: opts || {}, resolve });
      next();
    });
  }

  function next() {
    if (busy || !queue.length) return;
    busy = true;
    const job = queue.shift();
    const { kind, message, opts } = job;
    const danger = opts.danger != null ? opts.danger : (kind === 'confirm' && DANGER.test(message));

    const ov = el('div', 'ui-dlg-overlay');
    const dlg = el('div', 'ui-dlg' + (danger ? ' danger' : ''));
    dlg.setAttribute('role', kind === 'alert' ? 'alertdialog' : 'dialog');
    dlg.setAttribute('aria-modal', 'true');

    const icon = el('div', 'ui-dlg-ic');
    const i = el('i');
    i.className = 'fas fa-' + (opts.icon || (kind === 'prompt' ? 'pen' : danger ? 'triangle-exclamation' : kind === 'alert' ? 'circle-info' : 'circle-question'));
    icon.appendChild(i);

    const title = el('h3', 'ui-dlg-title', opts.title || (kind === 'alert' ? 'Notice' : kind === 'prompt' ? 'Enter a value' : danger ? 'Are you sure?' : 'Please confirm'));
    const msg = el('p', 'ui-dlg-msg', message);

    dlg.append(icon, title, msg);

    let input = null;
    if (kind === 'prompt') {
      input = el('input', 'ui-dlg-input');
      input.type = 'text';
      input.value = opts.value != null ? opts.value : '';
      input.autocomplete = 'off';
      input.spellcheck = false;
      dlg.appendChild(input);
    }

    const actions = el('div', 'ui-dlg-actions');
    const yes = el('button', 'ui-btn ' + (danger ? 'ui-btn-danger' : 'ui-btn-primary'), opts.yes || (kind === 'alert' ? 'OK' : 'Yes'));
    yes.type = 'button';
    let no = null;
    if (kind !== 'alert') {
      no = el('button', 'ui-btn ui-btn-ghost', opts.no || 'No');
      no.type = 'button';
      actions.appendChild(no);
    }
    actions.appendChild(yes);
    dlg.appendChild(actions);
    ov.appendChild(dlg);

    const prevFocus = document.activeElement;
    let closed = false;
    function finish(val) {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKey, true);
      ov.classList.remove('show');
      const done = () => {
        ov.remove();
        document.documentElement.classList.remove('ui-dlg-open');
        try { prevFocus && prevFocus.focus && prevFocus.focus({ preventScroll: true }); } catch (e) {}
        busy = false;
        job.resolve(val);
        next();
      };
      reduce ? done() : setTimeout(done, 180);
    }
    const accept = () => finish(kind === 'prompt' ? input.value : kind === 'alert' ? undefined : true);
    const cancel = () => finish(kind === 'prompt' ? null : kind === 'alert' ? undefined : false);

    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); cancel(); }
      else if (e.key === 'Enter' && !(e.target && e.target.tagName === 'BUTTON' && e.target !== yes)) { e.preventDefault(); e.stopPropagation(); accept(); }
      else if (e.key === 'Tab') {
        const f = Array.from(dlg.querySelectorAll('button,input')).filter((n) => !n.disabled);
        if (!f.length) return;
        const idx = f.indexOf(document.activeElement);
        e.preventDefault();
        f[(idx + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus();
      }
    }
    yes.onclick = accept;
    if (no) no.onclick = cancel;
    ov.addEventListener('mousedown', (e) => { if (e.target === ov && kind !== 'alert') cancel(); });
    document.addEventListener('keydown', onKey, true);

    document.documentElement.classList.add('ui-dlg-open');
    document.body.appendChild(ov);
    requestAnimationFrame(() => {
      ov.classList.add('show');
      (input || (danger && no ? no : yes)).focus({ preventScroll: true });
      if (input) input.select();
    });
  }

  window.uiConfirm = (m, o) => show('confirm', m, o);
  window.uiAlert = (m, o) => show('alert', m, o);
  window.uiPrompt = (m, def, o) => show('prompt', m, Object.assign({ value: def }, o || {}));

  /* forms / links: <button data-confirm="Delete it?"> or onclick="return confirm()" replacement */
  document.addEventListener('click', async (e) => {
    const t = e.target.closest('[data-confirm]');
    if (!t || t.__uiOk) return;
    e.preventDefault(); e.stopImmediatePropagation();
    const ok = await uiConfirm(t.getAttribute('data-confirm'), { title: t.getAttribute('data-confirm-title') || undefined });
    if (!ok) return;
    t.__uiOk = true;
    try { t.click(); } finally { setTimeout(() => { t.__uiOk = false; }, 0); }
  }, true);

  /* ======================= installer overlay ======================= */
  const CIRC = 326.7;
  const Installer = {
    st: { raf: null, timer: null, shown: 0, server: 0, next: 2, status: 'running', onDone: null, onError: null, opts: null, doneT: null },

    open(opts) {
      this.close(true);
      const o = this.st.opts = Object.assign({
        title: 'Installing operating system', doneTitle: 'Installation complete', errorTitle: 'Installation failed',
        icon: 'compact-disc', start: 'Preparing installation…', foot: 'Please keep this page open. Do not close your browser.',
        doneFoot: 'Your VPS is ready. Reloading…', stages: []
      }, opts || {});
      let ov = document.getElementById('installOverlay');
      if (ov) ov.remove();
      ov = el('div', 'inst-overlay');
      ov.id = 'installOverlay';
      ov.innerHTML =
        '<div class="inst-card">' +
        '<div class="inst-head"><i class="fas fa-' + o.icon + '"></i><span id="instTitle"></span></div>' +
        '<div class="inst-ring"><svg viewBox="0 0 120 120"><circle class="bg" cx="60" cy="60" r="52"/><circle class="fg" id="instArc" cx="60" cy="60" r="52"/></svg>' +
        '<div class="inst-pct"><span id="instPct">0</span><small>%</small></div></div>' +
        '<div class="inst-stage" id="instStage"></div>' +
        '<div class="inst-bar"><i id="instBar"></i></div>' +
        '<ul class="inst-list" id="instList"></ul>' +
        '<div class="inst-foot" id="instFoot"></div>' +
        '<button class="btn btn-primary inst-close" id="instClose" style="display:none" type="button">Close</button>' +
        '</div>';
      document.body.appendChild(ov);
      document.documentElement.classList.add('ui-dlg-open');
      ov.querySelector('#instTitle').textContent = o.title;
      ov.querySelector('#instStage').textContent = o.start;
      ov.querySelector('#instFoot').textContent = o.foot;
      this.setStages(o.stages);
      const s = this.st;
      s.shown = 0; s.server = 0; s.next = 2; s.status = 'running';
      this.paint(0);
      requestAnimationFrame(() => ov.classList.add('show'));
      this.loop();
      return ov;
    },

    setStages(stages) {
      const list = document.getElementById('instList');
      if (!list) return;
      list.textContent = '';
      (stages || []).forEach((s) => {
        const li = el('li');
        li.dataset.k = s.key;
        const dot = el('span', 'dot');
        const ic = el('i'); ic.className = 'fas fa-check';
        dot.appendChild(ic);
        li.append(dot, document.createTextNode(s.label));
        list.appendChild(li);
      });
    },

    paint(p) {
      const v = Math.max(0, Math.min(100, p));
      const a = document.getElementById('instPct'), b = document.getElementById('instBar'), c = document.getElementById('instArc');
      if (a) a.textContent = Math.floor(v);
      if (b) b.style.transform = 'scaleX(' + (v / 100) + ')';
      if (c) c.style.strokeDashoffset = CIRC * (1 - v / 100);
    },

    loop() {
      const s = this.st;
      cancelAnimationFrame(s.raf);
      const tick = () => {
        if (s.status === 'running') {
          const cap = s.next - 1;
          if (s.shown < s.server) s.shown += Math.max(0.25, (s.server - s.shown) * 0.12);
          else if (s.shown < cap) s.shown += (cap - s.shown) * 0.004 + 0.003;
        } else if (s.status === 'done') {
          s.shown = Math.min(100, s.shown + Math.max(0.4, (100 - s.shown) * 0.15));
        }
        this.paint(s.shown);
        if (s.status === 'error' || (s.status === 'done' && s.shown >= 100)) return;
        s.raf = requestAnimationFrame(tick);
      };
      s.raf = requestAnimationFrame(tick);
    },

    apply(job) {
      const s = this.st;
      s.server = job.percent || 0;
      s.next = job.next || 100;
      s.status = job.status;
      const stage = document.getElementById('instStage');
      if (stage && job.label) stage.textContent = job.label + (job.status === 'running' ? '…' : '');
      if (job.status === 'running') {   // tell the admin when one step is taking unusually long
        if (s.stg !== job.stage) { s.stg = job.stage; s.stgT = Date.now(); }
        const foot = document.getElementById('instFoot'), mins = Math.floor((Date.now() - s.stgT) / 60000);
        if (foot && mins >= 2) foot.textContent = 'This step is taking longer than usual (' + mins + ' min). Check "jazz-panel logs" on the server.';
      }
      document.querySelectorAll('#instList li').forEach((li, i) => {
        li.classList.toggle('ok', job.status === 'done' || i < job.index);
        li.classList.toggle('cur', job.status === 'running' && i === job.index);
      });
      const ov = document.getElementById('installOverlay');
      if (!ov) return;
      const o = s.opts || {};
      if (job.status === 'done') {
        ov.classList.add('done');
        document.getElementById('instTitle').textContent = o.doneTitle;
        document.getElementById('instFoot').textContent = o.doneFoot;
        this.stopPoll();
        s.doneT = setTimeout(() => { s.onDone ? s.onDone(job) : location.reload(); }, 1800);
      } else if (job.status === 'error') {
        this.fail(job.error);
      }
    },

    fail(message) {
      const s = this.st, ov = document.getElementById('installOverlay');
      this.stopPoll();
      s.status = 'error';
      if (!ov) return;
      ov.classList.add('err');
      document.getElementById('instTitle').textContent = (s.opts && s.opts.errorTitle) || 'Failed';
      document.getElementById('instStage').textContent = message || 'Unknown error';
      document.getElementById('instFoot').textContent = '';
      const c = document.getElementById('instClose');
      c.style.display = 'inline-flex';
      c.onclick = () => { this.close(); if (s.onError) s.onError(message); };
    },

    poll(url, cb) {
      const s = this.st;
      this.stopPoll();
      s.onDone = cb && cb.onDone; s.onError = cb && cb.onError;
      const every = (cb && cb.interval) || 1200;
      let bad = 0;
      const lost = () => {
        // the panel was restarted / logged us out / is unreachable: don't sit on a frozen bar forever
        if (++bad >= 6) this.fail('Lost contact with the panel (it may have been restarted, which cancels the job). Check the VPS list, then try again.');
      };
      const once = async () => {
        try {
          const r = await fetch(url, { credentials: 'same-origin', cache: 'no-store' });
          const ct = r.headers.get('content-type') || '';
          if (!ct.includes('json') || r.status === 401 || r.status === 403 || r.status >= 500) { lost(); return; }
          const job = await r.json();
          if (!job.success) { if (r.status === 404) this.fail(job.error || 'Job not found (the panel was probably restarted). Check the VPS list, then try again.'); return; }
          bad = 0;
          if (job.status === 'idle') return;
          if (cb && cb.stages && job.stages && !document.querySelector('#instList li')) this.setStages(job.stages);
          this.apply(job);
        } catch (e) { lost(); }
      };
      // pause polling while the tab is hidden (no wasted requests / timers)
      s.timer = setInterval(() => { if (!document.hidden) once(); }, every);
      once();
    },

    stopPoll() { clearInterval(this.st.timer); this.st.timer = null; },

    close(silent) {
      const s = this.st;
      cancelAnimationFrame(s.raf); this.stopPoll(); clearTimeout(s.doneT);
      const ov = document.getElementById('installOverlay');
      document.documentElement.classList.remove('ui-dlg-open');
      if (!ov) return;
      if (silent) { ov.remove(); return; }
      ov.classList.remove('show');
      setTimeout(() => ov.remove(), 320);
    }
  };
  window.UIInstaller = Installer;
})();
