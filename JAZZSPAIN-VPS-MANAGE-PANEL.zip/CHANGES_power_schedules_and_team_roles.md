# Power Schedules + Team Roles

## 1. Scheduled power actions (admin panel -> Power Schedules)
- Default rule (created once on first start): **Restart every VPS daily at 04:00, all 7 days**.
  There is no weekend-stop rule.
- Admin page `/admin/schedules`: add / edit / enable-disable / delete / "Run now",
  pick action (restart/stop/start), time, days, target (all VPS or one VPS) and VPS to exclude.
- Uses the server clock. Runs within 10 min after the exact time if the panel was down.
- Only running VPS are restarted/stopped, only stopped ones started.
  Suspended VPS and shared-hosting servers are skipped.
- Optional notification to each VPS owner (toggle on the page). History shown on the page.
- Users see the schedules that affect their VPS under Settings -> Scheduled maintenance.

## 2. Team access roles (VPS page -> Team tab, owner/admin only)
- Viewer: see VPS page, status and resource usage only.
- Operator: viewer + start/stop/restart, console, SSH/SSHX, files.
- Owner/admin only: reinstall, rename, notes, team management.
- Users shared before this update keep working as Operator.

## 3. Bug fix
- `update_vps()` bound its SQL parameters in the wrong order, so it never saved anything.
  Fixed (timestamp first, id last).

Files changed: hvm.py, templates/vps_detail.html, templates/base.html, templates/admin-base.html
New file: templates/admin/power_schedules.html
Database: new table `power_schedules` is created automatically on startup.

## 4. Profile page 500 error (regular users and non-main admins)
- Cause: profile.html did `current_user.api_key[:10]`, but only the main admin has an API key
  (everyone else has none), so the page crashed for them.
- Fix: templates/profile.html now shows "No API key yet" + a Generate button when there is no key,
  and also handles empty activity details.

## 5. Team-shared VPS not showing for the invited user
- Cause: adding someone in the VPS Team tab saved them in `vps.shared_with` and sent the
  "VPS Shared" notification, but `get_vps_for_user()` only listed owned VPS and shared-hosting
  accounts, so My VPS / Dashboard / Ctrl+K never showed it.
- Fix: `get_vps_for_user(user_id, include_team=True)` now also returns VPS the user was added to.
  Used by Dashboard, My VPS and the command palette only. Quota check and user deletion keep the
  old behaviour (a shared VPS never counts toward, or gets deleted with, the member's account).
- Each returned VPS has `is_team_member` and `team_role` for templates.
