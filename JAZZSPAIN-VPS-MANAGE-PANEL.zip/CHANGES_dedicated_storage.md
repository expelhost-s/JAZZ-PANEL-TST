# Dedicated storage per VPS (same system as the Discord bot)

## Dedicated VPS (LXC container and KVM VM)
- Every VPS now gets its OWN loop-backed LXD storage pool `<container>-disk` of exactly the assigned size.
  `df -h /` inside the VPS shows the full assigned disk; space is carved out per VPS, not shared.
- Drivers tried in order: btrfs, zfs, lvm (`DEDICATED_POOL_DRIVERS`). If none works on the node the VPS falls
  back to the old shared pool + quota method and the reason is written to the panel log.
- Lifecycle: created with the VPS -> resized from Admin > Edit VPS -> recreated on Reinstall -> deleted with the
  VPS (admin delete, user delete, bulk delete worker, node force-delete) and on failed creation (no leftovers).
- VPS created before this update keep working in the shared pool; they move to their own disk when reinstalled.
- `DEDICATED_DISK=0` in `.env` switches back to the old behaviour for new VPS.
- Host needs `btrfs-progs` (installer adds it) or zfs/lvm tools for the other drivers.
- Disk can only grow (LXD refuses to shrink a loop pool below its used space).

## Shared VPS
- Already had a dedicated disk: one ext4 volume per account (`/opt/hvm-shared/disks/<user>.img`, loop-mounted
  on the home folder, grows on resize, removed on delete). Needs a host that allows loop mounts
  (`jazz-panel fix-storage`); otherwise it falls back to quota monitoring. No change needed.

Files changed: hvm.py. Installer: btrfs-progs + DEDICATED_DISK settings in .env.
