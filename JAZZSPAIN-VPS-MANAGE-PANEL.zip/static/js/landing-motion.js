/* ==========================================================================
   Landing page motion engine  (Admin -> Landing Page -> Motion)
   Powered by Motion (the vanilla build of Framer Motion, loaded in base.html):
   springs, staggered orchestration, whileInView, whileHover and scroll-linked
   motion. If the library can't load, every effect falls back to the Web
   Animations API, so the page is never left hidden or broken.
   Config comes from window.HVM_LANDING (see build in hvm.py: get_landing_view).
   ========================================================================== */
(function () {
  'use strict';
  var C = window.HVM_LANDING || {};
  var root = document.querySelector('.lp-root');
  if (!root) return;
  window.__lpStarted = true;

  var M = window.Motion || window.FramerMotion || null;
  var hasMotion = !!(M && typeof M.animate === 'function');
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $$ = function (s, r) { return Array.prototype.slice.call((r || root).querySelectorAll(s)); };
  var done = function (el) { el.classList.add('lp-in'); };

  /* ---------- transition spec from the editor ---------- */
  function spec(extra) {
    var o = C.m_type === 'tween'
      ? { duration: (C.m_duration || 700) / 1000, ease: [0.16, 1, 0.3, 1] }
      : { type: 'spring', stiffness: C.m_stiffness || 220, damping: C.m_damping || 24 };
    for (var k in (extra || {})) o[k] = extra[k];
    return o;
  }

  /* ---------- keyframes per preset ---------- */
  function frames(preset, i) {
    var d = C.m_distance == null ? 28 : C.m_distance;
    switch (preset) {
      case 'fade':  return { opacity: [0, 1] };
      case 'rise':  return { opacity: [0, 1], y: [d, 0] };
      case 'pop':   return { opacity: [0, 1], scale: [0.86, 1], y: [d * 0.5, 0] };
      case 'zoom':  return { opacity: [0, 1], scale: [0.9, 1] };
      case 'blur':  return { opacity: [0, 1], filter: ['blur(14px)', 'blur(0px)'], y: [d * 0.5, 0] };
      case 'slide': return { opacity: [0, 1], x: [(i % 2 ? 1 : -1) * Math.max(d, 24) * 1.6, 0] };
      case 'flip':  return { opacity: [0, 1], rotateX: [48, 0], y: [d * 0.6, 0], transformPerspective: 900 };
      default:      return { opacity: [0, 1] };
    }
  }

  /* ---------- run: Motion first, WAAPI fallback ---------- */
  function run(el, kf, opts, onEnd) {
    function fin() { el.style.willChange = ''; onEnd && onEnd(); }
    if (hasMotion) {
      try {
        var ctl = M.animate(el, kf, opts);
        if (ctl && ctl.finished) ctl.finished.then(fin, fin); else if (ctl && ctl.then) ctl.then(fin, fin); else fin();
        return;
      } catch (e) { /* fall through */ }
    }
    var from = {}, to = {}, tf0 = [], tf1 = [];
    Object.keys(kf).forEach(function (k) {
      var v = kf[k]; if (!Array.isArray(v)) return;
      if (k === 'opacity' || k === 'filter') { from[k] = v[0]; to[k] = v[1]; }
      else if (k === 'y') { tf0.push('translateY(' + v[0] + 'px)'); tf1.push('translateY(' + v[1] + 'px)'); }
      else if (k === 'x') { tf0.push('translateX(' + v[0] + 'px)'); tf1.push('translateX(' + v[1] + 'px)'); }
      else if (k === 'scale') { tf0.push('scale(' + v[0] + ')'); tf1.push('scale(' + v[1] + ')'); }
      else if (k === 'rotateX') { tf0.unshift('perspective(900px)'); tf1.unshift('perspective(900px)'); tf0.push('rotateX(' + v[0] + 'deg)'); tf1.push('rotateX(' + v[1] + 'deg)'); }
    });
    if (tf0.length) { from.transform = tf0.join(' '); to.transform = tf1.join(' '); }
    var a = el.animate([from, to], { duration: C.m_type === 'tween' ? (C.m_duration || 700) : 800, delay: (opts.delay || 0) * 1000,
      easing: C.m_type === 'tween' ? 'cubic-bezier(.16,1,.3,1)' : 'cubic-bezier(.34,1.3,.5,1)', fill: 'backwards' });
    a.onfinish = fin; a.oncancel = fin;
  }

  /* ---------- 1. entrance choreography (whileInView + stagger) ---------- */
  var preset = C.m_preset || 'auto';
  function wordsSplit(h1) {
    var out = [];
    function wrap(textNode, cls) {
      var frag = document.createDocumentFragment();
      textNode.nodeValue.split(/(\s+)/).forEach(function (part) {
        if (!part) return;
        if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(' ')); return; }
        var w = document.createElement('span'); w.className = 'lp-w';
        var i = document.createElement('span'); i.className = 'lp-wi' + (cls ? ' ' + cls : ''); i.textContent = part;
        w.appendChild(i); frag.appendChild(w); out.push(i);
      });
      textNode.parentNode.replaceChild(frag, textNode);
    }
    (function walk(node, cls) {
      Array.prototype.slice.call(node.childNodes).forEach(function (n) {
        if (n.nodeType === 3) { if (n.nodeValue.trim()) wrap(n, cls); }
        else if (n.nodeType === 1 && n.tagName !== 'BR') {
          if (n.classList.contains('text-gradient-brand')) { var c2 = 'text-gradient-brand'; n.classList.remove('text-gradient-brand'); n.style.display = 'inline'; walk(n, c2); }
          else walk(n, cls);
        }
      });
    })(h1, '');
    return out;
  }

  var wordTargets = null, h1 = root.querySelector('h1[data-lp-words]');
  if (h1 && C.m_hero_text === 'words' && !reduce) wordTargets = wordsSplit(h1);

  function animateWords(delay) {
    if (!wordTargets || !wordTargets.length) return;
    h1.classList.add('lp-in');
    wordTargets.forEach(function (w, i) {
      w.style.transform = 'translateY(115%)';
      run(w, { y: ['115%', '0%'] }, spec({ delay: delay + i * 0.07 }), function () { w.style.transform = ''; });
    });
  }

  if (preset === 'auto') {
    if (wordTargets) animateWords(0.05);
    else if (h1) done(h1);
  } else if (reduce || preset === 'none') {
    $$('[data-lp-t],[data-lp-words]').forEach(done);
  } else {
    var stag = (C.m_stagger || 0) / 1000;
    var once = C.m_once !== false;
    // hero group runs on load (children are already "visible"); other groups when scrolled into view
    var groups = $$('[data-lp-g]');
    function play(els, base) {
      els.forEach(function (el, i) {
        if (el === h1 && wordTargets) { animateWords(base + i * stag); return; }
        el.style.willChange = 'transform,opacity';
        run(el, frames(preset, i), spec({ delay: base + i * stag }), function () { el.style.transform = ''; el.style.filter = ''; });
        done(el);
      });
    }
    function reset(els) { els.forEach(function (el) { el.classList.remove('lp-in'); }); }
    function watch(container, els) {
      var shown = false;
      var io = new IntersectionObserver(function (ents) {
        ents.forEach(function (en) {
          if (en.isIntersecting && !shown) { shown = true; play(els, 0); if (once) io.disconnect(); }
          else if (!en.isIntersecting && shown && !once) { shown = false; reset(els); }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
      io.observe(container);
    }
    var claimed = [];
    groups.forEach(function (g) {
      var els = $$('[data-lp-t]', g).filter(function (el) { return el.closest('[data-lp-g]') === g; });
      claimed = claimed.concat(els);
      if (g.classList.contains('hero-inner')) play(els, 0.08); else watch(g, els);
    });
    $$('[data-lp-t]').forEach(function (el) {
      if (claimed.indexOf(el) === -1) watch(el, [el]);   // section heads, CTA panel
    });
  }

  if (reduce) return;   // the rest is purely decorative motion

  /* ---------- 2. whileHover on cards ---------- */
  var hov = C.m_hover || 'auto';
  if (hov !== 'auto' && hov !== 'none') {
    $$('[data-lp-card]').forEach(function (card) {
      var sp = { type: 'spring', stiffness: 320, damping: 22 };
      function to(kf) { if (hasMotion) M.animate(card, kf, sp); else card.style.transform = 'translateY(' + (kf.y || 0) + 'px) scale(' + (kf.scale || 1) + ')'; }
      card.addEventListener('pointerenter', function () {
        if (hov === 'lift') to({ y: -8 }); else if (hov === 'scale') to({ scale: 1.035 });
        else if (hov === 'tilt') to({ scale: 1.02, transformPerspective: 900 });
      });
      card.addEventListener('pointermove', function (e) {
        var r = card.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
        if (hov === 'glow') { card.style.setProperty('--mx', (px * 100) + '%'); card.style.setProperty('--my', (py * 100) + '%'); }
        else if (hov === 'tilt' && hasMotion) M.animate(card, { rotateY: (px - .5) * 14, rotateX: (.5 - py) * 14, transformPerspective: 900 }, { type: 'spring', stiffness: 260, damping: 22 });
      });
      card.addEventListener('pointerleave', function () {
        if (hasMotion) M.animate(card, { y: 0, scale: 1, rotateX: 0, rotateY: 0 }, sp); else card.style.transform = '';
      });
    });
  }

  /* ---------- 3. scroll-linked: parallax + progress bar ---------- */
  var px = $$('[data-lp-px]'), bar = null;
  if (C.m_progress) { bar = document.createElement('div'); bar.className = 'lp-progress'; document.body.appendChild(bar); }
  if ((C.m_parallax && px.length) || bar) {
    var ticking = false;
    var onScroll = function () {
      if (ticking) return; ticking = true;
      requestAnimationFrame(function () {
        ticking = false;
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        if (C.m_parallax) px.forEach(function (el) {
          var k = parseFloat(el.getAttribute('data-lp-px')) || 0;
          // translate via CSS var-free `translate` property so it never fights entrance transforms
          el.style.translate = '0 ' + (y * k).toFixed(1) + 'px';
        });
        if (bar) {
          var h = (document.documentElement.scrollHeight - window.innerHeight) || 1;
          bar.style.transform = 'scaleX(' + Math.min(1, Math.max(0, y / h)).toFixed(4) + ')';
        }
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
  }

  /* ---------- 4. cursor spotlight ---------- */
  if (C.m_spotlight && matchMedia('(hover:hover)').matches) {
    var sp = document.createElement('div'); sp.className = 'lp-spot'; root.insertBefore(sp, root.firstChild);
    var tx = innerWidth / 2, ty = innerHeight / 3, cx = tx, cy = ty, raf = 0;
    var loop = function () {
      cx += (tx - cx) * 0.14; cy += (ty - cy) * 0.14;
      sp.style.transform = 'translate(' + cx.toFixed(1) + 'px,' + cy.toFixed(1) + 'px)';
      raf = (Math.abs(tx - cx) + Math.abs(ty - cy) > 0.5) ? requestAnimationFrame(loop) : 0;
    };
    window.addEventListener('pointermove', function (e) { tx = e.clientX; ty = e.clientY; sp.style.opacity = 1; if (!raf) raf = requestAnimationFrame(loop); }, { passive: true });
    document.addEventListener('pointerleave', function () { sp.style.opacity = 0; });
  }

  /* ---------- 5. magnetic buttons ---------- */
  if (C.m_magnetic && matchMedia('(hover:hover)').matches) {
    $$('[data-lp-mag]').forEach(function (b) {
      var spr = { type: 'spring', stiffness: 260, damping: 18, mass: 0.6 };
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        var dx = (e.clientX - (r.left + r.width / 2)) * 0.28, dy = (e.clientY - (r.top + r.height / 2)) * 0.36;
        if (hasMotion) M.animate(b, { x: dx, y: dy }, spr); else b.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      });
      b.addEventListener('pointerleave', function () { if (hasMotion) M.animate(b, { x: 0, y: 0 }, spr); else b.style.transform = ''; });
    });
  }

  /* ---------- 6. count-up stats ---------- */
  if (C.m_countup) {
    $$('[data-lp-count]').forEach(function (el) {
      var tn = null;
      for (var i = 0; i < el.childNodes.length; i++) { var n = el.childNodes[i]; if (n.nodeType === 3 && /\d/.test(n.nodeValue)) { tn = n; break; } }
      if (!tn) return;
      var m = tn.nodeValue.match(/^(\D*)([\d.]+)(.*)$/); if (!m) return;
      var end = parseFloat(m[2]), dec = (m[2].split('.')[1] || '').length;
      if (!isFinite(end)) return;
      var set = function (v) { tn.nodeValue = m[1] + v.toFixed(dec) + m[3]; };
      set(0);
      var started = false;
      var io = new IntersectionObserver(function (ents) {
        if (!ents[0].isIntersecting || started) return; started = true; io.disconnect();
        var t0 = performance.now(), dur = 1400;
        (function step(t) { var p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 4); set(end * e); if (p < 1) requestAnimationFrame(step); })(t0);
      }, { threshold: 0.4 });
      io.observe(el);
    });
  }
})();
