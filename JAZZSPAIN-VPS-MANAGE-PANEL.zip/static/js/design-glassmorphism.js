/* =====================================================================
   HVM GLASSMORPHISM MOTION
   Animation set used ONLY when <html data-design="glassmorphism">.
   Powered by Motion (the vanilla build of Framer Motion). Everything is
   routed through HVMDesign.run (Motion first, Web Animations fallback),
   so the panel keeps working if the CDN is blocked.

   What it does
     - entrance : sidebar floats in, header drops down, nav items cascade,
                  cards rise out of a blur, stat cards pop, table rows cascade
     - scroll   : cards below the fold reveal when they scroll into view
     - hover    : glass cards lift with a springy scale, buttons squish on press
     - modals   : backdrop fades, dialog springs up out of a blur
     - popovers : user menu / notifications / dropdowns scale from the top
     - auth     : sign in / register card glides in with staggered fields
     - ambient  : the two colour orbs behind the glass drift slowly
   Loaded BEFORE design.js. design.js calls into window.HVMGlass.
   ===================================================================== */
(function () {
  'use strict';
  var root = document.documentElement;
  var reduce = false;
  try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}

  var SPRING = {
    float: { type: 'spring', stiffness: 170, damping: 22, mass: 1 },     // big panels
    pop:   { type: 'spring', stiffness: 320, damping: 20, mass: 0.8 },   // small, bouncy
    soft:  { type: 'spring', stiffness: 210, damping: 26 },              // rows / nav
    hover: { type: 'spring', stiffness: 380, damping: 26, mass: 0.7 }
  };

  function M() { return window.Motion || window.FramerMotion || null; }
  function active() { return root.getAttribute('data-design') === 'glassmorphism' && !reduce; }
  function D() { return window.HVMDesign || {}; }

  function uniqueOuter(list) {
    var arr = Array.prototype.slice.call(list);
    return arr.filter(function (el) {
      return !arr.some(function (o) { return o !== el && o.contains(el); });
    });
  }
  function q(sel, max) { return uniqueOuter(document.querySelectorAll(sel)).slice(0, max || 48); }

  function go(els, spec, opts, stagger) {
    if (!els.length || !D().run) return;
    D().run(els, spec, opts, stagger);
  }

  function inViewport(el) {
    var r = el.getBoundingClientRect();
    return r.top < window.innerHeight * 0.96 && r.bottom > 0;
  }

  /* ---------------- page entrance ---------------- */
  var observers = [];
  function clearObservers() { observers.forEach(function (o) { try { o.disconnect(); } catch (e) {} }); observers = []; }

  function entrance() {
    if (!active()) return;
    clearObservers();

    var sidebar = q('.sidebar', 1);
    var header = q('.header', 1);
    var nav = q('.sidebar .nav-item');
    var blocks = q('.main-content .page-header, .main-content .stat-card, .main-content .card, ' +
                   '.main-content .table-responsive, .main-content .alert, .main-content .empty-state, ' +
                   '.main-content .tabs');
    var now = [], later = [];
    blocks.forEach(function (el) { (inViewport(el) ? now : later).push(el); });

    // sidebar slides out of the left like a pane of glass, header drops from above
    go(sidebar, { opacity: [0, 1], x: [-46, 0], scale: [0.97, 1], blur: [16, 0] }, SPRING.float);
    go(header, { opacity: [0, 1], y: [-26, 0], scale: [0.98, 1], blur: [12, 0] }, Object.assign({ delay: 0.06 }, SPRING.float));
    go(nav, { opacity: [0, 1], x: [-14, 0] }, Object.assign({ delay: 0.18 }, SPRING.soft), 0.03);

    // stat cards pop, everything else floats up out of the blur
    var stats = now.filter(function (el) { return el.classList.contains('stat-card'); });
    var rest = now.filter(function (el) { return !el.classList.contains('stat-card'); });
    go(rest, { opacity: [0, 1], y: [34, 0], scale: [0.96, 1], blur: [14, 0] }, Object.assign({ delay: 0.12 }, SPRING.float), 0.07);
    go(stats, { opacity: [0, 1], y: [22, 0], scale: [0.88, 1], blur: [10, 0] }, Object.assign({ delay: 0.14 }, SPRING.pop), 0.06);

    // table rows cascade a beat later
    var rows = q('.main-content .table tbody tr', 24).filter(inViewport);
    go(rows, { opacity: [0, 1], x: [-12, 0] }, Object.assign({ delay: 0.35 }, SPRING.soft), 0.03);

    scrollReveal(later);
    ambient();
  }

  // below-the-fold blocks: hidden now, animate when they scroll into view
  function scrollReveal(els) {
    if (!els.length) return;
    if (!('IntersectionObserver' in window)) return;
    els.forEach(function (el) { el.style.opacity = '0'; });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        io.unobserve(en.target);
        var el = en.target;
        el.style.removeProperty('opacity');
        go([el], { opacity: [0, 1], y: [40, 0], scale: [0.95, 1], blur: [12, 0] }, SPRING.float);
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    els.forEach(function (el) { io.observe(el); });
    observers.push(io);
    // safety net: never leave something invisible if the observer misbehaves
    setTimeout(function () { els.forEach(function (el) { if (el.style.opacity === '0') el.style.removeProperty('opacity'); }); }, 6000);
  }

  /* ---------------- ambient drifting orbs ---------------- */
  var orbCtl = null;
  function ambient() {
    var m = M();
    if (orbCtl || !m || typeof m.animate !== 'function' || !active()) return;
    try {
      orbCtl = m.animate(0, 1, {
        duration: 22, ease: 'easeInOut', repeat: Infinity, repeatType: 'reverse',
        onUpdate: function (v) {
          var a = v * Math.PI * 2;
          root.style.setProperty('--gm-ox', (Math.sin(a) * 4.2).toFixed(2) + 'vmax');
          root.style.setProperty('--gm-oy', (Math.cos(a * 0.8) * 3.4).toFixed(2) + 'vmax');
          root.style.setProperty('--gm-os', (1 + Math.sin(a * 0.5) * 0.08).toFixed(3));
        }
      });
    } catch (e) { orbCtl = null; }
  }
  function stopAmbient() {
    if (orbCtl && orbCtl.stop) { try { orbCtl.stop(); } catch (e) {} }
    orbCtl = null;
    root.style.removeProperty('--gm-ox'); root.style.removeProperty('--gm-oy'); root.style.removeProperty('--gm-os');
  }

  /* ---------------- hover / press micro-interactions ---------------- */
  var HOVER_SEL = '.card, .stat-card, .feature-card, .pulse-card, .inst-card';
  var PRESS_SEL = '.btn, .nav-item, .tabs .tab';
  var lifted = (typeof WeakSet === 'function') ? new WeakSet() : null;

  function spring(el, kf, opts) {
    var m = M();
    if (m && typeof m.animate === 'function') {
      try { return m.animate(el, kf, opts); } catch (e) {}
    }
    return null;
  }
  function busy(el) { return el.classList.contains('hvm-motion-in'); }

  function bindInteractions() {
    if (window.__hvmGlassBound) return;
    window.__hvmGlassBound = true;

    document.addEventListener('pointerover', function (e) {
      if (!active() || e.pointerType === 'touch') return;
      var el = e.target.closest && e.target.closest(HOVER_SEL);
      if (!el || busy(el) || el.closest('.modal')) return;
      if (e.relatedTarget && el.contains(e.relatedTarget)) return;
      if (lifted) lifted.add(el);
      spring(el, { y: -5, scale: 1.012 }, SPRING.hover);
    }, true);

    document.addEventListener('pointerout', function (e) {
      if (!active()) return;
      var el = e.target.closest && e.target.closest(HOVER_SEL);
      if (!el || (e.relatedTarget && el.contains(e.relatedTarget))) return;
      if (lifted && !lifted.has(el)) return;
      if (lifted) lifted.delete(el);
      var c = spring(el, { y: 0, scale: 1 }, SPRING.hover);
      var clean = function () { if (!lifted || !lifted.has(el)) { el.style.removeProperty('transform'); el.style.removeProperty('translate'); el.style.removeProperty('scale'); } };
      if (c && c.finished) c.finished.then(clean, clean); else clean();
    }, true);

    document.addEventListener('pointerdown', function (e) {
      if (!active()) return;
      var el = e.target.closest && e.target.closest(PRESS_SEL);
      if (!el || el.disabled || busy(el)) return;
      var up = function () {
        document.removeEventListener('pointerup', up, true);
        document.removeEventListener('pointercancel', up, true);
        var c = spring(el, { scale: 1 }, SPRING.pop);
        var clean = function () { el.style.removeProperty('transform'); el.style.removeProperty('scale'); };
        if (c && c.finished) c.finished.then(clean, clean); else clean();
      };
      document.addEventListener('pointerup', up, true);
      document.addEventListener('pointercancel', up, true);
      spring(el, { scale: 0.94 }, { type: 'spring', stiffness: 520, damping: 24 });
    }, true);
  }

  /* ---------------- modals & popovers ---------------- */
  function pop(el, isModal) {
    if (!active()) return;
    if (isModal) {
      var box = el.querySelector('.modal-content');
      if (!box) return;
      go([el], { opacity: [0, 1] }, { duration: 0.28, ease: 'easeOut' });
      go([box], { opacity: [0, 1], y: [48, 0], scale: [0.9, 1], blur: [18, 0] }, SPRING.float);
      var inner = uniqueOuter(box.querySelectorAll('.modal-header, .modal-body > *, .modal-footer')).slice(0, 14);
      go(inner, { opacity: [0, 1], y: [10, 0] }, Object.assign({ delay: 0.12 }, SPRING.soft), 0.035);
    } else {
      go([el], { opacity: [0, 1], y: [-10, 0], scale: [0.93, 1], blur: [10, 0] }, SPRING.pop);
      var items = uniqueOuter(el.querySelectorAll('a, button, .notification-item, li')).slice(0, 10);
      go(items, { opacity: [0, 1], x: [10, 0] }, Object.assign({ delay: 0.06 }, SPRING.soft), 0.03);
    }
  }

  /* ---------------- sign in / register ---------------- */
  function auth(card, kids, dir) {
    if (!active()) return;
    go([card], { opacity: [0, 1], x: [dir * 70, 0], y: [20, 0], scale: [0.94, 1], blur: [18, 0] }, SPRING.float);
    go(kids, { opacity: [0, 1], y: [16, 0], blur: [6, 0] }, Object.assign({ delay: 0.14 }, SPRING.soft), 0.05);
  }

  function stop() {
    clearObservers();
    stopAmbient();
    document.querySelectorAll(HOVER_SEL + ',' + PRESS_SEL).forEach(function (el) {
      if (el.style.transform || el.style.scale) { el.style.removeProperty('transform'); el.style.removeProperty('scale'); }
    });
    document.querySelectorAll('.main-content *').forEach(function (el) {
      if (el.style.opacity === '0') el.style.removeProperty('opacity');
    });
  }

  function start() { entrance(); }

  bindInteractions();

  window.HVMGlass = {
    entrance: entrance, pop: pop, auth: auth, stop: stop, start: start,
    springs: SPRING
  };
})();
