/* ==========================================================================
   Main pages motion engine  (Admin -> Main Pages -> Motion)
   Every signed-in page: dashboard, My VPS, ports, profile, admin pages...
   Powered by Motion (the vanilla build of Framer Motion) with a Web Animations
   fallback. Config: window.HVM_MAIN (get_main_view in hvm.py).
     - page entrance: blocks animate in with springs + stagger, below-the-fold
       blocks when scrolled into view, blocks added later by scripts too
     - sidebar entrance, table rows, card hover, count-up stats
     - page-to-page transitions, scroll progress bar, cursor spotlight, magnetic buttons
   "auto" for a setting leaves the design's built-in behaviour untouched.
   ========================================================================== */
(function () {
  'use strict';
  var C = window.HVM_MAIN || {};
  var main = document.querySelector('.main-content');
  if (!main) { document.documentElement.classList.remove('mp-motion'); return; }
  window.__mpStarted = true;

  var M = window.Motion || window.FramerMotion || null;
  var hasMotion = !!(M && typeof M.animate === 'function');
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var preview = !!window.HVM_MAIN_PREVIEW;
  var BLOCKS = '.page-header,.stat-card,.card,.dash-stat,.dash-panel,.welcome-panel,.table-responsive,.alert,.empty-state';
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var root = document.documentElement;

  function spec(extra) {
    var o = C.m_type === 'tween'
      ? { duration: (C.m_duration || 700) / 1000, ease: [0.16, 1, 0.3, 1] }
      : { type: 'spring', stiffness: C.m_stiffness || 220, damping: C.m_damping || 24 };
    for (var k in (extra || {})) o[k] = extra[k];
    return o;
  }

  function frames(kind, i) {
    var d = C.m_distance == null ? 28 : C.m_distance;
    switch (kind) {
      case 'fade':  return { opacity: [0, 1] };
      case 'rise':  return { opacity: [0, 1], y: [d, 0] };
      case 'pop':   return { opacity: [0, 1], scale: [0.88, 1], y: [d * 0.4, 0] };
      case 'zoom':  return { opacity: [0, 1], scale: [0.94, 1] };
      case 'blur':  return { opacity: [0, 1], filter: ['blur(12px)', 'blur(0px)'], y: [d * 0.4, 0] };
      case 'slide': return { opacity: [0, 1], x: [(i % 2 ? 1 : -1) * Math.max(d, 24) * 1.4, 0] };
      case 'flip':  return { opacity: [0, 1], rotateX: [40, 0], y: [d * 0.5, 0], transformPerspective: 900 };
      default:      return { opacity: [0, 1] };
    }
  }

  function run(el, kf, opts, onEnd) {
    function fin() { el.style.willChange = ''; onEnd && onEnd(); }
    el.style.willChange = 'transform,opacity';
    if (hasMotion) {
      try {
        var ctl = M.animate(el, kf, opts);
        if (ctl && ctl.finished) ctl.finished.then(fin, fin); else if (ctl && ctl.then) ctl.then(fin, fin); else fin();
        return;
      } catch (e) { /* fall through */ }
    }
    var from = {}, to = {}, t0 = [], t1 = [];
    Object.keys(kf).forEach(function (k) {
      var v = kf[k]; if (!Array.isArray(v)) return;
      if (k === 'opacity' || k === 'filter') { from[k] = v[0]; to[k] = v[1]; }
      else if (k === 'y') { t0.push('translateY(' + v[0] + 'px)'); t1.push('translateY(' + v[1] + 'px)'); }
      else if (k === 'x') { t0.push('translateX(' + v[0] + 'px)'); t1.push('translateX(' + v[1] + 'px)'); }
      else if (k === 'scale') { t0.push('scale(' + v[0] + ')'); t1.push('scale(' + v[1] + ')'); }
      else if (k === 'rotateX') { t0.unshift('perspective(900px)'); t1.unshift('perspective(900px)'); t0.push('rotateX(' + v[0] + 'deg)'); t1.push('rotateX(' + v[1] + 'deg)'); }
    });
    if (t0.length) { from.transform = t0.join(' '); to.transform = t1.join(' '); }
    var a = el.animate([from, to], { duration: C.m_type === 'tween' ? (C.m_duration || 700) : 800, delay: (opts.delay || 0) * 1000,
      easing: C.m_type === 'tween' ? 'cubic-bezier(.16,1,.3,1)' : 'cubic-bezier(.34,1.3,.5,1)', fill: 'backwards' });
    a.onfinish = fin; a.oncancel = fin;
  }

  function clean(el) { el.style.transform = ''; el.style.filter = ''; }
  function outer(list) {
    return list.filter(function (el) { return !list.some(function (o) { return o !== el && o.contains(el); }); });
  }

  /* ---------- 1. page entrance ---------- */
  var preset = C.m_preset || 'auto';
  var stag = (C.m_stagger || 0) / 1000;
  var loaded = false;                                   // later-added blocks get a quick entrance, not the full sequence

  function reveal(els, base) {
    els.forEach(function (el, i) {
      el.classList.add('mp-in');
      if (reduce || preset === 'none') return;
      run(el, frames(preset, i), spec({ delay: base + Math.min(i, 14) * stag }), function () { clean(el); });
    });
  }

  if (preset !== 'auto') {
    var all = $$(BLOCKS, main);
    if (reduce || preset === 'none') { all.forEach(function (el) { el.classList.add('mp-in'); }); }
    else {
      var tops = outer(all), vh = window.innerHeight || 800, first = [], later = [];
      tops.forEach(function (el) { (el.getBoundingClientRect().top < vh * 0.96 ? first : later).push(el); });
      all.forEach(function (el) { if (tops.indexOf(el) === -1) el.classList.add('mp-in'); });   // nested blocks ride with their parent
      reveal(first, 0.04);
      later.forEach(function (el) {
        var io = new IntersectionObserver(function (ents) {
          if (ents[0].isIntersecting) { io.disconnect(); reveal([el], 0); }
        }, { threshold: 0.08, rootMargin: '0px 0px -6% 0px' });
        io.observe(el);
      });
      // blocks injected by page scripts (lists rendered client-side, modals' cards...) must never stay hidden
      if (window.MutationObserver) {
        new MutationObserver(function (muts) {
          if (!loaded) return;
          muts.forEach(function (m) {
            Array.prototype.forEach.call(m.addedNodes, function (n) {
              if (n.nodeType !== 1 || !main.contains(n)) return;
              var hit = n.matches && n.matches(BLOCKS) ? [n] : [];
              hit = hit.concat($$(BLOCKS, n));
              outer(hit).forEach(function (el) {
                if (el.classList.contains('mp-in')) return;
                el.classList.add('mp-in');
                run(el, { opacity: [0, 1], y: [10, 0] }, spec({ stiffness: 300, damping: 28 }), function () { clean(el); });
              });
              hit.forEach(function (el) { el.classList.add('mp-in'); });
            });
          });
        }).observe(main, { childList: true, subtree: true });
      }
    }
  }
  setTimeout(function () { loaded = true; }, 400);
  root.classList.remove('mp-motion-pending');

  if (reduce) return;   // everything below is decorative

  /* ---------- 2. sidebar entrance (once per session; always in the editor preview) ---------- */
  var navMode = C.m_nav || 'auto';
  if (navMode !== 'auto' && navMode !== 'none') {
    var seen = false; try { seen = sessionStorage.getItem('hvmMpNav') === '1'; sessionStorage.setItem('hvmMpNav', '1'); } catch (e) {}
    if (!seen || preview) {
      var kfn = navMode === 'fade' ? { opacity: [0, 1] } : navMode === 'rise' ? { opacity: [0, 1], y: [14, 0] } : { opacity: [0, 1], x: [-22, 0] };
      $$('.sidebar .nav-item').slice(0, 40).forEach(function (el, i) {
        run(el, kfn, spec({ delay: 0.05 + i * 0.03 }), function () { clean(el); });
      });
    }
  }

  /* ---------- 3. table rows ---------- */
  if (C.m_rows) {
    $$('.main-content table tbody tr').slice(0, 30).forEach(function (tr, i) {
      run(tr, { opacity: [0, 1], x: [-14, 0] }, spec({ delay: 0.15 + i * 0.03 }), function () { clean(tr); });
    });
  }

  /* ---------- 4. card hover ---------- */
  var hov = C.m_hover || 'auto';
  if (hov !== 'auto' && hov !== 'none') {
    $$('.stat-card,.dash-stat,.dash-panel,.vps-card,.card', main).forEach(function (card) {
      if (card.querySelector('table,.table-responsive,form,canvas') || card.offsetHeight > 460) return;   // big working areas stay still
      card.setAttribute('data-mp-card', '');
      if (hov === 'glow') return;                       // pure CSS
      var sp = { type: 'spring', stiffness: 320, damping: 22 };
      function to(kf) { if (hasMotion) M.animate(card, kf, sp); else card.style.transform = 'translateY(' + (kf.y || 0) + 'px) scale(' + (kf.scale || 1) + ')'; }
      card.addEventListener('pointerenter', function () {
        if (hov === 'lift') to({ y: -6 }); else if (hov === 'scale') to({ scale: 1.025 }); else if (hov === 'tilt') to({ scale: 1.015 });
      });
      card.addEventListener('pointermove', function (e) {
        if (hov !== 'tilt' || !hasMotion) return;
        var r = card.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
        M.animate(card, { rotateY: (px - .5) * 8, rotateX: (.5 - py) * 8, transformPerspective: 900 }, { type: 'spring', stiffness: 260, damping: 22 });
      });
      card.addEventListener('pointerleave', function () {
        if (hasMotion) M.animate(card, { y: 0, scale: 1, rotateX: 0, rotateY: 0 }, sp); else card.style.transform = '';
      });
    });
  }

  /* ---------- 5. page-to-page transition ---------- */
  var pg = C.m_page || 'auto';
  if (pg !== 'auto' && pg !== 'none' && !preview) {
    document.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;   // design.js may already own this click
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download') || a.hasAttribute('onclick') || a.hasAttribute('data-bs-toggle')) return;
      var href = a.getAttribute('href');
      if (!href || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href)) return;
      var u; try { u = new URL(a.href, location.href); } catch (x) { return; }
      if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search)) return;
      if (a.closest('.modal')) return;
      e.preventDefault();
      var kf = pg === 'slide' ? { opacity: [1, 0], x: [0, -32] } : pg === 'zoom' ? { opacity: [1, 0], scale: [1, 0.97] } : { opacity: [1, 0] };
      var go = function () { location.href = u.href; };
      var timer = setTimeout(go, 400);
      var to = { duration: 0.18, ease: 'easeIn' };
      var done = function () { clearTimeout(timer); go(); setTimeout(restore, 2500); };
      function restore() { main.getAnimations && main.getAnimations().forEach(function (an) { an.cancel(); }); clean(main); main.style.opacity = ''; }
      try {
        var ctl = hasMotion ? M.animate(main, kf, to) : main.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 180, fill: 'forwards' });
        var p = ctl.finished || ctl; if (p && p.then) p.then(done, done); else done();
      } catch (err) { done(); }
    });
    window.addEventListener('pageshow', function (e) {          // back/forward cache: never return to a faded page
      if (!e.persisted) return;
      main.getAnimations && main.getAnimations().forEach(function (an) { an.cancel(); }); clean(main); main.style.opacity = '';
    });
  }

  /* ---------- 6. scroll progress bar ---------- */
  if (C.m_progress) {
    var bar = document.createElement('div'); bar.className = 'mp-progress'; document.body.appendChild(bar);
    var sc = main.scrollHeight > main.clientHeight + 4 && getComputedStyle(main).overflowY !== 'visible' ? main : window;
    var tick = false;
    var upd = function () {
      if (tick) return; tick = true;
      requestAnimationFrame(function () {
        tick = false;
        var y, h;
        if (sc === window) { y = window.pageYOffset || document.documentElement.scrollTop || 0; h = (document.documentElement.scrollHeight - window.innerHeight) || 1; }
        else { y = main.scrollTop; h = (main.scrollHeight - main.clientHeight) || 1; }
        bar.style.transform = 'scaleX(' + Math.min(1, Math.max(0, y / h)).toFixed(4) + ')';
      });
    };
    sc.addEventListener('scroll', upd, { passive: true }); window.addEventListener('scroll', upd, { passive: true }); upd();
  }

  /* ---------- 7. cursor spotlight ---------- */
  if (C.m_spotlight && matchMedia('(hover:hover)').matches) {
    var spot = document.createElement('div'); spot.className = 'mp-spot'; document.body.insertBefore(spot, document.body.firstChild);
    var tx = innerWidth / 2, ty = innerHeight / 3, cx = tx, cy = ty, raf = 0;
    var loop = function () {
      cx += (tx - cx) * 0.14; cy += (ty - cy) * 0.14;
      spot.style.transform = 'translate(' + cx.toFixed(1) + 'px,' + cy.toFixed(1) + 'px)';
      raf = (Math.abs(tx - cx) + Math.abs(ty - cy) > 0.5) ? requestAnimationFrame(loop) : 0;
    };
    window.addEventListener('pointermove', function (e) { tx = e.clientX; ty = e.clientY; spot.style.opacity = 1; if (!raf) raf = requestAnimationFrame(loop); }, { passive: true });
    document.addEventListener('pointerleave', function () { spot.style.opacity = 0; });
  }

  /* ---------- 8. magnetic buttons ---------- */
  if (C.m_magnetic && matchMedia('(hover:hover)').matches) {
    $$('.main-content .btn-lg, .page-header .btn, .welcome-panel .btn').slice(0, 20).forEach(function (b) {
      var spr = { type: 'spring', stiffness: 260, damping: 18, mass: 0.6 };
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        var dx = (e.clientX - (r.left + r.width / 2)) * 0.2, dy = (e.clientY - (r.top + r.height / 2)) * 0.3;
        if (hasMotion) M.animate(b, { x: dx, y: dy }, spr); else b.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      });
      b.addEventListener('pointerleave', function () { if (hasMotion) M.animate(b, { x: 0, y: 0 }, spr); else b.style.transform = ''; });
    });
  }

  /* ---------- 9. count-up numbers ---------- */
  if (C.m_countup) {
    $$('.dash-stat-value,.stat-value,.stat-number,.stat-card h3,.stat-info h3', main).forEach(function (el) {
      var tn = null;
      for (var i = 0; i < el.childNodes.length; i++) { var n = el.childNodes[i]; if (n.nodeType === 3 && /\d/.test(n.nodeValue)) { tn = n; break; } }
      if (!tn) return;
      var m = tn.nodeValue.match(/^(\D*)([\d.]+)(.*)$/s); if (!m) return;
      var end = parseFloat(m[2]), dec = (m[2].split('.')[1] || '').length;
      if (!isFinite(end) || end === 0) return;
      var set = function (v) { tn.nodeValue = m[1] + v.toFixed(dec) + m[3]; };
      set(0);
      var started = false;
      var io = new IntersectionObserver(function (ents) {
        if (!ents[0].isIntersecting || started) return; started = true; io.disconnect();
        var t0 = performance.now(), dur = 1200;
        (function step(t) { var p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 4); set(end * e); if (p < 1) requestAnimationFrame(step); else set(end); })(t0);
      }, { threshold: 0.3 });
      io.observe(el);
    });
  }
})();
