/* =====================================================================
   HVM STUDIO MOTION
   Animation set used ONLY when <html data-design="studio">.
   Powered by Motion (the vanilla build of Framer Motion). Everything goes
   through HVMDesign.run (Motion first, Web Animations fallback) so the panel
   keeps working if the CDN is blocked.

   Motion language: springs that settle without bouncing, short distances
   (6-14px), nothing blurs, nothing glows. Motion explains what changed; it
   is never decoration.

     - sidebar   : ONE raised pill glides from the old page's item to the new
                   one (like Framer's shared `layoutId`), even across page
                   loads. A second soft pill follows the pointer.
     - entrance  : header fades, nav cascades, blocks rise 10px, table rows
                   and progress bars follow a beat later
     - scroll    : blocks below the fold rise in when they arrive
     - tiles     : stat / feature cards lift 2px on hover (panels stay still)
     - press     : buttons and tabs compress on press, spring back on release
     - overlays  : modal scales from .985, menus open from their top-right
     - pages     : sidebar clicks glide the pill first, then a 140 ms fade out
     - accent    : button text flips dark/light by accent luminance (WCAG)
   Loaded BEFORE design.js. design.js calls into window.HVMStudio.
   ===================================================================== */
(function () {
  'use strict';
  var root = document.documentElement;
  var reduce = false;
  try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
  var KEY = 'hvmStudioNav';

  // damping ratios 0.88 - 1.0: critically damped, no visible overshoot
  var SPRING = {
    panel: { type: 'spring', stiffness: 280, damping: 32, mass: 0.9 },
    soft:  { type: 'spring', stiffness: 320, damping: 34 },
    nav:   { type: 'spring', stiffness: 440, damping: 38 },
    pop:   { type: 'spring', stiffness: 460, damping: 32 },
    press: { type: 'spring', stiffness: 700, damping: 36 }
  };

  function M() { return window.Motion || window.FramerMotion || null; }
  function hasM() { var m = M(); return !!(m && typeof m.animate === 'function'); }
  function active() { return root.getAttribute('data-design') === 'studio' && !reduce; }
  function D() { return window.HVMDesign || {}; }

  function uniqueOuter(list) {
    var arr = Array.prototype.slice.call(list);
    return arr.filter(function (el) { return !arr.some(function (o) { return o !== el && o.contains(el); }); });
  }
  function q(sel, max) { return uniqueOuter(document.querySelectorAll(sel)).slice(0, max || 48); }
  function go(els, spec, opts, stagger) { if (els.length && D().run) D().run(els, spec, opts, stagger); }
  function inViewport(el) { var r = el.getBoundingClientRect(); return r.top < window.innerHeight * 0.96 && r.bottom > 0; }
  function clean(el) {
    ['transform', 'scale', 'translate', 'opacity', 'filter'].forEach(function (p) { el.style.removeProperty(p); });
    el.classList.remove('hvm-motion-in');
  }

  /* ---------- text colour on the accent button (contrast, not guesswork) ---------- */
  function onAccent() {
    var raw = (getComputedStyle(root).getPropertyValue('--accent-primary') || '').trim();
    var m = /^#([0-9a-f]{6})$/i.exec(raw);
    if (!m) return;
    var n = parseInt(m[1], 16);
    function lin(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
    var L = 0.2126 * lin((n >> 16) & 255) + 0.7152 * lin((n >> 8) & 255) + 0.0722 * lin(n & 255);
    var col = L > 0.19 ? '#1A1308' : '#FFFFFF';      // whichever reads better on the accent
    if (root.style.getPropertyValue('--st-on-accent') !== col) root.style.setProperty('--st-on-accent', col);
  }
  try {
    var pend = false;
    new MutationObserver(function () {
      if (pend) return; pend = true;
      requestAnimationFrame(function () { pend = false; onAccent(); });
    }).observe(root, { attributes: true, attributeFilter: ['data-theme', 'style', 'data-design'] });
  } catch (e) {}

  /* ---------- number-driven glide (the vanilla take on Framer's layout animation) ---------- */
  function setY(el, y) { el._y = y; el.style.transform = 'translate3d(0,' + y.toFixed(2) + 'px,0)'; }
  function glide(el, from, to, spec) {
    if (el._ctl && el._ctl.stop) { try { el._ctl.stop(); } catch (e) {} }
    el._ctl = null;
    if (!hasM() || reduce || Math.abs(from - to) < 1) { setY(el, to); return; }
    setY(el, from);
    try {
      el._ctl = M().animate(from, to, Object.assign({
        onUpdate: function (v) { setY(el, v); },
        onComplete: function () { setY(el, to); }
      }, spec));
    } catch (e) { setY(el, to); }
  }
  function itemTop(item, nav) { return item.getBoundingClientRect().top - nav.getBoundingClientRect().top + nav.scrollTop; }
  function itemOf(el) { return el.closest('li.nav-item') || el.closest('.nav-item') || el; }

  /* ---------- sidebar: one current-page pill + one hover pill ---------- */
  function navInd() {
    var nav = document.querySelector('.sidebar-nav'), sb = document.querySelector('.sidebar');
    if (!nav || !sb) return;
    var act = nav.querySelector('.nav-item.active, .nav-link.active');
    var ind = nav.querySelector('.st-nav-ind'), hov = nav.querySelector('.st-nav-hover');
    if (!act) { sb.classList.remove('has-ind'); if (ind) ind.remove(); if (hov) hov.remove(); return; }
    var item = itemOf(act);
    if (!ind) { ind = document.createElement('span'); ind.className = 'st-nav-ind'; nav.insertBefore(ind, nav.firstChild); }
    if (!hov) { hov = document.createElement('span'); hov.className = 'st-nav-hover'; hov.style.transition = 'opacity .16s ease'; nav.insertBefore(hov, ind); }
    var top = itemTop(item, nav), prev = NaN;
    ind.style.height = item.offsetHeight + 'px';
    try { prev = parseFloat(sessionStorage.getItem(KEY)); } catch (e) {}
    sb.classList.add('has-ind');
    glide(ind, isFinite(prev) ? prev : top, top, SPRING.nav);
    try { sessionStorage.setItem(KEY, String(top)); } catch (e) {}
  }

  // called by design.js when a sidebar link is clicked: move the pill NOW, load the page after
  function hint(a) {
    if (!active()) return;
    var nav = a.closest('.sidebar-nav'), ind = nav && nav.querySelector('.st-nav-ind');
    if (!ind) return;
    var it = itemOf(a), top = itemTop(it, nav);
    ind.style.height = it.offsetHeight + 'px';
    glide(ind, ind._y != null ? ind._y : top, top, SPRING.nav);
    try { sessionStorage.setItem(KEY, String(top)); } catch (e) {}
  }

  function bindNavHover() {
    document.addEventListener('pointerover', function (e) {
      if (!active() || e.pointerType === 'touch') return;
      var it = e.target.closest && e.target.closest('.sidebar-nav .nav-item');
      if (!it) return;
      var nav = it.closest('.sidebar-nav'), h = nav.querySelector('.st-nav-hover');
      if (!h) return;
      var top = itemTop(it, nav), shown = h.style.opacity === '1';
      h.style.height = it.offsetHeight + 'px';
      glide(h, shown && h._y != null ? h._y : top, top, SPRING.nav);
      h.style.opacity = '1';
    }, true);
    document.addEventListener('pointerout', function (e) {
      if (!active()) return;
      var nav = e.target.closest && e.target.closest('.sidebar-nav');
      if (!nav || (e.relatedTarget && nav.contains(e.relatedTarget))) return;
      var h = nav.querySelector('.st-nav-hover'); if (h) h.style.opacity = '0';
    }, true);
  }

  /* ---------- page entrance ---------- */
  var observers = [];
  function clearObservers() { observers.forEach(function (o) { try { o.disconnect(); } catch (e) {} }); observers = []; }

  function bars() {
    var els = q('.main-content .progress-bar', 30).filter(inViewport);
    if (!els.length) return;
    els.forEach(function (el) { el.classList.add('hvm-motion-in'); });
    var m = M(), done = function () { els.forEach(clean); };
    if (hasM()) {
      try {
        var c = m.animate(els, { transform: ['scaleX(0)', 'scaleX(1)'] }, {
          duration: 0.8, ease: [0.22, 1, 0.36, 1],
          delay: typeof m.stagger === 'function' ? m.stagger(0.05, { startDelay: 0.2 }) : 0.2
        });
        (c.finished || c).then(done, done);
        return;
      } catch (e) {}
    }
    els.forEach(function (el, i) {
      var a = el.animate([{ transform: 'scaleX(0)' }, { transform: 'scaleX(1)' }],
        { duration: 800, delay: 200 + i * 50, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' });
      a.onfinish = a.oncancel = function () { clean(el); };
    });
  }

  function scrollReveal(els) {
    if (!els.length || !('IntersectionObserver' in window)) return;
    els.forEach(function (el) { el.style.opacity = '0'; });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        io.unobserve(en.target);
        en.target.style.removeProperty('opacity');
        go([en.target], { opacity: [0, 1], y: [14, 0] }, SPRING.panel);
      });
    }, { threshold: 0.06, rootMargin: '0px 0px -30px 0px' });
    els.forEach(function (el) { io.observe(el); });
    observers.push(io);
    setTimeout(function () { els.forEach(function (el) { if (el.style.opacity === '0') el.style.removeProperty('opacity'); }); }, 6000);
  }

  function entrance() {
    if (!active()) return;
    clearObservers();
    onAccent();
    root.classList.toggle('st-motion', hasM());

    var blocks = q('.main-content .page-header, .main-content .stat-card, .main-content .card, ' +
                   '.main-content .table-responsive, .main-content .alert, .main-content .empty-state, .main-content .tabs');
    var now = [], later = [];
    blocks.forEach(function (el) { (inViewport(el) ? now : later).push(el); });

    go(q('.header', 1), { opacity: [0, 1] }, { duration: 0.3, ease: 'easeOut' });
    go(q('.sidebar .nav-item'), { opacity: [0, 1], x: [-6, 0] }, Object.assign({ delay: 0.04 }, SPRING.soft), 0.018);
    go(now, { opacity: [0, 1], y: [10, 0] }, Object.assign({ delay: 0.05 }, SPRING.panel), 0.04);
    go(q('.main-content .table tbody tr', 20).filter(inViewport), { opacity: [0, 1], y: [6, 0] },
       Object.assign({ delay: 0.22 }, SPRING.soft), 0.018);

    bars();
    navInd();
    scrollReveal(later);
    bindInteractions();
  }

  /* ---------- hover lift (small tiles only) + press feedback ---------- */
  var HOVER_SEL = '.stat-card, .feature-card, .inst-card, .pulse-card';
  var PRESS_SEL = '.btn, .tabs .tab';
  var lifted = (typeof WeakSet === 'function') ? new WeakSet() : null;
  function spring(el, kf, opts) {
    if (!hasM()) return null;
    try { return M().animate(el, kf, opts); } catch (e) { return null; }
  }
  function busy(el) { return el.classList.contains('hvm-motion-in'); }
  function settle(c, fn) { if (c && c.finished) c.finished.then(fn, fn); else fn(); }

  function bindInteractions() {
    if (window.__hvmStudioBound) return;
    window.__hvmStudioBound = true;
    bindNavHover();

    document.addEventListener('pointerover', function (e) {
      if (!active() || e.pointerType === 'touch') return;
      var el = e.target.closest && e.target.closest(HOVER_SEL);
      if (!el || busy(el) || el.closest('.modal')) return;
      if (e.relatedTarget && el.contains(e.relatedTarget)) return;
      if (lifted) lifted.add(el);
      spring(el, { y: -2 }, SPRING.soft);
    }, true);

    document.addEventListener('pointerout', function (e) {
      if (!active()) return;
      var el = e.target.closest && e.target.closest(HOVER_SEL);
      if (!el || (e.relatedTarget && el.contains(e.relatedTarget))) return;
      if (lifted && !lifted.has(el)) return;
      if (lifted) lifted.delete(el);
      settle(spring(el, { y: 0 }, SPRING.soft), function () {
        if (!lifted || !lifted.has(el)) { el.style.removeProperty('transform'); el.style.removeProperty('translate'); }
      });
    }, true);

    document.addEventListener('pointerdown', function (e) {
      if (!active() || e.button) return;
      var el = e.target.closest && e.target.closest(PRESS_SEL);
      if (!el || el.disabled || busy(el)) return;
      var up = function () {
        document.removeEventListener('pointerup', up, true);
        document.removeEventListener('pointercancel', up, true);
        settle(spring(el, { scale: 1 }, SPRING.press), function () { el.style.removeProperty('transform'); el.style.removeProperty('scale'); });
      };
      document.addEventListener('pointerup', up, true);
      document.addEventListener('pointercancel', up, true);
      spring(el, { scale: 0.97 }, SPRING.press);
    }, true);
  }

  /* ---------- modals & popovers ---------- */
  function pop(el, isModal) {
    if (!active()) return;
    if (isModal) {
      var box = el.querySelector('.modal-content');
      if (!box) return;
      go([el], { opacity: [0, 1] }, { duration: 0.18, ease: 'easeOut' });
      go([box], { opacity: [0, 1], y: [14, 0], scale: [0.985, 1] }, SPRING.pop);
    } else {
      go([el], { opacity: [0, 1], y: [-4, 0], scale: [0.96, 1] }, SPRING.pop);
      go(uniqueOuter(el.querySelectorAll('a, button, .notification-item, li')).slice(0, 10), { opacity: [0, 1] },
         Object.assign({ delay: 0.04 }, SPRING.soft), 0.02);
    }
  }

  /* ---------- sign in / register ---------- */
  function auth(card, kids, dir) {
    if (!active()) return;
    go([card], { opacity: [0, 1], x: [dir * 24, 0], y: [10, 0] }, SPRING.panel);
    go(kids, { opacity: [0, 1], y: [8, 0] }, Object.assign({ delay: 0.1 }, SPRING.soft), 0.04);
  }

  /* ---------- leaving the design ---------- */
  function stop() {
    clearObservers();
    root.classList.remove('st-motion');
    var sb = document.querySelector('.sidebar'); if (sb) sb.classList.remove('has-ind');
    document.querySelectorAll('.st-nav-ind, .st-nav-hover').forEach(function (n) {
      if (n._ctl && n._ctl.stop) { try { n._ctl.stop(); } catch (e) {} }
      n.remove();
    });
    document.querySelectorAll(HOVER_SEL + ',' + PRESS_SEL).forEach(clean);
    document.querySelectorAll('.main-content *').forEach(function (el) {
      if (el.style.opacity === '0') el.style.removeProperty('opacity');
    });
    root.style.removeProperty('--st-on-accent');
  }

  if (root.getAttribute('data-design') === 'studio') { root.classList.toggle('st-motion', hasM()); onAccent(); }
  bindInteractions();

  window.HVMStudio = { entrance: entrance, pop: pop, auth: auth, stop: stop, hint: hint, springs: SPRING };
})();
