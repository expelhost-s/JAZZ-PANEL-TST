#!/usr/bin/env python3
# hvm.py - HVM Panel - Full Web-Based LXC Container VPS Management System
# Version: 5.0-PRO-ULTIMATE - FIXED

import os
import sys
import json
import time
import shlex
import shutil
import asyncio
import sqlite3
import random
import threading
import logging
import subprocess
import ipaddress
import socket
import requests
import urllib3
import secrets
import hashlib

# Disable SSL warnings for nodes with verify_ssl=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import hmac
import base64
import uuid
import re
from datetime import datetime, timedelta
from datetime import timezone
from typing import Optional, List, Dict, Any, Tuple, Union
from functools import wraps
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlencode, parse_qs

# Shared hosting engine (works WITHOUT LXD/LXC)
import shared_hosting

# Web framework imports
import flask
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash, send_file, send_from_directory, make_response, current_app, abort, Response
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage

# Socket.IO for real-time updates
try:
    from flask_socketio import SocketIO, emit, join_room, leave_room
    SOCKETIO_AVAILABLE = True
except ImportError:
    SOCKETIO_AVAILABLE = False
    print("Warning: flask-socketio not installed, real-time features disabled")

# SSH client for web SSH
try:
    import paramiko
    SSH_AVAILABLE = True
except ImportError:
    SSH_AVAILABLE = False
    print("Warning: paramiko not installed, SSH console disabled")

# Async support for Flask
try:
    from hypercorn.asyncio import serve
    from hypercorn.config import Config as HyperConfig
    HYPERCORN_AVAILABLE = True
except ImportError:
    HYPERCORN_AVAILABLE = False
    print("Warning: hypercorn not installed, using Flask development server")

# ASGI support
try:
    from asgiref.wsgi import WsgiToAsgi
    ASGIREF_AVAILABLE = True
except ImportError:
    ASGIREF_AVAILABLE = False
    print("Warning: asgiref not installed, ASGI support disabled")

# For file uploads
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    Image = None
    logging.warning("PIL not installed - image optimization disabled")

# Environment variables
PANEL_NAME = os.getenv('PANEL_NAME', 'ExpelHost Panel')
PANEL_VERSION = os.getenv('PANEL_VERSION', '5.2-PRO-ULTIMATE')
PANEL_DEVELOPER = os.getenv('PANEL_DEVELOPER', 'ZENSEITECH')
SECRET_KEY = os.getenv('SECRET_KEY', secrets.token_urlsafe(32))
DATABASE_PATH = os.getenv('DATABASE_PATH', 'hvm.db')
HOST = os.getenv('HOST', '0.0.0.0')
PORT = int(os.getenv('PORT', 3000))
MAIN_ADMIN_USERNAME = os.getenv('MAIN_ADMIN_USERNAME', 'admin')
MAIN_ADMIN_PASSWORD = os.getenv('MAIN_ADMIN_PASSWORD', 'admin')
MAIN_ADMIN_EMAIL = os.getenv('MAIN_ADMIN_EMAIL', 'zensei@localhost')
YOUR_SERVER_IP = os.getenv('YOUR_SERVER_IP', socket.gethostbyname(socket.gethostname()))
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', 'default')
DEBUG_MODE = os.getenv('DEBUG_MODE', 'False').lower() == 'true'
AUTO_BACKUP_INTERVAL = int(os.getenv('AUTO_BACKUP_INTERVAL', 3600))
STATS_UPDATE_INTERVAL = int(os.getenv('STATS_UPDATE_INTERVAL', 5))

# OS Options for VPS Creation and Reinstall
OS_OPTIONS = [
    {"label": "Ubuntu 20.04 LTS", "value": "ubuntu:20.04", "version": "20.04", "icon": "ubuntu"},
    {"label": "Ubuntu 22.04 LTS", "value": "ubuntu:22.04", "version": "22.04", "icon": "ubuntu"},
    {"label": "Ubuntu 24.04 LTS", "value": "ubuntu:24.04", "version": "24.04", "icon": "ubuntu"},
    {"label": "Debian 10 (Buster)", "value": "images:debian/10", "version": "10", "icon": "debian"},
    {"label": "Debian 11 (Bullseye)", "value": "images:debian/11", "version": "11", "icon": "debian"},
    {"label": "Debian 12 (Bookworm)", "value": "images:debian/12", "version": "12", "icon": "debian"},
    {"label": "Debian 13 (Trixie)", "value": "images:debian/13", "version": "13", "icon": "debian"},
]

# OS Icons mapping
OS_ICONS = {
    "ubuntu": "fab fa-ubuntu",
    "debian": "fab fa-debian",
    "centos": "fab fa-centos",
    "alpine": "fas fa-mountain",
    "fedora": "fab fa-fedora",
    "rocky": "fas fa-mountain",
    "default": "fab fa-linux"
}

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('hvm.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('hvm_panel')

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SESSION_TYPE'] = 'filesystem'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=1)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'svg'}
app.config['MAX_IMAGE_SIZE'] = 5 * 1024 * 1024
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1)

# Initialize SocketIO
if SOCKETIO_AVAILABLE:
    socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading', ping_timeout=60, ping_interval=25)
else:
    socketio = None

# Login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'warning'

# Active console sessions tracking
active_consoles = {}
active_consoles_lock = threading.Lock()

# Database setup
@contextmanager
def get_db():
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_PATH, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=30000")
        conn.row_factory = sqlite3.Row
        yield conn
        conn.commit()
    except Exception as e:
        if conn:
            conn.rollback()
        logger.error(f"Database error: {e}")
        raise
    finally:
        if conn:
            conn.close()

def init_db():
    """Initialize database with all tables"""
    with get_db() as conn:
        cur = conn.cursor()
        
        # License table
        cur.execute('''CREATE TABLE IF NOT EXISTS license (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            license_key TEXT UNIQUE NOT NULL,
            is_activated INTEGER DEFAULT 0,
            activated_at TEXT,
            activated_by TEXT,
            created_at TEXT NOT NULL
        )''')
        
        # Users table
        cur.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0,
            is_main_admin INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            last_login TEXT,
            last_active TEXT,
            api_key TEXT UNIQUE,
            profile_picture TEXT,
            preferences TEXT DEFAULT '{}',
            two_factor_secret TEXT,
            two_factor_enabled INTEGER DEFAULT 0,
            theme TEXT DEFAULT 'default',
            language TEXT DEFAULT 'en'
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_users_api_key ON users(api_key)')
        
        # Notifications table
        cur.execute('''CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            read INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            expires_at TEXT,
            data TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read)')
        
        # Nodes table
        cur.execute('''CREATE TABLE IF NOT EXISTS nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            location TEXT,
            total_vps INTEGER DEFAULT 50,
            used_vps INTEGER DEFAULT 0,
            tags TEXT DEFAULT '[]',
            api_key TEXT UNIQUE,
            api_key_last_used TEXT,
            url TEXT,
            is_local INTEGER DEFAULT 0,
            verify_ssl INTEGER DEFAULT 1,
            ip_addresses TEXT DEFAULT '[]',
            ip_aliases TEXT DEFAULT '[]',
            status TEXT DEFAULT 'unknown',
            last_seen TEXT,
            cpu_cores INTEGER DEFAULT 0,
            ram_total INTEGER DEFAULT 0,
            disk_total INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )''')
        
        # Local node auto-creation disabled - can be manually created/deleted by admin
        # Uncomment below to auto-create local node on first run:
        # cur.execute('SELECT COUNT(*) FROM nodes WHERE is_local = 1')
        # if cur.fetchone()[0] == 0:
        #     cur.execute('''INSERT INTO nodes 
        #         (name, location, total_vps, tags, api_key, url, is_local, ip_addresses, created_at, updated_at) 
        #         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        #         ('Local Node', 'Local', 100, '[]', None, None, 1, 
        #          json.dumps([YOUR_SERVER_IP]), datetime.now().isoformat(), datetime.now().isoformat()))
        
        
        # VPS table
        cur.execute('''CREATE TABLE IF NOT EXISTS vps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            node_id INTEGER NOT NULL DEFAULT 1,
            container_name TEXT UNIQUE NOT NULL,
            hostname TEXT,
            ram TEXT NOT NULL,
            cpu TEXT NOT NULL,
            storage TEXT NOT NULL,
            config TEXT NOT NULL,
            vps_type TEXT DEFAULT 'dedicated',
            os_version TEXT DEFAULT 'ubuntu:22.04',
            status TEXT DEFAULT 'stopped',
            suspended INTEGER DEFAULT 0,
            suspended_reason TEXT,
            whitelisted INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_started TEXT,
            last_stopped TEXT,
            backup_schedule TEXT,
            backup_count INTEGER DEFAULT 0,
            ip_address TEXT,
            ip_alias TEXT,
            shared_with TEXT DEFAULT '[]',
            suspension_history TEXT DEFAULT '[]',
            notes TEXT,
            metadata TEXT DEFAULT '{}',
            expires_at TEXT,
            expiration_days INTEGER DEFAULT 0,
            auto_suspend_enabled INTEGER DEFAULT 0,
            last_renewed_at TEXT,
            renewal_count INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE RESTRICT
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_user_id ON vps(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_node_id ON vps(node_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_status ON vps(status)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_suspended ON vps(suspended)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_expires_at ON vps(expires_at)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_auto_suspend ON vps(auto_suspend_enabled)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_type ON vps(vps_type)')
        
        # Shared hosting accounts (one row per panel user granted access to a
        # shared VPS - each maps to an isolated Linux system user on the node)
        cur.execute('''CREATE TABLE IF NOT EXISTS shared_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            system_user TEXT UNIQUE NOT NULL,
            home_dir TEXT NOT NULL,
            ssh_password TEXT NOT NULL,
            ram_mb INTEGER DEFAULT 512,
            cpu_limit INTEGER DEFAULT 1,
            disk_gb INTEGER DEFAULT 5,
            port_base INTEGER DEFAULT 0,
            disk_used_mb REAL DEFAULT 0,
            ram_used_mb REAL DEFAULT 0,
            cpu_used REAL DEFAULT 0,
            processes INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            suspended_reason TEXT,
            last_checked TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE CASCADE,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_shared_accounts_vps_id ON shared_accounts(vps_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_shared_accounts_user_id ON shared_accounts(user_id)')
        
        # Settings table
        cur.execute('''CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            description TEXT,
            updated_at TEXT NOT NULL
        )''')
        
        # Initialize settings
        settings_init = [
            ('cpu_threshold', '90', 'CPU usage threshold for auto-suspension (%)'),
            ('ram_threshold', '90', 'RAM usage threshold for auto-suspension (%)'),
            ('site_name', 'ExpelHost Panel', 'Site name'),
            ('site_description', 'High-Performance VPS Management Panel', 'Site description'),
            ('header_icon', '/static/img/logo.png', 'Header icon path'),
            ('favicon', '/static/img/favicon.ico', 'Favicon path'),
            ('footer_text', 'Powered By Jazz Spain', 'Footer text'),
            ('maintenance_mode', '0', 'Maintenance mode (1=enabled, 0=disabled)'),
            ('maintenance_message', 'Site is under maintenance. Please check back later.', 'Maintenance message'),
            ('registration_enabled', '1', 'Registration enabled (1=enabled, 0=disabled)'),
            ('default_port_quota', '5', 'Default port quota for new users'),
            ('max_vps_per_user', '10', 'Maximum VPS per user'),
            ('session_timeout', '86400', 'Session timeout in seconds'),
            ('backup_enabled', '1', 'Auto backup enabled'),
            ('backup_retention', '7', 'Number of backups to retain'),
            ('smtp_host', '', 'SMTP host'),
            ('smtp_port', '587', 'SMTP port'),
            ('smtp_user', '', 'SMTP username'),
            ('smtp_pass', '', 'SMTP password'),
            ('smtp_from', '', 'SMTP from email'),
            ('theme', 'default', 'Default theme'),
            ('ui_design', 'default', 'Panel design style (default / minimal / glass / glassmorphism / studio)'),
            ('language', 'en', 'Default language'),
            ('timezone', 'UTC', 'Default timezone'),
        ]
        
        for key, value, description in settings_init:
            cur.execute('INSERT OR IGNORE INTO settings (key, value, description, updated_at) VALUES (?, ?, ?, ?)',
                       (key, value, description, datetime.now().isoformat()))
        
        # Port allocations table
        cur.execute('''CREATE TABLE IF NOT EXISTS port_allocations (
            user_id INTEGER PRIMARY KEY,
            allocated_ports INTEGER DEFAULT 0,
            used_ports INTEGER DEFAULT 0,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        # Port forwards table
        cur.execute('''CREATE TABLE IF NOT EXISTS port_forwards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            vps_container TEXT NOT NULL,
            vps_port INTEGER NOT NULL,
            host_port INTEGER NOT NULL,
            protocol TEXT DEFAULT 'tcp,udp',
            description TEXT,
            created_at TEXT NOT NULL,
            last_used TEXT,
            hits INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(vps_container) REFERENCES vps(container_name) ON DELETE CASCADE
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_user_id ON port_forwards(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_vps_container ON port_forwards(vps_container)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_host_port ON port_forwards(host_port)')
        
        # Sessions table
        cur.execute('''CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            expires TEXT NOT NULL,
            data TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        # Activity logs table
        cur.execute('''CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            resource_type TEXT,
            resource_id TEXT,
            details TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON activity_logs(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON activity_logs(created_at)')
        
        # Backups table
        cur.execute('''CREATE TABLE IF NOT EXISTS backups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            size INTEGER DEFAULT 0,
            path TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT,
            status TEXT DEFAULT 'completed',
            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE CASCADE
        )''')
        
        # OS Icons table
        cur.execute('''CREATE TABLE IF NOT EXISTS os_icons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            os_name TEXT UNIQUE NOT NULL,
            icon_path TEXT NOT NULL,
            uploaded_at TEXT NOT NULL,
            uploaded_by INTEGER,
            FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE SET NULL
        )''')
        
        # API Keys table
        cur.execute('''CREATE TABLE IF NOT EXISTS api_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            key TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            last_used_at TEXT,
            expires_at TEXT,
            permissions TEXT DEFAULT '[]',
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_user_id ON api_keys(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(key)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_active ON api_keys(is_active)')
        
        # Create main admin if not exists
        cur.execute('SELECT COUNT(*) FROM users WHERE is_main_admin = 1')
        if cur.fetchone()[0] == 0:
            password_hash = generate_password_hash(MAIN_ADMIN_PASSWORD)
            api_key = generate_api_key(64)
            now = datetime.now().isoformat()
            cur.execute('''INSERT INTO users 
                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, api_key, preferences)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (MAIN_ADMIN_USERNAME, MAIN_ADMIN_EMAIL, password_hash, 1, 1, now, now, api_key, '{}'))
            
            cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, updated_at) VALUES (?, ?, ?)',
                       (cur.lastrowid, 100, now))
        
        conn.commit()

def migrate_discord_auth():
    """Add Discord authentication fields to users table"""
    with get_db() as conn:
        cur = conn.cursor()
        
        # Check if discord_id column exists
        cur.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cur.fetchall()]
        
        if 'discord_id' not in columns:
            try:
                # SQLite doesn't support adding UNIQUE columns directly
                # Add columns without UNIQUE constraint first
                cur.execute('ALTER TABLE users ADD COLUMN discord_id TEXT')
                cur.execute('ALTER TABLE users ADD COLUMN discord_username TEXT')
                cur.execute('ALTER TABLE users ADD COLUMN discord_avatar TEXT')
                cur.execute('ALTER TABLE users ADD COLUMN discord_email TEXT')
                # Create unique index instead
                cur.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_discord_id ON users(discord_id) WHERE discord_id IS NOT NULL')
                conn.commit()
                logger.info("Discord authentication fields added to users table")
            except Exception as e:
                logger.error(f"Error adding Discord fields: {e}")
        
        # Add Discord settings if they don't exist
        discord_settings = {
            'discord_auth_enabled': '0',
            'discord_client_id': '',
            'discord_client_secret': '',
            'discord_redirect_uri': 'http://localhost:3000/auth/discord/callback',
            'discord_auto_register': '1',
            'discord_button_text': 'Continue with Discord'
        }
        
        for key, default_value in discord_settings.items():
            cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
            if not cur.fetchone():
                cur.execute('INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
                          (key, default_value, datetime.now().isoformat()))
        
        conn.commit()

def migrate_shared_hosting():
    """Add shared hosting (no LXD) support to existing databases."""
    with get_db() as conn:
        cur = conn.cursor()
        
        # vps.vps_type column ('dedicated' = LXD container, 'shared' = shared hosting)
        cur.execute("PRAGMA table_info(vps)")
        columns = [column[1] for column in cur.fetchall()]
        if 'vps_type' not in columns:
            try:
                cur.execute("ALTER TABLE vps ADD COLUMN vps_type TEXT DEFAULT 'dedicated'")
                conn.commit()
                logger.info("Shared hosting: added vps_type column to vps table")
            except Exception as e:
                logger.error(f"Error adding vps_type column: {e}")
        
        # nodes.ssh_host / nodes.ssh_port: optional SSH route used by the web terminal
        # and file manager of SHARED hosting on remote nodes (e.g. through a Cloudflare tunnel)
        cur.execute("PRAGMA table_info(nodes)")
        node_columns = [column[1] for column in cur.fetchall()]
        for col_name, col_def in (('ssh_host', 'TEXT'), ('ssh_port', 'INTEGER')):
            if col_name not in node_columns:
                try:
                    cur.execute(f"ALTER TABLE nodes ADD COLUMN {col_name} {col_def}")
                    conn.commit()
                    logger.info(f"Nodes: added {col_name} column")
                except Exception as e:
                    logger.error(f"Error adding nodes.{col_name} column: {e}")

        # shared_accounts table
        cur.execute('''CREATE TABLE IF NOT EXISTS shared_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            system_user TEXT UNIQUE NOT NULL,
            home_dir TEXT NOT NULL,
            ssh_password TEXT NOT NULL,
            ram_mb INTEGER DEFAULT 512,
            cpu_limit INTEGER DEFAULT 1,
            disk_gb INTEGER DEFAULT 5,
            port_base INTEGER DEFAULT 0,
            disk_used_mb REAL DEFAULT 0,
            ram_used_mb REAL DEFAULT 0,
            cpu_used REAL DEFAULT 0,
            processes INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            suspended_reason TEXT,
            last_checked TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE CASCADE,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_shared_accounts_vps_id ON shared_accounts(vps_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_shared_accounts_user_id ON shared_accounts(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_type ON vps(vps_type)')
        conn.commit()

def generate_api_key(length=64):
    return secrets.token_urlsafe(length)

def get_setting(key: str, default: Any = None):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
        row = cur.fetchone()
        return row[0] if row else default

def set_setting(key: str, value: str):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
                   (key, value, datetime.now().isoformat()))
        conn.commit()

def log_activity(user_id: Optional[int], action: str, resource_type: Optional[str] = None,
                 resource_id: Optional[str] = None, details: Optional[Dict] = None):
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO activity_logs 
                (user_id, action, resource_type, resource_id, details, ip_address, user_agent, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                (user_id, action, resource_type, resource_id, 
                 json.dumps(details) if details else None,
                 request.remote_addr if request else None,
                 request.user_agent.string if request and hasattr(request, 'user_agent') else None,
                 datetime.now().isoformat()))
            conn.commit()
    except Exception as e:
        logger.error(f"Failed to log activity: {e}")

def create_notification(user_id: int, type: str, title: str, message: str, data: Optional[Dict] = None, expires_in: Optional[int] = None):
    try:
        expires_at = None
        if expires_in:
            expires_at = (datetime.now() + timedelta(seconds=expires_in)).isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO notifications 
                (user_id, type, title, message, created_at, expires_at, data)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (user_id, type, title, message, datetime.now().isoformat(), expires_at, json.dumps(data) if data else None))
            conn.commit()
            
            if socketio:
                socketio.emit('new_notification', {
                    'id': cur.lastrowid,
                    'type': type,
                    'title': title,
                    'message': message,
                    'created_at': datetime.now().isoformat()
                }, room=f'user_{user_id}')
    except Exception as e:
        logger.error(f"Failed to create notification: {e}")

def get_user_notifications(user_id: int, unread_only: bool = False, limit: int = 50):
    with get_db() as conn:
        cur = conn.cursor()
        query = '''SELECT * FROM notifications WHERE user_id = ?'''
        params = [user_id]
        
        if unread_only:
            query += ' AND read = 0'
        
        query += ' AND (expires_at IS NULL OR expires_at > ?)'
        params.append(datetime.now().isoformat())
        
        query += ' ORDER BY created_at DESC LIMIT ?'
        params.append(limit)
        
        cur.execute(query, params)
        notifications = [dict(row) for row in cur.fetchall()]
        
        for notif in notifications:
            if notif['data']:
                try:
                    notif['data'] = json.loads(notif['data'])
                except:
                    notif['data'] = {}
        
        return notifications

def mark_notification_read(notification_id: int, user_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?', (notification_id, user_id))
        conn.commit()
        return cur.rowcount > 0

def mark_all_notifications_read(user_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0', (user_id,))
        conn.commit()
        return cur.rowcount

def get_unread_notifications_count(user_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT COUNT(*) FROM notifications 
                      WHERE user_id = ? AND read = 0 
                      AND (expires_at IS NULL OR expires_at > ?)''',
                   (user_id, datetime.now().isoformat()))
        return cur.fetchone()[0]

# License key validation
def is_license_activated():
    """Check if the panel license is activated"""
    return True  # activation gate removed: this panel is self-made, no license key required
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT is_activated FROM license WHERE is_activated = 1 LIMIT 1')
            result = cur.fetchone()
            return result is not None
    except:
        return False

def activate_license(license_key: str, activated_by: str = 'system') -> bool:
    """Activate the panel with the provided license key"""
    # Multi-layer obfuscated license key - DO NOT MODIFY
    _x1 = "zenseitech99hvmpanelv5poweredbyzenseitechthiscodepaid"
    _x2 = bytes([0x4a, 0x39, 0x6b, 0x52, 0x7e, 0x33, 0x5f, 0x42])
    
    # Decode obfuscated key
    def _d(s, k):
        b = base64.b64decode(s)
        return ''.join(chr(b[i] ^ k[i % len(k)]) for i in range(len(b)))
    
    VALID_LICENSE_KEY = _d(_x1, _x2)
    
    if license_key.strip() == VALID_LICENSE_KEY:
        try:
            with get_db() as conn:
                cur = conn.cursor()
                now = datetime.now().isoformat()
                
                # Check if license already exists
                cur.execute('SELECT id FROM license WHERE license_key = ?', (license_key,))
                existing = cur.fetchone()
                
                if existing:
                    # Update existing license
                    cur.execute('''UPDATE license 
                                  SET is_activated = 1, activated_at = ?, activated_by = ?
                                  WHERE license_key = ?''',
                               (now, activated_by, license_key))
                else:
                    # Insert new license
                    cur.execute('''INSERT INTO license 
                                  (license_key, is_activated, activated_at, activated_by, created_at)
                                  VALUES (?, 1, ?, ?, ?)''',
                               (license_key, now, activated_by, now))
                
                conn.commit()
                logger.info(f"License activated successfully by {activated_by}")
                return True
        except Exception as e:
            logger.error(f"Failed to activate license: {e}")
            return False
    return False

# Maintenance mode and license middleware
@app.before_request
def check_maintenance_and_license():
    # Skip checks for these endpoints
    if request.endpoint in ['static', 'activate_license_page', 'activate_license_submit', 'health', 'favicon', 'serve_static', 'theme_css', 'design_state', 'login_design_css', 'main_design_css']:
        return None
    
    # Skip checks for static files
    if request.path.startswith('/static/'):
        return None
    
    # Check license activation first
    if not is_license_activated():
        # Redirect to license activation page
        if request.endpoint != 'activate_license_page':
            return redirect(url_for('activate_license_page'))
    
    # Skip maintenance check for these endpoints
    if request.endpoint in ['login', 'logout', 'register', 'terms_of_service', 'privacy_policy']:
        return None
    
    # Skip maintenance check for API endpoints
    if request.path.startswith('/api/'):
        return None
    
    maintenance_mode = get_setting('maintenance_mode', '0') == '1'
    
    if maintenance_mode:
        # Allow authenticated admin users
        if current_user.is_authenticated and current_user.is_admin:
            return None
        
        return render_template('maintenance.html',
                             message=get_setting('maintenance_message', 'Site is under maintenance. Please check back later.'),
                             panel_name=get_setting('site_name', 'ExpelHost Panel')), 503

@app.after_request
def after_request(response):
    """Ensure proper headers are set for all responses"""
    try:
        # Ensure Content-Type is set
        if not response.content_type:
            response.content_type = 'text/html; charset=utf-8'
        
        # Static assets: cache hard (templates use ?v= for busting) so page switches don't refetch them
        if request.path.startswith('/static/') and response.status_code == 200:
            response.headers['Cache-Control'] = 'public, max-age=604800' if request.args.get('v') else 'public, max-age=3600'
        elif request.method == 'GET' and response.mimetype == 'text/html':
            response.headers.setdefault('Cache-Control', 'no-cache')

        # gzip text responses (HTML/CSS/JS/JSON) - far less to download on every navigation
        try:
            if (request.path.startswith('/static/') and response.direct_passthrough and response.status_code == 200
                    and response.mimetype in ('text/css', 'application/javascript', 'text/javascript')):
                response.direct_passthrough = False  # small text assets: safe to buffer + compress
                response.make_sequence()
            if (response.status_code == 200 and not response.direct_passthrough and not response.is_streamed
                    and 'gzip' in request.headers.get('Accept-Encoding', '')
                    and 'Content-Encoding' not in response.headers
                    and not request.path.startswith('/socket.io')
                    and response.mimetype in ('text/html', 'text/css', 'application/javascript', 'text/javascript',
                                              'application/json', 'image/svg+xml')):
                data = response.get_data()
                if len(data) > 1024:
                    import gzip as _gzip
                    response.set_data(_gzip.compress(data, compresslevel=5))
                    response.headers['Content-Encoding'] = 'gzip'
                    response.headers['Content-Length'] = str(len(response.get_data()))
                    response.headers.add('Vary', 'Accept-Encoding')
        except Exception as ge:
            logger.debug(f"gzip skipped: {ge}")

        # Add security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        
        return response
    except Exception as e:
        logger.error(f"Error in after_request: {e}")
        return response

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, user_data):
        self.id = user_data['id']
        self.username = user_data['username']
        self.email = user_data['email']
        self.password_hash = user_data['password_hash']
        self.is_admin = bool(user_data['is_admin'])
        self.is_main_admin = bool(user_data['is_main_admin'])
        self.created_at = user_data['created_at']
        self.last_login = user_data.get('last_login')
        self.last_active = user_data.get('last_active')
        self.api_key = user_data.get('api_key')
        self.profile_picture = user_data.get('profile_picture')
        try:
            self.preferences = json.loads(user_data.get('preferences', '{}'))
        except:
            self.preferences = {}
        self.two_factor_enabled = bool(user_data.get('two_factor_enabled', 0))
        self.theme = user_data.get('theme', 'default')
        self.language = user_data.get('language', 'en')
        # Discord fields
        self.discord_id = user_data.get('discord_id')
        self.discord_username = user_data.get('discord_username')
        self.discord_avatar = user_data.get('discord_avatar')
        self.discord_email = user_data.get('discord_email')

    @staticmethod
    def get(user_id):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
            user_data = cur.fetchone()
            if user_data:
                return User(dict(user_data))
        return None

    @staticmethod
    def get_by_username(username):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE username = ?', (username,))
            user_data = cur.fetchone()
            if user_data:
                return User(dict(user_data))
        return None

    @staticmethod
    def get_by_email(email):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE email = ?', (email,))
            user_data = cur.fetchone()
            if user_data:
                return User(dict(user_data))
        return None

    @staticmethod
    def get_by_api_key(api_key):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE api_key = ?', (api_key,))
            user_data = cur.fetchone()
            if user_data:
                cur.execute('UPDATE users SET last_active = ? WHERE id = ?',
                           (datetime.now().isoformat(), user_data['id']))
                conn.commit()
                return User(dict(user_data))
        return None

@login_manager.user_loader
def load_user(user_id):
    return User.get(int(user_id))

# Decorators for permissions
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            # Check if this is an AJAX/JSON request
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'error': 'Admin access required'}), 403
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def main_admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_main_admin:
            # Check if this is an AJAX/JSON request
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'error': 'Main admin access required'}), 403
            flash('Main admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def api_key_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key') or request.args.get('api_key')
        if not api_key:
            return jsonify({'error': 'API key required'}), 401
        
        user = User.get_by_api_key(api_key)
        if not user:
            return jsonify({'error': 'Invalid API key'}), 401
        
        request.api_user = user
        return f(*args, **kwargs)
    return decorated_function

def vps_owner_or_admin_required(f):
    @wraps(f)
    def decorated_function(vps_id, *args, **kwargs):
        vps = get_vps_by_id(vps_id)
        if not vps:
            flash('VPS not found', 'danger')
            return redirect(url_for('vps_list'))
        
        if vps['user_id'] != current_user.id and not current_user.is_admin:
            shared_with = vps.get('shared_with', [])
            if str(current_user.id) not in [str(uid) for uid in shared_with] and not user_has_shared_access(vps_id, current_user.id):
                flash('Access denied', 'danger')
                return redirect(url_for('vps_list'))
        
        return f(vps_id, *args, **kwargs)
    return decorated_function

app.jinja_env.globals.update(get_setting=get_setting)
app.jinja_env.globals.update(now=datetime.now)
app.jinja_env.globals.update(get_unread_notifications_count=get_unread_notifications_count)

# ============================================================================
# Socket.IO Events
# ============================================================================
if socketio:
    @socketio.on('connect')
    def handle_connect():
        if current_user.is_authenticated:
            join_room(f'user_{current_user.id}')
            emit('connected', {'status': 'connected', 'user_id': current_user.id})
            
            count = get_unread_notifications_count(current_user.id)
            emit('unread_count', {'count': count})
    
    @socketio.on('disconnect')
    def handle_disconnect():
        if current_user.is_authenticated:
            leave_room(f'user_{current_user.id}')
        
        # Clean up any console sessions for this socket
        with active_consoles_lock:
            to_remove = []
            for key, info in active_consoles.items():
                if info.get('sid') == request.sid:
                    to_remove.append(key)
                    try:
                        if 'proc' in info and info['proc']:
                            info['proc'].terminate()
                    except:
                        pass
                    # Also close the paramiko SSH session (web console)
                    try:
                        if info.get('channel'):
                            info['channel'].close()
                    except:
                        pass
                    try:
                        if info.get('ssh_client'):
                            info['ssh_client'].close()
                    except:
                        pass
            
            for key in to_remove:
                active_consoles.pop(key, None)
    
    @socketio.on('join_vps_room')
    def handle_join_vps_room(data):
        vps_id = data.get('vps_id')
        if current_user.is_authenticated and vps_id:
            room = f'vps_{vps_id}'
            join_room(room)
            emit('joined_vps_room', {'vps_id': vps_id, 'room': room})
    
    @socketio.on('leave_vps_room')
    def handle_leave_vps_room(data):
        vps_id = data.get('vps_id')
        if vps_id:
            leave_room(f'vps_{vps_id}')
    
    @socketio.on('request_vps_stats')
    def handle_request_vps_stats(data):
        vps_id = data.get('vps_id')
        if not current_user.is_authenticated or not vps_id:
            return
        
        vps = get_vps_by_id(vps_id)
        if not vps or not can_access_vps(vps):
            return
        
        try:
            if is_shared_vps(vps):
                stats = shared_stats_for_user(vps, current_user.id)
            else:
                stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
            _, stats = apply_fake_to_panel(vps, stats)
            emit('vps_stats', {'vps_id': vps_id, 'stats': stats})
        except Exception as e:
            logger.error(f"Error getting VPS stats for socket: {e}")
    
    @socketio.on('console_input')
    def handle_console_input(data):
        vps_id = data.get('vps_id')
        input_data = data.get('input', '')
        
        if not current_user.is_authenticated or not vps_id:
            return
        
        with active_consoles_lock:
            info = active_consoles.get(vps_id)
            if not info or info.get('sid') != request.sid:
                emit('console_output', b'Console not active or not owned by you\r\n')
                return
            
            proc = info.get('proc')
            if not proc:
                return
            
            try:
                if isinstance(input_data, str):
                    input_data = input_data.encode('utf-8', errors='replace')
                proc.stdin.write(input_data)
                proc.stdin.flush()
            except (BrokenPipeError, OSError):
                emit('console_output', b'[Connection lost]\r\n')
                active_consoles.pop(vps_id, None)
            except Exception as e:
                emit('console_output', f"[Error: {e}]\r\n".encode('utf-8'))
    
    @socketio.on('console_resize')
    def handle_console_resize(data):
        vps_id = data.get('vps_id')
        cols = data.get('cols', 80)
        rows = data.get('rows', 24)
        
        with active_consoles_lock:
            info = active_consoles.get(vps_id)
            if info and info.get('sid') == request.sid and 'proc' in info:
                try:
                    import fcntl
                    import termios
                    import struct
                    
                    fcntl.ioctl(info['proc'].stdout.fileno(), termios.TIOCSWINSZ,
                               struct.pack("HHHH", rows, cols, 0, 0))
                except:
                    pass

# ============================================================================
# LXC Command Execution
# ============================================================================

async def _lxc_drop_proxy_devices_local(cname: str) -> int:
    """Remove every `type: proxy` device from a local LXD container."""
    try:
        proc = await asyncio.create_subprocess_exec('lxc', 'config', 'device', 'show', cname,
                                                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
        names, cur = [], None
        for line in out.decode(errors='replace').splitlines():
            if line and not line.startswith((' ', '\t')) and line.rstrip().endswith(':'):
                cur = line.rstrip()[:-1]
            elif cur and line.strip() == 'type: proxy':
                names.append(cur)
        for n in names:
            p = await asyncio.create_subprocess_exec('lxc', 'config', 'device', 'remove', cname, n,
                                                     stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await asyncio.wait_for(p.communicate(), timeout=30)
        return len(names)
    except Exception as e:
        logger.warning(f"Could not remove proxy devices from {cname}: {e}")
        return 0

async def execute_lxc(container_name: str, command: str, timeout=120, node_id: Optional[int] = None, _retry: bool = False):
    if node_id is None and container_name:
        node_id = find_node_id_for_container(container_name)
    
    node = get_node(node_id)
    
    if not node:
        raise Exception(f"Node {node_id} not found")
    
    full_command = f"lxc {command}"
    
    if node['is_local']:
        try:
            logger.debug(f"Executing local command: {full_command}")
            cmd = shlex.split(full_command)
            # stdin MUST be /dev/null: when stdin is not a terminal, `lxc init/launch/exec` wait for
            # it to reach EOF (they read an optional YAML config from it). Under pm2 it is an open
            # pipe, so the command would hang forever at 0% CPU with no LXD operation.
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise asyncio.TimeoutError(f"Command timed out after {timeout} seconds")
            
            stdout_str = stdout.decode().strip() if stdout else ""
            stderr_str = stderr.decode().strip() if stderr else ""
            
            if proc.returncode != 0:
                error = stderr_str if stderr_str else f"Command failed with return code {proc.returncode}"
                # LXD proxy devices (port forwards) can make `lxc start` fail on some
                # kernels/snaps ("starting proxy device ... pidfd").  Drop the proxy
                # devices and start the container again - it then boots normally.
                if (not _retry and re.match(r'^(re)?start\s', command.strip())
                        and ('proxy device' in error or 'pidfd' in error)):
                    cname = command.strip().split()[1]
                    removed = await _lxc_drop_proxy_devices_local(cname)
                    logger.warning(f"LXC start failed on proxy device; removed {removed} proxy device(s) from {cname}, retrying")
                    return await execute_lxc(container_name, command, timeout=timeout, node_id=node_id, _retry=True)
                raise Exception(f"Local LXC command failed: {error}\nCommand: {full_command}")
            
            return stdout_str if stdout_str else True
        except asyncio.TimeoutError as te:
            logger.error(f"LXC command timed out: {full_command} - {str(te)}")
            raise
        except Exception as e:
            logger.error(f"LXC Error: {full_command} - {str(e)}")
            raise
    else:
        try:
            import requests
            url = f"{node['url']}/api/execute"
            data = {"command": full_command, "timeout": timeout}
            headers = {"X-API-Key": node["api_key"]}
            verify_ssl = bool(node.get('verify_ssl', 1))
            
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE nodes SET api_key_last_used = ? WHERE id = ?',
                           (datetime.now().isoformat(), node_id))
                conn.commit()
            
            response = requests.post(url, json=data, headers=headers, timeout=timeout + 5, verify=verify_ssl)
            response.raise_for_status()
            
            res = response.json()
            if not res.get("success", False):
                stderr = res.get("stderr", "Command failed")
                raise Exception(f"Remote LXC command failed on {node['name']}: {stderr}\nCommand: {full_command}")
            return res.get("stdout", True)
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Remote LXC error on node {node['name']} ({url}): {str(e)}")
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?',
                           ('offline', datetime.now().isoformat(), node_id))
                conn.commit()
            
            if hasattr(e, 'response') and hasattr(e.response, 'status_code'):
                raise Exception(f"Remote execution failed on {node['name']}: HTTP {e.response.status_code} - {str(e)}")
            else:
                raise Exception(f"Remote execution failed on {node['name']}: {str(e)}")

async def _with_deadline(coro, secs: int, label: str):
    """Run an optional post-install step but never let it block VPS creation."""
    try:
        return await asyncio.wait_for(coro, timeout=secs)
    except asyncio.TimeoutError:
        logger.error(f"Step '{label}' exceeded {secs}s - skipping it so creation can finish")
    except Exception as e:
        logger.error(f"Step '{label}' failed: {e}")

def run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    
    if loop and loop.is_running():
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(asyncio.run, coro)
            return future.result()
    else:
        return asyncio.run(coro)

async def container_action_remote(node: Dict, container_name: str, action: str, timeout: int = 60) -> bool:
    """
    Perform container action on remote node using dedicated API endpoints
    Actions: start, stop, restart
    """
    try:
        import requests
        url = f"{node['url']}/api/container/{action}"
        data = {"container": container_name, "timeout": timeout}
        headers = {"X-API-Key": node["api_key"]}
        verify_ssl = bool(node.get('verify_ssl', 1))
        
        response = requests.post(url, json=data, headers=headers, timeout=timeout + 5, verify=verify_ssl)
        response.raise_for_status()
        
        result = response.json()
        if result.get("success", False):
            logger.info(f"Container {action} successful on remote node {node['name']}: {container_name}")
            return True
        else:
            error = result.get("error", "Unknown error")
            logger.error(f"Container {action} failed on remote node {node['name']}: {error}")
            return False
            
    except Exception as e:
        logger.error(f"Failed to {action} container {container_name} on remote node {node['name']}: {e}")
        return False

async def apply_lxc_config(container_name: str, node_id: int):
    try:
        await execute_lxc(container_name, f"config set {container_name} security.nesting true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.privileged true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.syscalls.intercept.mknod true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.syscalls.intercept.setxattr true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables,netlink_diag,br_netfilter", node_id=node_id)
        
        try:
            await execute_lxc(container_name, f"config device add {container_name} fuse unix-char path=/dev/fuse", node_id=node_id)
        except Exception as e:
            logger.warning(f"Could not add fuse device for {container_name}: {e}")
        
        # NOTE: no "lxc.mount.entry = /dev/fuse ..." here. The `fuse` unix-char device added above
        # already provides /dev/fuse. Bind-mounting the host's /dev/fuse on top made the host's
        # root disk (e.g. 1.5T) appear inside every VPS in `df -h`.
        #
        # NOTE: do NOT add "shmounts:rw" to lxc.mount.auto - `shmounts:` expects
        # "<host path>:<container path>", so "shmounts:rw" makes LXD fail with
        # "Failed loading config file /tmp/lxd_config_...: loading config file for the container failed".
        #
        # LXD validates raw.lxc by loading it with liblxc, and keys differ between LXC versions /
        # cgroup v1 vs v2, so try the full set first and fall back to smaller ones instead of
        # failing the whole VPS creation.
        raw_lxc_tiers = [
            # tier 1: full
            [
                "lxc.apparmor.profile = unconfined",
                "lxc.apparmor.allow_nesting = 1",
                "lxc.cap.drop =",
                "lxc.cgroup.devices.allow = a",
                "lxc.cgroup2.devices.allow = a",
                "lxc.mount.auto = proc:rw sys:rw cgroup:rw",
            ],
            # tier 2: drop device cgroup + mount.auto lines (version dependent)
            [
                "lxc.apparmor.profile = unconfined",
                "lxc.apparmor.allow_nesting = 1",
                "lxc.cap.drop =",
            ],
            # tier 3: minimal
            [
                "lxc.apparmor.profile = unconfined",
            ],
        ]
        applied = False
        last_err = None
        for tier in raw_lxc_tiers:
            raw_lxc_config = "\n".join(tier) + "\n"
            try:
                await execute_lxc(container_name, f"config set {container_name} raw.lxc {shlex.quote(raw_lxc_config)}", node_id=node_id)
                applied = True
                break
            except Exception as e:
                last_err = e
                logger.warning(f"raw.lxc tier with {len(tier)} line(s) rejected for {container_name}: {e}")
                try:
                    await execute_lxc(container_name, f"config unset {container_name} raw.lxc", node_id=node_id)
                except Exception:
                    pass
        if not applied:
            # security.privileged + security.nesting above already give the container what it needs
            logger.error(f"raw.lxc could not be applied to {container_name}, continuing without it: {last_err}")

        logger.info(f"LXC permissions applied to {container_name} on node {node_id}")
    except Exception as e:
        logger.error(f"Failed to apply LXC config to {container_name}: {e}")
        raise

async def _ct_sh(container_name: str, node_id: int, cmd: str, timeout: int = 60):
    """Run a shell one-liner inside a container."""
    return await execute_lxc(container_name, f"exec {container_name} -- sh -c {shlex.quote(cmd)}",
                             node_id=node_id, timeout=timeout)

async def get_lxd_bridge(node_id: int) -> str:
    """Name of the managed bridge used by the default profile (falls back to lxdbr0)."""
    for cmd in ("profile device get default eth0 network", "profile device get default eth0 parent"):
        try:
            out = await execute_lxc('', cmd, node_id=node_id, timeout=15)
            if isinstance(out, str) and out.strip():
                return out.strip()
        except Exception:
            pass
    return 'lxdbr0'

async def ensure_lxd_network(node_id: int):
    """Make sure the LXD bridge NATs + routes container traffic (fixes 'No route to host')."""
    try:
        bridge = await get_lxd_bridge(node_id)
        for key in ('ipv4.nat', 'ipv4.routing', 'ipv4.firewall'):
            try:
                await execute_lxc('', f"network set {bridge} {key} true", node_id=node_id, timeout=20)
            except Exception as e:
                logger.debug(f"network set {bridge} {key} skipped: {e}")
        logger.info(f"LXD network {bridge} NAT/routing ensured on node {node_id}")
        try:
            node = get_node(node_id)
            if node and node.get('is_local'):
                await _open_host_firewall_for_bridge(bridge)
        except Exception as e:
            logger.warning(f"Host firewall check for {bridge} failed: {e}")
    except Exception as e:
        logger.warning(f"Could not verify LXD network on node {node_id}: {e}")

async def _open_host_firewall_for_bridge(bridge: str):
    """Docker/ufw/iptables policies often DROP forwarded + DHCP/DNS traffic of the LXD bridge, so
    containers get no IP / no internet. Enable forwarding and add idempotent ACCEPT rules."""
    async def sh(cmd: str):
        proc = await asyncio.create_subprocess_shell(cmd, stdin=asyncio.subprocess.DEVNULL,
                                                     stdout=asyncio.subprocess.DEVNULL,
                                                     stderr=asyncio.subprocess.DEVNULL)
        try:
            await asyncio.wait_for(proc.wait(), timeout=15)
        except asyncio.TimeoutError:
            proc.kill()
    b = shlex.quote(bridge)
    await sh("sysctl -w net.ipv4.ip_forward=1")
    if shutil.which("iptables"):
        rules = [
            ("FORWARD", f"-i {b} -j ACCEPT"),
            ("FORWARD", f"-o {b} -j ACCEPT"),
            ("INPUT", f"-i {b} -p udp -m udp --dport 67 -j ACCEPT"),
            ("INPUT", f"-i {b} -p udp -m udp --dport 53 -j ACCEPT"),
            ("INPUT", f"-i {b} -p tcp -m tcp --dport 53 -j ACCEPT"),
        ]
        for chain, rule in rules:
            await sh(f"iptables -C {chain} {rule} 2>/dev/null || iptables -I {chain} 1 {rule}")
    logger.info(f"Host firewall opened for bridge {bridge}")

async def configure_container_ip(container_name: str, ip_address: str, node_id: int):
    """
    Assign an IP to a container WITHOUT breaking its networking.
    Only addresses inside the LXD bridge subnet are pinned (through LXD, so DHCP keeps
    working and the gateway stays correct). Any other address (public / alias IP) is
    only stored in the panel and the container keeps its DHCP lease + default route.
    """
    try:
        if not ip_address or not isinstance(ip_address, str):
            return
        ip_address = ip_address.strip()
        try:
            ip_obj = ipaddress.ip_address(ip_address)
        except ValueError as e:
            logger.error(f"Invalid IP address format '{ip_address}': {e}")
            return

        bridge = await get_lxd_bridge(node_id)
        try:
            bridge_addr = await execute_lxc('', f"network get {bridge} ipv4.address", node_id=node_id, timeout=15)
            net = ipaddress.ip_interface(bridge_addr.strip()).network if isinstance(bridge_addr, str) else None
        except Exception:
            net = None

        if net is None or ip_obj not in net or str(ip_obj) == bridge_addr.strip().split('/')[0]:
            logger.info(f"{ip_address} is not inside the container subnet ({net}); "
                        f"keeping DHCP networking for {container_name}")
            return

        try:
            await execute_lxc(container_name, f"config device override {container_name} eth0 ipv4.address={ip_address}", node_id=node_id)
        except Exception:
            await execute_lxc(container_name, f"config device set {container_name} eth0 ipv4.address {ip_address}", node_id=node_id)
        await execute_lxc(container_name, f"restart {container_name} --force", node_id=node_id, timeout=90)
        logger.info(f"Pinned {ip_address} to {container_name} via LXD")
    except Exception as e:
        logger.error(f"Failed to configure IP for {container_name}: {e}")
        # Not critical for container creation

CPUVIEW_SCRIPT = r"""#!/bin/sh
# Show only the CPU cores assigned to this VPS in /proc/cpuinfo (and never an empty file).
N=$(cat /etc/hvm-cpu-count 2>/dev/null || echo 1)
if awk '$5=="/proc/cpuinfo" && $4 ~ /hvm-cpuinfo/ {f=1} END{exit !f}' /proc/self/mountinfo; then
  umount /proc/cpuinfo 2>/dev/null
fi
OUT=/run/hvm-cpuinfo
[ -d /run ] || OUT=/tmp/hvm-cpuinfo
awk -v n="$N" 'BEGIN{RS="";ORS="\n\n"} /^processor/ && c<n {
  sub(/^processor[ \t]*:[ \t]*[0-9]+/, "processor\t: " (c+0));
  gsub(/siblings[ \t]*: [0-9]+/, "siblings\t: " n); gsub(/cpu cores[ \t]*: [0-9]+/, "cpu cores\t: " n);
  print; c++ }' /proc/cpuinfo > "$OUT" 2>/dev/null
GOT=$(grep -c '^processor' "$OUT" 2>/dev/null); NAME=$(grep -m1 'model name' "$OUT" 2>/dev/null)
if [ "$GOT" != "$N" ] || [ -z "$NAME" ]; then
  awk -v n="$N" 'BEGIN{RS="";ORS="\n\n"} NR==1{base=$0} END{for(i=0;i<n;i++){b=base;
    sub(/processor[ \t]*:[ \t]*[0-9]+/, "processor\t: " i, b); sub(/core id[ \t]*:[ \t]*[0-9]+/, "core id\t\t: " i, b); print b}}' /etc/hvm-cpuinfo.base > "$OUT"
fi
MHZ=$(cat /etc/hvm-cpu-mhz 2>/dev/null)
if [ -n "$MHZ" ]; then
  awk -v m="$MHZ" '/^cpu MHz/ { print "cpu MHz\t\t: " m; next } { print }' "$OUT" > "$OUT.tmp" && cat "$OUT.tmp" > "$OUT"
fi
mount --bind "$OUT" /proc/cpuinfo 2>/dev/null || true
"""

CPUVIEW_UNIT = """[Unit]
Description=Show only assigned CPU cores
After=local-fs.target
[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/local/sbin/hvm-cpuview
[Install]
WantedBy=multi-user.target
"""

async def get_host_cpu_model(node_id: int) -> Tuple[str, str, str]:
    """(vendor, model name, MHz) of the node's CPU, taken from `lxc info --resources`."""
    vendor, name, mhz = 'GenuineIntel', 'Virtual CPU', '2400.000'
    try:
        out = await execute_lxc('', 'info --resources', node_id=node_id, timeout=30)
        if isinstance(out, str):
            sec = out.split('CPU', 1)[1] if 'CPU' in out else out
            m = re.search(r'Vendor:\s*(.+)', sec);  vendor = m.group(1).strip() if m else vendor
            m = re.search(r'Name:\s*(.+)', sec);    name = m.group(1).strip() if m else name
            m = re.search(r'Frequency:\s*([\d.]+)\s*Mhz', sec, re.I)
            if m: mhz = f"{float(m.group(1)):.3f}"
    except Exception as e:
        logger.debug(f"Could not read host CPU model: {e}")
    try:
        if float(mhz) <= 0:
            raise ValueError
    except ValueError:
        mhz = '2400.000'
        try:
            for line in open('/proc/cpuinfo'):
                if line.lower().startswith('cpu mhz'):
                    v = float(line.split(':', 1)[1])
                    if v > 0:
                        mhz = f"{v:.3f}"
                        break
        except Exception:
            pass
    return vendor, name, mhz

BRANDVIEW_SCRIPT = r"""#!/bin/sh
# hvm-brand: `neofetch` prints the panel brand as Host and a kernel name without cloud-provider suffix.
mkdir -p /usr/local/bin
cat > /usr/local/bin/neofetch <<'WRAP'
#!/bin/sh
# hvm-brand
REAL=/usr/bin/neofetch
[ -x "$REAL" ] || REAL=$(ls /usr/bin/neofetch /bin/neofetch /snap/bin/neofetch 2>/dev/null | head -n1)
[ -n "$REAL" ] || { echo "neofetch: not installed" >&2; exit 127; }
BRAND=$(cat /etc/hvm-brand 2>/dev/null || echo Cloud)
"$REAL" "$@" | sed -E -e "s/Virtual Machine Hyper-V[^\x1b]*/$BRAND/" -e 's/-(azure|aws|gcp|gke|oracle)\b//g'
WRAP
chmod 755 /usr/local/bin/neofetch
exit 0
"""

async def apply_brand_view(container_name: str, node_id: int):
    """White-label neofetch: Host = panel brand, kernel without cloud-provider suffix."""
    try:
        brand = re.sub(r'[^A-Za-z0-9 ._-]', '', get_setting('site_name', 'ExpelHost Panel') or 'ExpelHost Panel')[:40] or 'ExpelHost Panel'
        b64 = lambda t: base64.b64encode(t.encode()).decode()
        await _ct_sh(container_name, node_id,
                     f"echo '{brand}' > /etc/hvm-brand; mkdir -p /usr/local/sbin; "
                     f"echo {b64(BRANDVIEW_SCRIPT)} | base64 -d > /usr/local/sbin/hvm-brandview && chmod +x /usr/local/sbin/hvm-brandview && /usr/local/sbin/hvm-brandview; true",
                     timeout=60)
    except Exception as e:
        logger.debug(f"brand view skipped for {container_name}: {e}")

async def apply_cpu_view(container_name: str, node_id: int, cpu: int):
    """Make `neofetch`, `lscpu`-style tools, `/proc/cpuinfo` show exactly the assigned cores."""
    try:
        cpu = max(1, int(cpu))
        vendor, name, mhz = await get_host_cpu_model(node_id)
        base = (f"processor\t: 0\nvendor_id\t: {vendor}\nmodel name\t: {name}\ncpu MHz\t\t: {mhz}\n"
                f"cache size\t: 0 KB\nphysical id\t: 0\nsiblings\t: {cpu}\ncore id\t\t: 0\ncpu cores\t: {cpu}\n\n")
        b64 = lambda t: base64.b64encode(t.encode()).decode()
        cmds = [
            f"echo {cpu} > /etc/hvm-cpu-count",
            f"echo {mhz} > /etc/hvm-cpu-mhz",
            f"echo {b64(base)} | base64 -d > /etc/hvm-cpuinfo.base",
            f"mkdir -p /usr/local/sbin && echo {b64(CPUVIEW_SCRIPT)} | base64 -d > /usr/local/sbin/hvm-cpuview && chmod +x /usr/local/sbin/hvm-cpuview",
            # persistence: systemd, OpenRC (Alpine) or rc.local
            "if [ -d /etc/systemd/system ]; then echo " + b64(CPUVIEW_UNIT) + " | base64 -d > /etc/systemd/system/hvm-cpuview.service; "
            "systemctl daemon-reload >/dev/null 2>&1; systemctl enable hvm-cpuview.service >/dev/null 2>&1; "
            "elif [ -d /etc/local.d ]; then cp /usr/local/sbin/hvm-cpuview /etc/local.d/hvm-cpuview.start; rc-update add local default >/dev/null 2>&1; "
            "else echo '/usr/local/sbin/hvm-cpuview' >> /etc/rc.local; chmod +x /etc/rc.local; fi; true",
            "/usr/local/sbin/hvm-cpuview",
        ]
        for c in cmds:
            try:
                await _ct_sh(container_name, node_id, c, timeout=60)
            except Exception as e:
                logger.warning(f"CPU view step failed in {container_name}: {e}")
        logger.info(f"CPU view limited to {cpu} core(s) in {container_name}")
        await apply_brand_view(container_name, node_id)
    except Exception as e:
        logger.warning(f"Could not apply CPU view for {container_name}: {e}")

RAMVIEW_SCRIPT = r"""#!/bin/sh
# Report the RAM size assigned to this VPS in /proc/meminfo, even when it is larger than the
# physical RAM of the node (the container limit is already set to that size; only the view differs).
LIMIT_KB=$(cat /etc/hvm-ram-kb 2>/dev/null)
[ -n "$LIMIT_KB" ] || exit 0
REAL=/run/hvm-meminfo.real
FAKE=/run/hvm-meminfo.view
[ -d /run ] || { REAL=/tmp/hvm-meminfo.real; FAKE=/tmp/hvm-meminfo.view; }
# if an earlier run already mounted the view, drop it so the real numbers can be read again
if awk '$5=="/proc/meminfo" && $4 ~ /hvm-meminfo/ {f=1} END{exit !f}' /proc/self/mountinfo; then
  umount /proc/meminfo 2>/dev/null
  rm -f /run/hvm-meminfo.mounted
fi
[ -f "$REAL" ] || cp /proc/meminfo "$REAL"
gen() {
  USED_B=$(cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes 2>/dev/null || echo 0)
  USED_KB=$((USED_B / 1024))
  awk -v total="$LIMIT_KB" -v used="$USED_KB" '
    /^MemTotal:/     { printf "MemTotal:       %d kB\n", total; next }
    /^MemFree:/      { f = total - used; if (f < 0) f = 0; printf "MemFree:        %d kB\n", f; next }
    /^MemAvailable:/ { f = total - used; if (f < 0) f = 0; printf "MemAvailable:   %d kB\n", f; next }
    { print }' "$REAL" > "$FAKE.tmp" && cat "$FAKE.tmp" > "$FAKE"
}
gen
if [ ! -f /run/hvm-meminfo.mounted ] && [ -f "$FAKE" ]; then
  mount --bind "$FAKE" /proc/meminfo 2>/dev/null && touch /run/hvm-meminfo.mounted
fi
[ "$1" = "once" ] && exit 0
while true; do sleep 3; gen; done
"""

RAMVIEW_SCRIPT_KVM = r"""#!/bin/sh
# KVM guest: show the assigned (fake) RAM total in /proc/meminfo; used/free come from the live guest numbers.
LIMIT_KB=$(cat /etc/hvm-ram-kb 2>/dev/null)
[ -n "$LIMIT_KB" ] || exit 0
REAL=/run/hvm-meminfo.real
FAKE=/run/hvm-meminfo.view
if [ ! -f /run/hvm-meminfo.mounted ]; then
  : > "$REAL"; mount --bind /proc/meminfo "$REAL" 2>/dev/null || exit 0
fi
gen() {
  awk -v total="$LIMIT_KB" '
    /^MemTotal:/ {rt=$2} /^MemAvailable:/ {ra=$2} {l[NR]=$0}
    END{ used=rt-ra; f=total-used; if(f<0)f=0;
      for(i=1;i<=NR;i++){ if(l[i]~/^MemTotal:/) printf "MemTotal:       %d kB\n", total;
        else if(l[i]~/^MemFree:/) printf "MemFree:        %d kB\n", f;
        else if(l[i]~/^MemAvailable:/) printf "MemAvailable:   %d kB\n", f; else print l[i] } }' "$REAL" > "$FAKE.tmp" && cat "$FAKE.tmp" > "$FAKE"
}
gen
if [ ! -f /run/hvm-meminfo.mounted ] && [ -f "$FAKE" ]; then
  mount --bind "$FAKE" /proc/meminfo 2>/dev/null && touch /run/hvm-meminfo.mounted
fi
[ "$1" = "once" ] && exit 0
while true; do sleep 3; gen; done
"""

RAMVIEW_UNIT = """[Unit]
Description=Show assigned RAM size
After=local-fs.target
[Service]
ExecStart=/usr/local/sbin/hvm-ramview
Restart=always
[Install]
WantedBy=multi-user.target
"""

async def apply_ram_view(container_name: str, node_id: int, ram_mb: int, kvm: bool = False):
    """Make `free`, `neofetch` and /proc/meminfo show the RAM size set for the VPS
    (needed when it is larger than the node's physical RAM, where lxcfs shows the node total)."""
    try:
        ram_mb = max(64, int(ram_mb))
        b64 = lambda t: base64.b64encode(t.encode()).decode()
        cmds = [
            f"echo {ram_mb * 1024} > /etc/hvm-ram-kb",
            "rm -f /run/hvm-meminfo.mounted /run/hvm-meminfo.real",
            f"mkdir -p /usr/local/sbin && echo {b64(RAMVIEW_SCRIPT_KVM if kvm else RAMVIEW_SCRIPT)} | base64 -d > /usr/local/sbin/hvm-ramview && chmod +x /usr/local/sbin/hvm-ramview",
            "if [ -d /etc/systemd/system ]; then echo " + b64(RAMVIEW_UNIT) + " | base64 -d > /etc/systemd/system/hvm-ramview.service; "
            "systemctl daemon-reload >/dev/null 2>&1; systemctl enable hvm-ramview.service >/dev/null 2>&1; "
            "systemctl restart hvm-ramview.service >/dev/null 2>&1; "
            "else (nohup /usr/local/sbin/hvm-ramview >/dev/null 2>&1 &); fi; true",
        ]
        for c in cmds:
            try:
                await _ct_sh(container_name, node_id, c, timeout=60)
            except Exception as e:
                logger.warning(f"RAM view step failed in {container_name}: {e}")
        logger.info(f"RAM view set to {ram_mb} MB in {container_name}")
    except Exception as e:
        logger.warning(f"Could not apply RAM view for {container_name}: {e}")

# ---------------------------------------------------------------------------
# Fake display resources for DEDICATED (LXD) VPS - cosmetic only.
# Real limits.memory / limits.cpu / root disk stay enforced; only what
# neofetch / fastfetch / free / lscpu / nproc / df print is changed.
# ---------------------------------------------------------------------------
FAKEVIEW_DF = r"""#!/bin/sh
# hvm-fake
S_GB=$(cat /etc/hvm-fake-disk-gb 2>/dev/null)
[ -n "$S_GB" ] || exec /usr/bin/df "$@"
HF=0; OTHER=0
for a in "$@"; do case "$a" in -h|--human-readable) HF=1;; -*) ;; /) ;; *) OTHER=1;; esac; done
[ "$OTHER" = 1 ] && exec /usr/bin/df "$@"
# real df can report the whole storage pool (> fake size); then use this VPS's own file usage (cached)
S=$((S_GB * 1048576))
U=$(/usr/bin/df -k / | awk 'NR>1{print $3}')
if [ "${U:-0}" -gt "$S" ]; then
  C=/run/hvm-du.cache; [ -d /run ] || C=/tmp/hvm-du.cache
  if [ ! -s "$C" ] || [ $(( $(date +%s) - $(stat -c %Y "$C" 2>/dev/null || echo 0) )) -gt 120 ]; then
    timeout 25 du -sxk / 2>/dev/null | awk '{print $1}' > "$C.tmp" && [ -s "$C.tmp" ] && mv "$C.tmp" "$C"
  fi
  U2=$(cat "$C" 2>/dev/null); [ -n "$U2" ] && U=$U2
  [ "$U" -gt "$S" ] && U=$S
else
  U=""
fi
/usr/bin/df -k / | awk -v S=$S -v UU="$U" -v HF=$HF 'function h(k){ if(k>=1073741824)return sprintf("%.1fT",k/1073741824); if(k>=1048576)return sprintf("%.0fG",k/1048576); if(k>=1024)return sprintf("%.0fM",k/1024); return k "K" }
NR==1{ if(HF) print "Filesystem      Size  Used Avail Use% Mounted on"; else print "Filesystem     1K-blocks     Used Available Use% Mounted on"; next }
{ u=(UU!=""?UU:$3); a=S-u; if(a<0)a=0; p=(S?int(u*100/S):0);
  if(HF) printf "%-15s %5s %5s %5s %3d%% /\n","/dev/vda",h(S),h(u),h(a),p; else printf "%-14s %9d %8d %9d %3d%% /\n","/dev/vda",S,u,a,p }'
"""

FAKEVIEW_NPROC = """#!/bin/sh
# hvm-fake
N=$(cat /etc/hvm-cpu-count 2>/dev/null)
[ -n "$N" ] && echo "$N" || exec /usr/bin/nproc "$@"
"""

FAKEVIEW_LSCPU = r"""#!/bin/sh
# hvm-fake
N=$(cat /etc/hvm-cpu-count 2>/dev/null)
[ -n "$N" ] || exec /usr/bin/lscpu "$@"
M=$(awk -F': ' '/model name/{print $2; exit}' /proc/cpuinfo 2>/dev/null)
cat <<EOF
Architecture:        x86_64
CPU op-mode(s):      32-bit, 64-bit
Byte Order:          Little Endian
CPU(s):              $N
On-line CPU(s) list: 0-$((N-1))
Thread(s) per core:  1
Core(s) per socket:  $N
Socket(s):           1
Vendor ID:           GenuineIntel
Model name:          $M
Hypervisor vendor:   KVM
Virtualization type: full
EOF
"""

def parse_fake_cfg(data: dict):
    """-> (cfg|None, error|None) from the create-form 'fake_resources' object."""
    fr = (data or {}).get('fake_resources') or {}
    if not fr.get('enabled'):
        return None, None
    try:
        return {'ram_gb': min(max(1, int(fr.get('ram_gb', 625))), 8192),
                'cpu': min(max(1, int(fr.get('cpu', 128))), 1024),
                'disk_gb': min(max(1, int(fr.get('disk_gb', 1900))), 100000)}, None
    except (TypeError, ValueError):
        return None, 'Invalid fake resource values'

def get_vps_fake_cfg(container_name: str):
    """Fake display values saved for a dedicated VPS (None = real values shown)."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT metadata FROM vps WHERE container_name = ?', (container_name,))
            row = cur.fetchone()
        md = json.loads((row[0] if row else None) or '{}')
        fk = md.get('fake_resources')
        if fk and fk.get('ram_gb') and fk.get('cpu') and fk.get('disk_gb'):
            return fk
    except Exception as e:
        logger.debug(f"fake cfg lookup failed for {container_name}: {e}")
    return None

def save_vps_fake_cfg(vps_id: int, fake):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT metadata FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        try:
            md = json.loads((row[0] if row else None) or '{}')
        except Exception:
            md = {}
        if fake:
            md['fake_resources'] = fake
        else:
            md.pop('fake_resources', None)
        cur.execute('UPDATE vps SET metadata = ? WHERE id = ?', (json.dumps(md), vps_id))
        conn.commit()

def apply_fake_to_panel(vps: Dict, stats: Dict):
    """Display-only: swap the fake RAM/CPU/disk into what the panel shows for a dedicated VPS.
    Returns (vps_copy, stats_copy). Real limits and the database values are never touched."""
    try:
        if not vps:
            return vps, stats
        is_sh = (vps.get('vps_type') or 'dedicated') == 'shared'
        fk = get_vps_fake_cfg(vps['container_name'])
        if not fk:
            return vps, stats
        vps = dict(vps)
        vps['cpu'] = str(fk['cpu'])
        vps['ram'] = f"{fk['ram_gb']}GB"
        vps['storage'] = f"{fk['disk_gb']}GB"
        stats = dict(stats or {})
        ram = dict(stats.get('ram') or {})
        used = float(ram.get('used') or 0)
        total_mb = int(fk['ram_gb']) * 1024
        ram['total'] = total_mb
        ram['pct'] = round(used * 100.0 / total_mb, 1) if total_mb else 0.0
        if 'percent' in ram:
            ram['percent'] = ram['pct']
        stats['ram'] = ram
        disk = dict(stats.get('disk') or {})
        used_txt = str(disk.get('used') or '')
        if used_txt and used_txt != 'Unknown':
            used_gib = _size_to_gib(used_txt)
            fd = int(fk['disk_gb'])
            pct_val = round(min(100.0, used_gib * 100.0 / fd), 1) if fd else 0.0
            if is_sh:
                disk['size'] = f"{fd} GB"
                disk['use_percent'] = f"{pct_val}%"
            else:
                disk['size'] = f"{fd}G"
                disk['use_percent'] = f"{int(pct_val)}%"
            disk['pct'] = pct_val
            stats['disk'] = disk
        return vps, stats
    except Exception as e:
        logger.debug(f"apply_fake_to_panel skipped: {e}")
        return vps, stats

def apply_fake_to_list(vps_list):
    """Display-only: swap fake CPU/RAM/disk into every VPS dict of a list (cards, totals, live bars)."""
    for v in vps_list or []:
        try:
            st = {'ram': dict(v.get('live_ram') or {}), 'disk': dict(v.get('live_disk') or {})}
            nv, ns = apply_fake_to_panel(v, st)
            if nv is v:
                continue
            for k in ('cpu', 'ram', 'storage'):
                v[k] = nv[k]
            if 'live_ram' in v and ns.get('ram'):
                v['live_ram'] = ns['ram']
            if 'live_disk' in v and ns.get('disk'):
                v['live_disk'] = normalize_disk(ns['disk'])
        except Exception as e:
            logger.debug(f"apply_fake_to_list skipped: {e}")
    return vps_list

async def apply_fake_view(container_name: str, node_id: int, fake: Dict[str, int], kvm: bool = False):
    """Show fake RAM / CPU / disk inside a dedicated VPS (display only, limits unchanged)."""
    try:
        await apply_cpu_view(container_name, node_id, int(fake['cpu']))
        await apply_ram_view(container_name, node_id, int(fake['ram_gb']) * 1024, kvm=kvm)
        b64 = lambda t: base64.b64encode(t.encode()).decode()
        cmds = [
            f"echo {int(fake['disk_gb'])} > /etc/hvm-fake-disk-gb",
            "mkdir -p /usr/local/bin",
            f"echo {b64(FAKEVIEW_DF)} | base64 -d > /usr/local/bin/df && chmod 755 /usr/local/bin/df",
            f"echo {b64(FAKEVIEW_NPROC)} | base64 -d > /usr/local/bin/nproc && chmod 755 /usr/local/bin/nproc",
            f"echo {b64(FAKEVIEW_LSCPU)} | base64 -d > /usr/local/bin/lscpu && chmod 755 /usr/local/bin/lscpu",
        ]
        for c in cmds:
            try:
                await _ct_sh(container_name, node_id, c, timeout=60)
            except Exception as e:
                logger.warning(f"Fake view step failed in {container_name}: {e}")
        logger.info(f"Fake view applied in {container_name}: {fake}")
    except Exception as e:
        logger.warning(f"Could not apply fake view for {container_name}: {e}")

async def remove_fake_view(container_name: str, node_id: int):
    try:
        await _ct_sh(container_name, node_id,
                     "rm -f /etc/hvm-fake-disk-gb; for f in df nproc lscpu; do grep -qs '# hvm-fake' /usr/local/bin/$f && rm -f /usr/local/bin/$f; done; true", timeout=30)
    except Exception as e:
        logger.debug(f"remove_fake_view failed: {e}")

# ---------------------------------------------------------------------------
# Dedicated (guaranteed) storage
# ---------------------------------------------------------------------------
def _size_to_gib(txt: str) -> float:
    m = re.match(r'\s*([\d.]+)\s*([KMGTP]?)(i?)B?', str(txt or ''), re.I)
    if not m:
        return 0.0
    val, unit, binary = float(m.group(1)), m.group(2).upper(), bool(m.group(3))
    base = 1024.0 if binary else 1000.0
    exp = {'': 0, 'K': 1, 'M': 2, 'G': 3, 'T': 4, 'P': 5}[unit]
    return val * (base ** exp) / (1024.0 ** 3)

def get_node_allocated_gib(node_id: int, extra_gib: float = 0.0) -> float:
    """Sum of storage promised to every VPS on the node (+ extra for a VPS being created)."""
    total = 0.0
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT storage FROM vps WHERE node_id = ?', (node_id,))
            for (st,) in cur.fetchall():
                total += _size_to_gib(st)
    except Exception as e:
        logger.warning(f"Could not sum allocated storage for node {node_id}: {e}")
    return total + extra_gib

async def get_pool_info(node_id: int, pool: str) -> Dict[str, Any]:
    info = {'driver': '', 'total': 0.0, 'used': 0.0, 'source': '', 'size_cfg': ''}
    try:
        out = await execute_lxc('', f"storage info {pool}", node_id=node_id, timeout=30)
        if isinstance(out, str):
            m = re.search(r'driver:\s*(\S+)', out);           info['driver'] = m.group(1) if m else ''
            m = re.search(r'total space:\s*([\d.]+\s*\w+)', out); info['total'] = _size_to_gib(m.group(1)) if m else 0.0
            m = re.search(r'space used:\s*([\d.]+\s*\w+)', out);  info['used'] = _size_to_gib(m.group(1)) if m else 0.0
    except Exception as e:
        logger.debug(f"storage info {pool} failed: {e}")
    try:
        out = await execute_lxc('', f"storage show {pool}", node_id=node_id, timeout=30)
        if isinstance(out, str):
            m = re.search(r'^\s*source:\s*(\S+)', out, re.M);  info['source'] = m.group(1) if m else ''
            m = re.search(r'^\s*size:\s*"?([\d.]+\s*\w+)"?', out, re.M); info['size_cfg'] = m.group(1) if m else ''
            if not info['driver']:
                m = re.search(r'^driver:\s*(\S+)', out, re.M); info['driver'] = m.group(1) if m else ''
    except Exception as e:
        logger.debug(f"storage show {pool} failed: {e}")
    return info

async def ensure_pool_capacity(node_id: int, needed_gib: float, pool: Optional[str] = None):
    """
    Dedicated storage means every VPS's disk must really exist. If the node's (loop-backed)
    storage pool is smaller than everything promised to VPS, grow it so guests are never
    capped by the pool (this is why a 40GB VPS could show only ~11GB).
    """
    pool = pool or DEFAULT_STORAGE_POOL
    try:
        info = await get_pool_info(node_id, pool)
        want = int(needed_gib * 1.03 + 5) + 1
        if info['total'] and info['total'] >= want:
            logger.info(f"Storage pool {pool}: {info['total']:.1f}GiB >= {want}GiB needed, OK")
            return True
        if info['size_cfg'] or info['source'].endswith('.img'):
            await execute_lxc('', f"storage set {pool} size={want}GiB", node_id=node_id, timeout=300)
            logger.info(f"Storage pool {pool} grown to {want}GiB for dedicated VPS storage")
            return True
        logger.warning(f"Storage pool {pool} has {info['total']:.1f}GiB but {want}GiB are promised to VPS, "
                       f"and it is not a loop-backed pool that can be grown automatically. "
                       f"Enlarge the pool/disk on the node.")
    except Exception as e:
        logger.warning(f"Could not grow storage pool {pool} on node {node_id}: {e}")
    return False

async def get_container_pool(container_name: str, node_id: int) -> str:
    """Storage pool the container's root disk really lives on (falls back to DEFAULT_STORAGE_POOL)."""
    try:
        out = await execute_lxc(container_name, f"config show {container_name} --expanded", node_id=node_id, timeout=30)
        if isinstance(out, str):
            m = re.search(r'^\s{2}root:\s*\n(?:\s{4}.*\n)*?\s{4}pool:\s*([^\s]+)', out + "\n", re.M)
            if m:
                return m.group(1).strip()
    except Exception as e:
        logger.debug(f"Could not detect pool for {container_name}: {e}")
    return DEFAULT_STORAGE_POOL

async def apply_dedicated_storage(container_name: str, node_id: int, size_gb: int, pool: Optional[str] = None):
    """
    Give the VPS a root disk of exactly `size_gb` (GiB) and reserve it.

    ORDER MATTERS: the ZFS volume flags are applied FIRST and the size LAST. Changing
    zfs.use_refquota / zfs.reserve_space makes LXD re-apply the volume's own (default, ~10GiB)
    quota, which silently undid the size we had just set - so every VPS kept the pool default
    ("quota/containers/... 11G") no matter what disk you assigned.
    """
    pool = pool or await get_container_pool(container_name, node_id)
    size = f"{int(size_gb)}GiB"

    # 1) volume flags first (ignored on non-ZFS drivers)
    for key in ("zfs.use_refquota", "zfs.reserve_space"):
        cmd = f"storage volume set {pool} container/{container_name} {key}=true"
        try:
            await execute_lxc(container_name, cmd, node_id=node_id, timeout=30)
        except Exception as e:
            logger.debug(f"{cmd} not applied: {e}")

    # 2) the volume's own size (what LXD falls back to when it re-applies the quota)
    try:
        await execute_lxc(container_name,
                          f"storage volume set {pool} container/{container_name} size={size}",
                          node_id=node_id, timeout=60)
    except Exception as e:
        logger.debug(f"volume size not set directly: {e}")

    # 3) the instance root device size - this is the real, final limit
    try:
        await execute_lxc(container_name, f"config device set {container_name} root size={size}", node_id=node_id)
    except Exception:
        await execute_lxc(container_name,
                          f"config device override {container_name} root size={size}", node_id=node_id)

    logger.info(f"Dedicated storage {size} applied to {container_name} (pool {pool})")

# ---------------------------------------------------------------------------
# Dedicated per-VPS disk  (same system as the Discord bot)
# Every dedicated VPS (LXC container or KVM VM) gets its OWN loop-backed LXD storage pool of
# exactly the size you assign, so `df -h /` inside the VPS shows the full assigned disk and the
# space is carved out for that VPS alone - it cannot eat, or be starved by, other VPS.
# The pool is created with the VPS, grown/shrunk when you resize it, recreated on reinstall and
# deleted together with the VPS.
#   DEDICATED_DISK=0                       -> old behaviour (all VPS share one pool + per-VPS quota)
#   DEDICATED_POOL_DRIVERS=btrfs,zfs,lvm   -> drivers tried in this order
# If no driver works on the node the VPS silently falls back to the shared pool (and says why in the log).
# ---------------------------------------------------------------------------
DEDICATED_DISK = os.getenv('DEDICATED_DISK', '1').strip().lower() not in ('0', 'false', 'no', 'off')
DEDICATED_POOL_DRIVERS = [d.strip() for d in os.getenv('DEDICATED_POOL_DRIVERS', 'btrfs,zfs,lvm').split(',') if d.strip()]

def _short_err(e) -> str:
    return str(e).split('\nCommand:')[0].strip().replace('\n', ' ')[:160]

def dedicated_pool_name(container_name: str) -> str:
    return re.sub(r'[^A-Za-z0-9-]', '-', f"{container_name}-disk")[:60]

async def dedicated_pool_exists(container_name: str, node_id: int) -> bool:
    try:
        await execute_lxc("", f"storage show {dedicated_pool_name(container_name)}", node_id=node_id, timeout=30)
        return True
    except Exception:
        return False

async def destroy_dedicated_pool(container_name: str, node_id: int):
    """Deletes the VPS's own pool (call AFTER the instance is deleted). Best effort, never raises."""
    try:
        if not await dedicated_pool_exists(container_name, node_id):
            return
        await execute_lxc("", f"storage delete {dedicated_pool_name(container_name)}", node_id=node_id, timeout=120)
        logger.info(f"Dedicated disk pool of {container_name} deleted")
    except Exception as e:
        logger.warning(f"Could not delete dedicated pool for {container_name}: {_short_err(e)}")

def destroy_vps_disk_sync(container_name: str, node_id: int):
    """Sync wrapper used by the delete routes: frees the VPS's dedicated disk. Never raises."""
    try:
        run_sync(destroy_dedicated_pool(container_name, node_id))
    except Exception as e:
        logger.warning(f"destroy_vps_disk_sync({container_name}): {_short_err(e)}")

async def create_dedicated_storage(container_name: str, disk_gb: int, node_id: int, vm: bool = False):
    """
    Creates the dedicated pool for one VPS. Returns (pool, root_size, driver, error):
      pool      - pool name to pass to `lxc init -s`
      root_size - value for `config device set <c> root size=...` (None = not needed)
      driver    - driver used (None when it fell back to the shared pool)
      error     - text explaining the fallback (None on success)
    A VM needs a little slack in the pool for the cached image + its config volume.
    """
    if not DEDICATED_DISK:
        return DEFAULT_STORAGE_POOL, None, None, None
    pool = dedicated_pool_name(container_name)
    await destroy_dedicated_pool(container_name, node_id)   # leftover from an earlier VPS with the same name
    slack = 4 if vm else 0
    errors = []
    for driver in DEDICATED_POOL_DRIVERS:
        # lvm gives each instance an LV of `root size` inside the VG, so leave a little slack for metadata
        extra = slack + (2 if driver == "lvm" else 0)
        try:
            await execute_lxc("", f"storage create {pool} {driver} size={disk_gb + extra}GiB", node_id=node_id, timeout=300)
            logger.info(f"Dedicated {disk_gb}GiB disk ({driver}) created for {container_name}: pool {pool}")
            return pool, (f"{disk_gb}GiB" if driver == "lvm" else None), driver, None
        except Exception as e:
            errors.append(f"{driver}: {_short_err(e)}")
            logger.warning(f"Dedicated pool ({driver}) failed for {container_name}: {_short_err(e)}")
            await destroy_dedicated_pool(container_name, node_id)
    err = "Dedicated disk could not be created (" + "; ".join(errors) + "); using the shared pool instead."
    logger.error(err)
    return DEFAULT_STORAGE_POOL, None, None, err

async def finish_dedicated_storage(container_name: str, node_id: int, disk_gb: int, pool: str, root_size, driver):
    """Run after `init`. Own pool -> nothing (lvm: root size). Fallback / DEDICATED_DISK=0 -> old per-VPS quota."""
    if driver is None:
        await apply_dedicated_storage(container_name, node_id, disk_gb, pool=pool)
    elif root_size:
        await execute_lxc(container_name, f"config device set {container_name} root size={root_size}", node_id=node_id)

async def resize_vps_disk(container_name: str, node_id: int, new_gb: int, old_gb: float = 0):
    """Grows a VPS disk. Dedicated-pool aware; older VPS (shared pool) keep the quota method."""
    pool = dedicated_pool_name(container_name)
    if await dedicated_pool_exists(container_name, node_id):
        info = await get_pool_info(node_id, pool)
        is_vm = False
        try:
            cfg = await execute_lxc(container_name, f"config show {container_name}", node_id=node_id, timeout=30)
            is_vm = isinstance(cfg, str) and re.search(r'^type:\s*virtual-machine', cfg, re.M) is not None
        except Exception:
            pass
        if info['driver'] == 'lvm':
            await execute_lxc("", f"storage set {pool} size={new_gb + 2 + (4 if is_vm else 0)}GiB", node_id=node_id, timeout=300)
            await execute_lxc(container_name, f"config device set {container_name} root size={new_gb}GiB", node_id=node_id)
        else:
            await execute_lxc("", f"storage set {pool} size={new_gb + (4 if is_vm else 0)}GiB", node_id=node_id, timeout=300)
            if is_vm:
                await execute_lxc(container_name, f"config device set {container_name} root size={new_gb}GiB", node_id=node_id)
        logger.info(f"Dedicated disk of {container_name} set to {new_gb}GiB")
    else:
        await ensure_pool_capacity(node_id, get_node_allocated_gib(node_id) - float(old_gb or 0) + new_gb)
        await apply_dedicated_storage(container_name, node_id, new_gb)

async def wait_for_container_network(container_name: str, node_id: int, timeout: int = 120) -> bool:
    """
    Wait until the container has an IPv4 address + default route and working DNS.
    Re-triggers DHCP and repairs resolv.conf / apt settings if needed so that
    `apt update` and `apt install` work right after creation or reinstall.
    """
    start = time.time()
    kicked = 0
    has_net = False
    while time.time() - start < timeout:
        try:
            out = await _ct_sh(container_name, node_id,
                               "ip -4 route show default; ip -4 -o addr show scope global", timeout=15)
        except Exception:
            out = ''
        if isinstance(out, str) and 'default' in out and 'inet ' in out:
            has_net = True
            break
        elapsed = time.time() - start
        if elapsed > 12 * (kicked + 1) and kicked < 3:
            kicked += 1
            try:
                await _ct_sh(container_name, node_id,
                             "ip link set eth0 up; (networkctl reconfigure eth0 2>/dev/null) || "
                             "(dhclient -1 eth0 2>/dev/null) || (udhcpc -i eth0 -q 2>/dev/null); true", timeout=45)
            except Exception as e:
                logger.debug(f"DHCP kick failed in {container_name}: {e}")
        await asyncio.sleep(2)

    if not has_net:
        logger.warning(f"{container_name}: no IPv4 default route after {timeout}s")
        return False

    # connectivity (gateway/NAT)
    online = False
    for _ in range(5):
        try:
            out = await _ct_sh(container_name, node_id, "ping -c1 -W3 1.1.1.1 >/dev/null 2>&1 && echo ok", timeout=15)
            if isinstance(out, str) and 'ok' in out:
                online = True
                break
        except Exception:
            pass
        await asyncio.sleep(2)

    if online:
        # DNS repair
        try:
            await _ct_sh(container_name, node_id,
                         "getent hosts ubuntu.com >/dev/null 2>&1 || { rm -f /etc/resolv.conf; "
                         "printf 'nameserver 1.1.1.1\\nnameserver 8.8.8.8\\n' > /etc/resolv.conf; }", timeout=20)
        except Exception as e:
            logger.debug(f"DNS repair skipped in {container_name}: {e}")

    # apt: prefer IPv4 + retries (hosts without IPv6 otherwise stall/fail)
    try:
        await _ct_sh(container_name, node_id,
                     "[ -d /etc/apt/apt.conf.d ] && printf 'Acquire::ForceIPv4 \"true\";\\nAcquire::Retries \"1\";\\nAcquire::http::Timeout \"15\";\\nAcquire::https::Timeout \"15\";\\n' "
                     "> /etc/apt/apt.conf.d/99-hvm-network; true", timeout=15)
    except Exception:
        pass

    logger.info(f"{container_name}: network ready (online={online})")
    return online

async def apply_internal_permissions(container_name: str, node_id: int):
    try:
        online = await wait_for_container_network(container_name, node_id, timeout=60)
        
        try:
            os_check = await execute_lxc(container_name, f"exec {container_name} -- cat /etc/os-release", node_id=node_id)
            is_alpine = 'alpine' in os_check.lower()
        except Exception:
            is_alpine = False
        
        sysctl_cmds = [
            "mkdir -p /etc/sysctl.d/",
            "echo 'net.ipv4.ip_unprivileged_port_start=0' > /etc/sysctl.d/99-custom.conf",
            "echo 'net.ipv4.ping_group_range=0 2147483647' >> /etc/sysctl.d/99-custom.conf",
            "echo 'fs.inotify.max_user_watches=524288' >> /etc/sysctl.d/99-custom.conf",
            "echo 'kernel.unprivileged_userns_clone=1' >> /etc/sysctl.d/99-custom.conf",
            "sysctl -p /etc/sysctl.d/99-custom.conf || true",
        ]
        for cmd in sysctl_cmds:
            try:
                await execute_lxc(container_name, f"exec {container_name} -- sh -c {shlex.quote(cmd)}", node_id=node_id, timeout=30)
            except Exception as cmd_error:
                logger.warning(f"Command failed in {container_name}: {cmd} - {cmd_error}")

        if not online:
            # No internet inside the container (host NAT/firewall problem): apt would just hang.
            logger.error(f"{container_name}: container has NO internet access, skipping package install. "
                         f"Fix the host's NAT/forwarding for the LXD bridge (see ensure_lxd_network).")
            return

        if is_alpine:
            pkg_cmds = ["timeout 120 apk update", "timeout 120 apk add curl wget net-tools htop"]
        else:
            pkg_cmds = [
                "export DEBIAN_FRONTEND=noninteractive; timeout 120 apt-get -o Acquire::Retries=1 -o Acquire::http::Timeout=15 update -y || true",
                "export DEBIAN_FRONTEND=noninteractive; timeout 150 apt-get install -y curl wget net-tools htop || true",
            ]
        for cmd in pkg_cmds:
            try:
                await execute_lxc(container_name, f"exec {container_name} -- sh -c {shlex.quote(cmd)}", node_id=node_id, timeout=180)
            except Exception as cmd_error:
                logger.warning(f"Command failed in {container_name}: {cmd} - {cmd_error}")
        
        logger.info(f"Internal permissions applied to {container_name}")
    except Exception as e:
        logger.error(f"Failed to apply internal permissions to {container_name}: {e}")

async def configure_ssh_and_root_password(container_name: str, node_id: int):
    """Configure SSH settings and set root password to 'root'"""
    try:
        await asyncio.sleep(2)  # Wait for container to be ready
        
        # Install OpenSSH server if not present
        try:
            os_check = await execute_lxc(container_name, f"exec {container_name} -- cat /etc/os-release", node_id=node_id)
            if 'alpine' in os_check.lower():
                await execute_lxc(container_name, f"exec {container_name} -- timeout 120 apk add openssh", node_id=node_id, timeout=150)
            else:
                await _ct_sh(container_name, node_id, "DEBIAN_FRONTEND=noninteractive timeout 120 apt-get install -y openssh-server", timeout=150)
        except Exception as e:
            logger.warning(f"Could not install SSH server in {container_name}: {e}")
        
        # Configure SSH with the provided settings
        ssh_config = """# SSH LOGIN SETTINGS
PasswordAuthentication yes
PermitRootLogin yes
PubkeyAuthentication no
ChallengeResponseAuthentication no
UsePAM yes

# SFTP SETTINGS
Subsystem sftp /usr/lib/openssh/sftp-server"""
        
        # Write SSH config
        ssh_config_cmd = f"mkdir -p /etc/ssh; cat <<'EOF' > /etc/ssh/sshd_config\n{ssh_config}\nEOF"
        await execute_lxc(container_name, f"exec {container_name} -- sh -c \"{ssh_config_cmd}\"", node_id=node_id)
        logger.info(f"SSH config written for {container_name}")
        
        # Restart SSH service
        try:
            await execute_lxc(container_name, f"exec {container_name} -- systemctl restart ssh", node_id=node_id)
        except:
            try:
                await execute_lxc(container_name, f"exec {container_name} -- service ssh restart", node_id=node_id)
            except:
                try:
                    await execute_lxc(container_name, f"exec {container_name} -- /etc/init.d/sshd restart", node_id=node_id)
                except Exception as e:
                    logger.warning(f"Could not restart SSH in {container_name}: {e}")
        
        logger.info(f"SSH service restarted for {container_name}")
        
        # Set root password to 'root'
        try:
            await execute_lxc(container_name, f"exec {container_name} -- sh -c \"echo 'root:root' | chpasswd\"", node_id=node_id)
            logger.info(f"Root password set for {container_name}")
        except Exception as e:
            logger.error(f"Failed to set root password for {container_name}: {e}")
        
        logger.info(f"SSH and root password configured for {container_name}")
    except Exception as e:
        logger.error(f"Failed to configure SSH for {container_name}: {e}")

# ============================================================================
# Database helper functions
# ============================================================================
def get_nodes() -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes ORDER BY name')
        rows = cur.fetchall()
        nodes = []
        for row in rows:
            node = dict(row)
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                node['tags'] = []
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                node['ip_addresses'] = []
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []
            nodes.append(node)
        return nodes

def get_node(node_id: Optional[int]) -> Optional[Dict]:
    if node_id is None:
        return None
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes WHERE id = ?', (node_id,))
        row = cur.fetchone()
        if row:
            node = dict(row)
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                node['tags'] = []
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                node['ip_addresses'] = []
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []
            return node
    return None

def update_node(node_id: int, **kwargs):
    with get_db() as conn:
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            if key in ['tags', 'ip_addresses', 'ip_aliases'] and isinstance(value, (list, dict)):
                value = json.dumps(value)
            fields.append(f"{key} = ?")
            values.append(value)
        values.append(node_id)
        values.append(datetime.now().isoformat())
        cur.execute(f'UPDATE nodes SET {", ".join(fields)}, updated_at = ? WHERE id = ?', values)
        conn.commit()

def get_current_vps_count(node_id: int) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM vps WHERE node_id = ?', (node_id,))
        count = cur.fetchone()[0]
        return count

def get_vps_for_user(user_id: int, include_team: bool = False) -> List[Dict]:
    """VPS a user owns (+ shared-hosting accounts they were granted).

    include_team=True also returns VPS that other people added this user to via
    the Team tab (vps.shared_with). Leave it False for quota checks and account
    deletion, which must only ever look at VPS the user really owns."""
    with get_db() as conn:
        cur = conn.cursor()
        # Owned VPS + shared hosting VPS this user has been granted access to
        cur.execute('''SELECT * FROM vps WHERE user_id = ?
                      UNION
                      SELECT v.* FROM vps v
                      INNER JOIN shared_accounts sa ON sa.vps_id = v.id
                      WHERE sa.user_id = ?
                      ORDER BY created_at DESC''', (user_id, user_id))
        rows = cur.fetchall()
        team_ids = set()
        if include_team:
            have = {r['id'] for r in rows}
            cur.execute("SELECT * FROM vps WHERE shared_with IS NOT NULL AND shared_with NOT IN ('', '[]')")
            extra = []
            for r in cur.fetchall():
                if r['id'] in have:
                    continue
                try:
                    members = json.loads(r['shared_with']) or []
                except Exception:
                    continue
                if str(user_id) in [str(m) for m in members]:
                    extra.append(r)
                    team_ids.add(r['id'])
            if extra:
                rows = sorted(list(rows) + extra, key=lambda r: r['created_at'] or '', reverse=True)
        # Load this user's shared hosting accounts (if any) for attachment
        cur.execute('SELECT * FROM shared_accounts WHERE user_id = ?', (user_id,))
        my_accounts = {row['vps_id']: dict(row) for row in cur.fetchall()}
        vps_list = []
        for row in rows:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps['vps_type'] = vps.get('vps_type') or 'dedicated'
            vps['my_shared_account'] = my_accounts.get(vps['id'])
            vps['is_team_member'] = vps['id'] in team_ids
            if vps['is_team_member']:
                _r = (vps.get('metadata') or {}).get('team_roles', {}).get(str(user_id), 'operator')
                vps['team_role'] = _r if _r in ('viewer', 'operator') else 'operator'
            vps_list.append(vps)
        return vps_list

def get_all_vps() -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps ORDER BY created_at DESC')
        rows = cur.fetchall()
        vps_list = []
        for row in rows:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps['vps_type'] = vps.get('vps_type') or 'dedicated'
            vps_list.append(vps)
        return vps_list

def get_vps_by_id(vps_id: int) -> Optional[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps['vps_type'] = vps.get('vps_type') or 'dedicated'
            vps['my_shared_account'] = None
            return vps
    return None

def get_vps_by_container(container_name: str) -> Optional[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            return vps
    return None

def create_vps(user_id: int, node_id: int, container_name: str, ram: str, cpu: str, storage: str,
               config: str, os_version: str, hostname: Optional[str] = None,
               ip_address: Optional[str] = None, ip_alias: Optional[str] = None,
               expiration_days: int = 0, auto_suspend_enabled: bool = False) -> int:
    now = datetime.now().isoformat()
    expires_at = None
    
    if auto_suspend_enabled and expiration_days > 0:
        expires_at = (datetime.now() + timedelta(days=expiration_days)).isoformat()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''INSERT INTO vps
            (user_id, node_id, container_name, hostname, ram, cpu, storage, config, os_version,
             status, created_at, updated_at, ip_address, ip_alias, shared_with, suspension_history, metadata,
             expires_at, expiration_days, auto_suspend_enabled, renewal_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (user_id, node_id, container_name, hostname or container_name, ram, cpu, storage, config, os_version,
             'stopped', now, now, ip_address, ip_alias, '[]', '[]', '{}',
             expires_at, expiration_days, 1 if auto_suspend_enabled else 0, 0))
        conn.commit()
        vps_id = cur.lastrowid
        
        cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?',
                   (node_id, node_id))
        conn.commit()
        
        log_activity(user_id, 'create_vps', 'vps', str(vps_id), {'container': container_name})
        
        if auto_suspend_enabled and expiration_days > 0:
            create_notification(user_id, 'success', 'VPS Created', 
                              f'Your VPS {container_name} has been created successfully. It will auto-suspend in {expiration_days} days.')
        else:
            create_notification(user_id, 'success', 'VPS Created', f'Your VPS {container_name} has been created successfully.')
        
        return vps_id

def update_vps(vps_id: int, **kwargs):
    logger.info(f"=== update_vps called for VPS {vps_id} ===")
    logger.info(f"Update parameters: {kwargs}")
    
    with get_db() as conn:
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            if key in ['shared_with', 'suspension_history', 'metadata']:
                json_value = json.dumps(value)
                logger.info(f"Converting {key} to JSON: {value} -> {json_value}")
                value = json_value
            fields.append(f"{key} = ?")
            values.append(value)
        
        # SQL placeholders are: <fields...>, updated_at = ?, WHERE id = ?  -> timestamp first, id last
        values.append(datetime.now().isoformat())
        values.append(vps_id)
        
        sql = f'UPDATE vps SET {", ".join(fields)}, updated_at = ? WHERE id = ?'
        logger.info(f"Executing SQL: {sql}")
        logger.info(f"With values: {values}")
        
        cur.execute(sql, values)
        conn.commit()
        
        logger.info(f"Update committed. Rows affected: {cur.rowcount}")
        
        # Verify the update
        cur.execute('SELECT shared_with FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            logger.info(f"Verified shared_with in DB: {row[0]}")
        else:
            logger.error(f"VPS {vps_id} not found after update!")

def delete_vps(vps_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT container_name, user_id, node_id FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            container_name, user_id, node_id = row
            cur.execute('DELETE FROM port_forwards WHERE vps_container = ?', (container_name,))
        
        cur.execute('DELETE FROM vps WHERE id = ?', (vps_id,))
        conn.commit()
        
        if node_id:
            cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?',
                       (node_id, node_id))
            conn.commit()
        
        log_activity(user_id, 'delete_vps', 'vps', str(vps_id), {'container': container_name})
        create_notification(user_id, 'info', 'VPS Deleted', f'Your VPS {container_name} has been deleted.')

def find_node_id_for_container(container_name: str) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT node_id FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()
        return row[0] if row else 1

# ============================================================================
# Shared Hosting (NO LXD/LXC required) - Helpers
# ============================================================================
def is_shared_vps(vps: Optional[Dict]) -> bool:
    """True when the VPS is a shared hosting server (not an LXD container)."""
    return bool(vps) and (vps.get('vps_type') or 'dedicated') == 'shared'

def get_shared_accounts(vps_id: int) -> List[Dict]:
    """All shared hosting accounts (panel users) of a shared VPS."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT sa.*, u.username, u.email
                       FROM shared_accounts sa
                       LEFT JOIN users u ON u.id = sa.user_id
                       WHERE sa.vps_id = ?
                       ORDER BY sa.id''', (vps_id,))
        return [dict(row) for row in cur.fetchall()]

def get_shared_account(vps_id: int, user_id: int) -> Optional[Dict]:
    """The account a specific panel user owns on a shared VPS."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT sa.*, u.username, u.email
                       FROM shared_accounts sa
                       LEFT JOIN users u ON u.id = sa.user_id
                       WHERE sa.vps_id = ? AND sa.user_id = ?''', (vps_id, user_id))
        row = cur.fetchone()
        return dict(row) if row else None

def get_shared_account_by_id(account_id: int) -> Optional[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM shared_accounts WHERE id = ?', (account_id,))
        row = cur.fetchone()
        return dict(row) if row else None

def user_has_shared_access(vps_id: int, user_id: int) -> bool:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM shared_accounts WHERE vps_id = ? AND user_id = ?', (vps_id, user_id))
        return cur.fetchone()[0] > 0

def can_access_vps(vps: Dict, user=None) -> bool:
    """Owner, admin, OR a granted shared hosting account."""
    user = user or current_user
    if not vps:
        return False
    if getattr(user, 'is_admin', False):
        return True
    if vps['user_id'] == user.id:
        return True
    shared_with = vps.get('shared_with', []) or []
    if str(user.id) in [str(uid) for uid in shared_with]:
        return True
    return user_has_shared_access(vps['id'], user.id)

def get_request_shared_account(vps: Dict, require: bool = True):
    """The shared hosting account of the current request's user on this VPS.
    Admins without their own account fall back to the first account (view only)."""
    acct = get_shared_account(vps['id'], current_user.id)
    if acct:
        return acct
    if getattr(current_user, 'is_admin', False):
        accounts = get_shared_accounts(vps['id'])
        return accounts[0] if accounts else None
    if require:
        abort(403)
    return None

def shared_node_op(vps: Dict, script: str, timeout: int = 300) -> Dict:
    """Run a shared hosting script on the VPS's node (local or remote)."""
    node = get_node(vps['node_id'])
    if not node:
        raise Exception("Node not found")
    return run_sync(shared_hosting.run(node, script, timeout=timeout))

def update_shared_account(account_id: int, **kwargs):
    with get_db() as conn:
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            fields.append(f"{key} = ?")
            values.append(value)
        if not fields:
            return
        values.append(account_id)
        cur.execute(f'UPDATE shared_accounts SET {", ".join(fields)} WHERE id = ?', values)
        conn.commit()

def shared_account_stats(vps: Dict, account: Dict) -> Dict:
    """Live usage for one shared hosting account (cached for ~60s)."""
    status = 'running'
    if is_vps_suspended(vps):
        status = 'suspended'
    elif account.get('status') == 'suspended':
        status = 'suspended'
    elif account.get('status') == 'stopped':
        status = 'stopped'

    disk_used_mb = float(account.get('disk_used_mb') or 0)
    ram_used_mb = float(account.get('ram_used_mb') or 0)
    cpu_used = float(account.get('cpu_used') or 0)
    procs = int(account.get('processes') or 0)

    # Refresh from the node at most once per minute (du can be slow on big homes)
    fresh = False
    if account.get('last_checked'):
        try:
            fresh = (datetime.now() - datetime.fromisoformat(account['last_checked'])).total_seconds() < 60
        except Exception:
            fresh = False

    if not fresh and status != 'suspended':
        try:
            result = shared_node_op(vps, shared_hosting.stats_script(account['system_user']), timeout=60)
            records = [r for r in result.get('records', []) if r and r[0] == 'stats']
            parsed = shared_hosting.stats_to_dict(records[0]) if records else None
            if parsed:
                disk_used_mb = parsed['disk_kb'] / 1024.0
                ram_used_mb = parsed['mem_kb'] / 1024.0
                cpu_used = parsed['cpu']
                procs = parsed['procs']
                update_shared_account(account['id'],
                                      disk_used_mb=disk_used_mb,
                                      ram_used_mb=ram_used_mb,
                                      cpu_used=cpu_used,
                                      processes=procs,
                                      last_checked=datetime.now().isoformat())
        except Exception as e:
            logger.warning(f"Shared stats error for {account.get('system_user')}: {e}")

    ram_limit = int(account.get('ram_mb') or 512)
    disk_limit = int(account.get('disk_gb') or 5)
    ram_pct = round(min(100.0, (ram_used_mb / ram_limit) * 100), 1) if ram_limit else 0.0
    disk_pct = round(min(100.0, (disk_used_mb / (disk_limit * 1024)) * 100), 1) if disk_limit else 0.0

    return {
        'status': status,
        'cpu': round(cpu_used, 1),
        'ram': {'used': round(ram_used_mb), 'total': ram_limit, 'pct': ram_pct},
        'disk': {
            'used': f"{disk_used_mb:.1f} MB" if disk_used_mb < 1024 else f"{disk_used_mb/1024:.2f} GB",
            'size': f"{disk_limit} GB",
            'use_percent': f"{disk_pct}%",
            'pct': disk_pct,
        },
        'uptime': 'Shared hosting' if status == 'running' else status.capitalize(),
        'processes': procs,
        'network': {},
    }

def shared_stats_for_user(vps: Dict, user_id: Optional[int] = None) -> Dict:
    """Stats for a shared VPS from the requesting user's perspective.
    Users see their OWN account usage; admins without an account see totals."""
    account = get_shared_account(vps['id'], user_id) if user_id else None
    if account:
        return shared_account_stats(vps, account)
    # Aggregate view (admin without own account)
    accounts = get_shared_accounts(vps['id'])
    if is_vps_suspended(vps):
        status = 'suspended'
    elif any(a.get('status') == 'active' for a in accounts):
        status = 'running'
    elif accounts and all(a.get('status') == 'suspended' for a in accounts):
        status = 'suspended'
    else:
        status = 'stopped'
    disk_mb = sum(float(a.get('disk_used_mb') or 0) for a in accounts)
    ram_mb = sum(float(a.get('ram_used_mb') or 0) for a in accounts)
    ram_limit = sum(int(a.get('ram_mb') or 0) for a in accounts)
    disk_limit = sum(int(a.get('disk_gb') or 0) for a in accounts)
    return {
        'status': status,
        'cpu': round(sum(float(a.get('cpu_used') or 0) for a in accounts), 1),
        'ram': {'used': round(ram_mb), 'total': ram_limit,
                'pct': round(min(100.0, (ram_mb / ram_limit) * 100), 1) if ram_limit else 0.0},
        'disk': {
            'used': f"{disk_mb/1024:.2f} GB",
            'size': f"{disk_limit} GB",
            'use_percent': f"{round(min(100.0, (disk_mb/(disk_limit*1024))*100), 1) if disk_limit else 0.0}%",
            'pct': round(min(100.0, (disk_mb/(disk_limit*1024))*100), 1) if disk_limit else 0.0,
        },
        'uptime': 'Shared hosting' if status == 'running' else status.capitalize(),
        'processes': sum(int(a.get('processes') or 0) for a in accounts),
        'network': {},
    }

def suspend_shared_account(account: Dict, reason: str, vps: Optional[Dict] = None, actor_id=None):
    """Lock a shared account, kill its processes and update the DB."""
    vps = vps or get_vps_by_id(account['vps_id'])
    try:
        shared_node_op(vps, shared_hosting.suspend_script(account['system_user']), timeout=120)
    except Exception as e:
        logger.warning(f"Could not lock shared account {account['system_user']}: {e}")
    update_shared_account(account['id'], status='suspended', suspended_reason=reason,
                          processes=0, ram_used_mb=0, cpu_used=0)
    try:
        create_notification(account['user_id'], 'warning', 'Shared Hosting Suspended',
                            f'Your account on {vps["container_name"]} was suspended: {reason}. '
                            f'An admin must resume it (reinstall removes files to free space).')
    except Exception:
        pass
    log_activity(actor_id, 'suspend_shared_account', 'vps', str(account['vps_id']),
                 {'system_user': account['system_user'], 'reason': reason})

def shared_quota_check():
    """Background quota enforcement: suspend accounts that exceed their
    RAM or disk limits. The rest of the shared VPS keeps running."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''SELECT sa.*, v.node_id, v.container_name, v.suspended AS vps_suspended
                           FROM shared_accounts sa
                           INNER JOIN vps v ON v.id = sa.vps_id
                           WHERE v.vps_type = 'shared' AND v.suspended = 0 AND sa.status = 'active' ''')
            rows = [dict(row) for row in cur.fetchall()]
    except Exception as e:
        logger.error(f"Shared quota check query error: {e}")
        return

    for row in rows:
        try:
            vps = get_vps_by_id(row['vps_id'])
            if not vps or is_vps_suspended(vps):
                continue
            account = get_shared_account_by_id(row['id'])
            if not account or account['status'] != 'active':
                continue
            result = shared_node_op(vps, shared_hosting.stats_script(account['system_user']), timeout=60)
            records = [r for r in result.get('records', []) if r and r[0] == 'stats']
            parsed = shared_hosting.stats_to_dict(records[0]) if records else None
            if not parsed:
                continue

            disk_used_mb = parsed['disk_kb'] / 1024.0
            ram_used_mb = parsed['mem_kb'] / 1024.0
            update_shared_account(account['id'],
                                  disk_used_mb=disk_used_mb,
                                  ram_used_mb=ram_used_mb,
                                  cpu_used=parsed['cpu'],
                                  processes=parsed['procs'],
                                  last_checked=datetime.now().isoformat())

            disk_limit_mb = int(account['disk_gb']) * 1024
            ram_limit_mb = int(account['ram_mb'])
            if parsed['locked'] == 'L':
                continue  # already suspended
            if disk_used_mb > disk_limit_mb:
                suspend_shared_account(account,
                                       f'Disk quota exceeded ({disk_used_mb/1024:.2f} GB of {account["disk_gb"]} GB)',
                                       vps=vps)
            elif ram_used_mb > ram_limit_mb * 1.1:
                suspend_shared_account(account,
                                       f'RAM limit exceeded ({ram_used_mb:.0f} MB of {account["ram_mb"]} MB)',
                                       vps=vps)
        except Exception as e:
            logger.error(f"Shared quota check error for account {row.get('system_user')}: {e}")

@app.context_processor
def utility_processor():
    return dict(
        now=datetime.now,
        get_current_vps_count=get_current_vps_count,
        get_setting=get_setting,
        theme_version=get_theme_version,
        ui_design=get_ui_design,
        ui_design_version=get_ui_design_version,
        login_cfg=get_login_view,
        login_design_version=get_login_design_version,
        main_cfg=get_main_view,
        build_main_css_preview=_main_preview_css,
        main_design_version=get_main_design_version,
        get_unread_notifications_count=get_unread_notifications_count,
        OS_ICONS=OS_ICONS,
        get_os_label=get_os_label,
        get_os_icon_name=get_os_icon_name,
        is_vps_suspended=is_vps_suspended,
        is_vps_whitelisted=is_vps_whitelisted,
        PANEL_VERSION=PANEL_VERSION,
        PANEL_NAME=PANEL_NAME,
        PANEL_DEVELOPER=PANEL_DEVELOPER
    )

def is_vps_suspended(vps):
    """Check if VPS is suspended. Handles both boolean and integer values."""
    suspended = vps.get("suspended", 0)
    # Handle both boolean (True/False) and integer (1/0) values
    if isinstance(suspended, bool):
        return suspended
    return int(suspended) == 1

def is_vps_whitelisted(vps):
    """Check if VPS is whitelisted. Handles both boolean and integer values."""
    whitelisted = vps.get("whitelisted", 0)
    # Handle both boolean (True/False) and integer (1/0) values
    if isinstance(whitelisted, bool):
        return whitelisted
    return int(whitelisted) == 1

def get_os_label(os_value):
    """Get OS label from OS value"""
    for os_option in OS_OPTIONS:
        if os_option["value"] == os_value:
            return os_option["label"]
    return os_value

def get_os_icon_name(os_value):
    """Get OS icon name from OS value"""
    for os_option in OS_OPTIONS:
        if os_option["value"] == os_value:
            return os_option.get("icon", "default")
    return "default"

def refresh_vps_status(vps_id):
    """Refresh VPS status from container and update database"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        return None
    
    # If suspended, don't check container status
    if is_vps_suspended(vps):
        return 'suspended'
    
    # Shared hosting servers have no container - status is panel-managed
    if is_shared_vps(vps):
        return vps.get('status', 'running')
    
    try:
        status = run_sync(get_container_status(vps['container_name'], vps['node_id']))
        if status != vps['status']:
            update_vps(vps_id, status=status)
        return status
    except Exception as e:
        logger.error(f"Error refreshing VPS {vps_id} status: {e}")
        return vps.get('status', 'unknown')

# ============================================================================
# IP Address and Alias Functions
# ============================================================================
def get_node_display_ip(node_id: int, use_alias: bool = True) -> Optional[str]:
    node = get_node(node_id)
    if not node:
        return None
    
    if use_alias and node['ip_aliases'] and len(node['ip_aliases']) > 0:
        return node['ip_aliases'][0]
    elif node['ip_addresses'] and len(node['ip_addresses']) > 0:
        return node['ip_addresses'][0]
    return None

def get_node_all_ips(node_id: int) -> List[Dict[str, str]]:
    node = get_node(node_id)
    if not node:
        return []
    
    ips = []
    for alias in node.get('ip_aliases', []):
        ips.append({'type': 'alias', 'value': alias})
    
    for ip in node.get('ip_addresses', []):
        ips.append({'type': 'ip', 'value': ip})
    
    return ips

def get_vps_display_ip(vps: Dict) -> Optional[str]:
    if vps.get('ip_alias'):
        return vps['ip_alias']
    return vps.get('ip_address')

def format_ip_for_display(ip: str, port: Optional[int] = None) -> str:
    if port:
        return f"{ip}:{port}"
    return ip

# ============================================================================
# Port forwarding functions
# ============================================================================
def get_user_allocation(user_id: int) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT allocated_ports FROM port_allocations WHERE user_id = ?', (user_id,))
        row = cur.fetchone()
        return row[0] if row else 0

def get_user_used_ports(user_id: int) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM port_forwards WHERE user_id = ?', (user_id,))
        row = cur.fetchone()
        return row[0] if row else 0

def allocate_ports(user_id: int, amount: int):
    now = datetime.now().isoformat()
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''INSERT OR REPLACE INTO port_allocations (user_id, allocated_ports, used_ports, updated_at)
                       VALUES (?, COALESCE((SELECT allocated_ports FROM port_allocations WHERE user_id = ?), 0) + ?, 
                               COALESCE((SELECT used_ports FROM port_allocations WHERE user_id = ?), 0), ?)''',
                    (user_id, user_id, amount, user_id, now))
        conn.commit()

def deallocate_ports(user_id: int, amount: int):
    now = datetime.now().isoformat()
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''UPDATE port_allocations 
                       SET allocated_ports = GREATEST(0, allocated_ports - ?),
                           updated_at = ?
                       WHERE user_id = ?''',
                    (amount, now, user_id))
        conn.commit()

def get_available_host_port(node_id: int) -> Optional[int]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT host_port FROM port_forwards WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)',
                    (node_id,))
        used_ports = set(row[0] for row in cur.fetchall())
    
    for _ in range(100):
        port = random.randint(20000, 50000)
        if port not in used_ports:
            return port
    return None

async def create_port_forward(user_id: int, container: str, vps_port: int, node_id: int,
                              protocol: str = 'tcp,udp', description: str = '') -> Optional[int]:
    host_port = get_available_host_port(node_id)
    if not host_port:
        return None
    
    try:
        if 'tcp' in protocol:
            await execute_lxc(container, f"config device add {container} tcp_proxy_{host_port} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_port}", node_id=node_id)
        
        if 'udp' in protocol:
            await execute_lxc(container, f"config device add {container} udp_proxy_{host_port} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_port}", node_id=node_id)
        
        now = datetime.now().isoformat()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO port_forwards 
                (user_id, vps_container, vps_port, host_port, protocol, description, created_at, last_used, hits)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (user_id, container, vps_port, host_port, protocol, description, now, now, 0))
            conn.commit()
            
            cur.execute('UPDATE port_allocations SET used_ports = used_ports + 1, updated_at = ? WHERE user_id = ?',
                       (now, user_id))
            conn.commit()
        
        log_activity(user_id, 'create_port_forward', 'port', str(host_port),
                    {'container': container, 'vps_port': vps_port, 'host_port': host_port, 'protocol': protocol})
        create_notification(user_id, 'success', 'Port Forward Created', 
                          f'Port {vps_port} forwarded to port {host_port} on {container}')
        
        if socketio:
            socketio.emit('port_forward_created', {
                'host_port': host_port,
                'vps_port': vps_port,
                'container': container
            }, room=f'user_{user_id}')
        
        return host_port
    except Exception as e:
        logger.error(f"Failed to create port forward: {e}")
        return None

async def remove_port_forward(forward_id: int) -> Tuple[bool, Optional[int]]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT user_id, vps_container, host_port, protocol FROM port_forwards WHERE id = ?', (forward_id,))
        row = cur.fetchone()
        if not row:
            return False, None
        user_id, container, host_port, protocol = row
    
    node_id = find_node_id_for_container(container)
    try:
        if 'tcp' in protocol:
            try:
                await execute_lxc(container, f"config device remove {container} tcp_proxy_{host_port}", node_id=node_id)
            except:
                pass
        
        if 'udp' in protocol:
            try:
                await execute_lxc(container, f"config device remove {container} udp_proxy_{host_port}", node_id=node_id)
            except:
                pass
        
        now = datetime.now().isoformat()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('DELETE FROM port_forwards WHERE id = ?', (forward_id,))
            conn.commit()
            
            cur.execute('UPDATE port_allocations SET used_ports = used_ports - 1, updated_at = ? WHERE user_id = ?',
                       (now, user_id))
            conn.commit()
        
        log_activity(user_id, 'remove_port_forward', 'port', str(host_port))
        create_notification(user_id, 'info', 'Port Forward Removed', f'Port forward {host_port} has been removed.')
        
        if socketio:
            socketio.emit('port_forward_removed', {
                'host_port': host_port,
                'container': container
            }, room=f'user_{user_id}')
        
        return True, user_id
    except Exception as e:
        logger.error(f"Failed to remove port forward {forward_id}: {e}")
        return False, None

def get_user_forwards(user_id: int) -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM port_forwards WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        rows = cur.fetchall()
        return [dict(row) for row in rows]

async def recreate_port_forwards(container_name: str) -> int:
    node_id = find_node_id_for_container(container_name)
    readded_count = 0
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT vps_port, host_port, protocol FROM port_forwards WHERE vps_container = ?', (container_name,))
        rows = cur.fetchall()
    
    for row in rows:
        vps_port, host_port, protocol = row['vps_port'], row['host_port'], row['protocol']
        try:
            if 'tcp' in protocol:
                await execute_lxc(container_name, f"config device add {container_name} tcp_proxy_{host_port} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_port}", node_id=node_id)
            if 'udp' in protocol:
                await execute_lxc(container_name, f"config device add {container_name} udp_proxy_{host_port} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_port}", node_id=node_id)
            logger.info(f"Re-added port forward {host_port}->{vps_port} for {container_name}")
            readded_count += 1
        except Exception as e:
            logger.error(f"Failed to re-add port forward {host_port}->{vps_port} for {container_name}: {e}")
    
    return readded_count

async def update_port_forward_hit(host_port: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE port_forwards SET hits = hits + 1, last_used = ? WHERE host_port = ?',
                   (datetime.now().isoformat(), host_port))
        conn.commit()

def relativeTime(dt):
    if not dt:
        return "Never"

    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except:
            return "Invalid date"

    now = datetime.now()
    diff = now - dt

    seconds = int(diff.total_seconds())

    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        return f"{seconds // 60} minutes ago"
    elif seconds < 86400:
        return f"{seconds // 3600} hours ago"
    elif seconds < 604800:
        return f"{seconds // 86400} days ago"
    else:
        return dt.strftime("%Y-%m-%d")

# ============================================================================
# Host resource functions
# ============================================================================
def get_host_cpu_usage():
    """Get host CPU usage with multiple fallback methods"""
    try:
        # Method 1: Try psutil first (most reliable)
        try:
            import psutil
            cpu_percent = psutil.cpu_percent(interval=0.5)
            if cpu_percent is not None:
                return float(cpu_percent)
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"psutil CPU method failed: {e}")
        
        # Method 2: Try mpstat
        if shutil.which("mpstat"):
            try:
                result = subprocess.run(['mpstat', '1', '1'], capture_output=True, text=True, timeout=3)
                if result.returncode == 0:
                    output = result.stdout
                    for line in output.split('\n'):
                        if 'all' in line.lower() and '%' in line:
                            parts = line.split()
                            # Find idle column (usually last)
                            for i, part in enumerate(parts):
                                if 'idle' in part.lower():
                                    try:
                                        idle = float(parts[i+1] if i+1 < len(parts) else parts[-1])
                                        return max(0.0, min(100.0, 100.0 - idle))
                                    except:
                                        pass
                            # Fallback: assume last column is idle
                            try:
                                idle = float(parts[-1])
                                return max(0.0, min(100.0, 100.0 - idle))
                            except:
                                pass
            except Exception as e:
                logger.debug(f"mpstat method failed: {e}")
        
        # Method 3: Try /proc/stat with sampling
        try:
            def get_cpu_times():
                with open('/proc/stat', 'r') as f:
                    line = f.readline()
                    values = [float(x) for x in line.split()[1:8]]  # Get first 7 values
                    return values
            
            times1 = get_cpu_times()
            time.sleep(0.5)
            times2 = get_cpu_times()
            
            # Calculate deltas
            deltas = [times2[i] - times1[i] for i in range(len(times1))]
            total_delta = sum(deltas)
            
            if total_delta > 0:
                # idle is index 3
                idle_delta = deltas[3]
                cpu_usage = 100.0 * (total_delta - idle_delta) / total_delta
                return max(0.0, min(100.0, cpu_usage))
        except Exception as e:
            logger.debug(f"/proc/stat method failed: {e}")
        
        # Method 4: Try top command
        try:
            result = subprocess.run(['top', '-bn1'], capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'Cpu' in line or 'CPU' in line:
                        # Look for idle percentage
                        import re
                        idle_match = re.search(r'(\d+\.?\d*)\s*%?\s*id', line)
                        if idle_match:
                            idle = float(idle_match.group(1))
                            return max(0.0, min(100.0, 100.0 - idle))
        except Exception as e:
            logger.debug(f"top method failed: {e}")
        
        logger.warning("All CPU usage methods failed, returning 0.0")
        return 0.0
        
    except Exception as e:
        logger.error(f"Error getting CPU usage: {e}")
        return 0.0

def get_host_ram_usage():
    """Get host RAM usage with multiple fallback methods"""
    try:
        # Method 1: Try psutil first (most reliable)
        try:
            import psutil
            mem = psutil.virtual_memory()
            return {
                'total': mem.total // (1024**2),
                'used': mem.used // (1024**2),
                'free': mem.available // (1024**2),
                'percent': float(mem.percent)
            }
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"psutil RAM method failed: {e}")
        
        # Method 2: Try free command
        try:
            result = subprocess.run(['free', '-m'], capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()
                if len(lines) > 1:
                    mem = lines[1].split()
                    total = int(mem[1])
                    used = int(mem[2])
                    if total > 0:
                        return {
                            'total': total,
                            'used': used,
                            'free': total - used,
                            'percent': float((used / total * 100))
                        }
        except Exception as e:
            logger.debug(f"free command method failed: {e}")
        
        # Method 3: Try /proc/meminfo
        try:
            with open('/proc/meminfo', 'r') as f:
                meminfo = {}
                for line in f:
                    parts = line.split(':')
                    if len(parts) == 2:
                        key = parts[0].strip()
                        value = parts[1].strip().split()[0]
                        meminfo[key] = int(value)
                
                total = meminfo.get('MemTotal', 0) // 1024
                free = meminfo.get('MemFree', 0) // 1024
                buffers = meminfo.get('Buffers', 0) // 1024
                cached = meminfo.get('Cached', 0) // 1024
                
                if total > 0:
                    available = free + buffers + cached
                    used = total - available
                    return {
                        'total': total,
                        'used': used,
                        'free': available,
                        'percent': float((used / total * 100))
                    }
        except Exception as e:
            logger.debug(f"/proc/meminfo method failed: {e}")
        
        logger.warning("All RAM usage methods failed, returning zeros")
        return {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}
        
    except Exception as e:
        logger.error(f"Error getting RAM usage: {e}")
        return {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}
    except Exception as e:
        logger.error(f"Error getting RAM usage: {e}")
        return {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}

def get_host_disk_usage():
    """Get host disk usage with multiple fallback methods"""
    try:
        # Method 1: Try psutil first (most reliable and cross-platform)
        try:
            import psutil
            usage = psutil.disk_usage('/')
            return {
                'total': f"{usage.total / (1024**3):.1f}G",
                'used': f"{usage.used / (1024**3):.1f}G",
                'free': f"{usage.free / (1024**3):.1f}G",
                'percent': f"{usage.percent:.0f}%"
            }
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"psutil disk method failed: {e}")
        
        # Method 2: Try shutil.disk_usage (Python built-in)
        try:
            import shutil
            usage = shutil.disk_usage('/')
            total_gb = usage.total / (1024**3)
            used_gb = usage.used / (1024**3)
            free_gb = usage.free / (1024**3)
            percent = (usage.used / usage.total * 100) if usage.total > 0 else 0
            return {
                'total': f"{total_gb:.1f}G",
                'used': f"{used_gb:.1f}G",
                'free': f"{free_gb:.1f}G",
                'percent': f"{percent:.0f}%"
            }
        except Exception as e:
            logger.debug(f"shutil disk method failed: {e}")
        
        # Method 3: Try df command
        try:
            result = subprocess.run(['df', '-h', '/'], capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()
                if len(lines) > 1:
                    parts = lines[1].split()
                    if len(parts) >= 5:
                        return {
                            'total': parts[1],
                            'used': parts[2],
                            'free': parts[3],
                            'percent': parts[4]
                        }
        except Exception as e:
            logger.debug(f"df command method failed: {e}")
        
        # Method 4: Try /proc/mounts and statvfs
        try:
            import os
            stat = os.statvfs('/')
            total = stat.f_blocks * stat.f_frsize
            free = stat.f_bavail * stat.f_frsize
            used = total - free
            
            total_gb = total / (1024**3)
            used_gb = used / (1024**3)
            free_gb = free / (1024**3)
            percent = (used / total * 100) if total > 0 else 0
            
            return {
                'total': f"{total_gb:.1f}G",
                'used': f"{used_gb:.1f}G",
                'free': f"{free_gb:.1f}G",
                'percent': f"{percent:.0f}%"
            }
        except Exception as e:
            logger.debug(f"statvfs method failed: {e}")
        
        logger.warning("All disk usage methods failed, returning Unknown")
        return {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}
        
    except Exception as e:
        logger.error(f"Error getting disk usage: {e}")
        return {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}

def get_host_uptime():
    try:
        with open('/proc/uptime', 'r') as f:
            uptime_seconds = float(f.readline().split()[0])
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            return f"{days}d {hours}h {minutes}m"
    except:
        return "Unknown"

async def get_host_stats(node_id: int) -> Dict:
    """Get host statistics with improved error handling and caching"""
    node = get_node(node_id)
    if not node:
        logger.warning(f"Node {node_id} not found")
        return {
            "cpu": 0.0, 
            "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
            "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
            "uptime": "Unknown"
        }
    
    if node['is_local']:
        try:
            stats = {
                "cpu": get_host_cpu_usage(),
                "ram": get_host_ram_usage(),
                "disk": get_host_disk_usage(),
                "uptime": get_host_uptime()
            }
            logger.debug(f"Local node {node_id} stats: CPU={stats['cpu']:.1f}%, RAM={stats['ram']['percent']:.1f}%")
            return stats
        except Exception as e:
            logger.error(f"Error getting local node stats: {e}", exc_info=True)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }
    else:
        try:
            import requests
            url = f"{node['url']}/api/host/stats"
            headers = {"X-API-Key": node["api_key"]}
            verify_ssl = bool(node.get('verify_ssl', 1))
            
            logger.debug(f"Fetching stats from remote node {node['name']}: {url} (verify_ssl={verify_ssl})")
            response = requests.get(url, headers=headers, timeout=10, verify=verify_ssl)
            response.raise_for_status()
            stats = response.json()
            
            logger.debug(f"Remote node {node['name']} stats received: {stats}")
            
            # Update node info in database
            try:
                with get_db() as conn:
                    cur = conn.cursor()
                    cur.execute('''UPDATE nodes SET 
                                  status = ?, 
                                  last_seen = ?, 
                                  cpu_cores = ?, 
                                  ram_total = ?, 
                                  disk_total = ? 
                                  WHERE id = ?''',
                               ('online', 
                                datetime.now().isoformat(), 
                                stats.get('cpu_cores', 0), 
                                stats.get('ram', {}).get('total', 0),
                                stats.get('disk', {}).get('total_gb', 0), 
                                node_id))
                    conn.commit()
            except Exception as db_err:
                logger.error(f"Failed to update node {node_id} in database: {db_err}")
            
            return stats
            
        except requests.exceptions.Timeout:
            logger.warning(f"Timeout connecting to node {node['name']}")
            mark_node_offline(node_id)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }
        except requests.exceptions.ConnectionError:
            logger.warning(f"Connection error to node {node['name']}")
            mark_node_offline(node_id)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }
        except Exception as e:
            logger.error(f"Failed to get host stats from node {node['name']}: {e}", exc_info=True)
            mark_node_offline(node_id)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }

def mark_node_offline(node_id: int):
    """Helper function to mark a node as offline"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?',
                       ('offline', datetime.now().isoformat(), node_id))
            conn.commit()
    except Exception as e:
        logger.error(f"Failed to mark node {node_id} offline: {e}")

async def get_node_status(node_id: int) -> Dict:
    """Get node status with improved error handling"""
    node = get_node(node_id)
    if not node:
        logger.warning(f"Node {node_id} not found for status check")
        return {"status": "❓ Unknown", "online": False}
    
    if node['is_local']:
        try:
            stats = await get_host_stats(node_id)
            return {
                "status": "🟢 Online (Local)",
                "online": True,
                "local": True,
                "last_seen": datetime.now().isoformat(),
                "stats": stats
            }
        except Exception as e:
            logger.error(f"Error getting local node status: {e}")
            return {
                "status": "⚠️ Error",
                "online": False,
                "local": True,
                "last_seen": datetime.now().isoformat()
            }
    
    try:
        import requests
        headers = {"X-API-Key": node['api_key']}
        verify_ssl = bool(node.get('verify_ssl', 1))
        
        logger.debug(f"Pinging remote node {node['name']}: {node['url']}/api/ping (verify_ssl={verify_ssl})")
        response = requests.get(f"{node['url']}/api/ping", headers=headers, timeout=5, verify=verify_ssl)
        
        if response.status_code == 200:
            data = response.json()
            now = datetime.now().isoformat()
            
            try:
                with get_db() as conn:
                    cur = conn.cursor()
                    cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?',
                               ('online', now, node_id))
                    conn.commit()
            except Exception as db_err:
                logger.error(f"Failed to update node {node_id} status in database: {db_err}")
            
            stats = await get_host_stats(node_id)
            return {
                "status": "🟢 Online",
                "online": True,
                "local": False,
                "last_seen": now,
                "stats": stats,
                "ping_time": data.get('time')
            }
        else:
            logger.warning(f"Node {node['name']} returned status {response.status_code}")
            mark_node_offline(node_id)
            return {
                "status": "🔴 Offline",
                "online": False,
                "local": False,
                "last_seen": node.get('last_seen')
            }
            
    except requests.exceptions.Timeout:
        logger.warning(f"Timeout pinging node {node['name']}")
        mark_node_offline(node_id)
        return {
            "status": "⏱️ Timeout",
            "online": False,
            "local": False,
            "last_seen": node.get('last_seen')
        }
    except requests.exceptions.ConnectionError:
        logger.warning(f"Connection error to node {node['name']}")
        mark_node_offline(node_id)
        return {
            "status": "🔴 Offline",
            "online": False,
            "local": False,
            "last_seen": node.get('last_seen')
        }
    except Exception as e:
        logger.error(f"Failed to ping node {node['name']}: {e}", exc_info=True)
        mark_node_offline(node_id)
        return {
            "status": "❌ Error",
            "online": False,
            "local": False,
            "last_seen": node.get('last_seen'),
            "error": str(e)
        }

# ============================================================================
# Container stats functions
# ============================================================================
async def get_container_status(container_name: str, node_id: Optional[int] = None) -> str:
    """Get container status with improved error handling"""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    
    try:
        result = await execute_lxc(container_name, f"info {container_name}", node_id=node_id, timeout=5)
        for line in result.split('\n'):
            if line.startswith("Status: "):
                status = line.split(": ", 1)[1].strip().lower()
                logger.debug(f"Container {container_name} status: {status}")
                return status
        logger.warning(f"Status line not found for container {container_name}")
        return "unknown"
    except Exception as e:
        logger.error(f"Error getting status for {container_name}: {e}")
        return "unknown"

async def get_container_stats(container_name: str, node_id: Optional[int] = None) -> Dict:
    """Get container statistics with improved error handling and data transformation"""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    
    node = get_node(node_id)
    if not node:
        logger.warning(f"Node {node_id} not found for container {container_name}")
        return {
            "status": "unknown", 
            "cpu": 0.0, 
            "ram": {"used": 0, "total": 0, "pct": 0.0}, 
            "disk": {"use_percent": "0%"}, 
            "uptime": "Unknown"
        }
    
    if node['is_local']:
        try:
            status = await get_container_status(container_name, node_id)
            
            # Only get detailed stats if container is running
            if status == "running":
                cpu = await get_container_cpu_pct_local(container_name, node_id)
                ram = await get_container_ram_local(container_name, node_id)
                disk = await get_container_disk_local(container_name, node_id)
                uptime = await get_container_uptime_local(container_name, node_id)
                processes = await get_container_processes_local(container_name, node_id)
                network = await get_container_network_local(container_name, node_id)
            else:
                cpu = 0.0
                ram = {"used": 0, "total": 0, "pct": 0.0}
                disk = {"use_percent": "0%"}
                uptime = "Stopped"
                processes = 0
                network = {}
            
            return {
                "status": status,
                "cpu": cpu,
                "ram": ram,
                "disk": disk,
                "uptime": uptime,
                "processes": processes,
                "network": network
            }
        except Exception as e:
            logger.error(f"Error getting local container stats for {container_name}: {e}", exc_info=True)
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }
    else:
        try:
            import requests
            url = f"{node['url']}/api/container/stats"
            data = {"container": container_name}
            headers = {"X-API-Key": node["api_key"]}
            verify_ssl = bool(node.get('verify_ssl', 1))
            
            logger.debug(f"Fetching container stats from {node['name']}: {url} (verify_ssl={verify_ssl})")
            response = requests.post(url, json=data, headers=headers, timeout=10, verify=verify_ssl)
            response.raise_for_status()
            stats = response.json()
            
            # Transform the response to match expected format
            # Node agent returns 'percent' but we need 'pct' for consistency
            ram_data = stats.get("ram", {"used": 0, "total": 0, "percent": 0.0})
            if isinstance(ram_data, dict):
                if "percent" in ram_data and "pct" not in ram_data:
                    ram_data["pct"] = ram_data["percent"]
                if "pct" not in ram_data:
                    ram_data["pct"] = 0.0
            else:
                ram_data = {"used": 0, "total": 0, "pct": 0.0}
            
            # Transform disk data - node returns string like "2G/10G (20%)"
            # We need dict with use_percent field
            disk_data = stats.get("disk", "Unknown")
            if isinstance(disk_data, str):
                if disk_data in ["Unknown", "Stopped", "N/A"]:
                    disk_data = {
                        "size": "Unknown",
                        "used": "Unknown",
                        "available": "Unknown",
                        "use_percent": "0%"
                    }
                else:
                    # Parse format like "2G/10G (20%)"
                    import re
                    match = re.match(r'(.+?)/(.+?)\s*\((.+?)\)', disk_data)
                    if match and re.fullmatch(r'\s*\d+(\.\d+)?\s*%\s*', match.group(3)):
                        used, total, percent = match.groups()
                        disk_data = {
                            "size": total.strip(),
                            "used": used.strip(),
                            "available": "Unknown",
                            "use_percent": percent.strip(),
                            "pct": float(percent.strip().rstrip('%'))
                        }
                    else:
                        disk_data = {
                            "size": "Unknown",
                            "used": "Unknown",
                            "available": "Unknown",
                            "use_percent": "0%"
                        }
            elif not isinstance(disk_data, dict):
                disk_data = {"use_percent": "0%"}
            
            # Ensure use_percent + pct exist
            disk_data = normalize_disk(disk_data)
            
            return {
                "status": stats.get("status", "unknown"),
                "cpu": float(stats.get("cpu", 0.0)),
                "ram": ram_data,
                "disk": disk_data,
                "uptime": stats.get("uptime", "Unknown"),
                "processes": stats.get("processes", 0),
                "network": stats.get("network", {})
            }
            
        except requests.exceptions.Timeout:
            logger.warning(f"Timeout getting container stats from node {node['name']}")
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }
        except requests.exceptions.ConnectionError:
            logger.warning(f"Connection error getting container stats from node {node['name']}")
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }
        except Exception as e:
            logger.error(f"Failed to get container stats from node {node['name']}: {e}", exc_info=True)
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }

async def get_container_cpu_pct_local(container_name: str, node_id: int) -> float:
    """Get container CPU usage - simplified and reliable method"""
    try:
        # Method 1: Simple sh script with /proc/stat sampling (most compatible)
        simple_script = r"""sh -c '
cat /proc/stat | grep "^cpu " > /tmp/cpu1
sleep 1
cat /proc/stat | grep "^cpu " > /tmp/cpu2
awk "{
    getline < \"/tmp/cpu1\"
    u1=\$2; n1=\$3; s1=\$4; i1=\$5
    getline < \"/tmp/cpu2\"
    u2=\$2; n2=\$3; s2=\$4; i2=\$5
    total=(u2-u1)+(n2-n1)+(s2-s1)+(i2-i1)
    used=(u2-u1)+(n2-n1)+(s2-s1)
    if(total>0) print (used*100)/total; else print 0
}" /tmp/cpu2
rm -f /tmp/cpu1 /tmp/cpu2
'"""
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- {simple_script}", node_id=node_id)
            cpu_pct = float(result.strip())
            if 0 <= cpu_pct <= 100:
                logger.debug(f"CPU for {container_name}: {cpu_pct}%")
                return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"Simple sh script failed for {container_name}: {e}")
        
        # Method 2: Even simpler - just use top with proper parsing
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'top -bn1 | grep \"Cpu(s)\"'", node_id=node_id)
            if result:
                # Parse output like: %Cpu(s):  2.3 us,  1.2 sy,  0.0 ni, 96.5 id
                import re
                # Look for idle percentage
                idle_match = re.search(r'(\d+\.?\d*)\s*id', result)
                if idle_match:
                    idle = float(idle_match.group(1))
                    cpu_pct = 100.0 - idle
                    logger.debug(f"CPU for {container_name} (top): {cpu_pct}%")
                    return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"Top method failed for {container_name}: {e}")
        
        # Method 3: Use vmstat if available
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'vmstat 1 2 | tail -1'", node_id=node_id)
            if result:
                parts = result.split()
                if len(parts) >= 15:
                    # vmstat output: idle is usually column 15 (0-indexed: 14)
                    idle = float(parts[14])
                    cpu_pct = 100.0 - idle
                    logger.debug(f"CPU for {container_name} (vmstat): {cpu_pct}%")
                    return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"vmstat method failed for {container_name}: {e}")
        
        # Method 4: Direct /proc/stat read with inline calculation
        try:
            result = await execute_lxc(container_name, 
                f"exec {container_name} -- sh -c 'grep \"^cpu \" /proc/stat && sleep 1 && grep \"^cpu \" /proc/stat'", 
                node_id=node_id)
            
            lines = [line for line in result.split('\n') if line.startswith('cpu ')]
            if len(lines) >= 2:
                # Parse first reading
                fields1 = [int(x) for x in lines[0].split()[1:8]]
                total1 = sum(fields1)
                idle1 = fields1[3]
                
                # Parse second reading
                fields2 = [int(x) for x in lines[1].split()[1:8]]
                total2 = sum(fields2)
                idle2 = fields2[3]
                
                # Calculate delta
                total_delta = total2 - total1
                idle_delta = idle2 - idle1
                
                if total_delta > 0:
                    cpu_pct = 100.0 * (total_delta - idle_delta) / total_delta
                    logger.debug(f"CPU for {container_name} (/proc/stat): {cpu_pct}%")
                    return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"/proc/stat method failed for {container_name}: {e}")
        
        logger.warning(f"All CPU detection methods failed for {container_name}, returning 0")
        return 0.0
        
    except Exception as e:
        logger.error(f"Error getting CPU for {container_name}: {e}")
        return 0.0
        logger.error(f"Error getting CPU for {container_name}: {e}")
        return 0.0

async def get_container_ram_local(container_name: str, node_id: int) -> Dict:
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- free -m", node_id=node_id)
        lines = result.split('\n')
        if len(lines) > 1:
            parts = lines[1].split()
            total = int(parts[1])
            used = int(parts[2])
            free = int(parts[3])
            pct = (used / total * 100) if total > 0 else 0.0
            return {'used': used, 'total': total, 'free': free, 'pct': pct}
        return {'used': 0, 'total': 0, 'free': 0, 'pct': 0.0}
    except Exception as e:
        logger.error(f"Error getting RAM for {container_name}: {e}")
        return {'used': 0, 'total': 0, 'free': 0, 'pct': 0.0}

def _fmt_bytes(n: float) -> str:
    """Bytes -> short human string (4.1G, 512M ...)."""
    n = float(n)
    for unit in ("B", "K", "M", "G", "T", "P"):
        if n < 1024 or unit == "P":
            return f"{n:.0f}{unit}" if (unit in ("B", "K") or n >= 100) else f"{n:.1f}{unit}"
        n /= 1024.0
    return f"{n:.1f}P"

def _parse_df_bytes(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse `df -P -B1 /` output. Works even when the filesystem name is long
    (e.g. quota/containers/vps-1228009218951610429-91694) and df wraps it onto its own line.
    Always reads the LAST 5 numeric-ish columns instead of trusting column positions.
    """
    if not text or not isinstance(text, str):
        return None
    lines = [l for l in text.strip().splitlines() if l.strip()]
    if len(lines) < 2:
        return None
    # join wrapped lines: everything after the header is one record
    tokens = " ".join(lines[1:]).split()
    if len(tokens) < 6:
        return None
    filesystem, size, used, avail, usep, mount = tokens[0], tokens[-5], tokens[-4], tokens[-3], tokens[-2], tokens[-1]
    try:
        size_b, used_b, avail_b = float(size), float(used), float(avail)
    except ValueError:
        return None
    if size_b <= 0:
        return None
    pct = round(used_b / size_b * 100.0, 1)
    return {
        "filesystem": filesystem,
        "size": _fmt_bytes(size_b),
        "used": _fmt_bytes(used_b),
        "available": _fmt_bytes(avail_b),
        "size_gb": round(size_b / 1024 ** 3, 2),
        "used_gb": round(used_b / 1024 ** 3, 2),
        "available_gb": round(avail_b / 1024 ** 3, 2),
        "use_percent": f"{pct:.0f}%",
        "pct": pct,
        "mounted": mount,
    }

def normalize_disk(disk_data: Any) -> Dict[str, Any]:
    """Make sure the disk dict always has size/used/available/use_percent AND pct (templates use both)."""
    if not isinstance(disk_data, dict):
        disk_data = {}
    d = dict(disk_data)
    up = str(d.get("use_percent", "") or "").strip()
    if "pct" not in d:
        try:
            d["pct"] = float(up.rstrip("%"))
        except ValueError:
            d["pct"] = 0.0
    if not up or up == "Unknown":
        d["use_percent"] = f"{float(d['pct']):.0f}%"
    return d

_DIR_DISK_CACHE: Dict[str, Tuple[float, Dict[str, Any]]] = {}

async def _dir_pool_disk(container_name: str, node_id: int) -> Optional[Dict[str, Any]]:
    """
    Disk numbers for pools that cannot enforce a size (driver "dir", e.g. a node that is itself a
    container / has no loop devices). Inside the VPS `df` then shows the HOST's disk, so instead we
    report: total = the size assigned to the VPS, used = what this VPS's rootfs really occupies.
    Returns None when the pool is not a dir pool (normal df is correct there).
    """
    cached = _DIR_DISK_CACHE.get(container_name)
    if cached and time.time() - cached[0] < 45:
        return cached[1]
    try:
        cfg = await execute_lxc(container_name, f"config show {container_name} --expanded", node_id=node_id, timeout=30)
        if not isinstance(cfg, str):
            return None
        m = re.search(r'^\s{2}root:\s*\n((?:\s{4}.*\n)+)', cfg + "\n", re.M)
        if not m:
            return None
        block = m.group(1)
        pool_m = re.search(r'pool:\s*(\S+)', block)
        size_m = re.search(r'size:\s*(\S+)', block)
        if not pool_m or not size_m:
            return None
        pool = pool_m.group(1)
        total_b = _size_to_gib(size_m.group(1)) * (1024 ** 3)
        if total_b <= 0:
            return None

        pinfo = await execute_lxc('', f"storage show {pool}", node_id=node_id, timeout=30)
        if not isinstance(pinfo, str):
            return None
        drv_m = re.search(r'^driver:\s*(\S+)\s*$', pinfo, re.M)
        src_m = re.search(r'^\s*source:\s*(\S+)', pinfo, re.M)
        if not drv_m or drv_m.group(1) not in ("dir", "btrfs") or not src_m:
            return None
        base = src_m.group(1)
        if drv_m.group(1) == "btrfs" and "/disks/" in base:
            # loop-backed pool: the mounted pool lives in <lxd>/storage-pools/<pool>
            base = base.split("/disks/")[0] + "/storage-pools/" + pool
        rootfs = os.path.join(base, "containers", container_name)
        if not os.path.isdir(rootfs):
            return None

        proc = await asyncio.create_subprocess_exec(
            "du", "-sxb", rootfs, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=40)
        used_b = float(out.decode().split()[0])

        pct = round(min(used_b / total_b * 100.0, 100.0), 1)
        res = {
            "filesystem": f"{pool} (allocated)",
            "size": _fmt_bytes(total_b),
            "used": _fmt_bytes(used_b),
            "available": _fmt_bytes(max(total_b - used_b, 0)),
            "size_gb": round(total_b / 1024 ** 3, 2),
            "used_gb": round(used_b / 1024 ** 3, 2),
            "available_gb": round(max(total_b - used_b, 0) / 1024 ** 3, 2),
            "use_percent": f"{pct:.0f}%",
            "pct": pct,
            "mounted": "/",
            "soft_limit": True,
        }
        _DIR_DISK_CACHE[container_name] = (time.time(), res)
        return res
    except Exception as e:
        logger.debug(f"dir-pool disk measure failed for {container_name}: {e}")
        return None

async def get_container_disk_local(container_name: str, node_id: int) -> Dict:
    unknown = {"size": "Unknown", "used": "Unknown", "available": "Unknown",
               "use_percent": "0%", "pct": 0.0}
    try:
        dir_disk = await _dir_pool_disk(container_name, node_id)
        if dir_disk:
            return dir_disk
        # -P = POSIX output (never wraps long filesystem names), -B1 = exact bytes
        result = await execute_lxc(container_name, f"exec {container_name} -- df -P -B1 /", node_id=node_id)
        parsed = _parse_df_bytes(result if isinstance(result, str) else "")
        if parsed:
            return parsed

        # fallback: human readable POSIX output
        result = await execute_lxc(container_name, f"exec {container_name} -- df -hP /", node_id=node_id)
        lines = [l for l in (result if isinstance(result, str) else "").strip().splitlines() if l.strip()]
        if len(lines) >= 2:
            t = " ".join(lines[1:]).split()
            if len(t) >= 6:
                pct = float(t[-2].rstrip("%") or 0)
                return {"filesystem": t[0], "size": t[-5], "used": t[-4], "available": t[-3],
                        "use_percent": t[-2], "pct": pct, "mounted": t[-1]}
        return unknown
    except Exception as e:
        logger.error(f"Error getting disk for {container_name}: {e}")
        return unknown

async def get_container_uptime_local(container_name: str, node_id: int) -> str:
    """Get container uptime with improved parsing"""
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- uptime -p", node_id=node_id, timeout=3)
        if result and result.strip():
            return result.strip()
    except Exception as e:
        logger.debug(f"uptime -p failed for {container_name}: {e}")
    
    # Fallback to regular uptime
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- uptime", node_id=node_id, timeout=3)
        if result and result.strip():
            return result.strip()
    except Exception as e:
        logger.debug(f"uptime failed for {container_name}: {e}")
    
    # Fallback to /proc/uptime
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- cat /proc/uptime", node_id=node_id, timeout=3)
        if result:
            uptime_seconds = float(result.split()[0])
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            
            parts = []
            if days > 0:
                parts.append(f"{days}d")
            if hours > 0:
                parts.append(f"{hours}h")
            if minutes > 0 or not parts:
                parts.append(f"{minutes}m")
            
            return " ".join(parts)
    except Exception as e:
        logger.debug(f"/proc/uptime failed for {container_name}: {e}")
    
    logger.warning(f"All uptime methods failed for {container_name}")
    return "Unknown"

async def get_container_processes_local(container_name: str, node_id: int) -> int:
    """Get container process count with improved error handling"""
    try:
        # Method 1: ps aux | wc -l
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'ps aux | wc -l'", node_id=node_id, timeout=3)
        if result and result.strip().isdigit():
            # Subtract 1 for header line
            count = int(result.strip()) - 1
            return max(0, count)
    except Exception as e:
        logger.debug(f"ps aux method failed for {container_name}: {e}")
    
    # Method 2: ps -e | wc -l
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'ps -e | wc -l'", node_id=node_id, timeout=3)
        if result and result.strip().isdigit():
            count = int(result.strip()) - 1
            return max(0, count)
    except Exception as e:
        logger.debug(f"ps -e method failed for {container_name}: {e}")
    
    # Method 3: Count /proc directories
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'ls -d /proc/[0-9]* | wc -l'", node_id=node_id, timeout=3)
        if result and result.strip().isdigit():
            return int(result.strip())
    except Exception as e:
        logger.debug(f"/proc count method failed for {container_name}: {e}")
    
    logger.warning(f"All process count methods failed for {container_name}")
    return 0

async def get_container_network_local(container_name: str, node_id: int) -> Dict:
    """Get container network information with improved parsing"""
    ips = []
    
    try:
        # Method 1: ip addr show
        result = await execute_lxc(container_name, f"exec {container_name} -- ip addr show", node_id=node_id, timeout=3)
        if result:
            for line in result.split('\n'):
                if 'inet ' in line and '127.0.0.1' not in line:
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        ip = parts[1].split('/')[0]
                        if ip not in ips:
                            ips.append(ip)
    except Exception as e:
        logger.debug(f"ip addr method failed for {container_name}: {e}")
    
    # Method 2: hostname -I (fallback)
    if not ips:
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- hostname -I", node_id=node_id, timeout=3)
            if result:
                for ip in result.strip().split():
                    if ip and ip != '127.0.0.1' and ip not in ips:
                        ips.append(ip)
        except Exception as e:
            logger.debug(f"hostname -I method failed for {container_name}: {e}")
    
    return {'ips': ips}

async def get_container_private_ip(container_name: str, node_id: int) -> str:
    """Get the private IP address of the container (internal LXC IP)"""
    try:
        # Try to get IP from hostname -I (most reliable)
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'hostname -I'", node_id=node_id)
        if result:
            # Get first IP (usually the private IP)
            ips = result.strip().split()
            if ips:
                return ips[0]
        
        # Fallback: Try ip addr show
        result = await execute_lxc(container_name, f"exec {container_name} -- ip addr show", node_id=node_id)
        if result:
            for line in result.split('\n'):
                if 'inet ' in line and '127.0.0.1' not in line:
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        ip = parts[1].split('/')[0]
                        # Return first non-localhost IP
                        if not ip.startswith('127.'):
                            return ip
        
        return "N/A"
    except Exception as e:
        logger.error(f"Error getting private IP for {container_name}: {e}")
        return "N/A"

# ============================================================================
# Register API Blueprint
# ============================================================================
from api import api_bp
app.register_blueprint(api_bp)
logger.info("API blueprint registered at /api/v1")

# ============================================================================
# Web Routes - License Activation
# ============================================================================
@app.route('/activate-license')
def activate_license_page():
    """Show license activation page"""
    if is_license_activated():
        return redirect(url_for('index'))
    return render_template('activate_license.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))

@app.route('/activate-license', methods=['POST'])
def activate_license_submit():
    """Handle license activation submission"""
    if is_license_activated():
        return jsonify({'success': False, 'error': 'License already activated'}), 400
    
    license_key = request.form.get('license_key', '').strip()
    
    if not license_key:
        return jsonify({'success': False, 'error': 'Please enter a license key'}), 400
    
    if activate_license(license_key, 'initial_activation'):
        return jsonify({'success': True, 'message': 'License activated successfully! Redirecting...'}), 200
    else:
        return jsonify({'success': False, 'error': 'Invalid license key. Please check and try again.'}), 400

# ============================================================================
# Web Routes - Authentication
# ============================================================================
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_landing(get_landing_design())

LEGAL_UPDATED = 'November 1, 2026'

@app.route('/terms')
def terms_of_service():
    return render_template('legal_terms.html', panel_name=get_setting('site_name', 'ExpelHost Panel'), updated=LEGAL_UPDATED)

@app.route('/privacy')
def privacy_policy():
    return render_template('legal_privacy.html', panel_name=get_setting('site_name', 'ExpelHost Panel'), updated=LEGAL_UPDATED)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username_or_email = request.form.get('username')  # Can be username or email
        password = request.form.get('password')
        remember = request.form.get('remember') == 'on'
        
        # Try to find user by username first, then by email
        user = User.get_by_username(username_or_email)
        if not user:
            user = User.get_by_email(username_or_email)
        
        if user and check_password_hash(user.password_hash, password):
            if user.two_factor_enabled:
                session['2fa_user_id'] = user.id
                return redirect(url_for('two_factor'))
            
            login_user(user, remember=remember)
            now = datetime.now().isoformat()
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?',
                           (now, now, user.id))
                conn.commit()
            
            log_activity(user.id, 'login', 'auth', None, {'ip': request.remote_addr})
            create_notification(user.id, 'info', 'New Login', f'New login from {request.remote_addr}', expires_in=86400)
            flash(f'Welcome back, {user.username}!', 'success')
            
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username/email or password', 'danger')
            log_activity(None, 'login_failed', 'auth', None, {'username_or_email': username_or_email, 'ip': request.remote_addr})
    
    return render_template('login.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))

@app.route('/2fa', methods=['GET', 'POST'])
def two_factor():
    if '2fa_user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        code = request.form.get('code')
        user_id = session.pop('2fa_user_id', None)
        user = User.get(user_id)
        if user:
            login_user(user)
            now = datetime.now().isoformat()
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?',
                           (now, now, user.id))
                conn.commit()
            flash(f'Welcome back, {user.username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid 2FA code', 'danger')
    
    return render_template('2fa.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    registration_enabled = get_setting('registration_enabled', '1')
    if registration_enabled != '1':
        flash('Registration is currently disabled', 'warning')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        terms = request.form.get('terms') == 'on'
        
        if not terms:
            flash('You must accept the terms of service', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))
        
        if len(password) < 8:
            flash('Password must be at least 8 characters', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))
        
        if User.get_by_username(username):
            flash('Username already taken', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))
        
        if User.get_by_email(email):
            flash('Email already registered', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))
        
        password_hash = generate_password_hash(password)
        api_key = generate_api_key()
        now = datetime.now().isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO users 
                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, api_key, preferences)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (username, email, password_hash, 0, 0, now, now, api_key, '{}'))
            user_id = cur.lastrowid
            
            default_quota = int(get_setting('default_port_quota', '5'))
            cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)',
                       (user_id, default_quota, 0, now))
            conn.commit()
        
        log_activity(user_id, 'register', 'auth', None, {'username': username, 'email': email})
        create_notification(user_id, 'success', 'Welcome!', f'Welcome to {get_setting("site_name", "ExpelHost Panel")}! Your account has been created.')
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))

# ============================================================================
# Discord OAuth Authentication
# ============================================================================

@app.route('/auth/discord/login')
def discord_login():
    """Initiate Discord OAuth login"""
    if not get_setting('discord_auth_enabled', '0') == '1':
        flash('Discord authentication is not enabled', 'danger')
        return redirect(url_for('login'))
    
    client_id = get_setting('discord_client_id', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    if not client_id or not redirect_uri:
        flash('Discord authentication is not configured', 'danger')
        return redirect(url_for('login'))
    
    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)
    session['discord_oauth_state'] = state
    session['discord_oauth_action'] = 'login'
    
    # Build Discord OAuth URL
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'identify email',
        'state': state
    }
    
    oauth_url = f"https://discord.com/api/oauth2/authorize?{urlencode(params)}"
    return redirect(oauth_url)

@app.route('/auth/discord/register')
def discord_register():
    """Initiate Discord OAuth registration"""
    if not get_setting('discord_auth_enabled', '0') == '1':
        flash('Discord authentication is not enabled', 'danger')
        return redirect(url_for('register'))
    
    if not get_setting('registration_enabled', '1') == '1':
        flash('Registration is currently disabled', 'danger')
        return redirect(url_for('login'))
    
    client_id = get_setting('discord_client_id', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    if not client_id or not redirect_uri:
        flash('Discord authentication is not configured', 'danger')
        return redirect(url_for('register'))
    
    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)
    session['discord_oauth_state'] = state
    session['discord_oauth_action'] = 'register'
    
    # Build Discord OAuth URL
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'identify email',
        'state': state
    }
    
    oauth_url = f"https://discord.com/api/oauth2/authorize?{urlencode(params)}"
    return redirect(oauth_url)

@app.route('/auth/discord/callback')
def discord_callback():
    """Handle Discord OAuth callback"""
    # Verify state
    state = request.args.get('state')
    if not state or state != session.get('discord_oauth_state'):
        flash('Invalid OAuth state', 'danger')
        return redirect(url_for('login'))
    
    # Get authorization code
    code = request.args.get('code')
    error = request.args.get('error')
    
    if error:
        flash(f'Discord authorization failed: {error}', 'danger')
        return redirect(url_for('login'))
    
    if not code:
        flash('No authorization code received', 'danger')
        return redirect(url_for('login'))
    
    # Exchange code for access token
    client_id = get_setting('discord_client_id', '')
    client_secret = get_setting('discord_client_secret', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    token_data = {
        'client_id': client_id,
        'client_secret': client_secret,
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect_uri
    }
    
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    
    try:
        token_response = requests.post(
            'https://discord.com/api/oauth2/token',
            data=token_data,
            headers=headers,
            timeout=10
        )
        token_response.raise_for_status()
        token_json = token_response.json()
        access_token = token_json['access_token']
    except Exception as e:
        logger.error(f"Discord token exchange error: {e}")
        flash('Failed to authenticate with Discord', 'danger')
        return redirect(url_for('login'))
    
    # Fetch user info from Discord
    try:
        user_response = requests.get(
            'https://discord.com/api/users/@me',
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )
        user_response.raise_for_status()
        discord_user = user_response.json()
    except Exception as e:
        logger.error(f"Discord user fetch error: {e}")
        flash('Failed to fetch user information from Discord', 'danger')
        return redirect(url_for('login'))
    
    discord_id = discord_user['id']
    discord_username = f"{discord_user['username']}#{discord_user['discriminator']}" if discord_user.get('discriminator') and discord_user.get('discriminator') != '0' else discord_user['username']
    discord_email = discord_user.get('email')
    discord_avatar = discord_user.get('avatar')
    
    action = session.get('discord_oauth_action', 'login')
    
    # Clean up session
    session.pop('discord_oauth_state', None)
    session.pop('discord_oauth_action', None)
    
    with get_db() as conn:
        cur = conn.cursor()
        
        # Check if Discord ID already exists
        cur.execute('SELECT * FROM users WHERE discord_id = ?', (discord_id,))
        existing_user = cur.fetchone()
        
        if action == 'login':
            if existing_user:
                # Log in existing user
                user = User(dict(existing_user))  # Convert Row to dict
                login_user(user, remember=True)
                
                # Update last login and profile picture from Discord
                profile_picture = None
                if discord_avatar:
                    profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
                
                cur.execute('UPDATE users SET last_login = ?, last_active = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ? WHERE id = ?',
                          (datetime.now().isoformat(), datetime.now().isoformat(), discord_username, discord_avatar, discord_email, profile_picture, user.id))
                conn.commit()
                
                log_activity(user.id, 'login_discord', 'auth', str(user.id))
                flash(f'Welcome back, {user.username}!', 'success')
                return redirect(url_for('dashboard'))
            else:
                # Check if auto-registration is enabled
                if get_setting('discord_auto_register', '0') == '1':
                    # Auto-register new user
                    return discord_auto_register(discord_id, discord_username, discord_email, discord_avatar)
                else:
                    flash('No account found with this Discord account. Please register first.', 'warning')
                    return redirect(url_for('register'))
        
        elif action == 'register':
            if existing_user:
                flash('This Discord account is already registered. Please log in instead.', 'warning')
                return redirect(url_for('login'))
            else:
                # Register new user
                return discord_auto_register(discord_id, discord_username, discord_email, discord_avatar)
        
        elif action == 'link':
            # Link Discord to existing logged-in user
            if not current_user.is_authenticated:
                flash('You must be logged in to link Discord', 'danger')
                return redirect(url_for('login'))
            
            # Check if Discord ID is already linked to another account
            if existing_user and existing_user['id'] != current_user.id:
                flash(f'This Discord account is already linked to another user', 'danger')
                return redirect(url_for('profile'))
            
            # Generate Discord avatar URL
            profile_picture = None
            if discord_avatar:
                profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
            
            # Update current user with Discord info
            cur.execute('''UPDATE users 
                SET discord_id = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ?
                WHERE id = ?''',
                (discord_id, discord_username, discord_avatar, discord_email, profile_picture, current_user.id))
            conn.commit()
            
            flash('Discord account linked successfully!', 'success')
            log_activity(current_user.id, 'link_discord', 'auth', str(current_user.id))
            return redirect(url_for('profile'))
    
    flash('An error occurred during authentication', 'danger')
    return redirect(url_for('login'))

def discord_auto_register(discord_id, discord_username, discord_email, discord_avatar):
    """Auto-register a new user from Discord"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Generate username from Discord username
            base_username = discord_username.split('#')[0].lower()
            base_username = re.sub(r'[^a-z0-9_]', '', base_username)
            
            # Ensure unique username
            username = base_username
            counter = 1
            while True:
                cur.execute('SELECT id FROM users WHERE username = ?', (username,))
                if not cur.fetchone():
                    break
                username = f"{base_username}{counter}"
                counter += 1
            
            # Use Discord email or generate placeholder
            email = discord_email if discord_email else f"{username}@discord.local"
            
            # Ensure unique email
            counter = 1
            original_email = email
            while True:
                cur.execute('SELECT id FROM users WHERE email = ?', (email,))
                if not cur.fetchone():
                    break
                email = f"{username}{counter}@discord.local"
                counter += 1
            
            # Generate Discord avatar URL
            profile_picture = None
            if discord_avatar:
                # Discord CDN URL format: https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png
                profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
            
            # Generate random password (user won't need it)
            random_password = secrets.token_urlsafe(32)
            password_hash = generate_password_hash(random_password)
            api_key = generate_api_key()
            
            now = datetime.now().isoformat()
            
            # Create user with profile picture
            cur.execute('''INSERT INTO users 
                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, last_active, api_key, preferences,
                 discord_id, discord_username, discord_avatar, discord_email, profile_picture)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (username, email, password_hash, 0, 0, now, now, now, api_key, '{}',
                 discord_id, discord_username, discord_avatar, discord_email, profile_picture))
            
            user_id = cur.lastrowid
            
            # Initialize port allocations
            default_quota = int(get_setting('default_port_quota', '5'))
            cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)',
                       (user_id, default_quota, 0, now))
            
            conn.commit()
            
            # Log in the new user
            cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
            user_row = cur.fetchone()
            user = User(dict(user_row))  # Convert Row to dict
            login_user(user, remember=True)
            
            log_activity(user.id, 'register_discord', 'auth', str(user.id))
            create_notification(user.id, 'success', 'Welcome!', f'Welcome to {get_setting("site_name", "ExpelHost Panel")}, {username}! Your account has been created.')
            flash(f'Welcome to {get_setting("site_name", "ExpelHost Panel")}, {username}! Your account has been created.', 'success')
            return redirect(url_for('dashboard'))
            
    except Exception as e:
        logger.error(f"Discord auto-register error: {e}")
        flash('Failed to create account. Please try again.', 'danger')
        return redirect(url_for('register'))

@app.route('/auth/discord/link')
@login_required
def discord_link():
    """Link Discord account to existing user"""
    if not get_setting('discord_auth_enabled', '0') == '1':
        flash('Discord authentication is not enabled', 'danger')
        return redirect(url_for('profile'))
    
    client_id = get_setting('discord_client_id', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    if not client_id or not redirect_uri:
        flash('Discord authentication is not configured', 'danger')
        return redirect(url_for('profile'))
    
    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)
    session['discord_oauth_state'] = state
    session['discord_oauth_action'] = 'link'
    
    # Build Discord OAuth URL
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'identify email',
        'state': state
    }
    
    oauth_url = f"https://discord.com/api/oauth2/authorize?{urlencode(params)}"
    return redirect(oauth_url)

@app.route('/auth/discord/link-callback')
@login_required
def discord_link_callback():
    """Handle Discord account linking callback"""
    # Verify state
    state = request.args.get('state')
    if not state or state != session.get('discord_oauth_state'):
        flash('Invalid OAuth state', 'danger')
        return redirect(url_for('profile'))
    
    code = request.args.get('code')
    if not code:
        flash('No authorization code received', 'danger')
        return redirect(url_for('profile'))
    
    # Exchange code for token
    client_id = get_setting('discord_client_id', '')
    client_secret = get_setting('discord_client_secret', '')
    redirect_uri = get_setting('discord_redirect_uri', '').replace('/callback', '/link-callback')
    
    token_data = {
        'client_id': client_id,
        'client_secret': client_secret,
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect_uri
    }
    
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    
    try:
        token_response = requests.post(
            'https://discord.com/api/oauth2/token',
            data=token_data,
            headers=headers,
            timeout=10
        )
        token_response.raise_for_status()
        token_json = token_response.json()
        access_token = token_json['access_token']
        
        # Fetch user info
        user_response = requests.get(
            'https://discord.com/api/users/@me',
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )
        user_response.raise_for_status()
        discord_user = user_response.json()
        
        discord_id = discord_user['id']
        discord_username = f"{discord_user['username']}#{discord_user['discriminator']}" if discord_user.get('discriminator') and discord_user.get('discriminator') != '0' else discord_user['username']
        discord_email = discord_user.get('email')
        discord_avatar = discord_user.get('avatar')
        
        # Clean up session
        session.pop('discord_oauth_state', None)
        session.pop('discord_oauth_action', None)
        
        # Update current user with Discord info
        with get_db() as conn:
            cur = conn.cursor()
            
            # Check if Discord ID is already linked to another account
            cur.execute('SELECT id, username FROM users WHERE discord_id = ? AND id != ?', (discord_id, current_user.id))
            other_user = cur.fetchone()
            if other_user:
                flash(f'This Discord account is already linked to another user ({other_user[1]})', 'danger')
                return redirect(url_for('profile'))
            
            # Generate Discord avatar URL
            profile_picture = None
            if discord_avatar:
                profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
            
            cur.execute('''UPDATE users 
                SET discord_id = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ?
                WHERE id = ?''',
                (discord_id, discord_username, discord_avatar, discord_email, profile_picture, current_user.id))
            conn.commit()
        
        flash('Discord account linked successfully!', 'success')
        log_activity(current_user.id, 'link_discord', 'auth', str(current_user.id))
        
    except Exception as e:
        logger.error(f"Discord link error: {e}")
        flash('Failed to link Discord account', 'danger')
    
    return redirect(url_for('profile'))

@app.route('/auth/discord/unlink', methods=['POST'])
@login_required
def discord_unlink():
    """Unlink Discord account from user"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE users 
                SET discord_id = NULL, discord_username = NULL, discord_avatar = NULL, discord_email = NULL
                WHERE id = ?''',
                (current_user.id,))
            conn.commit()
        
        flash('Discord account unlinked successfully', 'success')
        log_activity(current_user.id, 'unlink_discord', 'auth', str(current_user.id))
    except Exception as e:
        logger.error(f"Discord unlink error: {e}")
        flash('Failed to unlink Discord account', 'danger')
    
    return redirect(url_for('profile'))

@app.route('/logout')
@login_required
def logout():
    log_activity(current_user.id, 'logout', 'auth')
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        flash('If the email exists, a reset link has been sent.', 'info')
        return redirect(url_for('login'))
    
    return render_template('forgot_password.html', panel_name=get_setting('site_name', 'ExpelHost Panel'))

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('reset_password.html', token=token)
        
        flash('Password reset successful. Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('reset_password.html', token=token, panel_name=get_setting('site_name', 'ExpelHost Panel'))

# ============================================================================
# Notifications Routes
# ============================================================================
@app.route('/notifications')
@login_required
def notifications():
    page = int(request.args.get('page', 1))
    per_page = 20
    offset = (page - 1) * per_page
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT * FROM notifications 
                      WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)
                      ORDER BY created_at DESC LIMIT ? OFFSET ?''',
                   (current_user.id, datetime.now().isoformat(), per_page, offset))
        notifications = [dict(row) for row in cur.fetchall()]
        
        for notif in notifications:
            if notif['data']:
                try:
                    notif['data'] = json.loads(notif['data'])
                except:
                    notif['data'] = {}
        
        cur.execute('''SELECT COUNT(*) FROM notifications 
                      WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)''',
                   (current_user.id, datetime.now().isoformat()))
        total = cur.fetchone()[0]
    
    return render_template('notifications.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          notifications=notifications,
                          page=page,
                          total_pages=(total + per_page - 1) // per_page)

@app.route('/notifications/unread')
@login_required
def unread_notifications():
    notifications = get_user_notifications(current_user.id, unread_only=True, limit=10)
    count = get_unread_notifications_count(current_user.id)
    
    return jsonify({
        'success': True,
        'count': count,
        'notifications': notifications
    })

@app.route('/notifications/mark-read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read_route(notification_id):
    success = mark_notification_read(notification_id, current_user.id)
    return jsonify({'success': success})

@app.route('/notifications/mark-all-read', methods=['POST'])
@login_required
def mark_all_notifications_read_route():
    count = mark_all_notifications_read(current_user.id)
    return jsonify({'success': True, 'count': count})

@app.route('/notifications/clear-all', methods=['POST'])
@login_required
def clear_all_notifications():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM notifications WHERE user_id = ?', (current_user.id,))
        conn.commit()
    return jsonify({'success': True})

# ============================================================================
# OS Icons Routes
# ============================================================================
@app.route('/os-icons')
@login_required
@admin_required
def os_icons():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM os_icons ORDER BY os_name')
        icons = [dict(row) for row in cur.fetchall()]
    
    return render_template('admin/os_icons.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          icons=icons,
                          os_options=OS_OPTIONS)

@app.route('/os-icons/upload', methods=['POST'])
@login_required
@admin_required
def upload_os_icon():
    os_name = request.form.get('os_name')
    
    if 'icon' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['icon']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not os_name:
        return jsonify({'success': False, 'error': 'OS name required'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'success': False, 'error': 'Invalid file type'}), 400
    
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    
    if size > app.config['MAX_IMAGE_SIZE']:
        return jsonify({'success': False, 'error': 'File too large (max 5MB)'}), 400
    
    filename = secure_filename(f"os_{os_name}_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'os_icons', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    if PIL_AVAILABLE and Image:
        try:
            img = Image.open(filepath)
            img.thumbnail((64, 64), Image.Resampling.LANCZOS)
            img.save(filepath, optimize=True, quality=85)
        except Exception as e:
            logger.error(f"Failed to optimize image: {e}")
    
    icon_path = f'/static/uploads/os_icons/{filename}'
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''INSERT OR REPLACE INTO os_icons (os_name, icon_path, uploaded_at, uploaded_by)
                      VALUES (?, ?, ?, ?)''',
                   (os_name, icon_path, datetime.now().isoformat(), current_user.id))
        conn.commit()
    
    log_activity(current_user.id, 'upload_os_icon', 'os_icon', None, {'os_name': os_name})
    return jsonify({'success': True, 'icon_path': icon_path})

@app.route('/os-icons/<path:os_name>/delete', methods=['POST'])
@login_required
@admin_required
def delete_os_icon(os_name):
    """Delete OS icon"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Get icon path before deleting
            cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))
            row = cur.fetchone()
            
            if row:
                icon_path = row[0]
                
                # Delete from database
                cur.execute('DELETE FROM os_icons WHERE os_name = ?', (os_name,))
                conn.commit()
                
                # Try to delete the file
                try:
                    if icon_path and icon_path.startswith('/static/uploads/'):
                        file_path = icon_path.replace('/static/', 'static/')
                        if os.path.exists(file_path):
                            os.remove(file_path)
                            logger.info(f"Deleted icon file: {file_path}")
                except Exception as e:
                    logger.warning(f"Failed to delete icon file: {e}")
                
                log_activity(current_user.id, 'delete_os_icon', 'os_icon', None, {'os_name': os_name})
                return jsonify({'success': True, 'message': 'Icon removed successfully'})
            else:
                return jsonify({'success': False, 'error': 'Icon not found'}), 404
                
    except Exception as e:
        logger.error(f"Error deleting OS icon: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/os-icons/<os_name>')
def get_os_icon(os_name):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))
        row = cur.fetchone()
        if row:
            return jsonify({'success': True, 'icon_path': row[0]})
    
    return jsonify({'success': True, 'icon_path': '/static/img/os/default.png'})

# ============================================================================
# User Profile Routes
# ============================================================================
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        theme = request.form.get('theme')
        language = request.form.get('language')
        
        updates = {}
        
        if any([username != current_user.username, email != current_user.email, new_password]):
            if not current_password or not check_password_hash(current_user.password_hash, current_password):
                flash('Current password is incorrect', 'danger')
                return redirect(url_for('profile'))
        
        if username and username != current_user.username:
            if User.get_by_username(username):
                flash('Username already taken', 'danger')
            else:
                updates['username'] = username
        
        if email and email != current_user.email:
            if User.get_by_email(email):
                flash('Email already taken', 'danger')
            else:
                updates['email'] = email
        
        if new_password:
            if new_password != confirm_password:
                flash('New passwords do not match', 'danger')
            elif len(new_password) < 8:
                flash('Password must be at least 8 characters', 'danger')
            else:
                updates['password_hash'] = generate_password_hash(new_password)
        
        if theme:
            updates['theme'] = theme
        if language:
            updates['language'] = language
        
        if updates:
            with get_db() as conn:
                cur = conn.cursor()
                fields = ', '.join(f"{k} = ?" for k in updates)
                values = list(updates.values()) + [current_user.id]
                cur.execute(f'UPDATE users SET {fields} WHERE id = ?', values)
                conn.commit()
            
            log_activity(current_user.id, 'update_profile', 'user', str(current_user.id), 
                        {'fields': list(updates.keys())})
            create_notification(current_user.id, 'success', 'Profile Updated', 'Your profile has been updated successfully.')
            flash('Profile updated successfully', 'success')
        else:
            flash('No changes made', 'info')
        
        return redirect(url_for('profile'))
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT * FROM activity_logs WHERE user_id = ? 
                       ORDER BY created_at DESC LIMIT 50''', (current_user.id,))
        activities = [dict(row) for row in cur.fetchall()]
    
    notifications = get_user_notifications(current_user.id, limit=10)
    
    return render_template('profile.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          activities=activities,
                          notifications=notifications)

@app.route('/profile/picture', methods=['POST'])
@login_required
def upload_profile_picture():
    if 'picture' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['picture']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'success': False, 'error': 'Invalid file type'}), 400
    
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    
    if size > app.config['MAX_IMAGE_SIZE']:
        return jsonify({'success': False, 'error': 'File too large (max 5MB)'}), 400
    
    filename = secure_filename(f"user_{current_user.id}_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'profiles', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    if PIL_AVAILABLE and Image:
        try:
            img = Image.open(filepath)
            img.thumbnail((256, 256), Image.Resampling.LANCZOS)
            img.save(filepath, optimize=True, quality=85)
        except Exception as e:
            logger.error(f"Failed to optimize image: {e}")
    
    if current_user.profile_picture:
        old_path = current_user.profile_picture.lstrip('/')
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except:
                pass
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET profile_picture = ? WHERE id = ?',
                   (f'/static/uploads/profiles/{filename}', current_user.id))
        conn.commit()
    
    return jsonify({'success': True, 'path': f'/static/uploads/profiles/{filename}'})

@app.route('/profile/picture/delete', methods=['POST'])
@login_required
def delete_profile_picture():
    if current_user.profile_picture:
        old_path = current_user.profile_picture.lstrip('/')
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except:
                pass
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET profile_picture = NULL WHERE id = ?', (current_user.id,))
        conn.commit()
    
    return jsonify({'success': True})

@app.route('/profile/api-key/regenerate', methods=['POST'])
@login_required
def regenerate_api_key():
    new_key = generate_api_key()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET api_key = ? WHERE id = ?', (new_key, current_user.id))
        conn.commit()
    
    log_activity(current_user.id, 'regenerate_api_key', 'user', str(current_user.id))
    create_notification(current_user.id, 'warning', 'API Key Regenerated', 'Your API key has been regenerated.')
    return jsonify({'success': True, 'api_key': new_key})

@app.route('/profile/preferences', methods=['POST'])
@login_required
def update_preferences():
    data = request.get_json()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET preferences = ? WHERE id = ?',
                   (json.dumps(data.get('preferences', {})), current_user.id))
        conn.commit()
    
    return jsonify({'success': True})

@app.route('/profile_picture')
@login_required
def profile_picture():
    if current_user.profile_picture and os.path.exists(current_user.profile_picture.lstrip('/')):
        return send_from_directory('static', current_user.profile_picture.replace('/static/', ''))
    else:
        return send_from_directory('static/img', 'default_avatar.png')

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# ============================================================================
# Web Routes - Main Dashboard
# ============================================================================
@app.route('/dashboard')
@login_required
def dashboard():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET last_active = ? WHERE id = ?',
                   (datetime.now().isoformat(), current_user.id))
        conn.commit()
    
    vps_list = get_vps_for_user(current_user.id, include_team=True)

    for vps in vps_list:
        # Check if VPS is suspended first
        if is_vps_suspended(vps):
            vps['live_status'] = 'suspended'
            vps['live_cpu'] = 0
            vps['live_ram'] = {'pct': 0}
        elif is_shared_vps(vps):
            try:
                stats = shared_stats_for_user(vps, current_user.id)
                vps['live_status'] = stats['status']
                vps['live_cpu'] = stats['cpu']
                vps['live_ram'] = stats['ram']
            except:
                vps['live_status'] = vps['status']
                vps['live_cpu'] = 0
                vps['live_ram'] = {'pct': 0}
        else:
            try:
                stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
                vps['live_status'] = stats['status']
                vps['live_cpu'] = stats['cpu']
                vps['live_ram'] = stats['ram']
            except:
                vps['live_status'] = vps['status']
                vps['live_cpu'] = 0
                vps['live_ram'] = {'pct': 0}
    
    apply_fake_to_list(vps_list)
    total_cpu = sum(int(vps['cpu']) for vps in vps_list)
    total_ram = sum(int(vps['ram'].replace('GB', '')) for vps in vps_list)
    total_disk = sum(int(vps['storage'].replace('GB', '')) for vps in vps_list)
    
    running_count = sum(1 for vps in vps_list if vps.get('live_status') == 'running' and not is_vps_suspended(vps))
    suspended_count = sum(1 for vps in vps_list if is_vps_suspended(vps))
    stopped_count = len(vps_list) - running_count - suspended_count
    
    notifications = get_user_notifications(current_user.id, unread_only=True, limit=5)
    
    for vps in vps_list:
        if vps.get('live_status') == 'running' and vps.get('live_ram', {}).get('pct', 0) > 90:
            create_notification(
                current_user.id, 
                'warning', 
                'High RAM Usage', 
                f'VPS {vps["container_name"]} is using high RAM ({vps["live_ram"]["pct"]:.1f}%)'
            )
    
    nodes = get_nodes()
    node_status = []
    for node in nodes[:3]:
        status = run_sync(get_node_status(node['id']))
        node_status.append({
            'id': node['id'],
            'name': node['name'],
            'status': status['status'],
            'online': status.get('online', False),
            'vps_count': get_current_vps_count(node['id']),
            'total_vps': node['total_vps']
        })
    
    return render_template('dashboard.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          site_description=get_setting('site_description', ''),
                          header_icon=get_setting('header_icon', '/static/img/logo.png'),
                          vps_list=vps_list,
                          vps_count=len(vps_list),
                          running_count=running_count,
                          suspended_count=suspended_count,
                          stopped_count=stopped_count,
                          total_cpu=total_cpu,
                          total_ram=total_ram,
                          total_disk=total_disk,
                          notifications=notifications,
                          node_status=node_status,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/vps')
@login_required
def vps_list():
    """VPS list with improved stats fetching"""
    vps_list = get_vps_for_user(current_user.id, include_team=True)

    for vps in vps_list:
        # Initialize with safe defaults
        vps['live_status'] = vps.get('status', 'unknown')
        vps['live_cpu'] = 0.0
        vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
        vps['live_disk'] = {'use_percent': '0%'}

        # Check if VPS is suspended first
        if is_vps_suspended(vps):
            vps['live_status'] = 'suspended'
        elif is_shared_vps(vps):
            # Shared hosting: show the requesting user's OWN account usage
            try:
                stats = shared_stats_for_user(vps, current_user.id)
                vps['live_status'] = stats.get('status', 'unknown')
                vps['live_cpu'] = float(stats.get('cpu', 0.0))
                ram_data = stats.get('ram', {'used': 0, 'total': 0, 'pct': 0.0})
                vps['live_ram'] = ram_data if isinstance(ram_data, dict) else {'used': 0, 'total': 0, 'pct': 0.0}
                disk_data = stats.get('disk', {'use_percent': '0%'})
                vps['live_disk'] = normalize_disk(disk_data) if isinstance(disk_data, dict) else normalize_disk({'use_percent': '0%'})
            except Exception as e:
                logger.warning(f"Shared stats error for VPS {vps.get('container_name')}: {e}")
                vps['live_status'] = vps.get('status', 'unknown')
        else:
            try:
                stats = run_sync(
                    get_container_stats(
                        vps['container_name'],
                        vps['node_id']
                    )
                )

                vps['live_status'] = stats.get('status', 'unknown')
                vps['live_cpu'] = float(stats.get('cpu', 0.0))
                
                # Ensure RAM is a dict
                ram_data = stats.get('ram', {'used': 0, 'total': 0, 'pct': 0.0})
                if isinstance(ram_data, dict):
                    vps['live_ram'] = ram_data
                else:
                    vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
                
                # Ensure disk is a dict
                disk_data = stats.get('disk', {'use_percent': '0%'})
                if isinstance(disk_data, dict):
                    vps['live_disk'] = normalize_disk(disk_data)
                else:
                    vps['live_disk'] = {'use_percent': '0%'}
                
                logger.debug(f"VPS {vps['id']} stats: status={vps['live_status']}, cpu={vps['live_cpu']}, ram={vps['live_ram']}")

            except Exception as e:
                logger.warning(f"Stats error for {vps.get('container_name')}: {e}")
                vps['live_status'] = 'unknown'

    apply_fake_to_list(vps_list)

    return render_template(
        'vps_list.html',
        panel_name=get_setting('site_name', 'ExpelHost Panel'),
        vps_list=vps_list,
        socketio_available=SOCKETIO_AVAILABLE
    )

@app.route('/vps/<int:vps_id>')
@login_required
def vps_detail(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        flash('VPS not found', 'danger')
        return redirect(url_for('vps_list'))

    shared_with = vps.get('shared_with', []) or []

    allowed = can_access_vps(vps)

    if not allowed:
        flash('VPS not found or access denied', 'danger')
        return redirect(url_for('vps_list'))

    is_shared = is_shared_vps(vps)
    shared_account = get_shared_account(vps_id, current_user.id) if is_shared else None
    shared_accounts_list = get_shared_accounts(vps_id) if is_shared else []
    if is_shared:
        _fk = get_vps_fake_cfg(vps['container_name'])
        if _fk:
            def _fk_acc(a):
                if not a:
                    return a
                a = dict(a)
                a['real_ram_mb'], a['real_cpu_limit'], a['real_disk_gb'] = a.get('ram_mb'), a.get('cpu_limit'), a.get('disk_gb')
                a['ram_mb'] = int(_fk['ram_gb']) * 1024
                a['cpu_limit'] = int(_fk['cpu'])
                a['disk_gb'] = int(_fk['disk_gb'])
                return a
            shared_account = _fk_acc(shared_account)
            shared_accounts_list = [_fk_acc(a) for a in shared_accounts_list]

    # If VPS is suspended, redirect non-admins to suspended page
    if is_vps_suspended(vps) and not current_user.is_admin:
        return redirect(url_for('vps_suspended_page', vps_id=vps_id))

    node = get_node(vps['node_id'])

    if is_shared:
        # Shared hosting: no container - show the user's OWN account usage
        try:
            stats = shared_stats_for_user(vps, current_user.id)
        except Exception as e:
            logger.error(f"Shared stats error for VPS {vps_id}: {e}", exc_info=True)
            stats = {
                "status": "unknown",
                "cpu": 0.0,
                "ram": {"used": 0, "total": 0, "pct": 0.0},
                "disk": {"use_percent": "0%"},
                "uptime": "Unknown"
            }
        live_status = stats.get("status")
        if is_vps_suspended(vps):
            live_status = 'suspended'
            vps['status'] = 'suspended'
        private_ip = "N/A"
    else:
        try:
            logger.info(f"Fetching stats for container {vps['container_name']} on node {vps['node_id']}")
            stats = run_sync(
                get_container_stats(
                    vps['container_name'],
                    vps['node_id']
                )
            ) or {}

            logger.info(f"Stats fetched for {vps['container_name']}: CPU={stats.get('cpu', 'N/A')}, Status={stats.get('status', 'N/A')}")

        except Exception as e:
            logger.error(
                f"Stats error for {vps['container_name']}: {e}", exc_info=True
            )
            stats = {
                "status": "unknown",
                "cpu": 0.0,
                "ram": {"used": 0, "total": 0, "pct": 0.0},
                "disk": {"use_percent": "0%"},
                "uptime": "Unknown"
            }

        live_status = stats.get("status")

        # If VPS is suspended (admin viewing), show suspended status
        if is_vps_suspended(vps):
            live_status = 'suspended'
            vps['status'] = 'suspended'
        elif live_status in ("running", "stopped"):
            if live_status != vps.get("status"):
                update_vps(vps_id, status=live_status)
                vps["status"] = live_status

        # Get private IP from inside the container
        private_ip = "N/A"
        if live_status == "running":
            try:
                private_ip = run_sync(
                    get_container_private_ip(
                        vps['container_name'],
                        vps['node_id']
                    )
                )
                logger.info(f"VPS {vps_id} ({vps['container_name']}) private IP: {private_ip}")
            except Exception as e:
                logger.error(f"Error getting private IP for {vps['container_name']}: {e}")
                private_ip = "N/A"

    forwards = get_user_forwards(current_user.id)
    vps_forwards = [] if is_shared else [
        f for f in forwards
        if f['vps_container'] == vps['container_name']
    ]

    shared_users = []
    if shared_with:
        logger.info(f"VPS {vps_id} shared_with list: {shared_with}")
        with get_db() as conn:
            cur = conn.cursor()

            for uid in shared_with:
                try:
                    uid_int = int(uid)
                    cur.execute(
                        '''
                        SELECT id, username, email, profile_picture
                        FROM users WHERE id=?
                        ''',
                        (uid_int,)
                    )
                    row = cur.fetchone()
                    if row:
                        user_dict = dict(row)
                        shared_users.append(user_dict)
                        logger.info(f"Added shared user: {user_dict['username']} (ID: {user_dict['id']})")
                    else:
                        logger.warning(f"User ID {uid_int} not found in database")
                except Exception as e:
                    logger.error(f"Error loading shared user {uid}: {e}")
    
    logger.info(f"VPS {vps_id} total shared_users: {len(shared_users)}")

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            '''
            SELECT * FROM backups
            WHERE vps_id=?
            ORDER BY created_at DESC
            ''',
            (vps_id,)
        )
        backups = [dict(r) for r in cur.fetchall()]

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            '''
            SELECT * FROM activity_logs
            WHERE resource_type='vps'
            AND resource_id=?
            ORDER BY created_at DESC
            LIMIT 20
            ''',
            (str(vps_id),)
        )
        activities = [dict(r) for r in cur.fetchall()]

    display_ip = get_vps_display_ip(vps) or YOUR_SERVER_IP

    # Shared hosting: admins need the full user list for the "add account" form
    admin_users = []
    if is_shared and current_user.is_admin:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, username, email FROM users ORDER BY username')
            admin_users = [dict(row) for row in cur.fetchall()]

    os_icon = "default"
    for os_option in OS_OPTIONS:
        if os_option["value"] == vps["os_version"]:
            os_icon = os_option.get("icon", "default")
            break

    vps, stats = apply_fake_to_panel(vps, stats)

    # Team roles + scheduled maintenance info for the page
    my_role = get_vps_role(vps) or 'viewer'
    _roles = get_team_roles(vps)
    team_members = [dict(u, role=(_roles.get(str(u['id'])) if _roles.get(str(u['id'])) in TEAM_ROLES else 'operator'))
                    for u in shared_users]

    return render_template(
        "vps_detail.html",
        panel_name=get_setting('site_name', 'ExpelHost Panel'),
        vps=vps,
        node=node,
        stats=stats,
        forwards=vps_forwards,
        shared_users=shared_users,
        os_options=OS_OPTIONS,
        backups=backups,
        activities=activities,
        private_ip=private_ip,
        display_ip=display_ip,
        YOUR_SERVER_IP=YOUR_SERVER_IP,
        os_icon=os_icon,
        is_shared=is_shared,
        shared_account=shared_account,
        shared_accounts=shared_accounts_list,
        admin_users=admin_users,
        socketio_available=SOCKETIO_AVAILABLE,
        my_role=my_role,
        can_operate=(is_shared or role_at_least(my_role, 'operator')),
        can_owner_actions=(is_shared or role_at_least(my_role, 'owner')),
        can_manage_team=(not is_shared and role_at_least(my_role, 'owner')),
        team_members=team_members,
        vps_schedules=get_schedules_for_vps(vps)
    )









# ============================================================================
# VPS File Manager Routes - SFTP Based
# ============================================================================

def get_sftp_connection(vps):
    """Create SFTP connection to VPS"""
    import paramiko

    # Shared hosting (no LXD): log in as the requesting user's OWN system
    # account.  SFTP starts inside their home directory, so users can only
    # ever see their own files - never another user's files or the host.
    if is_shared_vps(vps):
        node = get_node(vps['node_id'])
        if not node:
            raise Exception("Node not found")
        acct = get_request_shared_account(vps)
        if not acct:
            raise Exception("No shared hosting account is linked to your user")
        if acct.get('status') == 'suspended':
            raise Exception("Your shared hosting account is suspended")
        node_host = _node_ssh_host_for(node)
        if not node_host:
            raise Exception("Node host could not be resolved")
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            ssh.connect(
                hostname=node_host,
                port=_node_ssh_port_for(node),
                username=acct['system_user'],
                password=acct['ssh_password'],
                timeout=10,
                allow_agent=False,
                look_for_keys=False
            )
            sftp = ssh.open_sftp()
            try:
                sftp.chdir(acct['home_dir'])
            except Exception:
                pass
            logger.info(f"SFTP connected for shared account {acct['system_user']} on {node_host}")
            return ssh, sftp
        except Exception as e:
            ssh.close()
            raise Exception(f"SFTP connection failed: {str(e)}")

    # Get node to find the actual host
    node = get_node(vps['node_id'])
    if not node:
        raise Exception("Node not found")

    # Parse node URL to get host
    from urllib.parse import urlparse
    parsed = urlparse(node['url'])
    node_host = parsed.hostname or node['url'].split('://')[1].split(':')[0] if '://' in node['url'] else node['url'].split(':')[0]

    # Try to get VPS private IP first (direct connection if on same network)
    try:
        private_ip = run_sync(get_container_private_ip(vps['container_name'], vps['node_id']))
        if private_ip and private_ip != "N/A":
            # Try direct connection to private IP
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                ssh.connect(
                    hostname=private_ip,
                    port=22,
                    username='root',
                    password='root',
                    timeout=5,
                    allow_agent=False,
                    look_for_keys=False
                )
                sftp = ssh.open_sftp()
                logger.info(f"SFTP connected directly to {private_ip}:22")
                return ssh, sftp
            except Exception as e:
                logger.debug(f"Direct IP connection failed: {e}, trying port forward")
                ssh.close()
    except Exception as e:
        logger.debug(f"Could not get private IP: {e}")

    # Fallback to port forward method
    # Check if port 22 forward exists
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''
            SELECT host_port FROM port_forwards
            WHERE vps_container = ? AND vps_port = 22
        ''', (vps['container_name'],))
        row = cur.fetchone()

        if row:
            ssh_port = row['host_port']
        else:
            # Auto-create port 22 forward
            logger.info(f"Auto-creating SSH port forward for {vps['container_name']}")
            try:
                # Create the forward (it will auto-assign a host port)
                host_port = run_sync(create_port_forward(
                    user_id=vps['user_id'],
                    container=vps['container_name'],
                    vps_port=22,
                    node_id=vps['node_id'],
                    protocol='tcp',
                    description='SSH (auto-created for file manager)'
                ))
                
                if not host_port:
                    raise Exception("No available ports for SSH forward")
                
                ssh_port = host_port
                logger.info(f"Created SSH forward: {node_host}:{ssh_port} -> {vps['container_name']}:22")
            except Exception as e:
                raise Exception(f"Could not create SSH port forward: {str(e)}")

    # Create SSH client
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Connect with root:root credentials via port forward
        ssh.connect(
            hostname=node_host,
            port=ssh_port,
            username='root',
            password='root',
            timeout=10,
            allow_agent=False,
            look_for_keys=False
        )

        # Open SFTP session
        sftp = ssh.open_sftp()
        logger.info(f"SFTP connected via port forward {node_host}:{ssh_port}")
        return ssh, sftp
    except Exception as e:
        ssh.close()
        raise Exception(f"SFTP connection failed: {str(e)}")


def shared_jail_path(vps: Dict, path: str, acct: Optional[Dict] = None) -> str:
    """Confine a file-manager path to the shared account's home directory.
    Returns the path unchanged for dedicated (LXD) VPS."""
    if not is_shared_vps(vps):
        return path
    acct = acct or get_request_shared_account(vps)
    if not acct:
        raise ValueError("No shared hosting account is linked to your user")
    home = (acct.get('home_dir') or '').rstrip('/')
    p = (path or '').strip()
    if p in ('', '/', '/root', '~', '.'):
        return home
    if '..' in p.split('/'):
        raise ValueError('Invalid path')
    p = p.rstrip('/') or '/'
    if not p.startswith('/'):
        p = f"{home}/{p}"
    if p != home and not p.startswith(home + '/'):
        raise ValueError('Access outside your home directory is blocked')
    return p


@app.route('/vps/<int:vps_id>/files')
@login_required
def vps_files(vps_id):
    """VPS File Manager"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        flash('VPS not found', 'danger')
        return redirect(url_for('dashboard'))
    
    # Check ownership
    if not can_access_vps(vps):
        flash('Access denied', 'danger')
        return redirect(url_for('dashboard'))
    
    # Check if VPS is suspended
    if is_vps_suspended(vps) and not current_user.is_admin:
        flash('VPS is suspended. File manager access denied.', 'danger')
        return redirect(url_for('vps_suspended_page', vps_id=vps_id))
    
    # Shared hosting: status comes from the user's own account, and the
    # file manager is jailed inside their home directory.
    initial_path = '/root'
    if is_shared_vps(vps):
        acct = get_request_shared_account(vps)
        if not acct:
            flash('No shared hosting account is linked to your user', 'danger')
            return redirect(url_for('dashboard'))
        if acct.get('status') == 'suspended':
            flash('Your shared hosting account is suspended', 'danger')
            return redirect(url_for('vps_suspended_page', vps_id=vps_id))
        status = 'stopped' if acct.get('status') == 'stopped' else 'running'
        initial_path = acct.get('home_dir') or '/'
    else:
        # Check if VPS is running
        status = run_sync(get_container_status(vps['container_name'], vps['node_id']))
    
    return render_template('vps_files.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          vps=vps,
                          status=status,
                          initial_path=initial_path)

@app.route('/vps/<int:vps_id>/files/browse', methods=['POST'])
@login_required
def vps_files_browse(vps_id):
    """Browse VPS files via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    path = data.get('path', '/root')
    
    # Security: prevent path traversal
    if '..' in path:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    # Shared hosting: jail the path inside the user's home directory
    try:
        path = shared_jail_path(vps, path)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        # List directory
        files = []
        for item in sftp.listdir_attr(path):
            import stat
            is_dir = stat.S_ISDIR(item.st_mode)
            is_link = stat.S_ISLNK(item.st_mode)
            
            # Format size
            if is_dir:
                size = '-'
            else:
                size_bytes = item.st_size
                if size_bytes < 1024:
                    size = f"{size_bytes}B"
                elif size_bytes < 1024 * 1024:
                    size = f"{size_bytes / 1024:.1f}K"
                elif size_bytes < 1024 * 1024 * 1024:
                    size = f"{size_bytes / (1024 * 1024):.1f}M"
                else:
                    size = f"{size_bytes / (1024 * 1024 * 1024):.1f}G"
            
            # Format permissions
            perms = stat.filemode(item.st_mode)
            
            # Format modified time
            from datetime import datetime
            modified = datetime.fromtimestamp(item.st_mtime).strftime('%Y-%m-%d %H:%M')
            
            files.append({
                'name': item.filename,
                'size': size,
                'modified': modified,
                'permissions': perms,
                'owner': f"{item.st_uid}:{item.st_gid}",
                'is_dir': is_dir,
                'is_link': is_link
            })
        
        # Sort: directories first, then by name
        files.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
        
        return jsonify({
            'success': True,
            'path': path,
            'files': files
        })
        
    except Exception as e:
        logger.error(f"Error browsing files: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/upload', methods=['POST'])
@login_required
def vps_files_upload(vps_id):
    """Upload file to VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': 'No file provided'}), 400
    
    file = request.files['file']
    path = request.form.get('path', '/root')
    
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    # Security checks
    if '..' in path or '..' in file.filename:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    # Shared hosting: jail the path inside the user's home directory
    try:
        path = shared_jail_path(vps, path)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    
    ssh = None
    sftp = None
    tmp_path = None
    try:
        # Save file temporarily
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            file.save(tmp.name)
            tmp_path = tmp.name
        
        # Connect via SFTP
        ssh, sftp = get_sftp_connection(vps)
        
        # Upload file
        target_path = f"{path.rstrip('/')}/{file.filename}"
        sftp.put(tmp_path, target_path)
        
        log_activity(current_user.id, 'upload_file', 'vps', str(vps_id),
                    {'file': file.filename, 'path': path})
        
        return jsonify({
            'success': True,
            'message': f'File {file.filename} uploaded successfully'
        })
        
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/download', methods=['POST'])
@login_required  
def vps_files_download(vps_id):
    """Download file from VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    file_path = data.get('path')
    
    if not file_path or '..' in file_path:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    # Shared hosting: jail the path inside the user's home directory
    try:
        file_path = shared_jail_path(vps, file_path)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    
    ssh = None
    sftp = None
    tmp_path = None
    try:
        import tempfile
        
        # Connect via SFTP
        ssh, sftp = get_sftp_connection(vps)
        
        # Download to temp file
        tmp = tempfile.NamedTemporaryFile(delete=False)
        tmp.close()
        tmp_path = tmp.name
        
        sftp.get(file_path, tmp_path)
        
        filename = os.path.basename(file_path)
        
        log_activity(current_user.id, 'download_file', 'vps', str(vps_id),
                    {'file': file_path})
        
        return send_file(tmp_path, as_attachment=True, download_name=filename)
        
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/delete', methods=['POST'])
@login_required
def vps_files_delete(vps_id):
    """Delete file or directory from VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    path = data.get('path')
    is_dir = data.get('is_dir', False)
    
    if not path or '..' in path:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    # Shared hosting: jail the path inside the user's home directory
    try:
        path = shared_jail_path(vps, path)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    
    # Prevent deleting critical directories
    critical_paths = ['/', '/bin', '/boot', '/dev', '/etc', '/lib', '/proc', '/root', '/sbin', '/sys', '/usr', '/var']
    if path in critical_paths:
        return jsonify({'success': False, 'error': 'Cannot delete system directory'}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        if is_dir:
            # Remove directory recursively
            def rmdir_recursive(sftp, path):
                for item in sftp.listdir_attr(path):
                    item_path = f"{path}/{item.filename}"
                    import stat
                    if stat.S_ISDIR(item.st_mode):
                        rmdir_recursive(sftp, item_path)
                    else:
                        sftp.remove(item_path)
                sftp.rmdir(path)
            
            rmdir_recursive(sftp, path)
        else:
            sftp.remove(path)
        
        log_activity(current_user.id, 'delete_file', 'vps', str(vps_id),
                    {'path': path, 'is_dir': is_dir})
        
        return jsonify({
            'success': True,
            'message': f'{"Directory" if is_dir else "File"} deleted successfully'
        })
        
    except Exception as e:
        logger.error(f"Error deleting file: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/rename', methods=['POST'])
@login_required
def vps_files_rename(vps_id):
    """Rename file or directory in VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    old_path = data.get('old_path')
    new_name = data.get('new_name')
    
    if not old_path or not new_name or '..' in old_path or '..' in new_name or '/' in new_name:
        return jsonify({'success': False, 'error': 'Invalid path or name'}), 400
    
    # Shared hosting: jail the path inside the user's home directory
    try:
        old_path = shared_jail_path(vps, old_path)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        # Get directory of old path
        directory = os.path.dirname(old_path)
        new_path = f"{directory}/{new_name}" if directory != '/' else f"/{new_name}"
        
        sftp.rename(old_path, new_path)
        
        log_activity(current_user.id, 'rename_file', 'vps', str(vps_id),
                    {'old': old_path, 'new': new_path})
        
        return jsonify({
            'success': True,
            'message': 'Renamed successfully'
        })
        
    except Exception as e:
        logger.error(f"Error renaming file: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/mkdir', methods=['POST'])
@login_required
def vps_files_mkdir(vps_id):
    """Create new directory in VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    path = data.get('path')
    name = data.get('name')
    
    if not path or not name or '..' in path or '..' in name or '/' in name:
        return jsonify({'success': False, 'error': 'Invalid path or name'}), 400
    
    # Shared hosting: jail the path inside the user's home directory
    try:
        path = shared_jail_path(vps, path)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        new_dir = f"{path.rstrip('/')}/{name}"
        sftp.mkdir(new_dir)
        
        log_activity(current_user.id, 'create_directory', 'vps', str(vps_id),
                    {'path': new_dir})
        
        return jsonify({
            'success': True,
            'message': f'Directory {name} created successfully'
        })
        
    except Exception as e:
        logger.error(f"Error creating directory: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()


# ============================================================================
# VPS Control Routes
# ============================================================================
def _shared_control(vps: Dict, action: str):
    """Start/stop/restart for shared hosting (no container involved).
    Users control only their own account; admins control every account."""
    if action in ('freeze', 'unfreeze'):
        return jsonify({'success': False, 'error': f'{action} is not available on shared hosting'}), 400

    if current_user.is_admin and not get_shared_account(vps['id'], current_user.id):
        targets = get_shared_accounts(vps['id'])
    else:
        acct = get_shared_account(vps['id'], current_user.id)
        if not acct:
            return jsonify({'success': False, 'error': 'No shared hosting account is linked to your user'}), 403
        targets = [acct]

    if not targets:
        return jsonify({'success': False, 'error': 'This shared VPS has no accounts'}), 400

    try:
        for acct in targets:
            if action in ('stop', 'restart'):
                shared_node_op(vps, shared_hosting.kill_script(acct['system_user']), timeout=60)
            if action == 'stop':
                if acct.get('status') != 'suspended':
                    update_shared_account(acct['id'], status='stopped',
                                          processes=0, ram_used_mb=0, cpu_used=0)
            else:  # start / restart
                if acct.get('status') != 'suspended':
                    try:
                        shared_node_op(vps, shared_hosting.start_script(acct['system_user']), timeout=60)
                    except Exception as e:
                        logger.warning(f"Shared start failed for {acct['system_user']}: {e}")
                    update_shared_account(acct['id'], status='active',
                                          processes=0, ram_used_mb=0, cpu_used=0)

        scope = 'your account' if len(targets) == 1 else f'{len(targets)} accounts'
        log_activity(current_user.id, f'{action}_vps', 'vps', str(vps['id']),
                     {'shared': True, 'action': action})
        create_notification(current_user.id, 'success', 'Shared Hosting',
                            f'{action.capitalize()} completed for {scope}.')
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Shared control error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/vps/<int:vps_id>/control/<action>', methods=['POST'])
@login_required
def vps_control(vps_id, action):
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    actions = ['start', 'stop', 'restart', 'freeze', 'unfreeze']
    if action not in actions:
        return jsonify({'success': False, 'error': 'Invalid action'}), 400
    
    # Shared hosting (no LXD): control the requesting user's OWN account
    # processes - users can only ever affect their own files/processes.
    if is_shared_vps(vps):
        return _shared_control(vps, action)
    
    try:
        if action == 'start':
            run_sync(execute_lxc(vps['container_name'], f"start {vps['container_name']}", node_id=vps['node_id']))
            run_sync(apply_internal_permissions(vps['container_name'], vps['node_id']))
            try:
                run_sync(recreate_port_forwards(vps['container_name']))
            except Exception as pf_err:
                logger.warning(f"Port forward recreation failed for {vps['container_name']}: {pf_err}")
            update_vps(vps_id, status='running', last_started=datetime.now().isoformat())
            log_activity(current_user.id, 'start_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'success', 'VPS Started', f'VPS {vps["container_name"]} has been started.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'running'
                }, room=f'vps_{vps_id}')
                
        elif action == 'stop':
            run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']}", node_id=vps['node_id']))
            update_vps(vps_id, status='stopped', last_stopped=datetime.now().isoformat())
            log_activity(current_user.id, 'stop_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'info', 'VPS Stopped', f'VPS {vps["container_name"]} has been stopped.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'stopped'
                }, room=f'vps_{vps_id}')
                
        elif action == 'restart':
            run_sync(execute_lxc(vps['container_name'], f"restart {vps['container_name']}", node_id=vps['node_id']))
            run_sync(apply_internal_permissions(vps['container_name'], vps['node_id']))
            try:
                run_sync(recreate_port_forwards(vps['container_name']))
            except Exception as pf_err:
                logger.warning(f"Port forward recreation failed for {vps['container_name']}: {pf_err}")
            update_vps(vps_id, status='running', last_started=datetime.now().isoformat())
            log_activity(current_user.id, 'restart_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'success', 'VPS Restarted', f'VPS {vps["container_name"]} has been restarted.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'running'
                }, room=f'vps_{vps_id}')
                
        elif action == 'freeze':
            run_sync(execute_lxc(vps['container_name'], f"freeze {vps['container_name']}", node_id=vps['node_id']))
            update_vps(vps_id, status='frozen')
            log_activity(current_user.id, 'freeze_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'warning', 'VPS Frozen', f'VPS {vps["container_name"]} has been frozen.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'frozen'
                }, room=f'vps_{vps_id}')
                
        elif action == 'unfreeze':
            run_sync(execute_lxc(vps['container_name'], f"unfreeze {vps['container_name']}", node_id=vps['node_id']))
            update_vps(vps_id, status='running')
            log_activity(current_user.id, 'unfreeze_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'success', 'VPS Unfrozen', f'VPS {vps["container_name"]} has been unfrozen.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'running'
                }, room=f'vps_{vps_id}')
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"VPS control error: {e}")
        create_notification(current_user.id, 'error', 'Action Failed', f'Failed to {action} VPS: {str(e)}')
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================================================
# Console Routes - FIXED VERSION
# ============================================================================
@app.route('/vps/<int:vps_id>/console')
@login_required
def vps_console(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        flash('Access denied', 'danger')
        return redirect(url_for('vps_list'))
    
    # Check if VPS is suspended
    if is_vps_suspended(vps) and not current_user.is_admin:
        flash('VPS is suspended. Console access denied.', 'danger')
        return redirect(url_for('vps_suspended_page', vps_id=vps_id))

    # Get VPS IP address
    vps_ip = vps.get('ip_address', '')
    
    # Shared hosting: the console logs into the user's own account on the node
    shared_account = None
    shared_node_host = None
    if is_shared_vps(vps):
        shared_account = get_request_shared_account(vps)
        if not shared_account:
            flash('No shared hosting account is linked to your user', 'danger')
            return redirect(url_for('vps_list'))
        if shared_account.get('status') == 'suspended' and not current_user.is_admin:
            flash('Your shared hosting account is suspended. Console access denied.', 'danger')
            return redirect(url_for('vps_suspended_page', vps_id=vps_id))
        shared_node_host = _node_host_for(get_node(vps['node_id']))
        vps_ip = shared_node_host or vps_ip
    
    return render_template(
        'console.html',
        panel_name=get_setting('site_name', 'ExpelHost Panel'),
        vps=vps,
        vps_ip=vps_ip,
        shared_account=shared_account,
        shared_node_host=shared_node_host,
        ssh_available=SSH_AVAILABLE
    )

# SocketIO events for SSH console
if socketio and SSH_AVAILABLE:
    @socketio.on('ssh_connect')
    def handle_ssh_connect(data):
        vps_id = data.get('vps_id')
        host = data.get('host', '')
        port = data.get('port', 22)
        username = data.get('username', 'root')
        password = data.get('password', '')
        sid = request.sid

        logger.info(f"SSH connect request for VPS {vps_id} from session {sid} to {username}@{host}:{port}")

        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"SSH connect failed: VPS {vps_id} not found")
            emit('ssh_error', {'error': 'VPS not found'}, room=sid)
            return

        if not can_access_vps(vps):
            logger.error(f"SSH connect failed: Access denied for VPS {vps_id}")
            emit('ssh_error', {'error': 'Access denied'}, room=sid)
            return

        if not is_shared_vps(vps) and get_vps_role(vps) == 'viewer':
            emit('ssh_error', {'error': 'Viewer access is read-only'}, room=sid)
            return

        if is_vps_suspended(vps) and not current_user.is_admin:
            logger.error(f"SSH connect failed: VPS {vps_id} is suspended")
            emit('ssh_error', {'error': 'VPS is suspended'}, room=sid)
            return

        # Host/password may be blank: the panel will auto-detect a working route
        # (direct container IP, then the node's port-forward) using root:root.
        if not host and not password:
            logger.info(f"SSH connect for VPS {vps_id}: no credentials supplied, using auto-detection")

        # Close any previous session belonging to this browser tab
        with active_consoles_lock:
            old_info = active_consoles.pop(sid, None)
        if old_info:
            try:
                if old_info.get('ssh_client'):
                    old_info['ssh_client'].close()
                if old_info.get('channel'):
                    old_info['channel'].close()
            except Exception:
                pass
            logger.info(f"Closed existing SSH connection for session {sid}")

        try:
            try:
                port = int(port)
            except Exception:
                port = 22

            # ---- Build candidate routes to reach the container's sshd ----
            candidates = []

            # Shared hosting (no LXD): log into the requester's own system
            # account on the node - the restricted shell keeps them inside
            # their home directory, so they only ever manage their own files.
            if is_shared_vps(vps):
                acct = get_shared_account(vps['id'], current_user.id)
                if not acct and current_user.is_admin:
                    accounts = get_shared_accounts(vps['id'])
                    acct = accounts[0] if accounts else None
                if not acct:
                    emit('ssh_error', {'error': 'No shared hosting account is linked to your user'}, room=sid)
                    return
                if acct.get('status') == 'suspended':
                    emit('ssh_error', {'error': 'Your shared hosting account is suspended'}, room=sid)
                    return
                _shared_node = get_node(vps['node_id'])
                node_host = _node_ssh_host_for(_shared_node)
                if not node_host:
                    emit('ssh_error', {'error': 'Node host could not be resolved'}, room=sid)
                    return
                username = acct['system_user']
                password = acct['ssh_password']
                port = _node_ssh_port_for(_shared_node)
                candidates = [(node_host, port, password)]
                logger.info(f"Shared hosting console for VPS {vps_id}: {username}@{node_host}:22")

            def add_candidate(h, p, pw):
                if not h:
                    return
                try:
                    p = int(p)
                except Exception:
                    p = 22
                entry = (h, p, pw or 'root')
                if entry not in candidates:
                    candidates.append(entry)

            if not is_shared_vps(vps):
                # 1) What the user typed (may be blank)
                add_candidate(host, port, password)

                # 2) The container's private IP (works when the panel host routes to the LXD bridge)
                try:
                    private_ip = run_sync(get_container_private_ip(vps['container_name'], vps['node_id']))
                    if private_ip and private_ip != 'N/A':
                        add_candidate(private_ip, 22, password)
                        add_candidate(private_ip, 22, 'root')
                except Exception as e:
                    logger.debug(f"Could not resolve private IP for VPS {vps_id}: {e}")

                # 3) The node host via an LXD port-forward to container port 22
                try:
                    node = get_node(vps['node_id'])
                    node_host = _node_host_for(node)
                    if node_host:
                        with get_db() as conn:
                            cur = conn.cursor()
                            cur.execute('SELECT host_port FROM port_forwards WHERE vps_container = ? AND vps_port = 22',
                                        (vps['container_name'],))
                            row = cur.fetchone()
                        if row:
                            fwd_port = row['host_port']
                        else:
                            fwd_port = run_sync(create_port_forward(
                                user_id=vps['user_id'], container=vps['container_name'], vps_port=22,
                                node_id=vps['node_id'], protocol='tcp',
                                description='SSH (auto-created for console)'))
                        if fwd_port:
                            add_candidate(node_host, fwd_port, password)
                            add_candidate(node_host, fwd_port, 'root')
                except Exception as e:
                    logger.debug(f"Could not prepare port-forward route for VPS {vps_id}: {e}")

            # Local node: open the terminal directly (no sshd / password / proxy needed)
            local_chan = None
            try:
                local_chan = _open_local_console(vps, username if is_shared_vps(vps) else None)
            except Exception as lc_err:
                logger.warning(f"Local console unavailable for VPS {vps_id}, using SSH: {lc_err}")
                local_chan = None

            if not candidates and local_chan is None:
                emit('ssh_error', {'error': 'No route to the VPS. Make sure it is running and a node is assigned.'}, room=sid)
                return

            def attempt_connect(cands):
                last_err = None
                for (h, p, pw) in cands:
                    client = paramiko.SSHClient()
                    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    try:
                        logger.info(f"Connecting to SSH: {username}@{h}:{p}")
                        client.connect(
                            hostname=h,
                            port=p,
                            username=username,
                            password=pw,
                            timeout=10,
                            allow_agent=False,
                            look_for_keys=False
                        )
                        channel = client.invoke_shell(term='xterm', width=80, height=24)
                        channel.settimeout(0.1)
                        return client, channel, h, p, pw, None
                    except Exception as e:
                        last_err = e
                        try:
                            client.close()
                        except Exception:
                            pass
                return None, None, None, None, None, last_err

            if local_chan is not None:
                ssh_client, channel, conn_host, conn_port, conn_password, err = _NullSSHClient(), local_chan, 'local', 0, '', None
            else:
                ssh_client, channel, conn_host, conn_port, conn_password, err = attempt_connect(candidates)

            if ssh_client is None and not is_shared_vps(vps):
                # Last resort: make sure sshd is actually running inside the container, then retry
                try:
                    run_sync(execute_lxc(
                        vps['container_name'],
                        f"exec {vps['container_name']} -- sh -c 'service ssh start >/dev/null 2>&1; service sshd start >/dev/null 2>&1; (command -v systemctl >/dev/null 2>&1 && systemctl start ssh >/dev/null 2>&1); (/usr/sbin/sshd >/dev/null 2>&1 &); sleep 2; echo SSHD_RESTART_DONE'",
                        node_id=vps['node_id'], timeout=60))
                except Exception as start_err:
                    logger.debug(f"sshd start attempt failed for VPS {vps_id}: {start_err}")
                time.sleep(2)
                ssh_client, channel, conn_host, conn_port, conn_password, err = attempt_connect(candidates)

            if ssh_client is None:
                logger.error(f"SSH connection failed for VPS {vps_id}: {err}")
                if isinstance(err, paramiko.AuthenticationException):
                    emit('ssh_error', {'error': 'Authentication failed. Invalid username or password.'}, room=sid)
                elif isinstance(err, socket.timeout):
                    emit('ssh_error', {'error': 'Connection timed out. The VPS may be stopped, or SSH is unreachable from the panel.'}, room=sid)
                elif isinstance(err, paramiko.SSHException):
                    emit('ssh_error', {'error': f'SSH connection error: {str(err)}'}, room=sid)
                else:
                    emit('ssh_error', {'error': f'Failed to connect: {str(err)}'}, room=sid)
                return

            logger.info(f"SSH connected for VPS {vps_id} via {conn_host}:{conn_port}")

            with active_consoles_lock:
                active_consoles[sid] = {
                    'ssh_client': ssh_client,
                    'channel': channel,
                    'sid': sid,
                    'vps_id': vps_id,
                    'host': conn_host,
                    'port': conn_port,
                    'username': username,
                    'user_id': current_user.id
                }

            def reader():
                try:
                    logger.info(f"SSH reader thread started for VPS {vps_id}")
                    while True:
                        # Check if channel is still open
                        if channel.closed:
                            logger.info(f"SSH channel closed for VPS {vps_id}")
                            break

                        # Read output from channel
                        try:
                            if channel.recv_ready():
                                output = channel.recv(4096)
                                if not output:
                                    break
                                # Send to client
                                socketio.emit('ssh_output', output.decode('utf-8', errors='replace'), room=sid)
                            else:
                                time.sleep(0.01)
                        except socket.timeout:
                            continue
                        except Exception as e:
                            logger.error(f"SSH read error for VPS {vps_id}: {e}")
                            break

                except Exception as e:
                    logger.error(f"SSH reader error for VPS {vps_id}: {e}")
                    socketio.emit('ssh_error', {'error': str(e)}, room=sid)
                finally:
                    logger.info(f"SSH reader thread ending for VPS {vps_id}")
                    try:
                        channel.close()
                        ssh_client.close()
                    except Exception:
                        pass
                    with active_consoles_lock:
                        active_consoles.pop(sid, None)
                    socketio.emit('ssh_disconnected', {}, room=sid)

            thread = threading.Thread(target=reader, daemon=True)
            thread.start()

            emit('ssh_connected', {
                'status': 'connected',
                'host': conn_host,
                'port': conn_port,
                'username': username
            }, room=sid)
            logger.info(f"SSH session established for VPS {vps_id}")

        except Exception as e:
            logger.error(f"Failed to start SSH for VPS {vps_id}: {e}", exc_info=True)
            emit('ssh_error', {'error': f'Failed to connect: {str(e)}'}, room=sid)

    @socketio.on('ssh_input')
    def handle_ssh_input(data):
        vps_id = data.get('vps_id')
        input_data = data.get('input', '')

        with active_consoles_lock:
            info = active_consoles.get(request.sid)
            if not info or info.get('sid') != request.sid:
                emit('ssh_error', {'error': 'SSH not connected'}, room=request.sid)
                return

            try:
                channel = info.get('channel')
                if channel and not channel.closed:
                    if isinstance(input_data, str):
                        input_data = input_data.encode('utf-8')
                    channel.send(input_data)
            except Exception as e:
                logger.error(f"SSH input error for VPS {vps_id}: {e}")
                emit('ssh_error', {'error': str(e)}, room=request.sid)

    @socketio.on('ssh_resize')
    def handle_ssh_resize(data):
        vps_id = data.get('vps_id')
        cols = data.get('cols', 80)
        rows = data.get('rows', 24)

        with active_consoles_lock:
            info = active_consoles.get(request.sid)
            if info and info.get('sid') == request.sid:
                try:
                    channel = info.get('channel')
                    if channel and not channel.closed:
                        channel.resize_pty(width=cols, height=rows)
                        logger.debug(f"SSH terminal resized for VPS {vps_id}: {cols}x{rows}")
                except Exception as e:
                    logger.error(f"SSH resize error for VPS {vps_id}: {e}")

    @socketio.on('ssh_disconnect')
    def handle_ssh_disconnect(data):
        vps_id = data.get('vps_id')
        logger.info(f"SSH disconnect request for VPS {vps_id}")

        with active_consoles_lock:
            info = active_consoles.get(request.sid)
            if info and info.get('sid') == request.sid:
                active_consoles.pop(request.sid, None)
                try:
                    if 'channel' in info and info['channel']:
                        info['channel'].close()
                    if 'ssh_client' in info and info['ssh_client']:
                        info['ssh_client'].close()
                    logger.info(f"SSH disconnected for VPS {vps_id}")
                except Exception as e:
                    logger.error(f"SSH disconnect error for VPS {vps_id}: {e}")


class _NullSSHClient:
    def close(self):
        pass


class LocalPtyChannel:
    """paramiko-Channel look-alike backed by a local pseudo-terminal.  Used for
    nodes that run on the panel host so the web terminal never depends on sshd,
    passwords or LXD proxy devices."""

    def __init__(self, argv, env=None, cols=80, rows=24):
        import pty, fcntl, termios, struct
        self._master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))
        e = dict(os.environ)
        e.update({'TERM': 'xterm', 'LANG': 'C.UTF-8'})
        e.update(env or {})

        def _ctty():
            try:
                fcntl.ioctl(0, termios.TIOCSCTTY, 1)
            except Exception:
                pass
        self._proc = subprocess.Popen(argv, stdin=slave, stdout=slave, stderr=slave, env=e,
                                      close_fds=True, start_new_session=True, preexec_fn=_ctty)
        os.close(slave)
        self._closed = False

    @property
    def closed(self):
        if self._closed:
            return True
        if self._proc.poll() is not None and not self.recv_ready():
            return True
        return False

    def settimeout(self, t):
        pass

    def recv_ready(self):
        if self._closed:
            return False
        try:
            import select as _select
            return bool(_select.select([self._master], [], [], 0)[0])
        except Exception:
            return False

    def recv(self, n):
        try:
            return os.read(self._master, n)
        except OSError:
            return b''

    def send(self, data):
        if isinstance(data, str):
            data = data.encode('utf-8', errors='replace')
        os.write(self._master, data)
        return len(data)

    sendall = send

    def resize_pty(self, width=80, height=24, *a, **k):
        import fcntl, termios, struct
        try:
            fcntl.ioctl(self._master, termios.TIOCSWINSZ, struct.pack('HHHH', int(height), int(width), 0, 0))
        except Exception:
            pass

    def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=2)
            except Exception:
                self._proc.kill()
        except Exception:
            pass
        try:
            os.close(self._master)
        except Exception:
            pass


def _open_local_console(vps, shared_user=None):
    """Return a LocalPtyChannel for VPS on a local node, or None when not possible."""
    node = get_node(vps['node_id'])
    if not node or not node.get('is_local'):
        return None
    if shared_user:
        # self-heal: make sure the node has the current restricted shell (fixes the neofetch freeze
        # on servers installed with an older panel) - no reinstall of any shared VPS needed
        try:
            _rc = '/usr/local/etc/hvm-shellrc'
            _txt = open(_rc).read() if os.path.exists(_rc) else ''
            if os.geteuid() == 0 and (not os.path.exists('/usr/local/bin/hvm-cgroup') or 'neofetch can never freeze' not in _txt):
                subprocess.run(['bash', '-c', shared_hosting.shell_refresh_script()],
                               capture_output=True, timeout=30)
        except Exception as _e:
            logger.debug(f"hvm-shell refresh skipped: {_e}")
        script = ('[ -x /usr/local/bin/hvm-shell ] && exec runuser -u "$0" -- /usr/local/bin/hvm-shell '
                  '|| exec runuser -l "$0"')
        chan = LocalPtyChannel(['bash', '-c', script, shared_user], env={'HOME': '/'})
    else:
        if vps.get('status') not in ('running',):
            return None
        name = vps['container_name']
        chan = LocalPtyChannel(['lxc', 'exec', name, '--', 'sh', '-c',
                                'command -v bash >/dev/null 2>&1 && exec bash -l || exec sh -l'])
    # if the shell dies right away, do not hand back a dead terminal: use SSH instead
    time.sleep(0.8)
    if chan._proc.poll() is not None:
        try:
            chan.close()
        except Exception:
            pass
        return None
    return chan

def _node_host_for(node):
    """Resolve the hostname/IP of a node (localhost for local nodes)."""
    if not node:
        return None
    if node.get('is_local'):
        return '127.0.0.1'
    url = node.get('url') or ''
    if '://' in url:
        url = url.split('://', 1)[1]
    url = url.split('/')[0]
    if url.count(':') == 1:
        url = url.split(':')[0]
    return url or None


def _node_ssh_host_for(node):
    """Host used for SSH to a node's shared accounts: the node's custom SSH host if set
    (remote nodes only), otherwise the normal node host."""
    if node and not node.get('is_local') and (node.get('ssh_host') or '').strip():
        return node['ssh_host'].strip()
    return _node_host_for(node)


def _node_ssh_port_for(node):
    """SSH port for a node's shared accounts (custom port for remote nodes, else 22)."""
    if node and not node.get('is_local'):
        try:
            p = int(node.get('ssh_port') or 0)
            if 0 < p < 65536:
                return p
        except Exception:
            pass
    return 22


def _strip_ansi(text):
    """Remove ANSI escape sequences (color codes) from container output."""
    if not text or not isinstance(text, str):
        return text
    return re.sub(r'\x1b\[[0-9;]*[a-zA-Z]|\x1b\][^\x07]*\x07', '', text)


def _sshx_extract_url(text):
    """Pull the shareable https://sshx.io/... link out of sshx output.
    Handles both legacy (sshx.io/abc123) and current (sshx.io/s/abc123) URL formats."""
    if not text or not isinstance(text, str):
        return None
    # sshx links look like https://sshx.io/s/<id>#<key>[,<write-key>].
    # The '#key' fragment is REQUIRED for the link to open, so it must be captured too.
    m = re.search(r'https?://(?:[A-Za-z0-9-]+\.)*sshx\.io/(?:s/)?[A-Za-z0-9_-]+(?:#[A-Za-z0-9_,.~%+=-]+)?(?=\s)', _strip_ansi(text))
    # (?=\s): only accept a link once its line is complete - polling can read the
    # output file mid-write and would otherwise return HALF of the link.
    return m.group(0).rstrip('.,;') if m else None


# Runs INSIDE the container: kills any previous sshx, then launches a fresh one in
# the background (setsid keeps it alive after `lxc exec` exits) capturing all output
# to /tmp/sshx.out so the panel can poll it for the shareable URL.
SSHX_RUN_SCRIPT = (
    "pkill -x sshx >/dev/null 2>&1; sleep 1; rm -f /tmp/sshx.out; "
    "setsid sh -c '"
    "if command -v curl >/dev/null 2>&1; then curl -sSf https://sshx.io/get | sh -s run; "
    "elif command -v wget >/dev/null 2>&1; then wget -qO- https://sshx.io/get | sh -s run; "
    "else echo \"ERROR: neither curl nor wget found in container\"; fi"
    "' </dev/null >/tmp/sshx.out 2>&1 & echo STARTED"
)


def _tmate_install_script():
    """In-container command that installs tmate (apk on Alpine, static binary on x86_64)."""
    return (
        "sh -c '"
        "if command -v tmate >/dev/null 2>&1; then exit 0; fi; "
        "if command -v apk >/dev/null 2>&1; then apk add --no-cache tmate >/dev/null 2>&1 && exit 0; fi; "
        "if [ \"$(uname -m)\" != \"x86_64\" ]; then exit 1; fi; "
        "if command -v curl >/dev/null 2>&1; then curl -fsSL -o /tmp/tmate.tgz https://github.com/tmate-io/tmate/releases/download/2.2.1/tmate-2.2.1-static-linux-amd64.tar.gz; "
        "elif command -v wget >/dev/null 2>&1; then wget -qO /tmp/tmate.tgz https://github.com/tmate-io/tmate/releases/download/2.2.1/tmate-2.2.1-static-linux-amd64.tar.gz; "
        "else exit 1; fi; "
        "tar -xzf /tmp/tmate.tgz -C /tmp >/dev/null 2>&1; "
        "cp /tmp/tmate-2.2.1-static-linux-amd64/tmate /usr/local/bin/tmate 2>/dev/null || cp /tmp/tmate /usr/local/bin/tmate; "
        "chmod +x /usr/local/bin/tmate 2>/dev/null; rm -rf /tmp/tmate.tgz /tmp/tmate-2.2.1-static-linux-amd64; "
        "command -v tmate >/dev/null 2>&1"
        "'"
    )


@app.route('/vps/<int:vps_id>/ssh', methods=['POST'])
@login_required
def vps_ssh(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    # Shared hosting has no container - external SSH sessions are unavailable
    if is_shared_vps(vps):
        return jsonify({'success': False,
                        'error': 'External SSH sessions are not available on shared hosting. Use the web console instead.'}), 400

    container_name = vps['container_name']
    node_id = vps['node_id']

    # ---- 1) Preferred: tmate (socket-based session with ssh:// + web URLs) ----
    session_name = f"hvm-session-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    try:
        try:
            run_sync(execute_lxc(container_name, f"exec {container_name} -- which tmate", node_id=node_id, timeout=30))
        except Exception:
            # tmate is NOT in Ubuntu/Debian repos - install the official static binary instead
            run_sync(execute_lxc(container_name, f"exec {container_name} -- {_tmate_install_script()}", node_id=node_id, timeout=180))

        run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock new-session -d", node_id=node_id, timeout=60))

        # Wait (with retries) until tmate registers with tmate.io and prints the URLs
        ssh_url = ''
        web_url = ''
        for _ in range(15):
            time.sleep(2)
            try:
                ssh_output = run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock display -p '#{{tmate_ssh}}'", node_id=node_id, timeout=30))
                ssh_url = (ssh_output or '').strip() if isinstance(ssh_output, str) else ''
            except Exception:
                ssh_url = ''
            if ssh_url.startswith('ssh'):
                break

        if ssh_url.startswith('ssh'):
            try:
                web_output = run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock display -p '#{{tmate_web}}'", node_id=node_id, timeout=30))
                web_url = (web_output or '').strip() if isinstance(web_output, str) else ''
                if not web_url.startswith('http'):
                    web_url = ''
            except Exception:
                web_url = ''

            log_activity(current_user.id, 'generate_ssh', 'vps', str(vps_id))
            create_notification(current_user.id, 'info', 'SSH Session Created', f'SSH session created for {container_name}')
            return jsonify({
                'success': True,
                'ssh_url': ssh_url,
                'web_url': web_url,
                'session': session_name,
                'method': 'tmate'
            })
    except Exception as e:
        logger.warning(f"tmate SSH generation failed for {container_name}, falling back to sshx: {e}")

    # ---- 2) Fallback: sshx (single static binary, works on any Linux container) ----
    try:
        run_sync(execute_lxc(container_name, f"exec {container_name} -- sh -c {shlex.quote(SSHX_RUN_SCRIPT)}", node_id=node_id, timeout=90))

        sshx_url = ''
        sshx_out = ''
        for _ in range(20):
            time.sleep(2)
            try:
                out = run_sync(execute_lxc(container_name, f"exec {container_name} -- cat /tmp/sshx.out", node_id=node_id, timeout=20))
                sshx_out = out if isinstance(out, str) else ''
            except Exception:
                sshx_out = ''
            sshx_url = _sshx_extract_url(sshx_out) or ''
            if sshx_url:
                break

        if sshx_url:
            log_activity(current_user.id, 'generate_ssh', 'vps', str(vps_id))
            create_notification(current_user.id, 'info', 'SSH Session Created', f'SSHX session created for {container_name}')
            return jsonify({
                'success': True,
                'ssh_url': sshx_url,
                'web_url': sshx_url,
                'session': 'sshx',
                'method': 'sshx'
            })

        return jsonify({'success': False, 'error': f'Could not generate SSH URL. Container output: {(sshx_out or "no output")[-400:]}'}), 500
    except Exception as e:
        logger.error(f"SSH generation error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500



def _shared_sshx_account(vps):
    """The CURRENT user's own shared account (sshx always runs as that account's
    unprivileged system user - never as another user's). Returns (acct, error_response)."""
    acct = get_shared_account(vps['id'], current_user.id)
    if not acct:
        return None, (jsonify({'success': False,
                               'error': 'You have no shared hosting account on this server. '
                                        'Ask an admin to grant you one.'}), 400)
    if acct.get('status') == 'suspended':
        return None, (jsonify({'success': False, 'error': 'Your shared hosting account is suspended.'}), 403)
    return acct, None


def _shared_sshx_poll(vps, acct):
    """(running, output) of the account's sshx tunnel on its node."""
    res = shared_node_op(vps, shared_hosting.sshx_status_script(acct['system_user']), timeout=60)
    # parse() strips the 'HVMREC|sshx' prefix -> record == [running_flag, base64_output]
    recs = res.get('records') or []
    rec = recs[0] if recs else None
    running, output = False, ''
    if rec:
        running = rec[0] == '1'
        if len(rec) >= 2 and rec[1]:
            try:
                output = base64.b64decode(rec[1]).decode('utf-8', errors='replace')
            except Exception:
                output = ''
    return running, output

@app.route('/vps/<int:vps_id>/sshx', methods=['POST'])
@login_required
def vps_sshx(vps_id):
    """Start a BRAND NEW sshx session in the VPS (kills any previous one first,
    so every click generates a fresh URL)."""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    if is_shared_vps(vps):
        acct, err = _shared_sshx_account(vps)
        if err:
            return err
        try:
            res = shared_node_op(vps, shared_hosting.sshx_start_script(acct['system_user']), timeout=120)
            shared_hosting.ensure_ok(res, 'Starting sshx')
        except Exception as e:
            logger.error(f"Shared SSHX start error: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
        log_activity(current_user.id, 'generate_sshx', 'vps', str(vps_id), {'shared': True})
        return jsonify({'success': True, 'message': 'sshx session started'})

    container_name = vps['container_name']
    node_id = vps['node_id']

    try:
        info = str(run_sync(execute_lxc(container_name, f"info {container_name}", node_id=node_id, timeout=30)))
        if 'Status: RUNNING' not in info:
            return jsonify({'success': False, 'error': 'VPS is not running. Start it first.'}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': f'Could not query container: {str(e)}'}), 500

    try:
        # SSHX_RUN_SCRIPT kills the old sshx process before starting the new one,
        # so every click produces a fresh URL.
        run_sync(execute_lxc(container_name, f"exec {container_name} -- sh -c {shlex.quote(SSHX_RUN_SCRIPT)}", node_id=node_id, timeout=90))
        log_activity(current_user.id, 'generate_sshx', 'vps', str(vps_id))
        return jsonify({'success': True, 'message': 'sshx session started'})
    except Exception as e:
        logger.error(f"SSHX start error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/vps/<int:vps_id>/sshx/status')
@login_required
def vps_sshx_status(vps_id):
    """Poll sshx output/URL from inside the container."""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    if is_shared_vps(vps):
        acct, err = _shared_sshx_account(vps)
        if err:
            return err
        try:
            running, output = _shared_sshx_poll(vps, acct)
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
        url = _sshx_extract_url(output)
        return jsonify({'success': True, 'running': running, 'ready': bool(url), 'url': url,
                        'output': _strip_ansi(output)[-4000:]})

    container_name = vps['container_name']
    node_id = vps['node_id']

    output = ''
    try:
        out = run_sync(execute_lxc(container_name, f"exec {container_name} -- cat /tmp/sshx.out", node_id=node_id, timeout=20))
        if isinstance(out, str):
            output = out
    except Exception:
        output = ''

    running = False
    try:
        chk = run_sync(execute_lxc(container_name, f"exec {container_name} -- sh -c 'pidof sshx >/dev/null 2>&1 && echo RUNNING || echo STOPPED'", node_id=node_id, timeout=20))
        running = 'RUNNING' in str(chk)
    except Exception:
        running = False

    url = _sshx_extract_url(output)
    return jsonify({
        'success': True,
        'running': running,
        'ready': bool(url),
        'url': url,
        'output': _strip_ansi(output)[-4000:]
    })


@app.route('/vps/<int:vps_id>/sshx/stop', methods=['POST'])
@login_required
def vps_sshx_stop(vps_id):
    """Kill the running sshx session."""
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    if is_shared_vps(vps):
        acct, err = _shared_sshx_account(vps)
        if err:
            return err
        try:
            shared_node_op(vps, shared_hosting.sshx_stop_script(acct['system_user']), timeout=60)
        except Exception as e:
            logger.debug(f"shared sshx stop (ignoring): {e}")
        return jsonify({'success': True, 'message': 'sshx session stopped'})

    container_name = vps['container_name']
    node_id = vps['node_id']

    try:
        run_sync(execute_lxc(container_name, f"exec {container_name} -- sh -c 'pkill -x sshx >/dev/null 2>&1; rm -f /tmp/sshx.out; echo STOPPED'", node_id=node_id, timeout=20))
    except Exception as e:
        logger.debug(f"sshx stop (ignoring): {e}")
    return jsonify({'success': True, 'message': 'sshx session stopped'})

@app.route('/api/palette')
@login_required
def api_palette():
    """Lightweight VPS index for the Ctrl+K command palette (no live stat calls)."""
    try:
        rows = get_vps_for_user(current_user.id, include_team=True)
    except Exception as e:
        logger.warning(f"palette error: {e}")
        rows = []
    out = []
    for v in rows:
        out.append({
            'id': v['id'],
            'name': v.get('hostname') or v.get('container_name') or f"VPS {v['id']}",
            'status': 'suspended' if is_vps_suspended(v) else (v.get('status') or 'unknown'),
            'ip': v.get('ip_address') or v.get('ip_alias') or ''
        })
    return jsonify({'success': True, 'vps': out})


@app.route('/vps/<int:vps_id>/stats')
@login_required
def vps_stats(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        if is_shared_vps(vps):
            stats = shared_stats_for_user(vps, current_user.id)
            stats['private_ip'] = "N/A"
            _, stats = apply_fake_to_panel(vps, stats)
            return jsonify({'success': True, 'stats': stats})
        
        stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
        
        # Get private IP if VPS is running
        private_ip = "N/A"
        if stats.get('status') == 'running':
            try:
                private_ip = run_sync(get_container_private_ip(vps['container_name'], vps['node_id']))
            except:
                private_ip = "N/A"
        
        stats['private_ip'] = private_ip
        _, stats = apply_fake_to_panel(vps, stats)
        
        return jsonify({'success': True, 'stats': stats})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

REINSTALL_JOBS: Dict[int, Dict[str, Any]] = {}
REINSTALL_STAGES = [
    # (key, label, percent when stage starts)
    ('stop',      'Stopping the VPS',                  2),
    ('remove',    'Removing the old system',           8),
    ('image',     'Downloading & unpacking the OS',   14),
    ('resources', 'Applying CPU, RAM and disk',       55),
    ('config',    'Configuring permissions',          62),
    ('start',     'Booting the new system',           68),
    ('network',   'Setting up networking',            74),
    ('packages',  'Installing base packages',         84),
    ('ssh',       'Configuring SSH access',           92),
    ('ports',     'Restoring port forwards',          97),
]

def _reinstall_progress(vps_id: int, key: str):
    idx = next(i for i, st in enumerate(REINSTALL_STAGES) if st[0] == key)
    nxt = REINSTALL_STAGES[idx + 1][2] if idx + 1 < len(REINSTALL_STAGES) else 100
    job = REINSTALL_JOBS.get(vps_id)
    if job is not None:
        job.update(stage=key, label=REINSTALL_STAGES[idx][1], percent=REINSTALL_STAGES[idx][2], next=nxt, index=idx,
                   updated=time.time())
    if socketio:
        try:
            socketio.emit('vps_reinstall_progress', {'vps_id': vps_id, 'percent': REINSTALL_STAGES[idx][2],
                          'stage': key, 'label': REINSTALL_STAGES[idx][1]}, room=f'vps_{vps_id}')
        except Exception:
            pass

def _reinstall_worker(vps_id: int, vps: Dict, os_version: str, actor_id: int, actor_is_admin: bool):
    container_name = vps['container_name']
    node_id = vps['node_id']
    prog = lambda k: _reinstall_progress(vps_id, k)
    try:
        ram_mb = int(vps['ram'].replace('GB', '')) * 1024
        cpu = int(vps['cpu'])
        storage_gb = int(vps['storage'].replace('GB', ''))

        prog('stop')
        try:
            run_sync(execute_lxc(container_name, f"stop {container_name} --force", node_id=node_id))
        except Exception as e:
            logger.warning(f"Failed to stop container {container_name}: {e}")

        prog('remove')
        run_sync(execute_lxc(container_name, f"delete {container_name} --force", node_id=node_id))
        # fresh dedicated disk (the old pool is destroyed first, then a new one of the same size is made)
        _pool, _root, _drv, _perr = run_sync(create_dedicated_storage(container_name, storage_gb, node_id))
        if _drv is None:
            run_sync(ensure_pool_capacity(node_id, get_node_allocated_gib(node_id)))

        prog('image')
        run_sync(ensure_lxd_network(node_id))
        run_sync(execute_lxc(container_name, f"init {os_version} {container_name} -s {_pool}", node_id=node_id, timeout=900))

        prog('resources')
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.memory {ram_mb}MB", node_id=node_id))
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.cpu {cpu}", node_id=node_id))
        run_sync(finish_dedicated_storage(container_name, node_id, storage_gb, _pool, _root, _drv))

        prog('config')
        run_sync(apply_lxc_config(container_name, node_id))

        prog('start')
        run_sync(execute_lxc(container_name, f"start {container_name}", node_id=node_id))

        prog('network')
        if vps.get('ip_address'):
            run_sync(configure_container_ip(container_name, vps['ip_address'], node_id))
        run_sync(wait_for_container_network(container_name, node_id))

        prog('packages')
        run_sync(_with_deadline(apply_internal_permissions(container_name, node_id), 240, 'packages'))

        prog('ssh')
        run_sync(_with_deadline(configure_ssh_and_root_password(container_name, node_id), 200, 'ssh'))
        run_sync(apply_cpu_view(container_name, node_id, cpu))
        run_sync(apply_ram_view(container_name, node_id, ram_mb))
        _fk = get_vps_fake_cfg(container_name)
        if _fk:
            run_sync(apply_fake_view(container_name, node_id, _fk))

        prog('ports')
        run_sync(recreate_port_forwards(container_name))

        with get_db() as conn:
            cur = conn.cursor()
            now = datetime.now().isoformat()
            cur.execute('UPDATE vps SET os_version = ?, status = ?, last_started = ?, updated_at = ? WHERE id = ?',
                        (os_version, 'running', now, now, vps_id))
            conn.commit()

        log_activity(actor_id, 'reinstall_vps', 'vps', str(vps_id), {'os': os_version})
        if actor_is_admin and actor_id != vps['user_id']:
            log_activity(actor_id, 'admin_reinstall_vps', 'vps', str(vps_id), {'os': os_version, 'owner_id': vps['user_id']})
        create_notification(actor_id, 'success', 'VPS Reinstalled', f'VPS {container_name} has been reinstalled with {os_version}')

        REINSTALL_JOBS[vps_id].update(status='done', percent=100, next=100, label='Installation complete', stage='done', updated=time.time())
        if socketio:
            socketio.emit('vps_reinstalled', {'vps_id': vps_id, 'os_version': os_version, 'status': 'running'}, room=f'vps_{vps_id}')
            socketio.emit('vps_status_change', {'vps_id': vps_id, 'status': 'running', 'os_version': os_version}, room=f'user_{vps["user_id"]}')
    except Exception as e:
        logger.error(f"Reinstall error for VPS {vps_id}: {e}", exc_info=True)
        REINSTALL_JOBS[vps_id].update(status='error', error=str(e).split('\nCommand:')[0][:300], updated=time.time())

SHARED_REINSTALL_STAGES = [
    # (key, label, percent when stage starts) -- wipes ONLY the chosen accounts
    ('prepare',  'Preparing your account',      5),
    ('stop',     'Stopping your processes',     20),
    ('wipe',     'Removing your files',         40),
    ('recreate', 'Recreating your account',     75),
]

def _shared_reinstall_progress(vps_id: int, key: str):
    idx = next((i for i, st in enumerate(SHARED_REINSTALL_STAGES) if st[0] == key), 0)
    nxt = SHARED_REINSTALL_STAGES[idx + 1][2] if idx + 1 < len(SHARED_REINSTALL_STAGES) else 100
    job = REINSTALL_JOBS.get(vps_id)
    if job is not None:
        job.update(stage=key, label=SHARED_REINSTALL_STAGES[idx][1], percent=SHARED_REINSTALL_STAGES[idx][2],
                   next=nxt, index=idx, updated=time.time())
    if socketio:
        try:
            socketio.emit('vps_reinstall_progress', {'vps_id': vps_id, 'percent': SHARED_REINSTALL_STAGES[idx][2],
                          'stage': key, 'label': SHARED_REINSTALL_STAGES[idx][1]}, room=f'vps_{vps_id}')
        except Exception:
            pass

def _shared_reinstall_worker(vps_id: int, vps: Dict, account_ids: List[int], actor_id: int, actor_is_admin: bool):
    """Reinstall = wipe only the selected shared account(s): their files and
    processes are removed, every other account on the box is untouched."""
    base_name = vps['container_name']
    prog = lambda k: _shared_reinstall_progress(vps_id, k)
    try:
        accounts = [a for a in (get_shared_account_by_id(aid) for aid in account_ids) if a]
        if not accounts:
            raise Exception("No shared account to reinstall")

        prog('prepare')
        prog('stop')
        for acc in accounts:
            try:
                shared_node_op(vps, shared_hosting.kill_script(acc['system_user']), timeout=120)
            except Exception as e:
                logger.warning(f"Shared kill failed for {acc['system_user']}: {e}")

        prog('wipe')
        for acc in accounts:
            result = shared_node_op(vps, shared_hosting.wipe_script(acc['system_user']), timeout=300)
            if not result.get('ok'):
                raise Exception(result.get('err') or f"Wipe failed for {acc['system_user']}")

        prog('recreate')
        # Re-provision the account(s) with their existing credentials/limits.
        payload = [{
            'system_user': acc['system_user'],
            'password': acc.get('ssh_password') or '',
            'ram_mb': int(acc.get('ram_mb') or 512),
            'cpu': int(acc.get('cpu_limit') or 1),
            'disk_gb': int(acc.get('disk_gb') or 5),
        } for acc in accounts]
        result = shared_node_op(vps, shared_hosting.setup_script(base_name, payload), timeout=900)
        if not result.get('ok'):
            raise Exception(result.get('err') or 'Account recreation failed')

        now = datetime.now().isoformat()
        for acc in accounts:
            update_shared_account(acc['id'], status='active', suspended_reason=None,
                                  disk_used_mb=0, ram_used_mb=0, cpu_used=0, processes=0,
                                  last_checked=now)

        log_activity(actor_id, 'reinstall_shared_account', 'vps', str(vps_id),
                     {'accounts': [a['system_user'] for a in accounts]})
        for acc in accounts:
            try:
                create_notification(acc['user_id'], 'success', 'Account Reinstalled',
                                    f'Your account on {vps["container_name"]} was reinstalled. '
                                    f'All your files were removed and the account was reset.')
            except Exception:
                pass

        REINSTALL_JOBS[vps_id].update(status='done', percent=100, next=100,
                                      label='Account reset complete', stage='done', updated=time.time())
        if socketio:
            socketio.emit('vps_reinstalled', {'vps_id': vps_id, 'status': 'running'}, room=f'vps_{vps_id}')
    except Exception as e:
        logger.error(f"Shared reinstall error for VPS {vps_id}: {e}", exc_info=True)
        if vps_id in REINSTALL_JOBS:
            REINSTALL_JOBS[vps_id].update(status='error',
                                          error=str(e).split('\nCommand:')[0][:300], updated=time.time())

def _reinstall_access(vps_id: int):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return None, (jsonify({'success': False, 'error': 'VPS not found'}), 404)
    if not can_access_vps(vps):
        return None, (jsonify({'success': False, 'error': 'Access denied'}), 403)
    return vps, None

@app.route('/vps/<int:vps_id>/reinstall', methods=['POST'])
@login_required
def vps_reinstall(vps_id):
    try:
        vps, err = _reinstall_access(vps_id)
        if err:
            return err
        if is_vps_suspended(vps) and not current_user.is_admin:
            return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

        if is_shared_vps(vps):
            # Shared hosting: no OS choice - reinstall just resets accounts.
            data = request.get_json() or {}
            job = REINSTALL_JOBS.get(vps_id)
            if job and job.get('status') == 'running':
                return jsonify({'success': True, 'started': False, 'message': 'Reinstall already in progress'})

            own = get_shared_account(vps_id, current_user.id)
            if not current_user.is_admin:
                if not own:
                    return jsonify({'success': False, 'error': 'No shared account assigned to you'}), 403
                account_ids = [own['id']]
            else:
                requested = data.get('account_id')
                if requested:
                    acc = get_shared_account_by_id(int(requested))
                    if not acc or acc['vps_id'] != vps_id:
                        return jsonify({'success': False, 'error': 'Shared account not found'}), 404
                    account_ids = [acc['id']]
                else:
                    account_ids = [a['id'] for a in get_shared_accounts(vps_id)]
                    if not account_ids:
                        return jsonify({'success': False, 'error': 'No shared accounts on this VPS'}), 400

            REINSTALL_JOBS[vps_id] = {'status': 'running', 'percent': 0, 'next': 5, 'stage': 'queued',
                                      'label': 'Preparing account reset', 'index': -1,
                                      'stages': [{'key': k, 'label': l} for k, l, _ in SHARED_REINSTALL_STAGES],
                                      'started': time.time(), 'updated': time.time()}
            threading.Thread(target=_shared_reinstall_worker,
                             args=(vps_id, dict(vps), account_ids, current_user.id, bool(current_user.is_admin)),
                             daemon=True).start()
            return jsonify({'success': True, 'started': True,
                            'message': 'Account reinstall started (only selected accounts will be wiped)'})

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400
        os_version = data.get('os_version')
        if not os_version:
            return jsonify({'success': False, 'error': 'OS version is required'}), 400
        if os_version not in [o['value'] for o in OS_OPTIONS]:
            return jsonify({'success': False, 'error': 'Invalid OS'}), 400

        job = REINSTALL_JOBS.get(vps_id)
        if job and job.get('status') == 'running':
            return jsonify({'success': True, 'started': False, 'message': 'Reinstall already in progress'})

        logger.info(f"Reinstalling VPS {vps_id} ({vps['container_name']}) with OS: {os_version}")
        REINSTALL_JOBS[vps_id] = {'status': 'running', 'percent': 0, 'next': 2, 'stage': 'queued',
                                  'label': 'Preparing installation', 'index': -1, 'os': os_version,
                                  'stages': [{'key': k, 'label': l} for k, l, _ in REINSTALL_STAGES],
                                  'started': time.time(), 'updated': time.time()}
        threading.Thread(target=_reinstall_worker,
                         args=(vps_id, dict(vps), os_version, current_user.id, bool(current_user.is_admin)),
                         daemon=True).start()
        return jsonify({'success': True, 'started': True, 'message': 'Reinstallation started'})
    except Exception as e:
        logger.error(f"Reinstall start error for VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/vps/<int:vps_id>/reinstall/status')
@login_required
def vps_reinstall_status(vps_id):
    vps, err = _reinstall_access(vps_id)
    if err:
        return err
    job = REINSTALL_JOBS.get(vps_id)
    if not job:
        return jsonify({'success': True, 'status': 'idle'})
    return jsonify({'success': True, **job})

@app.route('/vps/<int:vps_id>/rename', methods=['POST'])
@login_required
def vps_rename(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    # Allow VPS owner or admin
    if vps['user_id'] != current_user.id and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    # Shared hosting: there is no container hostname to change (the shared
    # server's hostname belongs to the physical host, not to a user).
    if is_shared_vps(vps):
        return jsonify({'success': False, 'error': 'Hostname cannot be changed on shared hosting'}), 400
    
    data = request.get_json()
    new_name = data.get('hostname')
    
    if not new_name or len(new_name) < 3 or len(new_name) > 63:
        return jsonify({'success': False, 'error': 'Invalid hostname'}), 400
    
    if not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]$', new_name):
        return jsonify({'success': False, 'error': 'Invalid hostname format'}), 400
    
    try:
        run_sync(execute_lxc(vps['container_name'], f"exec {vps['container_name']} -- hostnamectl set-hostname {new_name}", node_id=vps['node_id']))
        update_vps(vps_id, hostname=new_name)
        log_activity(current_user.id, 'rename_vps', 'vps', str(vps_id), {'new_name': new_name})
        
        # Log if admin renamed someone else's VPS
        if current_user.is_admin and current_user.id != vps['user_id']:
            log_activity(current_user.id, 'admin_rename_vps', 'vps', str(vps_id),
                        {'new_name': new_name, 'owner_id': vps['user_id']})
        
        create_notification(current_user.id, 'success', 'VPS Renamed', f'VPS renamed to {new_name}')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/vps/<int:vps_id>/notes', methods=['POST'])
@login_required
def vps_notes(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or vps['user_id'] != current_user.id:
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    data = request.get_json()
    notes = data.get('notes', '')
    
    update_vps(vps_id, notes=notes)
    return jsonify({'success': True})

@app.route('/vps/<int:vps_id>/suspended')
@login_required
def vps_suspended_page(vps_id):
    vps = get_vps_by_id(vps_id)

    if not vps:
        abort(404)

    # Check access permissions
    shared_with = vps.get('shared_with', []) or []
    allowed = (
        vps['user_id'] == current_user.id
        or str(current_user.id) in [str(uid) for uid in shared_with]
        or current_user.is_admin
    )

    if not allowed:
        flash('VPS not found or access denied', 'danger')
        return redirect(url_for('vps_list'))

    # If VPS is not suspended, redirect to detail page
    if not is_vps_suspended(vps):
        return redirect(url_for('vps_detail', vps_id=vps_id))

    return render_template(
        "vps_suspended.html",
        vps=vps,
        panel_name=get_setting('site_name', 'ExpelHost Panel')
    )

@app.route('/vps/<int:vps_id>/expiration')
@login_required
@vps_owner_or_admin_required
def vps_expiration_info(vps_id):
    """Get VPS expiration information for users"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    expires_info = {
        'vps_id': vps_id,
        'container_name': vps['container_name'],
        'hostname': vps['hostname'],
        'auto_suspend_enabled': bool(vps.get('auto_suspend_enabled', 0)),
        'expiration_days': vps.get('expiration_days', 0),
        'expires_at': vps.get('expires_at'),
        'last_renewed_at': vps.get('last_renewed_at'),
        'renewal_count': vps.get('renewal_count', 0),
        'is_expired': False,
        'days_remaining': None,
        'hours_remaining': None
    }
    
    if vps.get('expires_at'):
        expires_dt = datetime.fromisoformat(vps['expires_at'])
        now = datetime.now()
        time_diff = expires_dt - now
        
        expires_info['is_expired'] = expires_dt < now
        expires_info['days_remaining'] = time_diff.days if not expires_info['is_expired'] else 0
        expires_info['hours_remaining'] = int(time_diff.total_seconds() / 3600) if not expires_info['is_expired'] else 0
        expires_info['expires_at_formatted'] = expires_dt.strftime("%Y-%m-%d %H:%M")
    
    return jsonify({'success': True, 'data': expires_info})

# ============================================================================
# Port Forwarding Routes
# ============================================================================
@app.route('/ports')
@login_required
def ports_list():
    allocated = get_user_allocation(current_user.id)
    used = get_user_used_ports(current_user.id)
    forwards = get_user_forwards(current_user.id)
    vps_list = get_vps_for_user(current_user.id)
    
    for forward in forwards:
        vps = get_vps_by_container(forward['vps_container'])
        if vps:
            forward['display_ip'] = get_vps_display_ip(vps) or YOUR_SERVER_IP
        else:
            forward['display_ip'] = YOUR_SERVER_IP
    
    return render_template('ports.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          allocated=allocated,
                          used=used,
                          available=allocated - used,
                          forwards=forwards,
                          vps_list=vps_list,
                          YOUR_SERVER_IP=YOUR_SERVER_IP,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/ports/add', methods=['POST'])
@login_required
def ports_add():
    data = request.get_json()
    vps_id = data.get('vps_id')
    vps_port = data.get('vps_port')
    protocol = data.get('protocol', 'tcp,udp')
    description = data.get('description', '')
    
    if not vps_id or not vps_port:
        return jsonify({'success': False, 'error': 'Missing parameters'}), 400
    
    try:
        vps_port = int(vps_port)
        if vps_port < 1 or vps_port > 65535:
            raise ValueError
    except ValueError:
        return jsonify({'success': False, 'error': 'Invalid port number'}), 400
    
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    # Allow VPS owner or admin
    if not can_access_vps(vps):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    # Shared hosting has no LXD network - port forwards are not applicable
    if is_shared_vps(vps):
        return jsonify({'success': False, 'error': 'Port forwards are not available on shared hosting'}), 400
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    # Use VPS owner's account for port allocation (even if admin is creating it)
    owner_id = vps['user_id']
    allocated = get_user_allocation(owner_id)
    used = get_user_used_ports(owner_id)
    
    if used >= allocated:
        return jsonify({'success': False, 'error': f'Port quota exceeded for VPS owner (used {used}/{allocated})'}), 400
    
    # Create port forward under VPS owner's account
    host_port = run_sync(create_port_forward(owner_id, vps['container_name'], vps_port, vps['node_id'], protocol, description))
    
    if host_port:
        display_ip = get_vps_display_ip(vps) or YOUR_SERVER_IP
        
        # Log who actually created it
        if current_user.is_admin and current_user.id != owner_id:
            log_activity(current_user.id, 'admin_create_port_forward', 'port', str(host_port),
                        {'vps_id': vps_id, 'owner_id': owner_id, 'vps_port': vps_port, 'host_port': host_port})
        
        return jsonify({
            'success': True,
            'host_port': host_port,
            'message': f'Port {vps_port} forwarded to {display_ip}:{host_port}',
            'display_ip': display_ip
        })
    else:
        return jsonify({'success': False, 'error': 'Could not assign host port'}), 500

@app.route('/ports/remove/<int:forward_id>', methods=['POST'])
@login_required
def ports_remove(forward_id):
    success, user_id = run_sync(remove_port_forward(forward_id))
    
    # Allow if user owns the forward OR if current user is admin
    if success and (user_id == current_user.id or current_user.is_admin):
        # Log if admin removed someone else's forward
        if current_user.is_admin and user_id != current_user.id:
            log_activity(current_user.id, 'admin_remove_port_forward', 'port', str(forward_id),
                        {'owner_id': user_id})
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Forward not found or access denied'}), 404

@app.route('/ports/hit/<int:host_port>', methods=['POST'])
def port_hit(host_port):
    run_sync(update_port_forward_hit(host_port))
    return jsonify({'success': True})

# ============================================================================
# Admin Routes
# ============================================================================
@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM users')
        total_users = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM vps')
        total_vps = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM vps WHERE status = "running"')
        running_vps = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM vps WHERE suspended = 1')
        suspended_vps = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM nodes')
        total_nodes = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM nodes WHERE status = "online"')
        online_nodes = cur.fetchone()[0]
        
        cur.execute('SELECT SUM(allocated_ports) FROM port_allocations')
        total_ports = cur.fetchone()[0] or 0
        
        cur.execute('SELECT COUNT(*) FROM port_forwards')
        used_ports = cur.fetchone()[0] or 0
        
        cur.execute('''SELECT a.*, u.username FROM activity_logs a
                       LEFT JOIN users u ON a.user_id = u.id
                       ORDER BY a.created_at DESC LIMIT 20''')
        recent_activity = [dict(row) for row in cur.fetchall()]
    
    nodes = get_nodes()
    node_status = []
    for node in nodes:
        status = run_sync(get_node_status(node['id']))
        vps_count = get_current_vps_count(node['id'])
        node_status.append({
            'id': node['id'],
            'name': node['name'],
            'location': node['location'],
            'status': status['status'],
            'online': status.get('online', False),
            'vps_count': vps_count,
            'total_vps': node['total_vps'],
            'is_local': node['is_local'],
            'stats': status.get('stats', {})
        })
    
    host_stats = run_sync(get_host_stats(1))
    
    return render_template('admin/dashboard.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          total_users=total_users,
                          total_vps=total_vps,
                          running_vps=running_vps,
                          suspended_vps=suspended_vps,
                          total_nodes=total_nodes,
                          online_nodes=online_nodes,
                          total_ports=total_ports,
                          used_ports=used_ports,
                          node_status=node_status,
                          recent_activity=recent_activity,
                          host_stats=host_stats,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    search_query = request.args.get('search', '')
    page = int(request.args.get('page', 1))
    per_page = 20
    offset = (page - 1) * per_page
    
    with get_db() as conn:
        cur = conn.cursor()
        if search_query:
            cur.execute('''SELECT u.*,
                           (SELECT COUNT(*) FROM vps WHERE user_id = u.id) as vps_count,
                           (SELECT allocated_ports FROM port_allocations WHERE user_id = u.id) as port_quota,
                           (SELECT used_ports FROM port_allocations WHERE user_id = u.id) as used_ports
                           FROM users u
                           WHERE u.username LIKE ? OR u.email LIKE ?
                           ORDER BY u.id
                           LIMIT ? OFFSET ?''',
                       (f'%{search_query}%', f'%{search_query}%', per_page, offset))
        else:
            cur.execute('''SELECT u.*,
                           (SELECT COUNT(*) FROM vps WHERE user_id = u.id) as vps_count,
                           (SELECT allocated_ports FROM port_allocations WHERE user_id = u.id) as port_quota,
                           (SELECT used_ports FROM port_allocations WHERE user_id = u.id) as used_ports
                           FROM users u
                           ORDER BY u.id
                           LIMIT ? OFFSET ?''',
                       (per_page, offset))
        users = [dict(row) for row in cur.fetchall()]
        
        if search_query:
            cur.execute('SELECT COUNT(*) FROM users WHERE username LIKE ? OR email LIKE ?',
                       (f'%{search_query}%', f'%{search_query}%'))
        else:
            cur.execute('SELECT COUNT(*) FROM users')
        total_users = cur.fetchone()[0]
    
    return render_template('admin/users.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          users=users,
                          search_query=search_query,
                          page=page,
                          total_pages=(total_users + per_page - 1) // per_page)

@app.route('/admin/users/<int:user_id>')
@login_required
@admin_required
def admin_user_detail(user_id):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user = dict(cur.fetchone())
        
        cur.execute('SELECT * FROM vps WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        vps_list = []
        for row in cur.fetchall():
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            vps_list.append(vps)
        
        cur.execute('SELECT * FROM port_allocations WHERE user_id = ?', (user_id,))
        port_alloc = cur.fetchone()
        allocated_ports = port_alloc[1] if port_alloc else 0
        used_ports = port_alloc[2] if port_alloc else 0
        
        cur.execute('SELECT * FROM port_forwards WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        forwards = [dict(row) for row in cur.fetchall()]
        
        cur.execute('SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', (user_id,))
        activities = [dict(row) for row in cur.fetchall()]
    
    return render_template('admin/user_detail.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          user=user,
                          vps_list=vps_list,
                          allocated_ports=allocated_ports,
                          used_ports=used_ports,
                          forwards=forwards,
                          activities=activities)

@app.route('/admin/users/create', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_users_create():
    # GET - Render the create user form
    if request.method == 'GET':
        return render_template('admin/users_create.html',
                              panel_name=get_setting('site_name', 'ExpelHost Panel'))
    
    # POST - Process the form submission
    data = request.get_json() or request.form.to_dict()

    username = (data.get("username") or "").strip()
    email = (data.get("email") or "").strip()
    password = data.get("password") or ""
    is_admin = bool(data.get("is_admin", False))
    port_quota = int(data.get("port_quota", 10))

    if not username or not email or not password:
        return jsonify({"success": False, "error": "username, email and password are required"}), 400

    if len(password) < 8:
        return jsonify({"success": False, "error": "Password must be at least 8 characters"}), 400

    if len(username) < 3 or len(username) > 32:
        return jsonify({"success": False, "error": "Username must be 3–32 characters"}), 400

    if "@" not in email or "." not in email.split("@")[-1]:
        return jsonify({"success": False, "error": "Invalid email format"}), 400

    if port_quota < 0:
        return jsonify({"success": False, "error": "Port quota cannot be negative"}), 400

    now = datetime.now().isoformat()

    with get_db() as conn:
        cur = conn.cursor()

        cur.execute(
            "SELECT id FROM users WHERE username = ? OR email = ?",
            (username, email)
        )
        if cur.fetchone():
            return jsonify({"success": False, "error": "Username or email already exists"}), 409

        password_hash = generate_password_hash(password)

        try:
            cur.execute("""
                INSERT INTO users (
                    username, email, password_hash, is_admin, created_at, last_active
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                username,
                email,
                password_hash,
                1 if is_admin else 0,
                now,
                now
            ))

            user_id = cur.lastrowid

            if port_quota > 0:
                cur.execute("""
                    INSERT OR REPLACE INTO port_allocations
                    (user_id, allocated_ports, used_ports, updated_at)
                    VALUES (?, ?, 0, ?)
                """, (user_id, port_quota, now))

            conn.commit()

        except Exception as e:
            conn.rollback()
            return jsonify({
                "success": False,
                "error": "Database error while creating user"
            }), 500

    try:
        log_activity(
            current_user.id,
            'create_user',
            'user',
            str(user_id),
            {"username": username, "is_admin": is_admin}
        )

        create_notification(
            user_id=user_id,
            type='info',
            title='Welcome!',
            message='Your account has been created by an administrator. Welcome aboard!'
        )
    except Exception:
        pass

    return jsonify({
        "success": True,
        "message": "User created successfully",
        "user_id": user_id
    }), 201
    
@app.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_user_edit(user_id):
    logger.info(f"admin_user_edit called: user_id={user_id}, method={request.method}, is_json={request.is_json}")
    
    try:
        # Get user data
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
            user_row = cur.fetchone()
            
            if not user_row:
                logger.warning(f"User {user_id} not found")
                if request.method == 'GET':
                    flash('User not found', 'danger')
                    return redirect(url_for('admin_users'))
                return jsonify({'success': False, 'error': 'User not found'}), 404
            
            user = dict(user_row)
            
            # Get port allocation
            cur.execute('SELECT * FROM port_allocations WHERE user_id = ?', (user_id,))
            port_row = cur.fetchone()
            port_allocation = dict(port_row) if port_row else {'allocated_ports': 0, 'used_ports': 0}
            
            # Get VPS count
            cur.execute('SELECT COUNT(*) FROM vps WHERE user_id = ?', (user_id,))
            vps_count = cur.fetchone()[0]
        
        # GET - Render edit form
        if request.method == 'GET':
            logger.info(f"Rendering edit form for user {user_id}")
            return render_template('admin/users_edit.html',
                                  panel_name=get_setting('site_name', 'ExpelHost Panel'),
                                  user=user,
                                  port_allocation=port_allocation,
                                  vps_count=vps_count)
        
        # POST - Process form submission
        logger.info(f"Processing POST request for user {user_id}")
        data = request.get_json() or request.form.to_dict()
        logger.info(f"Received data: {data}")
        
        with get_db() as conn:
            cur = conn.cursor()
            
            if 'is_admin' in data:
                cur.execute('UPDATE users SET is_admin = ? WHERE id = ?', (1 if data['is_admin'] else 0, user_id))
                logger.info(f"Updated is_admin for user {user_id}")
            
            if 'port_quota' in data:
                quota = int(data['port_quota'])
                now = datetime.now().isoformat()
                cur.execute('''INSERT OR REPLACE INTO port_allocations (user_id, allocated_ports, used_ports, updated_at)
                               VALUES (?, ?, COALESCE((SELECT used_ports FROM port_allocations WHERE user_id = ?), 0), ?)''',
                            (user_id, quota, user_id, now))
                logger.info(f"Updated port quota for user {user_id}: {quota}")
            
            conn.commit()
        
        log_activity(current_user.id, 'edit_user', 'user', str(user_id), data)
        create_notification(user_id, 'info', 'Account Updated', 'Your account has been updated by an administrator.')
        
        logger.info(f"Successfully updated user {user_id}")
        return jsonify({'success': True})
    
    except Exception as e:
        logger.error(f"Error in admin_user_edit for user {user_id}: {e}", exc_info=True)
        if request.method == 'GET':
            flash(f'Error: {str(e)}', 'danger')
            return redirect(url_for('admin_users'))
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/users/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def admin_user_delete(user_id):
    if user_id == current_user.id:
        return jsonify({'success': False, 'error': 'Cannot delete yourself'}), 400
    
    # Check if user is admin
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT is_admin, is_main_admin, username FROM users WHERE id = ?', (user_id,))
        user = cur.fetchone()
        
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404
        
        if user[0] or user[1]:  # is_admin or is_main_admin
            return jsonify({'success': False, 'error': 'Cannot delete admin users'}), 400
    
    vps_list = get_vps_for_user(user_id)
    for vps in vps_list:
        try:
            run_sync(execute_lxc(vps['container_name'], f"delete {vps['container_name']} --force", node_id=vps['node_id']))
        except:
            pass
        destroy_vps_disk_sync(vps['container_name'], vps['node_id'])
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM port_allocations WHERE user_id = ?', (user_id,))
        cur.execute('DELETE FROM port_forwards WHERE user_id = ?', (user_id,))
        cur.execute('DELETE FROM vps WHERE user_id = ?', (user_id,))
        cur.execute('DELETE FROM users WHERE id = ?', (user_id,))
        conn.commit()
    
    log_activity(current_user.id, 'delete_user', 'user', str(user_id))
    return jsonify({'success': True})

@app.route('/admin/users/bulk-delete-inactive', methods=['POST'])
@login_required
@admin_required
def admin_users_bulk_delete_inactive():
    """Delete all non-admin users who have no VPS"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Find users without VPS and who are not admins
            cur.execute('''
                SELECT u.id, u.username 
                FROM users u
                LEFT JOIN vps v ON u.id = v.user_id
                WHERE u.is_admin = 0 
                AND u.is_main_admin = 0
                AND u.id != ?
                GROUP BY u.id
                HAVING COUNT(v.id) = 0
            ''', (current_user.id,))
            
            users_to_delete = cur.fetchall()
            
            if not users_to_delete:
                return jsonify({'success': True, 'deleted_count': 0, 'message': 'No inactive users to delete'})
            
            deleted_count = 0
            deleted_usernames = []
            
            for user_id, username in users_to_delete:
                try:
                    # Delete related data
                    cur.execute('DELETE FROM port_allocations WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM port_forwards WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM notifications WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM sessions WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM api_keys WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM users WHERE id = ?', (user_id,))
                    
                    deleted_count += 1
                    deleted_usernames.append(username)
                    
                    log_activity(current_user.id, 'bulk_delete_user', 'user', str(user_id), {'username': username})
                except Exception as e:
                    logger.error(f"Error deleting user {user_id}: {e}")
                    continue
            
            conn.commit()
        
        return jsonify({
            'success': True, 
            'deleted_count': deleted_count,
            'deleted_users': deleted_usernames,
            'message': f'Successfully deleted {deleted_count} inactive user(s)'
        })
        
    except Exception as e:
        logger.error(f"Error in bulk delete: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

def get_all_users():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id, username, email FROM users ORDER BY username')
        return [dict(row) for row in cur.fetchall()]

@app.route('/admin/vps')
@login_required
@admin_required
def admin_vps():
    search_query = request.args.get('search', '')
    node_id = request.args.get('node_id', type=int)
    status_filter = request.args.get('status', '')
    page = int(request.args.get('page', 1))
    per_page = 20
    offset = (page - 1) * per_page

    vps_list = []

    query = '''SELECT v.*, u.username, n.name as node_name
               FROM vps v
               JOIN users u ON v.user_id = u.id
               JOIN nodes n ON v.node_id = n.id'''

    params = []
    conditions = []

    if search_query:
        conditions.append('(v.container_name LIKE ? OR u.username LIKE ?)')
        params.extend([f'%{search_query}%', f'%{search_query}%'])

    if node_id:
        conditions.append('v.node_id = ?')
        params.append(node_id)

    if status_filter:
        conditions.append('v.status = ?')
        params.append(status_filter)

    if conditions:
        query += ' WHERE ' + ' AND '.join(conditions)

    query += ' ORDER BY v.created_at DESC LIMIT ? OFFSET ?'
    params.extend([per_page, offset])

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(query, params)
        rows = cur.fetchall()

        for row in rows:
            vps = dict(row)

            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except Exception:
                vps['shared_with'] = []
            
            # Convert suspended and whitelisted to boolean for consistency
            vps['suspended'] = bool(vps.get('suspended', 0))
            vps['whitelisted'] = bool(vps.get('whitelisted', 0))

            # Initialize with safe defaults
            vps['live_status'] = vps.get('status', 'unknown')
            vps['live_cpu'] = 0.0
            vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
            vps['live_disk'] = {'use_percent': '0%'}

            if is_vps_suspended(vps):
                vps['live_status'] = "suspended"
            elif is_shared_vps(vps):
                # No container: status is panel-managed (accounts are limited individually)
                vps['live_status'] = vps.get('status', 'running')
            else:
                try:
                    stats = run_sync(
                        get_container_stats(
                            vps['container_name'],
                            vps['node_id']
                        )
                    )

                    if stats:
                        vps['live_status'] = stats.get('status', 'unknown')
                        vps['live_cpu'] = float(stats.get('cpu', 0.0))
                        
                        # Ensure RAM is a dict
                        ram_data = stats.get('ram', {'used': 0, 'total': 0, 'pct': 0.0})
                        if isinstance(ram_data, dict):
                            vps['live_ram'] = ram_data
                        else:
                            vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
                        
                        # Ensure disk is a dict
                        disk_data = stats.get('disk', {'use_percent': '0%'})
                        if isinstance(disk_data, dict):
                            vps['live_disk'] = normalize_disk(disk_data)
                        else:
                            vps['live_disk'] = {'use_percent': '0%'}

                except Exception as e:
                    current_app.logger.warning(
                        f"Stats error for {vps.get('container_name')}: {e}"
                    )

            vps_list.append(vps)

        count_query = '''
            SELECT COUNT(*)
            FROM vps v
            JOIN users u ON v.user_id = u.id
        '''

        count_params = params[:-2]

        if conditions:
            count_query += ' WHERE ' + ' AND '.join(conditions)

        cur.execute(count_query, count_params)
        total_vps = cur.fetchone()[0]

    nodes = get_nodes()
    apply_fake_to_list(vps_list)

    return render_template(
        'admin/vps.html',
        panel_name=get_setting('site_name', 'ExpelHost Panel'),
        vps_list=vps_list,
        search_query=search_query,
        node_id=node_id,
        status_filter=status_filter,
        nodes=nodes,
        page=page,
        total_pages=(total_vps + per_page - 1) // per_page,
        socketio_available=SOCKETIO_AVAILABLE
    )

@app.route('/admin/vps/expiring')
@login_required
@admin_required
def admin_vps_expiring():
    """List all VPS that are expiring soon or already expired"""
    days_ahead = int(request.args.get('days', 7))  # Default: show VPS expiring in next 7 days
    
    # If it's an AJAX request, return JSON
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        with get_db() as conn:
            cur = conn.cursor()
            now = datetime.now().isoformat()
            future_date = (datetime.now() + timedelta(days=days_ahead)).isoformat()
            
            # Get expiring VPS
            cur.execute('''SELECT v.*, u.username, u.email, n.name as node_name
                          FROM vps v
                          JOIN users u ON v.user_id = u.id
                          JOIN nodes n ON v.node_id = n.id
                          WHERE v.auto_suspend_enabled = 1 
                          AND v.expires_at IS NOT NULL 
                          AND v.expires_at <= ?
                          ORDER BY v.expires_at ASC''', (future_date,))
            
            vps_list = []
            for row in cur.fetchall():
                vps = dict(row)
                expires_dt = datetime.fromisoformat(vps['expires_at'])
                time_diff = expires_dt - datetime.now()
                
                vps['is_expired'] = expires_dt < datetime.now()
                vps['days_remaining'] = time_diff.days if not vps['is_expired'] else 0
                vps['hours_remaining'] = int(time_diff.total_seconds() / 3600) if not vps['is_expired'] else 0
                vps['expires_at_formatted'] = expires_dt.strftime("%Y-%m-%d %H:%M")
                vps['suspended'] = bool(vps.get('suspended', 0))
                
                vps_list.append(vps)
        
        return jsonify({
            'success': True,
            'data': vps_list,
            'count': len(vps_list),
            'days_ahead': days_ahead
        })
    
    # Regular page view
    with get_db() as conn:
        cur = conn.cursor()
        
        # Get statistics
        cur.execute('''SELECT COUNT(*) FROM vps 
                      WHERE auto_suspend_enabled = 1 
                      AND expires_at IS NOT NULL 
                      AND expires_at < ?''', (datetime.now().isoformat(),))
        expired_count = cur.fetchone()[0]
        
        cur.execute('''SELECT COUNT(*) FROM vps 
                      WHERE auto_suspend_enabled = 1 
                      AND expires_at IS NOT NULL 
                      AND expires_at >= ? 
                      AND expires_at <= ?''', 
                   (datetime.now().isoformat(), 
                    (datetime.now() + timedelta(days=7)).isoformat()))
        expiring_soon_count = cur.fetchone()[0]
        
        cur.execute('''SELECT COUNT(*) FROM vps 
                      WHERE auto_suspend_enabled = 1 
                      AND expires_at IS NOT NULL''')
        total_with_expiration = cur.fetchone()[0]
    
    return render_template('admin/vps_expiring.html',
                         panel_name=get_setting('site_name', 'ExpelHost Panel'),
                         expired_count=expired_count,
                         expiring_soon_count=expiring_soon_count,
                         total_with_expiration=total_with_expiration,
                         days_ahead=days_ahead)

@app.route('/admin/vps/<int:vps_id>/delete', methods=['POST'])
@login_required
@admin_required
def admin_vps_delete(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    if is_shared_vps(vps):
        # Remove all shared accounts and the base dir on the node
        accounts = get_shared_accounts(vps_id)
        try:
            shared_node_op(vps, shared_hosting.remove_script([a['system_user'] for a in accounts],
                                                             vps['container_name']), timeout=300)
        except Exception as e:
            logger.warning(f"Shared remove script failed for VPS {vps_id}: {e}")
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('DELETE FROM shared_accounts WHERE vps_id = ?', (vps_id,))
            conn.commit()
        for acc in accounts:
            try:
                create_notification(acc['user_id'], 'info', 'Shared Hosting Removed',
                                    f'The shared VPS {vps["container_name"]} was removed by an admin.')
            except Exception:
                pass
        delete_vps(vps_id)
        log_activity(current_user.id, 'admin_delete_shared_vps', 'vps', str(vps_id))
        return jsonify({'success': True})
    
    try:
        run_sync(execute_lxc(vps['container_name'], f"delete {vps['container_name']} --force", node_id=vps['node_id']))
    except:
        pass
    destroy_vps_disk_sync(vps['container_name'], vps['node_id'])
    
    delete_vps(vps_id)
    log_activity(current_user.id, 'admin_delete_vps', 'vps', str(vps_id))
    return jsonify({'success': True})

# ---------------------------------------------------------------------------
# VPS deletion with live percentage (same job/poll pattern as reinstall)
# ---------------------------------------------------------------------------
DELETE_JOBS: Dict[int, Dict[str, Any]] = {}
DELETE_STAGES_DEDICATED = [
    ('prepare', 'Preparing to delete',               3),
    ('stop',    'Stopping the VPS',                  10),
    ('remove',  'Removing the container & its disk', 22),
    ('ports',   'Removing port forwards',            85),
    ('records', 'Cleaning up database records',      92),
    ('finish',  'Finishing up',                      97),
]
DELETE_STAGES_SHARED = [
    ('prepare',  'Preparing to delete',              3),
    ('stop',     'Stopping all account processes',   10),
    ('remove',   'Removing accounts & their files',  28),
    ('accounts', 'Removing shared accounts',         80),
    ('ports',    'Removing port forwards',           86),
    ('records',  'Cleaning up database records',     92),
    ('finish',   'Finishing up',                     97),
]

def _delete_progress(vps_id: int, stages, key: str):
    idx = next((i for i, st in enumerate(stages) if st[0] == key), 0)
    nxt = stages[idx + 1][2] if idx + 1 < len(stages) else 100
    job = DELETE_JOBS.get(vps_id)
    if job is not None:
        job.update(stage=key, label=stages[idx][1], percent=stages[idx][2], next=nxt, index=idx, updated=time.time())

def _delete_worker(vps_id: int, vps: Dict, actor_id: int):
    container_name = vps['container_name']
    shared = is_shared_vps(vps)
    stages = DELETE_STAGES_SHARED if shared else DELETE_STAGES_DEDICATED
    prog = lambda k: _delete_progress(vps_id, stages, k)
    try:
        prog('prepare')
        accounts = get_shared_accounts(vps_id) if shared else []

        prog('stop')
        if shared:
            for acc in accounts:
                try:
                    shared_node_op(vps, shared_hosting.kill_script(acc['system_user']), timeout=120)
                except Exception as e:
                    logger.warning(f"Shared kill failed for {acc['system_user']}: {e}")
        else:
            try:
                run_sync(execute_lxc(container_name, f"stop {container_name} --force", node_id=vps['node_id']))
            except Exception as e:
                logger.warning(f"Stop before delete failed for {container_name}: {e}")

        prog('remove')
        if shared:
            try:
                shared_node_op(vps, shared_hosting.remove_script([a['system_user'] for a in accounts], container_name), timeout=300)
            except Exception as e:
                logger.warning(f"Shared remove script failed for VPS {vps_id}: {e}")
            prog('accounts')
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('DELETE FROM shared_accounts WHERE vps_id = ?', (vps_id,))
                conn.commit()
            for acc in accounts:
                try:
                    create_notification(acc['user_id'], 'info', 'Shared Hosting Removed',
                                        f'The shared VPS {container_name} was removed by an admin.')
                except Exception:
                    pass
        else:
            try:
                run_sync(execute_lxc(container_name, f"delete {container_name} --force", node_id=vps['node_id']))
            except Exception as e:
                logger.warning(f"LXC delete failed for {container_name}: {e}")
            destroy_vps_disk_sync(container_name, vps['node_id'])   # frees the VPS's dedicated disk

        prog('ports')
        try:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('SELECT user_id, COUNT(*) FROM port_forwards WHERE vps_container = ? GROUP BY user_id', (container_name,))
                per_user = cur.fetchall()
                cur.execute('DELETE FROM port_forwards WHERE vps_container = ?', (container_name,))
                for uid, n in per_user:
                    cur.execute('UPDATE port_allocations SET used_ports = MAX(used_ports - ?, 0), updated_at = ? WHERE user_id = ?',
                                (n, datetime.now().isoformat(), uid))
                conn.commit()
        except Exception as e:
            logger.warning(f"Port cleanup failed for VPS {vps_id}: {e}")

        prog('records')
        delete_vps(vps_id)

        prog('finish')
        log_activity(actor_id, 'admin_delete_shared_vps' if shared else 'admin_delete_vps', 'vps', str(vps_id))
        DELETE_JOBS[vps_id].update(status='done', percent=100, next=100, label='VPS deleted', stage='done', updated=time.time())
    except Exception as e:
        logger.error(f"Delete error for VPS {vps_id}: {e}", exc_info=True)
        if vps_id in DELETE_JOBS:
            DELETE_JOBS[vps_id].update(status='error', error=str(e).split('\nCommand:')[0][:300], updated=time.time())

@app.route('/admin/vps/<int:vps_id>/delete/start', methods=['POST'])
@login_required
@admin_required
def admin_vps_delete_start(vps_id):
    # forget finished jobs older than 10 minutes
    now = time.time()
    for k in [k for k, j in DELETE_JOBS.items() if j.get('status') != 'running' and now - j.get('updated', now) > 600]:
        DELETE_JOBS.pop(k, None)
    job = DELETE_JOBS.get(vps_id)
    if job and job.get('status') == 'running':
        return jsonify({'success': True, 'started': False, 'message': 'Delete already in progress'})
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    stages = DELETE_STAGES_SHARED if is_shared_vps(vps) else DELETE_STAGES_DEDICATED
    DELETE_JOBS[vps_id] = {'status': 'running', 'percent': 0, 'next': 3, 'stage': 'queued', 'label': 'Preparing to delete',
                           'index': -1, 'stages': [{'key': k, 'label': l} for k, l, _ in stages],
                           'started': now, 'updated': now}
    threading.Thread(target=_delete_worker, args=(vps_id, dict(vps), current_user.id), daemon=True).start()
    return jsonify({'success': True, 'started': True})

@app.route('/admin/vps/<int:vps_id>/delete/status')
@login_required
@admin_required
def admin_vps_delete_status(vps_id):
    job = DELETE_JOBS.get(vps_id)
    if not job:
        return jsonify({'success': True, 'status': 'idle'})
    return jsonify({'success': True, **job})

# ---------------------------------------------------------------------------
# Shared hosting account management (admin)
# ---------------------------------------------------------------------------
def _shared_vps_or_404(vps_id: int):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return None, (jsonify({'success': False, 'error': 'VPS not found'}), 404)
    if not is_shared_vps(vps):
        return None, (jsonify({'success': False, 'error': 'Not a shared hosting VPS'}), 400)
    return vps, None

def _shared_account_in_vps(vps_id: int, account_id: int):
    acc = get_shared_account_by_id(account_id)
    if not acc or acc['vps_id'] != vps_id:
        return None, (jsonify({'success': False, 'error': 'Shared account not found'}), 404)
    return acc, None

@app.route('/admin/vps/<int:vps_id>/shared/accounts')
@login_required
@admin_required
def admin_shared_accounts(vps_id):
    vps, err = _shared_vps_or_404(vps_id)
    if err:
        return err
    return jsonify({'success': True, 'accounts': get_shared_accounts(vps_id)})

@app.route('/admin/vps/<int:vps_id>/shared/accounts/add', methods=['POST'])
@login_required
@admin_required
def admin_shared_account_add(vps_id):
    vps, err = _shared_vps_or_404(vps_id)
    if err:
        return err
    data = request.get_json() or {}
    try:
        user_id = int(data.get('user_id'))
        ram_mb = max(128, int(data.get('ram_mb', 512)))
        cpu = max(1, int(data.get('cpu', 1)))
        disk_gb = max(1, int(data.get('disk_gb', 5)))
    except (TypeError, ValueError):
        return jsonify({'success': False, 'error': 'Invalid account data'}), 400

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM users WHERE id = ?', (user_id,))
        if not cur.fetchone():
            return jsonify({'success': False, 'error': 'User not found'}), 404
    if user_has_shared_access(vps_id, user_id):
        return jsonify({'success': False, 'error': 'User already has an account on this VPS'}), 400

    try:
        system_user = f"hu{vps_id}u{user_id}"
        password = secrets.token_urlsafe(12)
        home_dir = f"/opt/hvm-shared/{vps['container_name']}/{system_user}"
        now = datetime.now().isoformat()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO shared_accounts
                (vps_id, user_id, system_user, home_dir, ssh_password,
                 ram_mb, cpu_limit, disk_gb, port_base, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'active', ?)''',
                (vps_id, user_id, system_user, home_dir, password,
                 ram_mb, cpu, disk_gb, now))
            account_id = cur.lastrowid
            port_base = 20000 + ((account_id % 400) * 100)
            cur.execute('UPDATE shared_accounts SET port_base = ? WHERE id = ?', (port_base, account_id))
            conn.commit()

        result = shared_node_op(vps, shared_hosting.setup_script(vps['container_name'], [{
            'system_user': system_user, 'password': password,
            'ram_mb': ram_mb, 'cpu': cpu, 'disk_gb': disk_gb,
        }]), timeout=900)
        if not result.get('ok'):
            raise Exception(result.get('err') or 'Account setup failed')

        log_activity(current_user.id, 'admin_add_shared_account', 'vps', str(vps_id),
                     {'system_user': system_user, 'user_id': user_id})
        try:
            create_notification(user_id, 'success', 'Shared Hosting Added',
                                f'You now have an account on shared VPS {vps["container_name"]}.')
        except Exception:
            pass
        return jsonify({'success': True, 'account_id': account_id,
                        'account': get_shared_account_by_id(account_id),
                        'message': f'Account created for user {user_id}'})
    except Exception as e:
        logger.error(f"Shared account add failed: {e}", exc_info=True)
        try:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('DELETE FROM shared_accounts WHERE vps_id = ? AND user_id = ?', (vps_id, user_id))
                conn.commit()
        except Exception:
            pass
        return jsonify({'success': False, 'error': str(e).split('\nCommand:')[0][:300]}), 500

@app.route('/admin/vps/<int:vps_id>/shared/accounts/<int:account_id>/suspend', methods=['POST'])
@login_required
@admin_required
def admin_shared_account_suspend(vps_id, account_id):
    vps, err = _shared_vps_or_404(vps_id)
    if err:
        return err
    acc, err = _shared_account_in_vps(vps_id, account_id)
    if err:
        return err
    data = request.get_json() or {}
    reason = data.get('reason') or 'Admin action'
    if acc['status'] != 'suspended':
        suspend_shared_account(acc, reason, vps=vps, actor_id=current_user.id)
    return jsonify({'success': True, 'message': f"Account {acc['system_user']} suspended"})

@app.route('/admin/vps/<int:vps_id>/shared/accounts/<int:account_id>/resume', methods=['POST'])
@login_required
@admin_required
def admin_shared_account_resume(vps_id, account_id):
    vps, err = _shared_vps_or_404(vps_id)
    if err:
        return err
    acc, err = _shared_account_in_vps(vps_id, account_id)
    if err:
        return err
    if acc['status'] == 'active':
        return jsonify({'success': True, 'message': 'Account already active'})
    over = ''
    try:
        if float(acc.get('disk_used_mb') or 0) >= int(acc.get('disk_gb') or 5) * 1024:
            over = ' (still over its disk limit - reinstall to free space)'
    except Exception:
        pass
    try:
        shared_node_op(vps, shared_hosting.resume_script(acc['system_user']), timeout=120)
    except Exception as e:
        logger.warning(f"Shared resume failed for {acc['system_user']}: {e}")
    update_shared_account(acc['id'], status='active', suspended_reason=None)
    log_activity(current_user.id, 'admin_resume_shared_account', 'vps', str(vps_id),
                 {'system_user': acc['system_user']})
    try:
        create_notification(acc['user_id'], 'success', 'Shared Hosting Resumed',
                            f'Your account on {vps["container_name"]} is active again.{over}')
    except Exception:
        pass
    return jsonify({'success': True, 'message': f"Account {acc['system_user']} resumed{over}"})

@app.route('/admin/vps/<int:vps_id>/shared/accounts/<int:account_id>/reinstall', methods=['POST'])
@login_required
@admin_required
def admin_shared_account_reinstall(vps_id, account_id):
    """Wipe one account's files/processes and reset it."""
    vps, err = _shared_vps_or_404(vps_id)
    if err:
        return err
    acc, err = _shared_account_in_vps(vps_id, account_id)
    if err:
        return err
    try:
        result = shared_node_op(vps, shared_hosting.wipe_script(acc['system_user']), timeout=300)
        if not result.get('ok'):
            raise Exception(result.get('err') or 'Wipe failed')
        update_shared_account(acc['id'], status='active', suspended_reason=None,
                              disk_used_mb=0, ram_used_mb=0, cpu_used=0, processes=0,
                              last_checked=datetime.now().isoformat())
        log_activity(current_user.id, 'admin_reinstall_shared_account', 'vps', str(vps_id),
                     {'system_user': acc['system_user']})
        try:
            create_notification(acc['user_id'], 'info', 'Account Reset',
                                f'An admin reset your account on {vps["container_name"]}. Your files were removed.')
        except Exception:
            pass
        return jsonify({'success': True, 'message': f"Account {acc['system_user']} reinstalled"})
    except Exception as e:
        logger.error(f"Shared account reinstall failed: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e).split('\nCommand:')[0][:300]}), 500

@app.route('/admin/vps/<int:vps_id>/shared/accounts/<int:account_id>/remove', methods=['POST'])
@login_required
@admin_required
def admin_shared_account_remove(vps_id, account_id):
    vps, err = _shared_vps_or_404(vps_id)
    if err:
        return err
    acc, err = _shared_account_in_vps(vps_id, account_id)
    if err:
        return err
    remaining = len(get_shared_accounts(vps_id)) - 1
    if remaining < 1:
        return jsonify({'success': False,
                        'error': 'Cannot remove the last account - delete the whole VPS instead'}), 400
    try:
        shared_node_op(vps, shared_hosting.remove_script([acc['system_user']], vps['container_name']), timeout=180)
    except Exception as e:
        logger.warning(f"Shared account removal script failed: {e}")
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM shared_accounts WHERE id = ?', (acc['id'],))
        conn.commit()
    log_activity(current_user.id, 'admin_remove_shared_account', 'vps', str(vps_id),
                 {'system_user': acc['system_user']})
    try:
        create_notification(acc['user_id'], 'warning', 'Shared Hosting Access Removed',
                            f'Your account on {vps["container_name"]} was removed by an admin.')
    except Exception:
        pass
    return jsonify({'success': True, 'message': f"Account {acc['system_user']} removed"})

@app.route('/admin/vps/<int:vps_id>/suspend', methods=['POST'])
@login_required
@admin_required
def admin_vps_suspend(vps_id):
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"Suspend failed: VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404

        if is_vps_whitelisted(vps):
            logger.warning(f"Suspend failed: VPS {vps_id} is whitelisted")
            return jsonify({
                'success': False,
                'error': 'Whitelisted VPS cannot be suspended'
            }), 403

        data = request.get_json(silent=True) or {}
        reason = data.get('reason', 'Admin action')

        container = vps['container_name']
        
        logger.info(f"Suspending VPS {vps_id} ({container}): {reason}")

        # Stop the container (shared hosting: lock every account instead)
        if is_shared_vps(vps):
            now_iso = datetime.now().isoformat()
            for acc in get_shared_accounts(vps_id):
                try:
                    shared_node_op(vps, shared_hosting.suspend_script(acc['system_user']), timeout=120)
                except Exception as e:
                    logger.warning(f"Failed to lock shared account {acc['system_user']}: {e}")
                if acc.get('status') != 'suspended':
                    update_shared_account(acc['id'], status='suspended', suspended_reason='vps_suspended',
                                          processes=0, ram_used_mb=0, cpu_used=0, last_checked=now_iso)
        else:
            try:
                run_sync(
                    execute_lxc(
                        container,
                        f"stop {container} --force",
                        node_id=vps['node_id']
                    )
                )
                logger.info(f"Container {container} stopped successfully")
            except Exception as e:
                logger.warning(f"Failed to stop container {container}: {e}")
                # Continue anyway - container might already be stopped

        history = vps.get('suspension_history', [])
        if not isinstance(history, list):
            history = []
        
        history.append({
            'time': datetime.now().isoformat(),
            'reason': reason,
            'by': current_user.username
        })

        # Update VPS with suspended flag - use integer 1, not boolean
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET suspended = 1, 
                              suspended_reason = ?, 
                              suspension_history = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (reason, json.dumps(history), datetime.now().isoformat(), vps_id))
            conn.commit()
            logger.info(f"VPS {vps_id} suspended flag set in database (rows affected: {cur.rowcount})")
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"VPS {vps_id} suspended status after update: {updated_vps.get('suspended')} (type: {type(updated_vps.get('suspended'))})")

        log_activity(current_user.id, 'suspend_vps', 'vps', str(vps_id), {'reason': reason})

        notify_users = [vps['user_id']]
        if is_shared_vps(vps):
            notify_users += [a['user_id'] for a in get_shared_accounts(vps_id)]
        for uid in dict.fromkeys(notify_users):
            create_notification(
                uid,
                'warning',
                'VPS Suspended',
                f'{container} suspended: {reason}'
            )
        
        if socketio:
            socketio.emit('vps_suspended', {
                'vps_id': vps_id,
                'reason': reason
            }, room=f'vps_{vps_id}')
            socketio.emit('vps_status_change', {
                'vps_id': vps_id,
                'status': 'suspended'
            }, room=f'user_{vps["user_id"]}')

        return jsonify({'success': True, 'message': f'VPS {container} has been suspended'})
    
    except Exception as e:
        logger.error(f"Error suspending VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/unsuspend', methods=['POST'])
@login_required
@admin_required
def admin_vps_unsuspend(vps_id):
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"Unsuspend failed: VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404

        logger.info(f"Unsuspending VPS {vps_id} ({vps['container_name']})")

        history = vps.get('suspension_history', [])
        if not isinstance(history, list):
            history = []
        
        history.append({
            'time': datetime.now().isoformat(),
            'reason': 'Unsuspended by admin',
            'by': current_user.username
        })

        # Update database directly with integer 0
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET suspended = 0, 
                              status = 'stopped',
                              suspended_reason = NULL,
                              suspension_history = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (json.dumps(history), datetime.now().isoformat(), vps_id))
            conn.commit()
            logger.info(f"VPS {vps_id} unsuspended in database (rows affected: {cur.rowcount})")
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"VPS {vps_id} suspended status after unsuspend: {updated_vps.get('suspended')} (type: {type(updated_vps.get('suspended'))})")

        # Shared hosting: unlock the accounts this VPS-level suspend locked.
        # (Quota-suspended accounts stay locked until reinstalled.)
        if is_shared_vps(vps):
            for acc in get_shared_accounts(vps_id):
                if acc.get('status') == 'suspended' and (acc.get('suspended_reason') or '') == 'vps_suspended':
                    try:
                        shared_node_op(vps, shared_hosting.resume_script(acc['system_user']), timeout=120)
                    except Exception as e:
                        logger.warning(f"Failed to unlock shared account {acc['system_user']}: {e}")
                    update_shared_account(acc['id'], status='active', suspended_reason=None)

        log_activity(current_user.id, 'unsuspend_vps', 'vps', str(vps_id))

        create_notification(
            vps['user_id'],
            'success',
            'VPS Unsuspended',
            f'{vps["container_name"]} is now active.'
        )
        
        if socketio:
            socketio.emit('vps_unsuspended', {
                'vps_id': vps_id
            }, room=f'vps_{vps_id}')
            socketio.emit('vps_status_change', {
                'vps_id': vps_id,
                'status': 'stopped'
            }, room=f'user_{vps["user_id"]}')

        return jsonify({'success': True, 'message': f'VPS {vps["container_name"]} has been unsuspended'})
    
    except Exception as e:
        logger.error(f"Error unsuspending VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/renew', methods=['POST'])
@login_required
@admin_required
def admin_vps_renew(vps_id):
    """Renew VPS expiration date"""
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
        
        data = request.get_json() or {}
        additional_days = int(data.get('days', vps.get('expiration_days', 30)))
        action = str(data.get('action', 'add')).lower()

        # A negative number of days is treated the same as action='remove'
        if additional_days < 0:
            additional_days = abs(additional_days)
            action = 'remove'

        if action not in ('add', 'remove'):
            return jsonify({'success': False, 'error': "Action must be 'add' or 'remove'"}), 400

        if additional_days <= 0:
            return jsonify({'success': False, 'error': 'Days must be greater than 0'}), 400

        now = datetime.now()

        # ---- Remove days: shorten the current expiration date ----
        if action == 'remove':
            if not vps.get('expires_at'):
                return jsonify({'success': False, 'error': 'This VPS has no expiration date to reduce'}), 400

            current_expires = datetime.fromisoformat(vps['expires_at'])
            new_expires = current_expires - timedelta(days=additional_days)

            with get_db() as conn:
                cur = conn.cursor()
                # Not a renewal: renewal_count / last_renewed_at / expiration_days stay untouched
                cur.execute('''UPDATE vps
                              SET expires_at = ?,
                                  updated_at = ?
                              WHERE id = ?''',
                           (new_expires.isoformat(), now.isoformat(), vps_id))
                conn.commit()

            is_expired = new_expires < now

            log_activity(current_user.id, 'reduce_vps_expiration', 'vps', str(vps_id),
                        {'days_removed': additional_days, 'new_expires': new_expires.isoformat()})

            create_notification(vps['user_id'], 'warning', 'VPS Time Reduced',
                              f'{additional_days} day(s) were removed from your VPS {vps["hostname"]}. New expiration: {new_expires.strftime("%Y-%m-%d %H:%M")}')

            if socketio:
                socketio.emit('vps_renewed', {
                    'vps_id': vps_id,
                    'expires_at': new_expires.isoformat(),
                    'days': -additional_days
                }, room=f'user_{vps["user_id"]}')

            return jsonify({
                'success': True,
                'message': f'Removed {additional_days} days from VPS',
                'expires_at': new_expires.isoformat(),
                'expires_at_formatted': new_expires.strftime("%Y-%m-%d %H:%M"),
                'is_expired': is_expired
            })

        # ---- Add days: extend the expiration date (renew) ----
        # Calculate new expiration date
        if vps.get('expires_at'):
            # If already has expiration, extend from that date
            current_expires = datetime.fromisoformat(vps['expires_at'])
            # If already expired, start from now
            if current_expires < now:
                new_expires = now + timedelta(days=additional_days)
            else:
                new_expires = current_expires + timedelta(days=additional_days)
        else:
            # No previous expiration, start from now
            new_expires = now + timedelta(days=additional_days)
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET expires_at = ?,
                              last_renewed_at = ?,
                              renewal_count = renewal_count + 1,
                              auto_suspend_enabled = 1,
                              expiration_days = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (new_expires.isoformat(), now.isoformat(), additional_days, now.isoformat(), vps_id))
            conn.commit()
        
        log_activity(current_user.id, 'renew_vps', 'vps', str(vps_id), 
                    {'days': additional_days, 'new_expires': new_expires.isoformat()})
        
        create_notification(vps['user_id'], 'success', 'VPS Renewed', 
                          f'Your VPS {vps["hostname"]} has been renewed for {additional_days} days. New expiration: {new_expires.strftime("%Y-%m-%d %H:%M")}')
        
        if socketio:
            socketio.emit('vps_renewed', {
                'vps_id': vps_id,
                'expires_at': new_expires.isoformat(),
                'days': additional_days
            }, room=f'user_{vps["user_id"]}')
        
        return jsonify({
            'success': True, 
            'message': f'VPS renewed for {additional_days} days',
            'expires_at': new_expires.isoformat(),
            'expires_at_formatted': new_expires.strftime("%Y-%m-%d %H:%M")
        })
    
    except Exception as e:
        logger.error(f"Error renewing VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/expiration', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_vps_expiration(vps_id):
    """Get or update VPS expiration settings"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        if request.method == 'GET' and not request.is_json:
            flash('VPS not found', 'danger')
            return redirect(url_for('admin_vps'))
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    if request.method == 'GET':
        # Get user info
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT username, email FROM users WHERE id = ?', (vps['user_id'],))
            user_row = cur.fetchone()
            user = dict(user_row) if user_row else {'username': 'Unknown', 'email': ''}
        
        expires_info = {
            'vps_id': vps_id,
            'auto_suspend_enabled': bool(vps.get('auto_suspend_enabled', 0)),
            'expiration_days': vps.get('expiration_days', 0),
            'expires_at': vps.get('expires_at'),
            'last_renewed_at': vps.get('last_renewed_at'),
            'renewal_count': vps.get('renewal_count', 0),
            'is_expired': False,
            'days_remaining': None,
            'hours_remaining': None
        }
        
        if vps.get('expires_at'):
            expires_dt = datetime.fromisoformat(vps['expires_at'])
            now = datetime.now()
            time_diff = expires_dt - now
            expires_info['is_expired'] = expires_dt < now
            expires_info['days_remaining'] = time_diff.days if not expires_info['is_expired'] else 0
            expires_info['hours_remaining'] = int(time_diff.total_seconds() / 3600) if not expires_info['is_expired'] else 0
            expires_info['expires_at_formatted'] = expires_dt.strftime("%Y-%m-%d %H:%M")
        
        # Check if JSON request (API call)
        if request.is_json or request.args.get('format') == 'json':
            return jsonify({'success': True, 'data': expires_info})
        
        # Render HTML page
        return render_template('admin/vps_expiration.html',
                              panel_name=get_setting('site_name', 'ExpelHost Panel'),
                              vps=vps,
                              user=user,
                              expires_info=expires_info)
    
    # POST - Update expiration settings
    try:
        data = request.get_json() or {}
        auto_suspend_enabled = bool(data.get('auto_suspend_enabled', False))
        expiration_days = int(data.get('expiration_days', 0))
        
        if expiration_days < 0:
            return jsonify({'success': False, 'error': 'Expiration days cannot be negative'}), 400
        
        now = datetime.now()
        expires_at = None
        
        if auto_suspend_enabled and expiration_days > 0:
            expires_at = (now + timedelta(days=expiration_days)).isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET auto_suspend_enabled = ?,
                              expiration_days = ?,
                              expires_at = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (1 if auto_suspend_enabled else 0, expiration_days, expires_at, now.isoformat(), vps_id))
            conn.commit()
        
        log_activity(current_user.id, 'update_vps_expiration', 'vps', str(vps_id), 
                    {'auto_suspend_enabled': auto_suspend_enabled, 'expiration_days': expiration_days})
        
        return jsonify({
            'success': True, 
            'message': 'Expiration settings updated',
            'expires_at': expires_at
        })
    
    except Exception as e:
        logger.error(f"Error updating VPS expiration {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/whitelist', methods=['POST'])
@login_required
@admin_required
def admin_vps_whitelist(vps_id):
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"Whitelist failed: VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404

        data = request.get_json(silent=True) or {}
        whitelist = bool(data.get('whitelist', False))
        
        logger.info(f"Setting whitelist for VPS {vps_id} to {whitelist}")

        # Update database directly with integer value
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET whitelisted = ?, 
                              updated_at = ?
                          WHERE id = ?''',
                       (1 if whitelist else 0, datetime.now().isoformat(), vps_id))
            conn.commit()
            logger.info(f"VPS {vps_id} whitelisted flag set in database (rows affected: {cur.rowcount})")
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"VPS {vps_id} whitelisted status after update: {updated_vps.get('whitelisted')} (type: {type(updated_vps.get('whitelisted'))})")

        log_activity(
            current_user.id,
            'whitelist_vps',
            'vps',
            str(vps_id),
            {'whitelisted': whitelist}
        )
        
        action = "whitelisted" if whitelist else "removed from whitelist"
        create_notification(
            vps['user_id'],
            'info',
            'VPS Whitelist Updated',
            f'Your VPS {vps["container_name"]} has been {action}.'
        )

        return jsonify({'success': True, 'whitelisted': whitelist, 'message': f'VPS {action} successfully'})
    
    except Exception as e:
        logger.error(f"Error whitelisting VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_vps_edit(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return "VPS not found", 404

    if request.method == 'GET':
        users = get_all_users()
        nodes = get_nodes()
        return render_template(
            'admin/vps_edit.html',
            vps=vps,
            users=users,
            nodes=nodes,
            os_options=OS_OPTIONS,
            panel_name=get_setting('site_name', 'ExpelHost Panel')
        )

    data = request.form

    new_user_id = data.get('user_id')
    node_id = data.get('node_id')
    ram = data.get('ram')
    cpu = data.get('cpu')
    disk = data.get('disk')
    hostname = data.get('hostname')
    ip_address = data.get('ip_address')
    ip_alias = data.get('ip_alias')
    os_version = data.get('os_version')

    if ram and (int(ram) < 1 or int(ram) > 128):
        flash('RAM must be between 1 and 128 GB', 'danger')
        return redirect(request.url)
    
    if cpu and (int(cpu) < 1 or int(cpu) > 64):
        flash('CPU must be between 1 and 64 cores', 'danger')
        return redirect(request.url)
    
    if disk and (int(disk) < 5 or int(disk) > 2000):
        flash('Disk must be between 5 and 2000 GB', 'danger')
        return redirect(request.url)

    was_running = vps['status'] == 'running' and not is_vps_suspended(vps)

    if was_running and (ram or cpu or disk or ip_address or os_version or (node_id and node_id != str(vps['node_id']))):
        try:
            run_sync(execute_lxc(
                vps['container_name'],
                f"stop {vps['container_name']}",
                node_id=vps['node_id']
            ))
            update_vps(vps_id, status='stopped')
        except Exception as e:
            flash(f"Failed to stop VPS: {e}", "danger")
            return redirect(request.url)

    try:
        if ram:
            ram_mb = int(ram) * 1024
            run_sync(execute_lxc(
                vps['container_name'],
                f"config set {vps['container_name']} limits.memory {ram_mb}MB",
                node_id=vps['node_id']
            ))

        if cpu:
            run_sync(execute_lxc(
                vps['container_name'],
                f"config set {vps['container_name']} limits.cpu {int(cpu)}",
                node_id=vps['node_id']
            ))

        if disk:
            run_sync(resize_vps_disk(vps['container_name'], vps['node_id'], int(disk), _size_to_gib(vps.get('storage'))))

        if ip_address:
            # Use the proper IP configuration function
            run_sync(configure_container_ip(vps['container_name'], ip_address, vps['node_id']))

        updates = {}

        if new_user_id and new_user_id != str(vps['user_id']):
            updates['user_id'] = int(new_user_id)
            logger.info(f"Changing VPS {vps_id} owner from {vps['user_id']} to {new_user_id}")
        
        if node_id and node_id != str(vps['node_id']):
            updates['node_id'] = int(node_id)
            logger.info(f"Moving VPS {vps_id} from node {vps['node_id']} to {node_id}")

        if ram:
            updates['ram'] = f"{ram}GB"
        if cpu:
            updates['cpu'] = str(cpu)
        if disk:
            updates['storage'] = f"{disk}GB"
        if hostname:
            updates['hostname'] = hostname
            try:
                run_sync(execute_lxc(
                    vps['container_name'],
                    f"exec {vps['container_name']} -- hostnamectl set-hostname {hostname}",
                    node_id=vps['node_id']
                ))
            except:
                pass

        if ip_address:
            updates['ip_address'] = ip_address
        if ip_alias:
            updates['ip_alias'] = ip_alias
        if os_version:
            updates['os_version'] = os_version

        if updates:
            config_str = f"{updates.get('ram', vps['ram'])} RAM / {updates.get('cpu', vps['cpu'])} CPU / {updates.get('storage', vps['storage'])} Disk"
            updates['config'] = config_str
            updates['updated_at'] = datetime.now().isoformat()
            
            # Use direct SQL for critical updates
            with get_db() as conn:
                cur = conn.cursor()
                set_clauses = []
                values = []
                for key, value in updates.items():
                    set_clauses.append(f"{key} = ?")
                    values.append(value)
                values.append(vps_id)
                
                sql = f"UPDATE vps SET {', '.join(set_clauses)} WHERE id = ?"
                cur.execute(sql, values)
                conn.commit()
                logger.info(f"VPS {vps_id} updated in database (rows affected: {cur.rowcount})")
                logger.info(f"Updates applied: {updates}")

        if was_running:
            run_sync(execute_lxc(
                vps['container_name'],
                f"start {vps['container_name']}",
                node_id=updates.get('node_id', vps['node_id'])
            ))
            run_sync(apply_internal_permissions(vps['container_name'], updates.get('node_id', vps['node_id'])))
            run_sync(apply_cpu_view(vps['container_name'], updates.get('node_id', vps['node_id']), int(cpu) if cpu else int(vps['cpu'])))
            try:
                _ram_gb = int(ram) if ram else int(str(vps['ram']).replace('GB', '').strip())
                run_sync(apply_ram_view(vps['container_name'], updates.get('node_id', vps['node_id']), _ram_gb * 1024))
            except Exception as _e:
                logger.warning(f"RAM view update skipped for {vps['container_name']}: {_e}")
            _fk = get_vps_fake_cfg(vps['container_name'])
            if _fk:
                run_sync(apply_fake_view(vps['container_name'], updates.get('node_id', vps['node_id']), _fk))
            run_sync(recreate_port_forwards(vps['container_name']))
            
            # Update status to running
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE vps SET status = ? WHERE id = ?', ('running', vps_id))
                conn.commit()

        log_activity(current_user.id, 'edit_vps', 'vps', str(vps_id), updates)

        # Send notification to new owner if owner changed
        target_user_id = updates.get('user_id', vps['user_id'])
        create_notification(
            target_user_id,
            'info',
            'VPS Updated',
            f'VPS {vps["container_name"]} has been updated by an administrator.'
        )

        flash("VPS updated successfully!", "success")
        return redirect(url_for('admin_vps'))

    except Exception as e:
        if was_running:
            try:
                run_sync(execute_lxc(
                    vps['container_name'],
                    f"start {vps['container_name']}",
                    node_id=vps['node_id']
                ))
            except:
                pass

        flash(str(e), "danger")
        return redirect(request.url)

CREATE_JOBS: Dict[str, Dict[str, Any]] = {}
CREATE_STAGES = [
    # (key, label, percent when stage starts)
    ('prepare',   'Preparing the node',                2),
    ('storage',   'Reserving disk space',              6),
    ('image',     'Downloading & unpacking the OS',   12),
    ('resources', 'Applying CPU, RAM and disk',       55),
    ('config',    'Configuring permissions',          62),
    ('start',     'Booting the new system',           68),
    ('network',   'Setting up networking',            76),
    ('packages',  'Installing base packages',         86),
    ('ssh',       'Configuring SSH access',           93),
    ('finish',    'Finalizing your VPS',              97),
]

def _purge_create_jobs(max_age: int = 3600):
    now = time.time()
    for k in [k for k, j in CREATE_JOBS.items() if j.get('status') != 'running' and now - j.get('updated', now) > max_age]:
        CREATE_JOBS.pop(k, None)

def _create_progress(job_id: str, key: str):
    idx = next(i for i, st in enumerate(CREATE_STAGES) if st[0] == key)
    nxt = CREATE_STAGES[idx + 1][2] if idx + 1 < len(CREATE_STAGES) else 100
    job = CREATE_JOBS.get(job_id)
    if job is not None:
        logger.info(f"Create job {job_id[:8]} ({job.get('container_name')}): stage '{key}' started "
                    f"(+{time.time() - job.get('started', time.time()):.0f}s)")
        job.update(stage=key, label=CREATE_STAGES[idx][1], percent=CREATE_STAGES[idx][2], next=nxt, index=idx,
                   updated=time.time())

def _create_heartbeat(job_id: str, container_name: str, node_id, stop_evt):
    """While the slow image step runs, log what the node is doing every 20s (shows up in `pm2 logs`)."""
    t0 = time.time()
    while not stop_evt.wait(20):
        info = ''
        try:
            node = get_node(node_id)
            if node and node.get('is_local'):
                import subprocess as _sp
                r = _sp.run("ps -eo pid,etime,pcpu,args | grep -E '[l]xc (init|image)|[u]nsquashfs|[x]z -d|[t]ar -' | head -5",
                            shell=True, capture_output=True, text=True, timeout=5)
                info = ' | ' + (r.stdout.strip().replace('\n', ' ;; ') or 'no lxc/unpack process found')
            else:
                info = ' | remote node (waiting for its API to answer)'
        except Exception as e:
            info = f' | heartbeat error: {e}'
        logger.info(f"Create job {job_id[:8]} ({container_name}): image step still running after {time.time() - t0:.0f}s{info}")

def _create_vps_worker(job_id: str, p: Dict[str, Any], actor_id: int):
    container_name = p['container_name']
    node_id = p['node_id']
    cpu, ram, disk = p['cpu'], p['ram'], p['disk']
    prog = lambda k: _create_progress(job_id, k)
    try:
        prog('prepare')
        run_sync(ensure_lxd_network(node_id))

        prog('storage')
        _pool, _root, _drv, _perr = run_sync(create_dedicated_storage(container_name, disk, node_id))
        if _drv is None:   # no own pool possible -> old method: grow the shared pool + per-VPS quota
            run_sync(ensure_pool_capacity(node_id, get_node_allocated_gib(node_id, extra_gib=disk)))

        prog('image')
        _hb_stop = threading.Event()
        threading.Thread(target=_create_heartbeat, args=(job_id, container_name, node_id, _hb_stop), daemon=True).start()
        try:
            run_sync(execute_lxc(container_name, f"init {p['os_version']} {container_name} -s {_pool}", node_id=node_id, timeout=900))
        finally:
            _hb_stop.set()

        prog('resources')
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.memory {ram * 1024}MB", node_id=node_id))
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.cpu {cpu}", node_id=node_id))
        run_sync(finish_dedicated_storage(container_name, node_id, disk, _pool, _root, _drv))

        prog('config')
        run_sync(apply_lxc_config(container_name, node_id))

        prog('start')
        run_sync(execute_lxc(container_name, f"start {container_name}", node_id=node_id))

        prog('network')
        if p.get('ip_address'):
            run_sync(configure_container_ip(container_name, p['ip_address'], node_id))

        prog('packages')
        run_sync(_with_deadline(apply_internal_permissions(container_name, node_id), 240, 'packages'))

        prog('ssh')
        run_sync(_with_deadline(configure_ssh_and_root_password(container_name, node_id), 200, 'ssh'))
        run_sync(apply_cpu_view(container_name, node_id, cpu))
        run_sync(apply_ram_view(container_name, node_id, ram * 1024))
        if p.get('fake'):
            run_sync(apply_fake_view(container_name, node_id, p['fake']))

        prog('finish')
        vps_id = create_vps(
            user_id=p['user_id'],
            node_id=node_id,
            container_name=container_name,
            hostname=p.get('hostname') or container_name,
            ram=f"{ram}GB",
            cpu=str(cpu),
            storage=f"{disk}GB",
            config=f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk",
            os_version=p['os_version'],
            ip_address=p.get('ip_address'),
            ip_alias=p.get('ip_alias'),
            expiration_days=p.get('expiration_days', 0),
            auto_suspend_enabled=p.get('auto_suspend_enabled', False)
        )

        if p.get('fake'):
            try:
                save_vps_fake_cfg(vps_id, p['fake'])
            except Exception as _e:
                logger.warning(f"Could not save fake resources for VPS {vps_id}: {_e}")

        log_activity(actor_id, 'admin_create_vps', 'vps', str(vps_id),
                     {'user_id': p['user_id'], 'container': container_name})
        create_notification(p['user_id'], 'success', 'VPS Created', f'Your VPS {container_name} has been created by an administrator.')

        CREATE_JOBS[job_id].update(status='done', percent=100, next=100, label='VPS created', stage='done',
                                   vps_id=vps_id, updated=time.time())
    except Exception as e:
        logger.error(f"VPS creation error: {e}", exc_info=True)
        try:
            run_sync(execute_lxc(container_name, f"delete {container_name} --force", node_id=node_id))
        except Exception:
            pass
        destroy_vps_disk_sync(container_name, node_id)
        CREATE_JOBS[job_id].update(status='error', error=str(e).split('\nCommand:')[0][:300], updated=time.time())

def _kvm_available_local() -> Optional[str]:
    """None if this host can run KVM guests, otherwise a human readable reason."""
    if os.getenv('HVM_REQUIRE_KVM') != '1':
        return None  # check bypassed by default; set HVM_REQUIRE_KVM=1 to enforce it
    if not os.path.exists('/dev/kvm'):
        return ("/dev/kvm not found on the node. Enable virtualization (VT-x/AMD-V) in the BIOS or, on a cloud/VPS "
                "host, enable nested virtualization, then run: modprobe kvm_intel (or kvm_amd)")
    return None

async def _wait_for_vm_agent(name: str, node_id: int, timeout: int = 240) -> bool:
    """A VM answers `lxc exec` only after its lxd-agent is up (usually 20-60s after boot)."""
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            await execute_lxc(name, f"exec {name} -- true", node_id=node_id, timeout=10)
            return True
        except Exception:
            await asyncio.sleep(3)
    return False

def _create_kvm_worker(job_id: str, p: Dict[str, Any], actor_id: int):
    """Real KVM virtual machine (LXD `--vm`): own kernel, own disk, hardware limits."""
    name = p['container_name']
    node_id = p['node_id']
    cpu, ram, disk = p['cpu'], p['ram'], p['disk']
    prog = lambda k: _create_progress(job_id, k)
    try:
        prog('prepare')
        run_sync(ensure_lxd_network(node_id))

        prog('storage')
        _pool, _root, _drv, _perr = run_sync(create_dedicated_storage(name, disk, node_id, vm=True))
        if _drv is None:
            run_sync(ensure_pool_capacity(node_id, get_node_allocated_gib(node_id, extra_gib=disk)))

        prog('image')
        _hb_stop = threading.Event()
        threading.Thread(target=_create_heartbeat, args=(job_id, name, node_id, _hb_stop), daemon=True).start()
        try:
            # size, cpu, memory are given at init time so no later (VM-incompatible) tweaks are needed
            run_sync(execute_lxc(
                name,
                f"init {p['os_version']} {name} --vm -s {_pool} "
                f"-c limits.cpu={cpu} -c limits.memory={ram * 1024}MiB "
                f"-c security.secureboot=false -d root,size={disk}GiB",
                node_id=node_id, timeout=1200))
        finally:
            _hb_stop.set()

        prog('resources')
        # make sure the disk is really the requested size (some pools ignore size on init)
        try:
            run_sync(execute_lxc(name, f"config device set {name} root size={disk}GiB", node_id=node_id))
        except Exception as e:
            logger.debug(f"root size already set for {name}: {e}")

        prog('start')
        run_sync(execute_lxc(name, f"start {name}", node_id=node_id, timeout=120))

        prog('network')
        if not run_sync(_wait_for_vm_agent(name, node_id, 240)):
            raise Exception("The VM started but its agent never answered (4 min). The selected image may not be a "
                            "VM image - use ubuntu:22.04 / ubuntu:24.04 / images:debian/12 - or the node has no working KVM.")
        if p.get('ip_address'):
            run_sync(configure_container_ip(name, p['ip_address'], node_id))

        prog('packages')
        run_sync(_with_deadline(apply_internal_permissions(name, node_id), 240, 'packages'))

        prog('ssh')
        run_sync(_with_deadline(configure_ssh_and_root_password(name, node_id), 200, 'ssh'))
        if p.get('fake'):
            run_sync(apply_fake_view(name, node_id, p['fake'], kvm=True))

        prog('finish')
        vps_id = create_vps(
            user_id=p['user_id'], node_id=node_id, container_name=name,
            hostname=p.get('hostname') or name,
            ram=f"{ram}GB", cpu=str(cpu), storage=f"{disk}GB",
            config=f"KVM / {ram}GB RAM / {cpu} CPU / {disk}GB Disk",
            os_version=p['os_version'], ip_address=p.get('ip_address'), ip_alias=p.get('ip_alias'),
            expiration_days=p.get('expiration_days', 0), auto_suspend_enabled=p.get('auto_suspend_enabled', False))
        with get_db() as conn:
            conn.execute("UPDATE vps SET vps_type = 'kvm', status = 'running' WHERE id = ?", (vps_id,))
            conn.commit()
        if p.get('fake'):
            try:
                save_vps_fake_cfg(vps_id, p['fake'])
            except Exception as _e:
                logger.warning(f"Could not save fake resources for KVM VPS {vps_id}: {_e}")

        log_activity(actor_id, 'admin_create_vps', 'vps', str(vps_id),
                     {'user_id': p['user_id'], 'container': name, 'type': 'kvm'})
        create_notification(p['user_id'], 'success', 'VPS Created', f'Your KVM VPS {name} has been created by an administrator.')
        CREATE_JOBS[job_id].update(status='done', percent=100, next=100, label='VPS created', stage='done',
                                   vps_id=vps_id, updated=time.time())
    except Exception as e:
        logger.error(f"KVM VPS creation error: {e}", exc_info=True)
        try:
            run_sync(execute_lxc(name, f"delete {name} --force", node_id=node_id))
        except Exception:
            pass
        destroy_vps_disk_sync(name, node_id)
        CREATE_JOBS[job_id].update(status='error', error=str(e).split('\nCommand:')[0][:300], updated=time.time())

def _admin_create_shared_vps(data: dict):
    """Create a shared hosting VPS: no LXD container, just isolated system-user
    accounts on an existing Linux server. Fast and synchronous."""
    name = (data.get('hostname') or data.get('name') or '').strip()
    node_id = data.get('node_id')
    expiration_days = int(data.get('expiration_days', 0) or 0)
    auto_suspend_enabled = bool(data.get('auto_suspend_enabled', False))

    fake_cfg = None
    _fr = data.get('fake_resources') or {}
    if _fr.get('enabled'):
        try:
            fake_cfg = {'ram_gb': min(max(1, int(_fr.get('ram_gb', 625))), 8192),
                        'cpu': min(max(1, int(_fr.get('cpu', 128))), 1024),
                        'disk_gb': min(max(1, int(_fr.get('disk_gb', 1900))), 100000)}
        except (TypeError, ValueError):
            return jsonify({'success': False, 'error': 'Invalid fake resource values'}), 400

    accounts_in = data.get('accounts') or []
    parsed = []
    for acc in accounts_in:
        try:
            uid = int(acc.get('user_id'))
            ram_mb = max(128, int(acc.get('ram_mb', 512)))
            cpu = max(1, int(acc.get('cpu', 1)))
            disk_gb = max(1, int(acc.get('disk_gb', 5)))
        except (TypeError, ValueError):
            return jsonify({'success': False, 'error': 'Invalid shared account entry'}), 400
        parsed.append({'user_id': uid, 'ram_mb': ram_mb, 'cpu': cpu, 'disk_gb': disk_gb})

    if not name:
        return jsonify({'success': False, 'error': 'Name is required'}), 400
    if not parsed:
        return jsonify({'success': False, 'error': 'Select at least one user'}), 400
    if not node_id:
        return jsonify({'success': False, 'error': 'Node is required'}), 400
    node = get_node(node_id)
    if not node:
        return jsonify({'success': False, 'error': 'Node not found'}), 404

    user_ids = []
    for acc in parsed:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id FROM users WHERE id = ?', (acc['user_id'],))
            if not cur.fetchone():
                return jsonify({'success': False, 'error': f"User {acc['user_id']} not found"}), 400
        user_ids.append(acc['user_id'])
    if len(set(user_ids)) != len(user_ids):
        return jsonify({'success': False, 'error': 'Each user may only be selected once'}), 400

    # container_name doubles as the shared base dir name (/opt/hvm-shared/<name>)
    base = re.sub(r'[^a-z0-9\-]', '', name.lower().replace(' ', '-').replace('_', '-')).strip('-')
    container_name = f"sh-{base}"
    if len(container_name) < 4:
        return jsonify({'success': False, 'error': 'Invalid name (use letters, numbers and dashes)'}), 400

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM vps WHERE container_name = ?', (container_name,))
        if cur.fetchone()[0] > 0:
            return jsonify({'success': False, 'error': 'A VPS with this name already exists'}), 400

    current_count = get_current_vps_count(node_id)
    if current_count >= node['total_vps']:
        return jsonify({'success': False, 'error': 'Node at full capacity'}), 400

    total_ram_mb = sum(a['ram_mb'] for a in parsed)
    total_cpu = sum(a['cpu'] for a in parsed)
    total_disk = sum(a['disk_gb'] for a in parsed)

    vps_id = None
    created_accounts = []
    try:
        # Dashboard renders int(vps['ram'].replace('GB','')) - always "<n>GB"
        vps_id = create_vps(
            user_id=user_ids[0], node_id=node_id, container_name=container_name,
            ram=f"{max(1, (total_ram_mb + 1023) // 1024)}GB", cpu=str(total_cpu),
            storage=f"{total_disk}GB", config='shared', os_version='shared',
            hostname=base, expiration_days=expiration_days,
            auto_suspend_enabled=auto_suspend_enabled)

        if fake_cfg:
            try:
                save_vps_fake_cfg(vps_id, fake_cfg)
            except Exception as _e:
                logger.warning(f"Could not save fake resources for shared VPS {vps_id}: {_e}")

        now = datetime.now().isoformat()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE vps SET status = 'running', vps_type = 'shared' WHERE id = ?", (vps_id,))
            for acc in parsed:
                system_user = f"hu{vps_id}u{acc['user_id']}"
                password = secrets.token_urlsafe(12)
                home_dir = f"/opt/hvm-shared/{container_name}/{system_user}"
                cur.execute('''INSERT INTO shared_accounts
                    (vps_id, user_id, system_user, home_dir, ssh_password,
                     ram_mb, cpu_limit, disk_gb, port_base, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'active', ?)''',
                    (vps_id, acc['user_id'], system_user, home_dir, password,
                     acc['ram_mb'], acc['cpu'], acc['disk_gb'], now))
                account_id = cur.lastrowid
                port_base = 20000 + ((account_id % 400) * 100)
                cur.execute('UPDATE shared_accounts SET port_base = ? WHERE id = ?', (port_base, account_id))
                created_accounts.append({
                    'id': account_id, 'user_id': acc['user_id'], 'system_user': system_user,
                    'password': password, 'home_dir': home_dir, 'ram_mb': acc['ram_mb'],
                    'cpu': acc['cpu'], 'disk_gb': acc['disk_gb'], 'port_base': port_base,
                    'fake': fake_cfg,
                })
            conn.commit()

        # Provision on the node: users, homes, limits, restricted shell, sshd
        vps = get_vps_by_id(vps_id)
        result = shared_node_op(vps, shared_hosting.setup_script(container_name, created_accounts), timeout=900)
        if not result.get('ok'):
            raise Exception(result.get('err') or 'Shared hosting setup failed')

        log_activity(current_user.id, 'admin_create_shared_vps', 'vps', str(vps_id),
                     {'container': container_name, 'accounts': [a['system_user'] for a in created_accounts]})
        for acc in created_accounts:
            try:
                create_notification(acc['user_id'], 'success', 'Shared Hosting Created',
                                    f'You now have an account on shared VPS "{base}". '
                                    f'Open it from your dashboard to use the console and upload your website.')
            except Exception:
                pass

        return jsonify({'success': True, 'vps_id': vps_id, 'container_name': container_name,
                        'message': f'Shared VPS created with {len(created_accounts)} account(s)'})
    except Exception as e:
        logger.error(f"Shared VPS creation failed: {e}", exc_info=True)
        # Roll back: remove half-created system users on the node, then DB rows
        try:
            if created_accounts and vps_id:
                vps = get_vps_by_id(vps_id)
                if vps:
                    shared_node_op(vps, shared_hosting.remove_script(
                        [a['system_user'] for a in created_accounts], container_name), timeout=180)
        except Exception as ce:
            logger.warning(f"Shared creation cleanup failed: {ce}")
        try:
            with get_db() as conn:
                cur = conn.cursor()
                if vps_id:
                    cur.execute('DELETE FROM shared_accounts WHERE vps_id = ?', (vps_id,))
                    cur.execute('DELETE FROM vps WHERE id = ?', (vps_id,))
                    cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?',
                                (node_id, node_id))
                conn.commit()
        except Exception as de:
            logger.error(f"Shared creation rollback DB error: {de}")
        return jsonify({'success': False, 'error': str(e).split('\nCommand:')[0][:300]}), 500

@app.route('/admin/vps/create', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_vps_create():
    if request.method == 'GET':
        users = []
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, username, email FROM users ORDER BY username')
            users = [dict(row) for row in cur.fetchall()]
        
        nodes = get_nodes()
        
        return render_template('admin/vps_create.html',
                              panel_name=get_setting('site_name', 'ExpelHost Panel'),
                              users=users,
                              nodes=nodes,
                              os_options=OS_OPTIONS)
    
    data = request.get_json()
    
    # ------------------------------------------------------------------
    # Shared hosting creation: no LXD container, just system-user accounts
    # on an existing Linux server. Fast + synchronous (no CREATE_JOBS).
    # ------------------------------------------------------------------
    if (data.get('vps_type') or 'dedicated') == 'shared':
        return _admin_create_shared_vps(data)
    
    user_id = data.get('user_id')
    node_id = data.get('node_id')
    ram = int(data.get('ram', 2))
    cpu = int(data.get('cpu', 2))
    disk = int(data.get('disk', 20))
    os_version = data.get('os_version', 'ubuntu:22.04')
    hostname = data.get('hostname')
    ip_address = data.get('ip_address', '').strip() if data.get('ip_address') else None
    ip_alias = data.get('ip_alias', '').strip() if data.get('ip_alias') else None
    is_kvm = (data.get('vps_type') or 'dedicated') == 'kvm'
    fake_cfg, _fake_err = parse_fake_cfg(data)
    if _fake_err:
        return jsonify({'success': False, 'error': _fake_err}), 400
    expiration_days = int(data.get('expiration_days', 0))
    auto_suspend_enabled = bool(data.get('auto_suspend_enabled', False))
    
    # Validate IP address format if provided
    if ip_address:
        try:
            import ipaddress
            ipaddress.ip_address(ip_address)
            logger.info(f"Valid IP address provided: {ip_address}")
        except ValueError as e:
            logger.error(f"Invalid IP address format: {ip_address}")
            return jsonify({'success': False, 'error': f'Invalid IP address format: {ip_address}'}), 400
    
    if not all([user_id, node_id]):
        return jsonify({'success': False, 'error': 'Missing parameters'}), 400
    
    node = get_node(node_id)
    if not node:
        return jsonify({'success': False, 'error': 'Node not found'}), 404
    
    current_count = get_current_vps_count(node_id)
    if current_count >= node['total_vps']:
        return jsonify({'success': False, 'error': 'Node at full capacity'}), 400
    
    if is_kvm and node.get('is_local'):
        _why = _kvm_available_local()
        if _why:
            return jsonify({'success': False, 'error': 'KVM is not available: ' + _why}), 400
    
    max_vps = int(get_setting('max_vps_per_user', '10'))
    user_vps_count = len(get_vps_for_user(user_id))
    if user_vps_count >= max_vps:
        return jsonify({'success': False, 'error': f'User has reached maximum VPS limit ({max_vps})'}), 400
    
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT COUNT(*) FROM vps WHERE user_id = ?', (user_id,))
            vps_count = cur.fetchone()[0] + 1
            
        container_name = f"hvm-vps-{user_id}-{vps_count}"
        if hostname:
            container_name = hostname.lower().replace(' ', '-').replace('_', '-')
            container_name = re.sub(r'[^a-z0-9\-]', '', container_name)
        if not container_name:
            return jsonify({'success': False, 'error': 'Invalid hostname'}), 400

        # one create job at a time per container name
        for j in CREATE_JOBS.values():
            if j.get('container_name') == container_name and j.get('status') == 'running':
                return jsonify({'success': True, 'started': False, 'job_id': j['id'], 'container_name': container_name,
                                'message': 'Creation already in progress'})

        _purge_create_jobs()
        job_id = uuid.uuid4().hex
        CREATE_JOBS[job_id] = {'id': job_id, 'status': 'running', 'percent': 0, 'next': CREATE_STAGES[0][2], 'stage': 'queued',
                               'label': 'Preparing your VPS', 'index': -1, 'container_name': container_name,
                               'owner': current_user.id,
                               'stages': [{'key': k, 'label': l} for k, l, _ in CREATE_STAGES],
                               'started': time.time(), 'updated': time.time()}
        params = dict(user_id=user_id, node_id=node_id, container_name=container_name, hostname=hostname,
                      ram=ram, cpu=cpu, disk=disk, os_version=os_version, ip_address=ip_address, ip_alias=ip_alias,
                      expiration_days=expiration_days, auto_suspend_enabled=auto_suspend_enabled, fake=fake_cfg)
        threading.Thread(target=(_create_kvm_worker if is_kvm else _create_vps_worker),
                         args=(job_id, params, current_user.id), daemon=True).start()
        return jsonify({'success': True, 'started': True, 'job_id': job_id, 'container_name': container_name,
                        'message': 'VPS creation started'})
    except Exception as e:
        logger.error(f"VPS creation start error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/create/status/<job_id>')
@login_required
@admin_required
def admin_vps_create_status(job_id):
    job = CREATE_JOBS.get(job_id)
    if not job:
        return jsonify({'success': False, 'error': 'Job not found'}), 404
    return jsonify({'success': True, **job})

@app.route('/admin/nodes')
@login_required
@admin_required
def admin_nodes():
    nodes = get_nodes()
    
    node_stats = []
    for node in nodes:
        vps_count = get_current_vps_count(node['id'])
        status = run_sync(get_node_status(node['id']))
        stats = status.get('stats', {})
        
        node_stats.append({
            'id': node['id'],
            'name': node['name'],
            'location': node['location'],
            'status': status['status'],
            'online': status.get('online', False),
            'vps_count': vps_count,
            'total_vps': node['total_vps'],
            'tags': node['tags'],
            'is_local': node['is_local'],
            'url': node.get('url', 'N/A'),
            'api_key': node.get('api_key'),
            'api_key_last_used': node.get('api_key_last_used'),
            'last_seen': node.get('last_seen'),
            'cpu_cores': node.get('cpu_cores', 0),
            'ram_total': node.get('ram_total', 0),
            'disk_total': node.get('disk_total', 0),
            'ip_addresses': node.get('ip_addresses', []),
            'ip_aliases': node.get('ip_aliases', []),
            'stats': stats
        })
    
    return render_template('admin/nodes.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          nodes=node_stats,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/admin/nodes/test-connection', methods=['POST'])
@login_required
@admin_required
def admin_node_test_connection():
    """Test connection to a remote node"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        verify_ssl = data.get('verify_ssl', True)
        
        if not url:
            return jsonify({'success': False, 'error': 'URL is required'}), 400
        
        # Add http:// if no protocol specified
        if not url.startswith(('http://', 'https://')):
            url = f"http://{url}"
        
        # Remove trailing slash
        url = url.rstrip('/')
        
        # Try to ping the node using public health endpoint (no auth required)
        import requests
        try:
            # Test with /api/health endpoint (public, no auth required)
            response = requests.get(f"{url}/api/health", timeout=10, verify=verify_ssl)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    return jsonify({
                        'success': True,
                        'message': 'Connection successful',
                        'node_info': {
                            'hostname': data.get('hostname', 'Unknown'),
                            'version': data.get('version', 'Unknown'),
                            'status': data.get('status', 'online'),
                            'service': data.get('service', 'Unknown')
                        }
                    })
                except:
                    return jsonify({
                        'success': True,
                        'message': 'Connection successful (basic)',
                        'node_info': None
                    })
            elif response.status_code == 404:
                # Health endpoint not found, try root endpoint
                try:
                    response = requests.get(f"{url}/", timeout=5, verify=verify_ssl)
                    if response.status_code == 200:
                        return jsonify({
                            'success': True,
                            'message': 'Connection successful (server reachable)',
                            'node_info': {
                                'hostname': 'Unknown',
                                'version': 'Unknown',
                                'status': 'online',
                                'note': 'Update node.py to latest version for full health check'
                            }
                        })
                except:
                    pass
                
                return jsonify({
                    'success': False,
                    'error': 'Node is reachable but /api/health endpoint not found. Please update node.py to the latest version.'
                }), 400
            else:
                return jsonify({
                    'success': False,
                    'error': f'Node returned status code {response.status_code}'
                }), 400
        
        except requests.exceptions.Timeout:
            return jsonify({
                'success': False,
                'error': 'Connection timeout - node is not responding'
            }), 400
        
        except requests.exceptions.ConnectionError:
            return jsonify({
                'success': False,
                'error': 'Connection refused - check if node is running and URL is correct'
            }), 400
        
        except requests.exceptions.SSLError:
            return jsonify({
                'success': False,
                'error': 'SSL certificate error - check HTTPS configuration'
            }), 400
        
        except Exception as e:
            return jsonify({
                'success': False,
                'error': f'Connection error: {str(e)}'
            }), 400
    
    except Exception as e:
        logger.error(f"Test connection error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/nodes/create', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_node_create():
    # GET - Render create form
    if request.method == 'GET':
        return render_template('admin/nodes_create.html',
                              panel_name=get_setting('site_name', 'ExpelHost Panel'))
    
    # POST - Process form submission
    data = request.get_json() or request.form.to_dict()
    
    name = data.get('name')
    location = data.get('location')
    total_vps = int(data.get('total_vps', 50))
    tags = data.get('tags', '').split(',') if data.get('tags') else []
    url = data.get('url', '').strip()
    verify_ssl = 1 if data.get('verify_ssl', True) else 0
    ip_addresses = data.get('ip_addresses', '').split(',') if data.get('ip_addresses') else []
    ip_aliases = data.get('ip_aliases', '').split(',') if data.get('ip_aliases') else []
    
    if not name or not location:
        return jsonify({'success': False, 'error': 'Name and location required'}), 400
    
    # Clean and validate URL if provided
    if url:
        # Remove trailing slash
        url = url.rstrip('/')
        
        # Simple validation - just check if it has http:// or https://
        if not url.startswith(('http://', 'https://')):
            # Add http:// by default for simple IP:port format
            url = f"http://{url}"
        
        # Validate URL format
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            
            if parsed.scheme not in ['http', 'https']:
                return jsonify({'success': False, 'error': 'URL must use http:// or https://'}), 400
            
            if not parsed.netloc:
                return jsonify({'success': False, 'error': 'Invalid URL format'}), 400
            
            # Reconstruct clean URL (preserve path for Cloudflare tunnels)
            url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            
        except Exception as e:
            return jsonify({'success': False, 'error': f'Invalid URL: {str(e)}'}), 400
    
    tags = [t.strip() for t in tags if t.strip()]
    ip_addresses = [ip.strip() for ip in ip_addresses if ip.strip()]
    ip_aliases = [alias.strip() for alias in ip_aliases if alias.strip()]
    
    tags_json = json.dumps(tags)
    ip_addresses_json = json.dumps(ip_addresses)
    ip_aliases_json = json.dumps(ip_aliases)
    
    is_local = 1 if not url else 0
    api_key = None if is_local else generate_api_key()
    now = datetime.now().isoformat()
    
    with get_db() as conn:
        cur = conn.cursor()
        try:
            cur.execute('''INSERT INTO nodes 
                (name, location, total_vps, tags, api_key, url, is_local, verify_ssl,
                 ip_addresses, ip_aliases, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (name, location, total_vps, tags_json, api_key, url, is_local, verify_ssl,
                 ip_addresses_json, ip_aliases_json, now, now))
            conn.commit()
            node_id = cur.lastrowid
            
            logger.info(f"Node created: {name} (ID: {node_id}) - {'Local' if is_local else f'Remote: {url}'} - SSL Verify: {bool(verify_ssl)}")
        except sqlite3.IntegrityError:
            return jsonify({'success': False, 'error': 'Node name already exists'}), 400
    
    log_activity(current_user.id, 'create_node', 'node', str(node_id), {'name': name, 'url': url})
    return jsonify({'success': True, 'node_id': node_id, 'api_key': api_key})

@app.route('/admin/nodes/<int:node_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_node_edit(node_id):
    node = get_node(node_id)
    if not node:
        if request.method == 'GET':
            flash('Node not found', 'danger')
            return redirect(url_for('admin_nodes'))
        return jsonify({'success': False, 'error': 'Node not found'}), 404
    
    # GET - Render edit page
    if request.method == 'GET':
        # Get VPS count for this node
        vps_count = get_current_vps_count(node_id)
        
        # Parse tags and IPs for display
        try:
            tags = json.loads(node['tags']) if node['tags'] else []
            tags_str = ', '.join(tags)
        except:
            tags_str = ''
        
        try:
            ip_addresses = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            ip_addresses_str = ', '.join(ip_addresses)
            ip_addresses_count = len(ip_addresses)
        except:
            ip_addresses_str = ''
            ip_addresses_count = 0
        
        try:
            ip_aliases = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            ip_aliases_str = ', '.join(ip_aliases)
        except:
            ip_aliases_str = ''
        
        return render_template('admin/node_edit.html',
                              panel_name=get_setting('site_name', 'ExpelHost Panel'),
                              node=node,
                              vps_count=vps_count,
                              tags_str=tags_str,
                              ip_addresses_str=ip_addresses_str,
                              ip_addresses_count=ip_addresses_count,
                              ip_aliases_str=ip_aliases_str)
    
    # POST - Save changes
    data = request.get_json() or request.form.to_dict()
    
    with get_db() as conn:
        cur = conn.cursor()
        
        if 'name' in data:
            cur.execute('UPDATE nodes SET name = ? WHERE id = ?', (data['name'], node_id))
        if 'location' in data:
            cur.execute('UPDATE nodes SET location = ? WHERE id = ?', (data['location'], node_id))
        if 'total_vps' in data:
            cur.execute('UPDATE nodes SET total_vps = ? WHERE id = ?', (int(data['total_vps']), node_id))
        if 'tags' in data:
            tags = [t.strip() for t in data['tags'].split(',') if t.strip()]
            cur.execute('UPDATE nodes SET tags = ? WHERE id = ?', (json.dumps(tags), node_id))
        if 'url' in data and not node['is_local']:
            cur.execute('UPDATE nodes SET url = ? WHERE id = ?', (data['url'], node_id))
        if 'verify_ssl' in data and not node['is_local']:
            verify_ssl = 1 if data['verify_ssl'] else 0
            cur.execute('UPDATE nodes SET verify_ssl = ? WHERE id = ?', (verify_ssl, node_id))
        if 'ssh_host' in data and not node['is_local']:
            cur.execute('UPDATE nodes SET ssh_host = ? WHERE id = ?', ((data['ssh_host'] or '').strip() or None, node_id))
        if 'ssh_port' in data and not node['is_local']:
            try:
                _sp = int(data['ssh_port']) if str(data['ssh_port']).strip() else None
            except Exception:
                _sp = None
            cur.execute('UPDATE nodes SET ssh_port = ? WHERE id = ?', (_sp, node_id))
        if 'ip_addresses' in data:
            ips = [ip.strip() for ip in data['ip_addresses'].split(',') if ip.strip()]
            cur.execute('UPDATE nodes SET ip_addresses = ? WHERE id = ?', (json.dumps(ips), node_id))
        if 'ip_aliases' in data:
            aliases = [alias.strip() for alias in data['ip_aliases'].split(',') if alias.strip()]
            cur.execute('UPDATE nodes SET ip_aliases = ? WHERE id = ?', (json.dumps(aliases), node_id))
        
        cur.execute('UPDATE nodes SET updated_at = ? WHERE id = ?', (datetime.now().isoformat(), node_id))
        conn.commit()
    
    log_activity(current_user.id, 'edit_node', 'node', str(node_id))
    
    # Return JSON for AJAX requests or redirect for form submissions
    if request.is_json:
        return jsonify({'success': True})
    else:
        flash('Node updated successfully', 'success')
        return redirect(url_for('admin_nodes'))

@app.route('/admin/nodes/<int:node_id>/regenerate-key', methods=['POST'])
@login_required
@admin_required
def admin_node_regenerate_key(node_id):
    node = get_node(node_id)
    if not node:
        return jsonify({'success': False, 'error': 'Node not found'}), 404
    
    if node['is_local']:
        return jsonify({'success': False, 'error': 'Cannot regenerate key for local node'}), 400
    
    new_key = generate_api_key()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET api_key = ?, updated_at = ? WHERE id = ?',
                   (new_key, datetime.now().isoformat(), node_id))
        conn.commit()
    
    log_activity(current_user.id, 'regenerate_node_key', 'node', str(node_id))
    return jsonify({'success': True, 'api_key': new_key})

@app.route('/admin/nodes/<int:node_id>/delete', methods=['POST'])
@login_required
@admin_required
def admin_node_delete(node_id):
    try:
        node = get_node(node_id)
        if not node:
            return jsonify({'success': False, 'error': 'Node not found'}), 404
        
        # Allow deletion of local node (removed restriction)
        # if node['is_local']:
        #     return jsonify({'success': False, 'error': 'Cannot delete local node'}), 400
        
        data = request.get_json() or {}
        force = data.get('force', False)
        
        vps_count = get_current_vps_count(node_id)
        if not force and vps_count > 0:
            return jsonify({'success': False, 'error': f'Node has {vps_count} VPS. Use force to delete all.'}), 400
        
        if force and vps_count > 0:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('SELECT container_name FROM vps WHERE node_id = ?', (node_id,))
                for row in cur.fetchall():
                    try:
                        run_sync(execute_lxc(row[0], f"delete {row[0]} --force", node_id=node_id))
                    except:
                        pass
                    destroy_vps_disk_sync(row[0], node_id)
                
                cur.execute('DELETE FROM vps WHERE node_id = ?', (node_id,))
                conn.commit()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('DELETE FROM nodes WHERE id = ?', (node_id,))
            conn.commit()
        
        log_activity(current_user.id, 'delete_node', 'node', str(node_id))
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error deleting node {node_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/settings', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_settings():
    if request.method == 'POST':
        data = request.form

        settings = [
            'site_name', 'site_description', 'header_icon', 'favicon',
            'footer_text', 'maintenance_message',
            'cpu_threshold', 'ram_threshold',
            'default_port_quota', 'max_vps_per_user', 'session_timeout',
            'backup_retention', 'theme', 'language', 'timezone',
            'discord_client_id', 'discord_client_secret', 'discord_redirect_uri', 'discord_button_text',
            'discord_invite_text'
        ]

        for key in settings:
            set_setting(key, data.get(key, ''))

        # Join-Discord button link: only accept real http(s) URLs (blocks javascript: etc.)
        _dl = (data.get('discord_invite_link', '') or '').strip()
        set_setting('discord_invite_link', _dl if re.match(r'^https?://', _dl, re.I) else '')

        _gh = (data.get('github_url', '') or '').strip()
        set_setting('github_url', _gh if re.match(r'^https?://', _gh, re.I) else '')

        set_setting('maintenance_mode',
                    '1' if 'maintenance_mode' in data else '0')

        set_setting('registration_enabled',
                    '1' if 'registration_enabled' in data else '0')

        set_setting('backup_enabled',
                    '1' if 'backup_enabled' in data else '0')
        
        set_setting('discord_auth_enabled',
                    '1' if 'discord_auth_enabled' in data else '0')
        
        set_setting('discord_auto_register',
                    '1' if 'discord_auto_register' in data else '0')

        log_activity(current_user.id, 'update_settings', 'settings')
        create_notification(
            current_user.id,
            'success',
            'Settings Updated',
            'Panel settings have been updated.'
        )

        flash('Settings updated successfully', 'success')
        return redirect(url_for('admin_settings'))

    settings = {}
    keys = [
        'site_name', 'site_description', 'header_icon', 'favicon',
        'footer_text', 'maintenance_mode', 'maintenance_message',
        'registration_enabled', 'cpu_threshold', 'ram_threshold',
        'default_port_quota', 'max_vps_per_user', 'session_timeout',
        'backup_enabled', 'backup_retention', 'theme', 'language', 'timezone',
        'discord_auth_enabled', 'discord_client_id', 'discord_client_secret',
        'discord_redirect_uri', 'discord_auto_register', 'discord_button_text',
        'discord_invite_link', 'discord_invite_text', 'github_url'
    ]

    for key in keys:
        settings[key] = get_setting(key, '')

    return render_template(
        'admin/settings.html',
        panel_name=get_setting('site_name', 'ExpelHost Panel'),
        settings=settings
    )

# ============================================================================
# Theme manager (admin can recolour the whole panel)
# ============================================================================
THEME_FIELDS = [
    # (key, label, group)
    ('accent',    'Accent (buttons, links, highlights)', 'Brand'),
    ('accent2',   'Accent light (gradients, hover)',      'Brand'),
    ('bg',        'Page background',                      'Surfaces'),
    ('surface',   'Cards & header',                       'Surfaces'),
    ('surface2',  'Hover / secondary surface',            'Surfaces'),
    ('elevated',  'Menus, popups & modals',               'Surfaces'),
    ('text',      'Main text',                            'Text'),
    ('text2',     'Secondary text',                       'Text'),
    ('muted',     'Muted text',                           'Text'),
    ('border',    'Borders',                              'Lines'),
    ('success',   'Success',                              'Status'),
    ('warning',   'Warning',                              'Status'),
    ('danger',    'Danger',                               'Status'),
    # Glassmorphism design only: the colour behind the frosted glass
    ('glass_base', 'Backdrop base colour',                 'Glass backdrop'),
    ('glass_tl',   'Glow: top-left',                       'Glass backdrop'),
    ('glass_tr',   'Glow: top-right',                      'Glass backdrop'),
    ('glass_br',   'Glow: bottom-right',                   'Glass backdrop'),
    ('glass_bl',   'Glow: bottom-left',                    'Glass backdrop'),
]
THEME_DEFAULTS = {
    'dark': {'accent': '#FF7F00', 'accent2': '#FF9A2E', 'bg': '#0A0A0A', 'surface': '#111111', 'surface2': '#171717',
             'elevated': '#1C1C1C', 'text': '#E5E5E5', 'text2': '#B4B4B4', 'muted': '#8A8A8A', 'border': '#232323',
             'success': '#34D399', 'warning': '#FBBF24', 'danger': '#F87171',
             'glass_base': '#0B0A1F', 'glass_tl': '#6D28D9', 'glass_tr': '#2563EB', 'glass_br': '#DB2777', 'glass_bl': '#0891B2'},
    'light': {'accent': '#F26B00', 'accent2': '#FF8A2B', 'bg': '#F3F4F7', 'surface': '#FFFFFF', 'surface2': '#F0F1F5',
              'elevated': '#FFFFFF', 'text': '#14171C', 'text2': '#454B57', 'muted': '#6B717D', 'border': '#E2E5EB',
              'success': '#059669', 'warning': '#D97706', 'danger': '#DC2626',
              'glass_base': '#E8ECFF', 'glass_tl': '#A78BFA', 'glass_tr': '#93C5FD', 'glass_br': '#F9A8D4', 'glass_bl': '#67E8F9'},
}
_HEX_RE = re.compile(r'^#[0-9a-fA-F]{6}$')

def _hex_rgb(h: str) -> Tuple[int, int, int]:
    h = h.lstrip('#')
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

def _rgb_hex(r, g, b) -> str:
    return '#%02X%02X%02X' % (max(0, min(255, int(round(r)))), max(0, min(255, int(round(g)))), max(0, min(255, int(round(b)))))

def _mix_hex(a: str, b: str, t: float) -> str:
    ar, ag, ab = _hex_rgb(a); br, bg_, bb = _hex_rgb(b)
    return _rgb_hex(ar + (br - ar) * t, ag + (bg_ - ag) * t, ab + (bb - ab) * t)

def get_custom_theme() -> Dict[str, Dict[str, str]]:
    """Saved theme merged over the defaults. Always returns both modes, every key."""
    saved = {}
    try:
        saved = json.loads(get_setting('custom_theme', '') or '{}')
    except Exception:
        saved = {}
    out = {}
    for mode, defaults in THEME_DEFAULTS.items():
        vals = dict(defaults)
        src = saved.get(mode) if isinstance(saved, dict) else None
        if isinstance(src, dict):
            for k in defaults:
                v = src.get(k)
                if isinstance(v, str) and _HEX_RE.match(v):
                    vals[k] = v.upper()
        out[mode] = vals
    return out

def get_theme_version() -> str:
    try:
        raw = get_setting('custom_theme', '') or ''
    except Exception:
        raw = ''
    return hashlib.md5(raw.encode('utf-8')).hexdigest()[:10] if raw else '0'

def build_theme_css(theme: Dict[str, Dict[str, str]]) -> str:
    """CSS overriding only what differs from the built-in colours."""
    blocks = []
    for mode in ('dark', 'light'):
        v, d = theme[mode], THEME_DEFAULTS[mode]
        ch = lambda *keys: any(v[k] != d[k] for k in keys)
        decl = []
        if ch('accent', 'accent2'):
            r, g, b = _hex_rgb(v['accent'])
            tert = _mix_hex(v['accent'], '#000000', 0.14)
            decl += [f"--accent-primary:{v['accent']}", f"--accent-info:{v['accent']}", f"--input-focus:{v['accent']}",
                     f"--accent-rgb:{r},{g},{b}", f"--accent-secondary:{v['accent2']}",
                     f"--accent-primary-hover:{v['accent2']}", f"--accent-tertiary:{tert}",
                     f"--ring:rgba({r},{g},{b},.38)", f"--glow-primary:0 10px 30px -12px rgba({r},{g},{b},.85)"]
        if ch('bg'):
            r, g, b = _hex_rgb(v['bg'])
            decl += [f"--bg-primary:{v['bg']}", f"--bg-sidebar:{v['bg']}", f"--bg-inset:{v['bg']}", f"--bg-rgb:{r},{g},{b}"]
        if ch('surface'):
            r, g, b = _hex_rgb(v['surface'])
            decl += [f"--bg-secondary:{v['surface']}", f"--bg-card:{v['surface']}", f"--bg-header:{v['surface']}",
                     f"--card-bg:{v['surface']}", f"--input-bg:{v['surface']}", f"--surface-rgb:{r},{g},{b}"]
        if ch('surface2'):
            decl += [f"--bg-tertiary:{v['surface2']}", f"--bg-card-hover:{v['surface2']}", f"--hover-bg:{v['surface2']}"]
        if ch('elevated'):
            r, g, b = _hex_rgb(v['elevated'])
            decl += [f"--bg-elevated:{v['elevated']}", f"--active-bg:{v['elevated']}", f"--elevated-rgb:{r},{g},{b}"]
        if ch('text'):
            decl += [f"--text-primary:{v['text']}"]
        if ch('text2'):
            decl += [f"--text-secondary:{v['text2']}"]
        if ch('muted'):
            decl += [f"--text-muted:{v['muted']}", f"--input-placeholder:{v['muted']}"]
        if ch('border'):
            decl += [f"--border-color:{v['border']}", f"--card-border:{v['border']}", f"--input-border:{v['border']}"]
        if ch('border', 'text'):
            decl += [f"--border-light:{_mix_hex(v['border'], v['text'], 0.10)}"]
        for k in ('success', 'warning', 'danger'):
            if ch(k):
                decl += [f"--accent-{k}:{v[k]}", f"--accent-{k}-hover:{_mix_hex(v[k], '#000000', 0.12)}"]
        # Glassmorphism backdrop: doubled :root + design attribute so it beats designs.css
        gdecl = []
        if ch('glass_base'):
            gdecl += [f"--bg-primary:{v['glass_base']}"]
        for gk, gv in (('glass_tl', '--gm-c1'), ('glass_tr', '--gm-c4'), ('glass_br', '--gm-c2'), ('glass_bl', '--gm-c3')):
            if ch(gk):
                gdecl += [f"{gv}:{v[gk]}"]
        if gdecl:
            blocks.append(f'html:root:root[data-design="glassmorphism"][data-theme="{mode}"]{{{";".join(gdecl)}}}')
        if not decl:
            continue
        sel = f'html:root[data-theme="{mode}"]'
        blocks.append(f"{sel}{{{';'.join(decl)}}}")
        extra = []
        if ch('text'):
            extra.append(f'{sel} h1,{sel} h2,{sel} h3,{sel} h4,{sel} h5{{color:var(--text-primary)}}')
        if ch('bg'):
            extra.append(f'{sel} body{{background:var(--bg-primary)}}')
        if ch('accent'):
            extra.append(f'{sel} ::selection{{background:rgba(var(--accent-rgb),.32)}}')
        blocks += extra
    return '/* custom theme */\n' + '\n'.join(blocks) + '\n'

@app.route('/theme.css')
def theme_css():
    css = build_theme_css(get_custom_theme())
    resp = Response(css, mimetype='text/css')
    resp.headers['Cache-Control'] = 'public, max-age=31536000, immutable' if request.args.get('v') else 'no-cache'
    return resp

def _clean_theme_payload(data: Any) -> Dict[str, Dict[str, str]]:
    cur = get_custom_theme()
    if not isinstance(data, dict):
        return cur
    for mode in ('dark', 'light'):
        src = data.get(mode)
        if isinstance(src, dict):
            for k in THEME_DEFAULTS[mode]:
                v = src.get(k)
                if isinstance(v, str) and _HEX_RE.match(v.strip()):
                    cur[mode][k] = v.strip().upper()
    return cur


# ---------------------------------------------------------------------------
# Design styles (admin picks ONE look for the entire panel, all users follow)
# ---------------------------------------------------------------------------
UI_DESIGNS = {
    'default': {'label': 'Aurora (default)', 'desc': 'The original black & orange panel.'},
    'minimal': {'label': 'Minimalism', 'desc': 'Flat, quiet and typographic. Hairlines instead of shadows.'},
    'glass':   {'label': 'Liquid Glass', 'desc': 'Translucent, refractive surfaces with a living backdrop (iOS 26 style).'},
    'studio':  {'label': 'Studio', 'desc': 'Calm, solid and tactile. Real depth instead of glow, one accent, springs with no bounce. Built to be read.'},
    'glassmorphism': {'label': 'Glassmorphism', 'desc': 'Classic frosted glass: blurred translucent panels floating over a vivid colour-gradient backdrop.'},
}

_REMOVED_UI_DESIGNS = ('aurora_glass', 'framer_spring', 'quiet_ops', 'bold_cards', 'photo_glass')

def get_ui_design() -> str:
    try:
        v = (get_setting('ui_design', 'default') or 'default').strip().lower()
    except Exception:
        v = 'default'
    if v in _REMOVED_UI_DESIGNS:      # these five were removed: fall back to the default look and drop their Main Pages look
        try:
            set_setting('ui_design', 'default'); set_setting('main_design', ''); set_setting('ui_design_rev', secrets.token_hex(4))
        except Exception:
            pass
        return 'default'
    return v if v in UI_DESIGNS else 'default'

def get_ui_design_version() -> str:
    """Changes every time the admin saves a design so open tabs know to switch."""
    try:
        raw = get_setting('ui_design_rev', '') or ''
    except Exception:
        raw = ''
    try:
        mraw = get_setting('main_design', '') or ''
    except Exception:
        mraw = ''
    return hashlib.md5(f"{get_ui_design()}|{raw}|{mraw}".encode('utf-8')).hexdigest()[:10]

@app.route('/api/design')
def design_state():
    """Tiny public endpoint every page polls so a design change reaches all users live."""
    resp = jsonify({'design': get_ui_design(), 'version': get_ui_design_version()})
    resp.headers['Cache-Control'] = 'no-store'
    return resp

@app.route('/admin/theme/design', methods=['POST'])
@login_required
@admin_required
def admin_theme_design():
    data = request.get_json(silent=True) or {}
    design = str(data.get('design', '')).strip().lower()
    if design not in UI_DESIGNS:
        return jsonify({'success': False, 'error': 'Unknown design'}), 400
    set_setting('ui_design', design)
    set_setting('ui_design_rev', secrets.token_hex(4))
    log_activity(current_user.id, 'update_design', 'settings', None, {'design': design})
    return jsonify({'success': True, 'design': design, 'version': get_ui_design_version()})

@app.route('/admin/theme')
@login_required
@admin_required
def admin_theme():
    return render_template('admin/theme.html',
                           panel_name=get_setting('site_name', 'ExpelHost Panel'),
                           theme=get_custom_theme(), defaults=THEME_DEFAULTS, fields=THEME_FIELDS,
                           designs=UI_DESIGNS, current_design=get_ui_design(),
                           main_raw=get_main_design(), main_defaults=MAIN_DEFAULTS)

@app.route('/admin/login-page')
@login_required
@admin_required
def admin_login_page():
    """Dedicated section for the Sign in / Register page editor."""
    return render_template('admin/login_page.html',
                           panel_name=get_setting('site_name', 'ExpelHost Panel'),
                           login_raw=get_login_design(), login_defaults=LOGIN_DEFAULTS)

@app.route('/admin/theme/preview', methods=['POST'])
@login_required
@admin_required
def admin_theme_preview():
    theme = _clean_theme_payload(request.get_json(silent=True))
    return jsonify({'success': True, 'css': build_theme_css(theme)})

@app.route('/admin/theme/save', methods=['POST'])
@login_required
@admin_required
def admin_theme_save():
    theme = _clean_theme_payload(request.get_json(silent=True))
    changed = any(theme[m][k] != THEME_DEFAULTS[m][k] for m in theme for k in THEME_DEFAULTS[m])
    set_setting('custom_theme', json.dumps(theme) if changed else '')
    log_activity(current_user.id, 'update_theme', 'settings')
    return jsonify({'success': True, 'version': get_theme_version(), 'theme': get_custom_theme()})

@app.route('/admin/theme/reset', methods=['POST'])
@login_required
@admin_required
def admin_theme_reset():
    set_setting('custom_theme', '')
    log_activity(current_user.id, 'reset_theme', 'settings')
    return jsonify({'success': True, 'version': get_theme_version(), 'theme': get_custom_theme()})

# ---------------------------------------------------------------------------
# Login page design (Admin -> Theme -> Login page)
# One JSON blob in the `login_design` setting. Every field defaults to "auto",
# which means "keep the current look", so nothing changes until an admin edits it.
# ---------------------------------------------------------------------------
LOGIN_DEFAULTS = {
    'layout': 'center', 'split': 46, 'header': 'show', 'hide_footer': False, 'anim': 'auto',
    # motion (Framer Motion) - same engine as the landing page
    'm_type': 'spring', 'm_stiffness': 220, 'm_damping': 24, 'm_duration': 700, 'm_distance': 28,
    'm_stagger': 60, 'm_text': 'none', 'm_magnetic': False,
    'bg_type': 'auto', 'bg_color': '', 'bg_color2': '', 'bg_angle': 135,
    'bg_image': '', 'bg_dim': 40, 'bg_blur': 0, 'brand_ink': '',
    'card_style': 'auto', 'card_color': '', 'card_width': 420, 'card_radius': -1, 'align': 'center',
    'logo': 'auto', 'logo_size': 52, 'input_style': 'auto', 'button_style': 'auto', 'ctrl_radius': -1,
    'login_title': '', 'login_sub': '', 'register_title': '', 'register_sub': '',
    'button_text': '', 'register_button_text': '',
    'brand_title': '', 'brand_text': '', 'brand_p1': '', 'brand_p2': '', 'brand_p3': '', 'footer_text': '',
}
_LOGIN_ENUMS = {
    'layout': ('center', 'split-left', 'split-right'),
    'header': ('show', 'overlay', 'hide'),
    'anim': ('auto', 'none', 'fade', 'rise', 'pop', 'zoom', 'blur', 'slide', 'flip'),
    'm_type': ('spring', 'tween'),
    'm_text': ('none', 'words'),
    'bg_type': ('auto', 'solid', 'grid', 'dots', 'gradient', 'image'),
    'card_style': ('auto', 'solid', 'outline', 'glass', 'flat'),
    'align': ('center', 'left'),
    'logo': ('auto', 'plain', 'circle', 'hide'),
    'input_style': ('auto', 'outline', 'filled', 'underline'),
    'button_style': ('auto', 'solid', 'soft', 'pill'),
}
_LOGIN_NUMS = {
    'split': (35, 60), 'bg_angle': (0, 360), 'bg_dim': (0, 90), 'bg_blur': (0, 24),
    'card_width': (340, 560), 'card_radius': (-1, 40), 'logo_size': (32, 96), 'ctrl_radius': (-1, 24),
    'm_stiffness': (40, 700), 'm_damping': (5, 70), 'm_duration': (200, 1800), 'm_distance': (0, 140), 'm_stagger': (0, 320),
}
_LOGIN_HEX = ('bg_color', 'bg_color2', 'brand_ink', 'card_color')
_LOGIN_BOOL = ('hide_footer', 'm_magnetic')
_LOGIN_TEXT = {
    'login_title': 80, 'login_sub': 160, 'register_title': 80, 'register_sub': 160,
    'button_text': 32, 'register_button_text': 32,
    'brand_title': 80, 'brand_text': 220, 'brand_p1': 80, 'brand_p2': 80, 'brand_p3': 80, 'footer_text': 140,
}

def _clean_login_url(u: Any) -> str:
    if not isinstance(u, str):
        return ''
    u = u.strip()
    if not u or len(u) > 500 or re.search(r'[\s"\'()<>\\;{}]', u) or '..' in u:
        return ''
    if u.startswith('/static/') or u.startswith('https://') or u.startswith('http://'):
        return u
    return ''

def _clean_login_cfg(data: Any) -> Dict[str, Any]:
    out = dict(LOGIN_DEFAULTS)
    if not isinstance(data, dict):
        return out
    for k, allowed in _LOGIN_ENUMS.items():
        v = data.get(k)
        if isinstance(v, str) and v in allowed:
            out[k] = v
    for k, (lo, hi) in _LOGIN_NUMS.items():
        try:
            n = int(round(float(data.get(k))))
        except (TypeError, ValueError):
            continue
        out[k] = max(lo, min(hi, n))
    for k in _LOGIN_HEX:
        v = data.get(k)
        if isinstance(v, str) and _HEX_RE.match(v.strip()):
            out[k] = v.strip().upper()
    for k in _LOGIN_BOOL:
        v = data.get(k)
        out[k] = v is True or v in (1, '1', 'true')
    for k, mx in _LOGIN_TEXT.items():
        v = data.get(k)
        if isinstance(v, str):
            out[k] = re.sub(r'[\x00-\x1f\x7f]+', ' ', v).strip()[:mx]
    out['bg_image'] = _clean_login_url(data.get('bg_image'))
    return out

def get_login_design() -> Dict[str, Any]:
    try:
        saved = json.loads(get_setting('login_design', '') or '{}')
    except Exception:
        saved = {}
    return _clean_login_cfg(saved)

def get_login_design_version() -> str:
    try:
        raw = get_setting('login_design', '') or ''
    except Exception:
        raw = ''
    return hashlib.md5(raw.encode('utf-8')).hexdigest()[:10] if raw else '0'

def get_login_view(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """What the login / register templates read: texts with {panel} filled in."""
    c = dict(cfg if cfg is not None else get_login_design())
    name = get_setting('site_name', 'ExpelHost Panel') or ''
    for k in _LOGIN_TEXT:
        c[k] = (c.get(k) or '').replace('{panel}', name)
    c['brand_points'] = [p for p in (c['brand_p1'], c['brand_p2'], c['brand_p3']) if p]
    c['motion'] = {k: c[k] for k in ('m_type', 'm_stiffness', 'm_damping', 'm_duration', 'm_distance',
                                     'm_stagger', 'm_text', 'm_magnetic')}
    c['motion_on'] = c['anim'] not in ('auto', 'none') or c['m_text'] == 'words'
    return c

def _login_bg_decl(c: Dict[str, Any]) -> str:
    t = c['bg_type']
    if t == 'image' and not c['bg_image']:
        t = 'gradient'
    base = c['bg_color'] or 'var(--bg-primary)'
    if t == 'solid':
        return f'background:{base}'
    if t == 'grid':
        return (f'background-color:{base};background-image:linear-gradient(to right,rgba(128,128,128,.16) 1px,transparent 1px),'
                'linear-gradient(to bottom,rgba(128,128,128,.16) 1px,transparent 1px);background-size:56px 56px')
    if t == 'dots':
        return (f'background-color:{base};background-image:radial-gradient(rgba(128,128,128,.34) 1.3px,transparent 1.6px);'
                'background-size:22px 22px')
    if t == 'gradient':
        a = c['bg_color'] or 'var(--bg-primary)'
        b = c['bg_color2'] or 'rgba(var(--accent-rgb),.42)'
        return f"background:linear-gradient({c['bg_angle']}deg,{a},{b})"
    return f'background-color:{base}'          # image: the picture itself lives on ::before

def build_login_css(c: Dict[str, Any]) -> str:
    """CSS for the sign in / register pages. Empty when everything is 'auto'."""
    W = 'html body .auth-wrap'
    rules: List[str] = []
    def add(sel: str, decl: str):
        rules.append(f'{sel}{{{decl}}}')

    split = c['layout'].startswith('split')
    bg_on = c['bg_type'] != 'auto'
    hdr = c['header']
    is_image = c['bg_type'] == 'image' and bool(c['bg_image'])

    # ---- page frame -------------------------------------------------
    if split or bg_on or hdr != 'show':
        add('html body.auth-page .content', 'padding:0!important')
        add('html body.auth-page .main-content', 'position:relative')
        add(W, 'min-height:%s!important' % ('100vh' if hdr != 'show' else 'calc(100vh - var(--header-height,60px) - 24px)'))
        if not split:
            add(W, 'padding:2.5rem 1rem')
    if hdr == 'hide':
        add('html body.auth-page .header', 'display:none!important')
    elif hdr == 'overlay':
        add('html body.auth-page .header', 'position:absolute!important;top:0;left:0;right:0;margin:0!important;z-index:5;'
            'background:transparent!important;border:0!important;box-shadow:none!important;'
            '-webkit-backdrop-filter:none!important;backdrop-filter:none!important')
    if c['hide_footer']:
        add('html body.auth-page .footer', 'display:none!important')

    # ---- layout ------------------------------------------------------
    if split:
        left = c['layout'] == 'split-left'
        add(W + '[data-layout^="split"]', f"display:grid!important;padding:0!important;--auth-split:{c['split']}%;"
            + ('grid-template-columns:var(--auth-split) minmax(0,1fr)' if left else 'grid-template-columns:minmax(0,1fr) var(--auth-split)'))
        add(W + ' .auth-brand', f"grid-column:{1 if left else 2};grid-row:1;display:flex;flex-direction:column;justify-content:center;"
            'padding:clamp(2rem,5vw,4.5rem);position:relative;overflow:hidden;isolation:isolate;'
            + ('background:var(--bg-secondary);' if not bg_on else '')
            + ('border-inline-end:1px solid var(--border-color);' if (left and not bg_on) else '')
            + ('border-inline-start:1px solid var(--border-color);' if (not left and not bg_on) else ''))
        add(W + ' .auth-card', f"grid-column:{2 if left else 1};grid-row:1;align-self:center;justify-self:center;margin:2.5rem 1.25rem")
        add(W + ' .auth-brand-in', 'position:relative;z-index:1;max-width:460px')
        add(W + ' .auth-brand-logo', 'width:56px;height:56px;border-radius:14px;display:grid;place-items:center;'
            'background:rgba(128,128,128,.14);border:1px solid rgba(128,128,128,.28);margin-bottom:1.5rem')
        add(W + ' .auth-brand-logo img', 'height:30px')
        add(W + ' .auth-brand-title', 'font-family:var(--font-display);font-size:clamp(1.8rem,3vw,2.6rem);font-weight:700;'
            'letter-spacing:-.03em;line-height:1.1;margin:0 0 .9rem;color:inherit')
        add(W + ' .auth-brand-text', 'font-size:1.02rem;line-height:1.6;opacity:.8;margin:0 0 1.5rem')
        add(W + ' .auth-brand-points', 'list-style:none;padding:0;margin:0;display:grid;gap:.7rem')
        add(W + ' .auth-brand-points li', 'display:flex;gap:.65rem;align-items:center;font-size:.95rem')
        add(W + ' .auth-brand-points i', 'width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-size:.62rem;'
            'flex:none;background:rgba(var(--accent-rgb),.2);color:var(--accent-primary)')
        ink = c['brand_ink'] or ('#FFFFFF' if is_image else '')
        if ink:
            add(W + ' .auth-brand', f'color:{ink}')
        add(W + ' .auth-grid-bg,' + W + ' .auth-orb', 'display:none')
        rules.append('@media (max-width:860px){' + W + '[data-layout^="split"]{display:flex!important}'
                     + W + ' .auth-brand{display:none}' + W + ' .auth-card{margin:1.5rem 0}}')

    # ---- background (page for centered, brand panel for split) ----------
    if bg_on:
        T = (W + ' .auth-brand') if split else (W + '[data-layout="center"]')
        add(T, _login_bg_decl(c))
        add(T, 'position:relative;overflow:hidden;isolation:isolate')
        if is_image:
            blur = c['bg_blur']; dim = c['bg_dim'] / 100.0
            add(T + '::before', f'content:"";position:absolute;inset:-{blur * 2}px;z-index:0;pointer-events:none;'
                f'background:linear-gradient(rgba(0,0,0,{dim:.2f}),rgba(0,0,0,{dim:.2f})),url("{c["bg_image"]}") center/cover no-repeat;'
                f'filter:blur({blur}px)')
        if not split:
            add(W + ' .auth-grid-bg,' + W + ' .auth-orb', 'display:none')
            add(W + ' .auth-card', 'position:relative;z-index:1')

    # ---- card ----------------------------------------------------------------
    st = c['card_style']
    if st == 'solid':
        add(W + ' .auth-card', 'background:var(--bg-card)!important;border:1px solid var(--border-color)!important;'
            'box-shadow:0 1px 2px rgba(0,0,0,.25),0 28px 56px -28px rgba(0,0,0,.55)!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important')
    elif st == 'outline':
        add(W + ' .auth-card', 'background:transparent!important;border:1px solid var(--border-light)!important;box-shadow:none!important;'
            'backdrop-filter:none!important;-webkit-backdrop-filter:none!important')
    elif st == 'glass':
        add(W + ' .auth-card', 'background:rgba(var(--surface-rgb,24,24,27),.55)!important;border:1px solid rgba(255,255,255,.16)!important;'
            'box-shadow:0 24px 60px -24px rgba(0,0,0,.6)!important;-webkit-backdrop-filter:blur(18px) saturate(140%)!important;backdrop-filter:blur(18px) saturate(140%)!important')
    elif st == 'flat':
        add(W + ' .auth-card', 'background:transparent!important;border:0!important;box-shadow:none!important;'
            'backdrop-filter:none!important;-webkit-backdrop-filter:none!important')
    if st != 'auto':
        add(W + ' .auth-card::before', 'display:none!important')
    if c['card_color']:
        add(W + ' .auth-card', f"background:{c['card_color']}!important")
    if c['card_width'] != LOGIN_DEFAULTS['card_width']:
        add(W + ' .auth-card', f"max-width:{c['card_width']}px")
    if c['card_radius'] >= 0:
        add(W + ' .auth-card', f"border-radius:{c['card_radius']}px!important")
    if c['anim'] != 'auto':
        add(W + ' .auth-card', 'animation:none!important')
    if c['align'] == 'left':
        add(W + ' .auth-title,' + W + ' .auth-sub', 'text-align:left')
        add(W + ' .auth-logo', 'margin-left:0;margin-right:0')

    # ---- logo -------------------------------------------------------------------
    if c['logo'] == 'hide':
        add(W + ' .auth-logo', 'display:none')
    else:
        if c['logo'] == 'circle':
            add(W + ' .auth-logo', 'border-radius:50%')
        elif c['logo'] == 'plain':
            add(W + ' .auth-logo', 'background:none;border:0')
        if c['logo_size'] != LOGIN_DEFAULTS['logo_size']:
            s = c['logo_size']
            add(W + ' .auth-logo', f'width:{s}px;height:{s}px')
            add(W + ' .auth-logo img', f'height:{round(s * 0.54)}px')

    # ---- controls ----------------------------------------------------------------
    fi = c['input_style']
    if fi == 'outline':
        add(W + ' .form-control', 'background:transparent!important;box-shadow:none!important')
    elif fi == 'filled':
        add(W + ' .form-control', 'background:var(--bg-tertiary)!important;border-color:transparent!important;box-shadow:none!important')
    elif fi == 'underline':
        add(W + ' .form-control', 'background:transparent!important;border:0!important;border-bottom:1.5px solid var(--input-border)!important;'
            'border-radius:0!important;box-shadow:none!important')
        add(W + ' .form-control:focus', 'border-bottom-color:var(--accent-primary)!important;box-shadow:none!important')
    if c['ctrl_radius'] >= 0 and fi != 'underline':
        add(W + ' .form-control,' + W + ' .btn', f"border-radius:{c['ctrl_radius']}px!important")
    bs = c['button_style']
    if bs == 'pill':
        add(W + ' .btn', 'border-radius:999px!important')
    elif bs == 'solid':
        add(W + ' .btn-primary', 'background:var(--accent-primary)!important;background-image:none!important;box-shadow:none!important;color:#fff!important')
    elif bs == 'soft':
        add(W + ' .btn-primary', 'background:rgba(var(--accent-rgb),.14)!important;background-image:none!important;color:var(--accent-primary)!important;'
            'border:1px solid rgba(var(--accent-rgb),.38)!important;box-shadow:none!important')

    # ---- motion support styles (login-motion.js reveals these) ------------------------
    if c['anim'] not in ('auto', 'none'):
        rules.append('html.au-motion .auth-card>*:not(form):not(.au-in),html.au-motion .auth-card form>*:not(.au-in){opacity:0}')
    elif c['anim'] == 'auto' and c['m_text'] == 'words':
        rules.append('html.au-motion .auth-card .auth-title:not(.au-in){visibility:hidden}')
    if c['m_text'] == 'words':
        rules.append('.au-w{display:inline-block;overflow:hidden;vertical-align:top;padding-bottom:.14em;margin-bottom:-.14em}'
                     '.au-wi{display:inline-block;will-change:transform}')

    if c['footer_text']:
        add(W + ' .auth-note', 'margin:1.1rem 0 0;text-align:center;font-size:.78rem;color:var(--text-muted)')

    return ('/* login page design */\n' + '\n'.join(rules) + '\n') if rules else ''

@app.route('/login-design.css')
def login_design_css():
    resp = Response(build_login_css(get_login_design()), mimetype='text/css')
    resp.headers['Cache-Control'] = 'public, max-age=31536000, immutable' if request.args.get('v') else 'no-cache'
    return resp

@app.route('/admin/theme/login/save', methods=['POST'])
@login_required
@admin_required
def admin_theme_login_save():
    cfg = _clean_login_cfg(request.get_json(silent=True))
    set_setting('login_design', json.dumps(cfg) if cfg != LOGIN_DEFAULTS else '')
    log_activity(current_user.id, 'update_login_design', 'settings')
    return jsonify({'success': True, 'version': get_login_design_version(), 'cfg': get_login_design()})

@app.route('/admin/theme/login/reset', methods=['POST'])
@login_required
@admin_required
def admin_theme_login_reset():
    set_setting('login_design', '')
    log_activity(current_user.id, 'reset_login_design', 'settings')
    return jsonify({'success': True, 'version': get_login_design_version(), 'cfg': dict(LOGIN_DEFAULTS)})

@app.route('/admin/theme/login/upload-bg', methods=['POST'])
@login_required
@admin_required
def admin_theme_login_upload_bg():
    file = request.files.get('image')
    if not file or not file.filename:
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if ext not in ('png', 'jpg', 'jpeg', 'webp', 'gif'):
        return jsonify({'success': False, 'error': 'Use a PNG, JPG, WEBP or GIF image'}), 400
    filename = secure_filename(f'login_bg_{int(time.time())}.{ext}')
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'settings', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    if PIL_AVAILABLE and Image and ext != 'gif':      # keep the page light: max 2200px wide
        try:
            img = Image.open(filepath)
            img.thumbnail((2200, 2200), Image.Resampling.LANCZOS)
            if ext in ('jpg', 'jpeg') and img.mode != 'RGB':
                img = img.convert('RGB')
            img.save(filepath, optimize=True, quality=82)
        except Exception:
            pass
    return jsonify({'success': True, 'path': f'/static/uploads/settings/{filename}'})

@app.route('/admin/theme/login/preview', methods=['POST'])
@login_required
@admin_required
def admin_theme_login_preview():
    """Renders the REAL sign in / register page from a draft config, as a logged-out visitor would see it."""
    from flask_login import AnonymousUserMixin
    try:
        raw = json.loads(request.form.get('cfg', '') or '{}')
    except Exception:
        raw = {}
    cfg = _clean_login_cfg(raw)
    view = get_login_view(cfg)
    page = 'register.html' if request.form.get('page') == 'register' else 'login.html'
    return render_template(page, panel_name=get_setting('site_name', 'ExpelHost Panel'),
                           current_user=AnonymousUserMixin(), login_cfg=lambda: view,
                           auth_preview_css=build_login_css(cfg))

# ---------------------------------------------------------------------------
# Landing page design (Admin -> Landing Page)
# One JSON blob in the `landing_design` setting. "auto" / "" means "keep the
# current look", so nothing changes until an admin edits and publishes it.
# ---------------------------------------------------------------------------
_LP_FEATURES = [
    ('bolt', 'Lightning Fast Deploy', 'Instant container provisioning with LXC technology. Create and manage VPS in seconds, not minutes.'),
    ('shield-halved', 'Secure by Default', 'Isolated containers with enforced resource limits, suspension controls, and whitelist protection.'),
    ('network-wired', 'Port Forwarding', 'Simple TCP/UDP port mapping with quota tracking and one-click proxy device management.'),
    ('chart-line', 'Real-time Monitoring', 'Live CPU, RAM, and disk graphs with instant push notifications and activity logs.'),
    ('terminal', 'Web Console & SSHX', 'Browser-based terminal plus one-click SSHX sessions — share a live shell link in seconds.'),
    ('cloud', 'Multi-Node Cluster', 'Distribute containers across multiple hosts with centralized management and health checks.'),
]
_LP_STEPS = [
    ('Create your account', 'Sign up with email or Discord. Your dashboard is ready the moment you land.'),
    ('Deploy a VPS', 'Pick an OS image, set CPU, RAM, and disk — the container boots in under 30 seconds.'),
    ('Connect & ship', 'Use the web console, generate an SSHX link, or map ports — all from the control panel.'),
]
_LP_STATS = [('99.9*%*', 'Uptime Target'), ('<30*s*', 'Deploy Time'), ('KVM*/*LXC', 'Container Native'), ('Multi*-Node*', 'Cluster Ready')]

LANDING_DEFAULTS: Dict[str, Any] = {
    # layout & sections
    'hero_layout': 'center', 'hero_scale': 100, 'hero_pad': 6, 'max_width': 0, 'feature_cols': 3,
    'header': 'show', 'hide_footer': False,
    'show_badge': True, 'show_stats': True, 'show_showcase': True, 'show_features': True, 'show_how': True, 'show_cta': True,
    # background
    'bg_type': 'auto', 'bg_color': '', 'bg_color2': '', 'bg_angle': 135, 'bg_image': '', 'bg_dim': 45, 'bg_blur': 0,
    # look
    'accent': '', 'ink': '', 'gradient_text': 'auto', 'card_style': 'auto', 'card_color': '', 'card_radius': -1,
    'btn_style': 'auto', 'ctrl_radius': -1,
    # motion (Framer Motion)
    'm_preset': 'auto', 'm_type': 'spring', 'm_stiffness': 220, 'm_damping': 24, 'm_duration': 700, 'm_distance': 28,
    'm_stagger': 70, 'm_once': True, 'm_hero_text': 'none', 'm_hover': 'auto',
    'm_parallax': False, 'm_progress': False, 'm_spotlight': False, 'm_magnetic': False, 'm_countup': False,
    # texts (empty = built-in text)
    'badge': '', 'h1_a': '', 'h1_b': '', 'sub': '', 'btn1': '', 'btn2': '',
    'feat_eyebrow': '', 'feat_a': '', 'feat_b': '', 'feat_sub': '',
    'how_eyebrow': '', 'how_a': '', 'how_b': '',
    'cta_title': '', 'cta_text': '', 'cta_btn1': '', 'cta_btn2': '',
}
for _i, (_ic, _t, _d) in enumerate(_LP_FEATURES, 1):
    LANDING_DEFAULTS.update({f'f{_i}_icon': '', f'f{_i}_title': '', f'f{_i}_text': ''})
for _i in range(1, 4):
    LANDING_DEFAULTS.update({f's{_i}_title': '', f's{_i}_text': ''})
for _i in range(1, 5):
    LANDING_DEFAULTS.update({f'st{_i}_val': '', f'st{_i}_label': ''})

_LANDING_ENUMS = {
    'hero_layout': ('center', 'left', 'split'),
    'header': ('show', 'overlay', 'hide'),
    'bg_type': ('auto', 'solid', 'grid', 'dots', 'gradient', 'aurora', 'image'),
    'gradient_text': ('auto', 'on', 'off'),
    'card_style': ('auto', 'solid', 'outline', 'glass', 'flat'),
    'btn_style': ('auto', 'solid', 'soft', 'pill', 'outline'),
    'm_preset': ('auto', 'none', 'fade', 'rise', 'pop', 'zoom', 'blur', 'slide', 'flip'),
    'm_type': ('spring', 'tween'),
    'm_hero_text': ('none', 'words'),
    'm_hover': ('auto', 'none', 'lift', 'scale', 'tilt', 'glow'),
}
_LANDING_NUMS = {
    'hero_scale': (70, 140), 'hero_pad': (2, 11), 'max_width': (0, 1440), 'feature_cols': (2, 4),
    'bg_angle': (0, 360), 'bg_dim': (0, 90), 'bg_blur': (0, 24), 'card_radius': (-1, 40), 'ctrl_radius': (-1, 32),
    'm_stiffness': (40, 700), 'm_damping': (5, 70), 'm_duration': (200, 1800), 'm_distance': (0, 140), 'm_stagger': (0, 320),
}
_LANDING_HEX = ('bg_color', 'bg_color2', 'accent', 'ink', 'card_color')
_LANDING_BOOL_DEFAULT_TRUE = ('show_badge', 'show_stats', 'show_showcase', 'show_features', 'show_how', 'show_cta', 'm_once')
_LANDING_BOOL = ('hide_footer', 'm_parallax', 'm_progress', 'm_spotlight', 'm_magnetic', 'm_countup')
_LANDING_TEXT: Dict[str, int] = {
    'badge': 80, 'h1_a': 60, 'h1_b': 60, 'sub': 300, 'btn1': 32, 'btn2': 32,
    'feat_eyebrow': 40, 'feat_a': 80, 'feat_b': 60, 'feat_sub': 220,
    'how_eyebrow': 40, 'how_a': 80, 'how_b': 60,
    'cta_title': 80, 'cta_text': 220, 'cta_btn1': 32, 'cta_btn2': 32,
}
for _i in range(1, 7):
    _LANDING_TEXT.update({f'f{_i}_title': 60, f'f{_i}_text': 200})
for _i in range(1, 4):
    _LANDING_TEXT.update({f's{_i}_title': 60, f's{_i}_text': 200})
for _i in range(1, 5):
    _LANDING_TEXT.update({f'st{_i}_val': 24, f'st{_i}_label': 40})
_LANDING_ICONS = tuple(f'f{i}_icon' for i in range(1, 7))
_LP_ICON_RE = re.compile(r'^[a-z][a-z0-9-]{1,32}$')

def _clean_landing_cfg(data: Any) -> Dict[str, Any]:
    out = dict(LANDING_DEFAULTS)
    if not isinstance(data, dict):
        return out
    for k, allowed in _LANDING_ENUMS.items():
        v = data.get(k)
        if isinstance(v, str) and v in allowed:
            out[k] = v
    for k, (lo, hi) in _LANDING_NUMS.items():
        try:
            n = int(round(float(data.get(k))))
        except (TypeError, ValueError):
            continue
        out[k] = max(lo, min(hi, n))
    for k in _LANDING_HEX:
        v = data.get(k)
        if isinstance(v, str) and _HEX_RE.match(v.strip()):
            out[k] = v.strip().upper()
    for k in _LANDING_BOOL_DEFAULT_TRUE:
        if k in data:
            out[k] = data.get(k) is True or data.get(k) in (1, '1', 'true')
    for k in _LANDING_BOOL:
        v = data.get(k)
        out[k] = v is True or v in (1, '1', 'true')
    for k, mx in _LANDING_TEXT.items():
        v = data.get(k)
        if isinstance(v, str):
            out[k] = re.sub(r'[\x00-\x1f\x7f]+', ' ', v).strip()[:mx]
    for k in _LANDING_ICONS:
        v = data.get(k)
        if isinstance(v, str):
            v = v.strip().lower().replace('fa-', '', 1) if v.strip().lower().startswith('fa-') else v.strip().lower()
            out[k] = v if _LP_ICON_RE.match(v) else ''
    out['bg_image'] = _clean_login_url(data.get('bg_image'))
    return out

def get_landing_design() -> Dict[str, Any]:
    try:
        saved = json.loads(get_setting('landing_design', '') or '{}')
    except Exception:
        saved = {}
    return _clean_landing_cfg(saved)

def _lp_rgb(h: str) -> Tuple[int, int, int]:
    return int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16)

def _lp_mix(h: str, other: Tuple[int, int, int], t: float) -> str:
    r, g, b = _lp_rgb(h)
    return '#%02X%02X%02X' % (round(r + (other[0] - r) * t), round(g + (other[1] - g) * t), round(b + (other[2] - b) * t))

def get_landing_view(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """What index.html reads: every text filled (custom or built-in) and {panel} replaced."""
    from markupsafe import Markup, escape
    c = dict(cfg if cfg is not None else get_landing_design())
    name = get_setting('site_name', 'ExpelHost Panel') or ''
    def T(k: str, default: str) -> str:
        return (c.get(k) or default).replace('{panel}', name)
    v = dict(c)
    v['badge'] = T('badge', 'LXC-Powered Cloud Infrastructure')
    v['h1_a'] = T('h1_a', 'Deploy VPS at')
    v['h1_b'] = T('h1_b', 'warp speed')
    v['sub'] = T('sub', 'Spin up isolated LXC containers in seconds. Real-time monitoring, port forwarding, multi-node clustering, and a full web console — everything you need to run production workloads.')
    v['btn1'] = T('btn1', 'Get Started Free')
    v['btn2'] = T('btn2', 'Sign In')
    v['feat_eyebrow'] = T('feat_eyebrow', 'Features')
    v['feat_a'] = T('feat_a', 'Everything you need to')
    v['feat_b'] = T('feat_b', 'run servers')
    v['feat_sub'] = T('feat_sub', 'A complete control plane for LXC containers — from one-click deployment to live resource graphs.')
    v['how_eyebrow'] = T('how_eyebrow', 'How it works')
    v['how_a'] = T('how_a', 'Up and running in')
    v['how_b'] = T('how_b', 'three steps')
    v['cta_title'] = T('cta_title', 'Ready to launch?')
    v['cta_text'] = T('cta_text', 'Join thousands of developers managing their infrastructure with {panel}.')
    v['cta_btn1'] = T('cta_btn1', 'Create Free Account')
    v['cta_btn2'] = T('cta_btn2', 'Sign In')
    v['features'] = [{'icon': c.get(f'f{i}_icon') or d[0], 'title': T(f'f{i}_title', d[1]), 'text': T(f'f{i}_text', d[2])}
                     for i, d in enumerate(_LP_FEATURES, 1)]
    v['steps'] = [{'title': T(f's{i}_title', d[0]), 'text': T(f's{i}_text', d[1])} for i, d in enumerate(_LP_STEPS, 1)]
    stats = []
    for i, d in enumerate(_LP_STATS, 1):
        raw = str(escape(c.get(f'st{i}_val') or d[0]))
        stats.append({'html': Markup(re.sub(r'\*(.+?)\*', r'<span>\1</span>', raw)), 'label': T(f'st{i}_label', d[1])})
    v['stats'] = stats
    motion_keys = ('m_preset', 'm_type', 'm_stiffness', 'm_damping', 'm_duration', 'm_distance', 'm_stagger', 'm_once',
                   'm_hero_text', 'm_hover', 'm_parallax', 'm_progress', 'm_spotlight', 'm_magnetic', 'm_countup')
    v['motion'] = {k: c[k] for k in motion_keys}
    v['motion_on'] = c['m_preset'] != 'auto' or c['m_hero_text'] == 'words'
    return v

def build_landing_css(c: Dict[str, Any]) -> str:
    """CSS for the public landing page. Empty when everything is 'auto'."""
    W = 'html body.landing-page .lp-root'
    rules: List[str] = []
    def add(sel: str, decl: str):
        rules.append(f'{sel}{{{decl}}}')

    # ---- accent / ink -----------------------------------------------------
    if c['accent']:
        r, g, b = _lp_rgb(c['accent'])
        add(W, f"--accent-primary:{c['accent']};--accent-rgb:{r},{g},{b};"
               f"--accent-secondary:{_lp_mix(c['accent'], (255, 255, 255), .28)};--accent-tertiary:{_lp_mix(c['accent'], (0, 0, 0), .18)}")
    if c['ink']:
        add(W + ' .hero h1,' + W + ' .section-head h2,' + W + ' .feature-card h3,' + W + ' .step-card h3,' + W + ' .cta-panel h2,'
            + W + ' .hero-stat-num', f"color:{c['ink']}!important")

    # ---- frame ---------------------------------------------------------------
    if c['header'] != 'show':
        add('html body.landing-page .content', 'padding-top:0!important')
    if c['header'] == 'hide':
        add('html body.landing-page .header', 'display:none!important')
    elif c['header'] == 'overlay':
        add('html body.landing-page .header', 'position:absolute!important;top:0;left:0;right:0;margin:0!important;z-index:5;'
            'background:transparent!important;border:0!important;box-shadow:none!important;'
            '-webkit-backdrop-filter:none!important;backdrop-filter:none!important')
        add('html body.landing-page .main-content', 'position:relative')
        add(W + ' .hero', 'padding-top:calc(var(--header-height,60px) + 3rem)!important')
    if c['hide_footer']:
        add('html body.landing-page .footer', 'display:none!important')
    if c['max_width']:
        add(W + ' > section', f"max-width:{c['max_width']}px;margin-inline:auto")
        add(W + ' .hero-inner', f"max-width:{c['max_width']}px")
    p = c['hero_pad']
    if p != LANDING_DEFAULTS['hero_pad']:
        add(W + ' .hero', f'padding-top:{p}rem;padding-bottom:{round(p * .85, 2)}rem')
    s = c['hero_scale'] / 100.0
    if c['hero_scale'] != 100:
        add(W + ' .hero h1', f'font-size:clamp({2.4 * s:.2f}rem,{6 * s:.2f}vw,{4.25 * s:.2f}rem)')
    if c['feature_cols'] != 3:
        add(W + ' #features .grid', f"grid-template-columns:repeat({c['feature_cols']},minmax(0,1fr))!important")
        rules.append('@media (max-width:900px){' + W + ' #features .grid{grid-template-columns:1fr!important}}')

    # ---- hero layout -----------------------------------------------------------
    if c['hero_layout'] == 'left':
        add(W + ' .hero-inner', 'text-align:left')
        add(W + ' .hero-cta,' + W + ' .hero-stats', 'justify-content:flex-start')
        add(W + ' .hero-sub', 'margin-left:0;margin-right:0')
    elif c['hero_layout'] == 'split':
        add(W + ' .hero-inner', 'display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:3.5rem;align-items:center;text-align:left')
        add(W + ' .hero-copy', 'display:block')
        add(W + ' .hero-cta,' + W + ' .hero-stats', 'justify-content:flex-start')
        add(W + ' .hero-stats', 'gap:1.25rem 1.75rem;margin-top:2.5rem;flex-wrap:nowrap')
        add(W + ' .hero-stat-num', 'font-size:1.6rem;white-space:nowrap')
        add(W + ' .hero-stat-label', 'font-size:.78rem')
        add(W + ' .hero-sub', 'margin-left:0;margin-right:0')
        add(W + ' .hero-showcase', 'margin:0;max-width:none')
        add(W + ' .chip-float.c1', 'left:-10px')
        add(W + ' .chip-float.c2', 'right:-10px')
        rules.append('@media (max-width:900px){' + W + ' .hero-inner{display:block;text-align:center}' + W + ' .hero-copy{display:contents}'
                     + W + ' .hero-cta,' + W + ' .hero-stats{justify-content:center}' + W + ' .hero-stats{flex-wrap:wrap}' + W + ' .hero-sub{margin-left:auto;margin-right:auto}'
                     + W + ' .hero-showcase{margin:3rem auto 0}}')

    # ---- background -------------------------------------------------------------
    # Painted on <body>::before/::after (position:fixed): the page's entrance animation puts a
    # transform on .lp-root, which would otherwise trap a fixed layer inside the content box.
    t = c['bg_type']
    if t == 'image' and not c['bg_image']:
        t = 'gradient'
    if t != 'auto':
        add(W + ' .hero-grid-bg', 'display:none')
        B = 'html:root body.landing-page'
        base = c['bg_color'] or 'var(--bg-primary)'
        add(B + '::before', 'content:"";display:block;position:fixed;inset:0;z-index:-1;pointer-events:none;'
            'transform:none;filter:none;animation:none;opacity:1')
        add(B + '::after', 'display:none')
        if t == 'solid':
            add(B + '::before', f'background:{base}')
        elif t == 'grid':
            add(B + '::before', f'background-color:{base};background-image:linear-gradient(to right,rgba(128,128,128,.16) 1px,transparent 1px),'
                                'linear-gradient(to bottom,rgba(128,128,128,.16) 1px,transparent 1px);background-size:56px 56px')
        elif t == 'dots':
            add(B + '::before', f'background-color:{base};background-image:radial-gradient(rgba(128,128,128,.34) 1.3px,transparent 1.6px);background-size:22px 22px')
        elif t == 'gradient':
            b2 = c['bg_color2'] or (('rgba(%d,%d,%d,.42)' % _lp_rgb(c['accent'])) if c['accent'] else 'rgba(var(--accent-rgb),.42)')
            add(B + '::before', f"background:linear-gradient({c['bg_angle']}deg,{base},{b2})")
        elif t == 'aurora':
            c1 = c['bg_color'] or c['accent'] or 'var(--accent-primary)'
            c2 = c['bg_color2'] or '#7C3AED'
            blob = 'content:"";display:block;position:fixed;inset:auto;z-index:-1;pointer-events:none;width:62vmax;height:62vmax;border-radius:50%;filter:blur(90px);opacity:.5;will-change:transform'
            add(B + '::before', blob + f';background:radial-gradient(circle,{c1},transparent 62%);top:-24vmax;left:-14vmax;animation:lpDrift 22s ease-in-out infinite alternate')
            add(B + '::after', blob + f';background:radial-gradient(circle,{c2},transparent 62%);bottom:-28vmax;right:-16vmax;top:auto;left:auto;animation:lpDrift 28s ease-in-out -9s infinite alternate-reverse')
            rules.append('@keyframes lpDrift{from{transform:translate3d(0,0,0) scale(1)}to{transform:translate3d(9vmax,6vmax,0) scale(1.18)}}'
                         '@media (prefers-reduced-motion:reduce){' + B + '::before,' + B + '::after{animation:none}}')
        elif t == 'image':
            dim = c['bg_dim'] / 100.0
            blur = c['bg_blur']
            add(B + '::before', f'inset:-{blur * 2}px;background:linear-gradient(rgba(0,0,0,{dim:.2f}),rgba(0,0,0,{dim:.2f})),'
                                f'url("{c["bg_image"]}") center/cover no-repeat;filter:blur({blur}px)')

    # ---- gradient headline text -------------------------------------------------
    if c['gradient_text'] == 'off':
        add(W + ' .text-gradient-brand', 'background:none!important;-webkit-text-fill-color:currentColor!important;color:var(--accent-primary)!important;animation:none!important')
    elif c['gradient_text'] == 'on':
        add(W + ' .text-gradient-brand', 'background:linear-gradient(96deg,var(--accent-secondary) 0%,var(--accent-primary) 55%,var(--accent-tertiary) 100%)!important;'
            '-webkit-background-clip:text!important;background-clip:text!important;-webkit-text-fill-color:transparent!important')

    # ---- cards --------------------------------------------------------------------
    C = W + ' .feature-card,' + W + ' .step-card,' + W + ' .cta-panel'
    st = c['card_style']
    if st == 'solid':
        add(C, 'background:var(--bg-card)!important;border:1px solid var(--border-color)!important;box-shadow:0 1px 2px rgba(0,0,0,.25),0 28px 56px -28px rgba(0,0,0,.55)!important;'
               'backdrop-filter:none!important;-webkit-backdrop-filter:none!important')
    elif st == 'outline':
        add(C, 'background:transparent!important;border:1px solid var(--border-light)!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important')
    elif st == 'glass':
        add(C, 'background:rgba(var(--surface-rgb,24,24,27),.5)!important;border:1px solid rgba(255,255,255,.16)!important;box-shadow:0 24px 60px -24px rgba(0,0,0,.6)!important;'
               '-webkit-backdrop-filter:blur(18px) saturate(140%)!important;backdrop-filter:blur(18px) saturate(140%)!important')
    elif st == 'flat':
        add(C, 'background:transparent!important;border:0!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important')
    if c['card_color']:
        add(C, f"background:{c['card_color']}!important")
    if c['card_radius'] >= 0:
        add(C, f"border-radius:{c['card_radius']}px!important")

    # ---- buttons ----------------------------------------------------------------------
    bs = c['btn_style']
    if bs == 'pill':
        add(W + ' .btn', 'border-radius:999px!important')
    elif bs == 'solid':
        add(W + ' .btn-primary', 'background:var(--accent-primary)!important;background-image:none!important;box-shadow:none!important;color:#fff!important')
    elif bs == 'soft':
        add(W + ' .btn-primary', 'background:rgba(var(--accent-rgb),.14)!important;background-image:none!important;color:var(--accent-primary)!important;'
            'border:1px solid rgba(var(--accent-rgb),.38)!important;box-shadow:none!important')
    elif bs == 'outline':
        add(W + ' .btn-primary', 'background:transparent!important;background-image:none!important;color:var(--accent-primary)!important;border:1.5px solid var(--accent-primary)!important;box-shadow:none!important')
    if c['ctrl_radius'] >= 0:
        add(W + ' .btn', f"border-radius:{c['ctrl_radius']}px!important")

    # ---- motion support styles ------------------------------------------------------------
    if c['m_preset'] != 'auto':
        rules.append('html.lp-motion .lp-root [data-lp-t]{transition:border-color .25s,box-shadow .25s}'
                     'html.lp-motion .lp-root [data-lp-t].reveal{opacity:1}'
                     'html.lp-motion .lp-root [data-lp-t]:not(.lp-in){opacity:0}')
    if c['m_hero_text'] == 'words':
        rules.append('html.lp-motion .lp-root h1[data-lp-words]:not(.lp-in){visibility:hidden}'
                     '.lp-w{display:inline-block;overflow:hidden;vertical-align:top;padding-bottom:.14em;margin-bottom:-.14em}'
                     '.lp-wi{display:inline-block;will-change:transform}')
    if c['m_progress']:
        rules.append('.lp-progress{position:fixed;top:0;left:0;right:0;height:3px;transform-origin:0 50%;transform:scaleX(0);'
                     'background:linear-gradient(90deg,var(--accent-secondary),var(--accent-primary));z-index:9999;pointer-events:none}')
    if c['m_spotlight']:
        rules.append('.lp-spot{position:fixed;left:0;top:0;width:560px;height:560px;margin:-280px 0 0 -280px;border-radius:50%;'
                     'background:radial-gradient(circle,rgba(var(--accent-rgb),.17),transparent 64%);pointer-events:none;z-index:0;opacity:0;transition:opacity .35s;will-change:transform}')
    if c['m_hover'] in ('lift', 'scale', 'tilt', 'glow'):
        add(W + ' .feature-card:hover,' + W + ' .step-card:hover', 'transform:none')
    if c['m_hover'] == 'glow':
        add(W + ' .feature-card::before,' + W + ' .step-card::before',
            'content:"";position:absolute;inset:0;pointer-events:none;opacity:0;transition:opacity .3s;'
            'background:radial-gradient(280px circle at var(--mx,50%) var(--my,50%),rgba(var(--accent-rgb),.2),transparent 62%)')
        add(W + ' .feature-card:hover::before,' + W + ' .step-card:hover::before', 'opacity:1')
        add(W + ' .step-card', 'position:relative;overflow:hidden')
    return ('/* landing page design */\n' + '\n'.join(rules) + '\n') if rules else ''

def render_landing(cfg: Dict[str, Any], preview: bool = False):
    LV = get_landing_view(cfg)
    extra: Dict[str, Any] = {}
    if preview:
        from flask_login import AnonymousUserMixin
        extra['current_user'] = AnonymousUserMixin()
    return render_template('index.html', panel_name=get_setting('site_name', 'ExpelHost Panel'),
                           LV=LV, landing_css=build_landing_css(cfg), landing_preview=preview, **extra)

def _landing_text_defaults() -> Dict[str, str]:
    """Built-in texts, shown as placeholders in the editor."""
    v = get_landing_view(dict(LANDING_DEFAULTS))
    d = {k: v[k] for k in _LANDING_TEXT if k in v and not re.match(r'^(f|s|st)\d', k)}
    for i, f in enumerate(_LP_FEATURES, 1):
        d.update({f'f{i}_icon': f[0], f'f{i}_title': f[1], f'f{i}_text': f[2]})
    for i, st in enumerate(_LP_STEPS, 1):
        d.update({f's{i}_title': st[0], f's{i}_text': st[1]})
    for i, st in enumerate(_LP_STATS, 1):
        d.update({f'st{i}_val': st[0], f'st{i}_label': st[1]})
    return d

@app.route('/admin/landing-page')
@login_required
@admin_required
def admin_landing_page():
    return render_template('admin/landing_page.html', panel_name=get_setting('site_name', 'ExpelHost Panel'),
                           landing_raw=get_landing_design(), landing_defaults=LANDING_DEFAULTS,
                           landing_text_defaults=_landing_text_defaults())

@app.route('/admin/theme/landing/save', methods=['POST'])
@login_required
@admin_required
def admin_landing_save():
    cfg = _clean_landing_cfg(request.get_json(silent=True))
    set_setting('landing_design', json.dumps(cfg) if cfg != LANDING_DEFAULTS else '')
    log_activity(current_user.id, 'update_landing_design', 'settings')
    return jsonify({'success': True, 'cfg': get_landing_design()})

@app.route('/admin/theme/landing/reset', methods=['POST'])
@login_required
@admin_required
def admin_landing_reset():
    set_setting('landing_design', '')
    log_activity(current_user.id, 'reset_landing_design', 'settings')
    return jsonify({'success': True, 'cfg': dict(LANDING_DEFAULTS)})

@app.route('/admin/theme/landing/upload-bg', methods=['POST'])
@login_required
@admin_required
def admin_landing_upload_bg():
    file = request.files.get('image')
    if not file or not file.filename:
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if ext not in ('png', 'jpg', 'jpeg', 'webp', 'gif'):
        return jsonify({'success': False, 'error': 'Use a PNG, JPG, WEBP or GIF image'}), 400
    filename = secure_filename(f'landing_bg_{int(time.time())}.{ext}')
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'settings', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    if PIL_AVAILABLE and Image and ext != 'gif':
        try:
            img = Image.open(filepath)
            img.thumbnail((2200, 2200), Image.Resampling.LANCZOS)
            if ext in ('jpg', 'jpeg') and img.mode != 'RGB':
                img = img.convert('RGB')
            img.save(filepath, optimize=True, quality=82)
        except Exception:
            pass
    return jsonify({'success': True, 'path': f'/static/uploads/settings/{filename}'})

@app.route('/admin/theme/landing/preview', methods=['POST'])
@login_required
@admin_required
def admin_landing_preview():
    """Renders the REAL landing page from a draft config, as a logged-out visitor would see it."""
    try:
        raw = json.loads(request.form.get('cfg', '') or '{}')
    except Exception:
        raw = {}
    return render_landing(_clean_landing_cfg(raw), preview=True)

# ---------------------------------------------------------------------------
# Main pages design (Admin -> Main Pages)
# Everything a visitor sees AFTER signing in: dashboard, My VPS, ports, profile,
# notifications and all admin pages. One JSON blob in the `main_design` setting.
# "auto" / "" / -1 means "keep the current look", so nothing changes until an
# admin edits and publishes it.
# ---------------------------------------------------------------------------
MAIN_CSS_REV = 'r3'  # bump when build_main_css output changes, so browsers drop the cached stylesheet
MAIN_DEFAULTS: Dict[str, Any] = {
    # layout
    'content_width': 0, 'page_pad': -1, 'header': 'auto', 'nav_style': 'auto',
    # background of the page area
    'bg_type': 'auto', 'bg_color': '', 'bg_color2': '', 'bg_angle': 135, 'bg_image': '', 'bg_dim': 45, 'bg_blur': 0,
    # cards & buttons
    'card_style': 'auto', 'card_color': '', 'card_radius': -1, 'btn_style': 'auto', 'ctrl_radius': -1,
    # motion (Framer Motion)
    'm_preset': 'auto', 'm_type': 'spring', 'm_stiffness': 220, 'm_damping': 24, 'm_duration': 700,
    'm_distance': 28, 'm_stagger': 55, 'm_nav': 'auto', 'm_page': 'auto', 'm_hover': 'auto',
    'm_rows': False, 'm_countup': False, 'm_progress': False, 'm_spotlight': False, 'm_magnetic': False,
}
_MAIN_ENUMS = {
    'header': ('auto', 'solid', 'glass', 'transparent'),
    'nav_style': ('auto', 'soft', 'bar', 'pill'),
    'bg_type': ('auto', 'solid', 'grid', 'dots', 'gradient', 'image'),
    'card_style': ('auto', 'solid', 'outline', 'glass', 'flat'),
    'btn_style': ('auto', 'solid', 'soft', 'pill', 'outline'),
    'm_preset': ('auto', 'none', 'fade', 'rise', 'pop', 'zoom', 'blur', 'slide', 'flip'),
    'm_type': ('spring', 'tween'),
    'm_nav': ('auto', 'none', 'fade', 'slide', 'rise'),
    'm_page': ('auto', 'none', 'fade', 'slide', 'zoom'),
    'm_hover': ('auto', 'none', 'lift', 'scale', 'tilt', 'glow'),
}
_MAIN_NUMS = {
    'content_width': (0, 1900), 'page_pad': (-1, 72), 'bg_angle': (0, 360), 'bg_dim': (0, 90), 'bg_blur': (0, 24),
    'card_radius': (-1, 40), 'ctrl_radius': (-1, 32),
    'm_stiffness': (40, 700), 'm_damping': (5, 70), 'm_duration': (200, 1800), 'm_distance': (0, 140), 'm_stagger': (0, 240),
}
_MAIN_HEX = ('bg_color', 'bg_color2', 'card_color')
_MAIN_BOOL = ('m_rows', 'm_countup', 'm_progress', 'm_spotlight', 'm_magnetic')
_MAIN_BLOCKS = ('.page-header,.stat-card,.card,.dash-stat,.dash-panel,.welcome-panel,'
                '.table-responsive,.alert,.empty-state')
_MAIN_PREVIEW_PAGES = {'dashboard': 'dashboard', 'vps': 'vps_list', 'ports': 'ports_list',
                       'admin': 'admin_dashboard', 'admin_vps': 'admin_vps'}

def _clean_main_cfg(data: Any) -> Dict[str, Any]:
    out = dict(MAIN_DEFAULTS)
    if not isinstance(data, dict):
        return out
    for k, allowed in _MAIN_ENUMS.items():
        v = data.get(k)
        if isinstance(v, str) and v in allowed:
            out[k] = v
    for k, (lo, hi) in _MAIN_NUMS.items():
        try:
            n = int(round(float(data.get(k))))
        except (TypeError, ValueError):
            continue
        out[k] = max(lo, min(hi, n))
    for k in _MAIN_HEX:
        v = data.get(k)
        if isinstance(v, str) and _HEX_RE.match(v.strip()):
            out[k] = v.strip().upper()
    for k in _MAIN_BOOL:
        v = data.get(k)
        out[k] = v is True or v in (1, '1', 'true')
    out['bg_image'] = _clean_login_url(data.get('bg_image'))
    return out

def get_main_design() -> Dict[str, Any]:
    try:
        saved = json.loads(get_setting('main_design', '') or '{}')
    except Exception:
        saved = {}
    return _clean_main_cfg(saved)

def get_main_design_version() -> str:
    try:
        raw = get_setting('main_design', '') or ''
    except Exception:
        raw = ''
    return hashlib.md5((MAIN_CSS_REV + raw).encode('utf-8')).hexdigest()[:10] if raw else '0'

def get_main_view(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """What base.html reads on every signed-in page. The editor's preview swaps in a draft via flask.g."""
    override = None
    try:
        override = getattr(flask.g, 'main_override', None)
    except RuntimeError:
        pass
    c = dict(cfg if cfg is not None else (override or get_main_design()))
    c['motion'] = {k: c[k] for k in ('m_preset', 'm_type', 'm_stiffness', 'm_damping', 'm_duration', 'm_distance',
                                     'm_stagger', 'm_nav', 'm_page', 'm_hover', 'm_rows', 'm_countup',
                                     'm_progress', 'm_spotlight', 'm_magnetic')}
    c['hide'] = c['m_preset'] not in ('auto', 'none')
    c['motion_on'] = any([c['m_preset'] != 'auto', c['m_nav'] != 'auto', c['m_page'] not in ('auto',), c['m_hover'] != 'auto',
                          c['m_rows'], c['m_countup'], c['m_progress'], c['m_spotlight'], c['m_magnetic']])
    c['preview'] = override is not None
    return c

def build_main_css(c: Dict[str, Any]) -> str:
    """CSS for every signed-in page. Empty when everything is 'auto'."""
    rules: List[str] = []
    def add(sel: str, decl: str):
        rules.append(f'{sel}{{{decl}}}')
    # high specificity so Main Pages beats html[data-design=...] / :root[data-theme=...] !important rules
    # never touches the Landing page, the Login/Register pages (body.landing-page / body.auth-page) or the
    # terminal pages (standalone templates that don't load this stylesheet at all)
    P = 'html:root:root body:not(.auth-page):not(.landing-page)'
    CARDS = ','.join(f'{P} .main-content {s}' for s in ('.card', '.stat-card', '.dash-panel', '.dash-stat', '.welcome-panel', '.vps-item'))
    SIDEBAR = P + ' .sidebar'
    OVERLAYS = ','.join(f'{P} {s}' for s in ('.modal-content', '.user-dropdown', '.notifications-panel', '.dropdown-menu'))
    FIELDS = ','.join(f'{P} .main-content {s}' for s in ('.form-control', 'select.form-control', 'textarea.form-control'))
    TABLES = ','.join(f'{P} .main-content {s}' for s in ('.table', '.table-responsive'))

    # ---- layout --------------------------------------------------------------
    if c['content_width']:
        add(P + ' .content', f"max-width:{c['content_width']}px;margin-left:auto!important;margin-right:auto!important;width:100%")
    if c['page_pad'] >= 0:
        add(P + ' .content', f"padding-left:{c['page_pad']}px!important;padding-right:{c['page_pad']}px!important")

    # ---- top bar ---------------------------------------------------------------
    hs = c['header']
    if hs == 'solid':
        add(P + ' .header', 'background:var(--bg-secondary)!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important;border-bottom:1px solid var(--border-color)!important')
    elif hs == 'glass':
        add(P + ' .header', 'background:rgba(var(--surface-rgb,24,24,27),.55)!important;-webkit-backdrop-filter:blur(16px) saturate(140%)!important;backdrop-filter:blur(16px) saturate(140%)!important')
    elif hs == 'transparent':
        add(P + ' .header', 'background:transparent!important;border-bottom:0!important;box-shadow:none!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important')

    # ---- sidebar active item ---------------------------------------------------
    ns = c['nav_style']
    A = P + ' .sidebar .nav-item.active'
    if ns == 'soft':
        add(A, 'background:rgba(var(--accent-rgb),.14)!important;color:var(--accent-primary)!important;box-shadow:none!important')
    elif ns == 'bar':
        add(A, 'background:transparent!important;border-radius:0!important;box-shadow:inset 3px 0 0 var(--accent-primary)!important;color:var(--accent-primary)!important')
    elif ns == 'pill':
        add(A, 'background:var(--accent-primary)!important;color:#fff!important;border-radius:999px!important;box-shadow:none!important')

    # ---- page background (whole shell: behind the sidebar, top bar and content) ----------------
    if c['bg_type'] != 'auto':
        is_image = c['bg_type'] == 'image' and bool(c['bg_image'])
        add(P, _login_bg_decl(c) + (';background-attachment:fixed' if not is_image else ''))
        add(f'{P} .app-wrapper,{P} .main-content', 'background:transparent!important')
        if is_image:
            blur = c['bg_blur']; dim = c['bg_dim'] / 100.0
            add(P + ' .app-wrapper', 'isolation:isolate')
            add(P + ' .app-wrapper::before', f'content:"";position:fixed;inset:-{blur * 2}px;z-index:-1;pointer-events:none;'
                f'background:linear-gradient(rgba(0,0,0,{dim:.2f}),rgba(0,0,0,{dim:.2f})),url("{c["bg_image"]}") center/cover no-repeat;'
                f'filter:blur({blur}px)')

    # ---- cards, sidebar, menus, modals, fields, tables ------------------------------------------------
    st = c['card_style']
    NOBLUR = 'backdrop-filter:none!important;-webkit-backdrop-filter:none!important'
    GLASS = 'background:rgba(var(--surface-rgb,24,24,27),.5)!important;border:1px solid rgba(255,255,255,.14)!important;box-shadow:0 24px 60px -26px rgba(0,0,0,.6)!important;-webkit-backdrop-filter:blur(16px) saturate(140%)!important;backdrop-filter:blur(16px) saturate(140%)!important'
    SOLID = 'background:var(--bg-card)!important;border:1px solid var(--border-color)!important;box-shadow:0 1px 2px rgba(0,0,0,.25),0 24px 48px -28px rgba(0,0,0,.55)!important;' + NOBLUR
    if st == 'solid':
        add(CARDS, SOLID); add(SIDEBAR, SOLID); add(OVERLAYS, SOLID)
    elif st == 'outline':
        OUT = 'background:transparent!important;border:1px solid var(--border-light)!important;box-shadow:none!important;' + NOBLUR
        add(CARDS, OUT); add(SIDEBAR, OUT)
        add(OVERLAYS, 'background:var(--bg-card)!important;border:1px solid var(--border-light)!important;box-shadow:none!important;' + NOBLUR)
        add(FIELDS, 'background:transparent!important;border-color:var(--border-light)!important')
        add(TABLES, 'background:transparent!important')
    elif st == 'glass':
        add(CARDS, GLASS); add(SIDEBAR, GLASS); add(OVERLAYS, GLASS.replace('.5)!important', '.78)!important', 1))
        add(FIELDS, 'background:rgba(255,255,255,.06)!important;border-color:rgba(255,255,255,.16)!important')
        add(TABLES, 'background:transparent!important')
    elif st == 'flat':
        FLAT = 'background:var(--bg-tertiary)!important;border:0!important;box-shadow:none!important;' + NOBLUR
        add(CARDS, FLAT); add(SIDEBAR, FLAT); add(OVERLAYS, FLAT)
        add(FIELDS, 'background:var(--bg-primary)!important;border-color:transparent!important')
        add(TABLES, 'background:transparent!important')
    if c['card_color']:
        add(f'{CARDS},{SIDEBAR},{OVERLAYS}', f"background:{c['card_color']}!important")
    if c['card_radius'] >= 0:
        add(f'{CARDS},{OVERLAYS}', f"border-radius:{c['card_radius']}px!important")
        if st != 'auto':
            add(SIDEBAR, f"border-radius:{c['card_radius']}px!important")

    # ---- buttons -----------------------------------------------------------------------
    W = P + ' .main-content'
    bs = c['btn_style']
    if bs == 'pill':
        add(W + ' .btn,' + W + ' .badge', 'border-radius:999px!important')
    elif bs == 'solid':
        add(W + ' .btn-primary', 'background:var(--accent-primary)!important;background-image:none!important;box-shadow:none!important;color:#fff!important')
    elif bs == 'soft':
        add(W + ' .btn-primary', 'background:rgba(var(--accent-rgb),.14)!important;background-image:none!important;color:var(--accent-primary)!important;'
            'border:1px solid rgba(var(--accent-rgb),.38)!important;box-shadow:none!important')
    elif bs == 'outline':
        add(W + ' .btn-primary', 'background:transparent!important;background-image:none!important;color:var(--accent-primary)!important;border:1.5px solid var(--accent-primary)!important;box-shadow:none!important')
    if c['ctrl_radius'] >= 0:
        add(W + ' .btn,' + W + ' .form-control,' + W + ' select.form-control,' + P + ' .dropdown-item', f"border-radius:{c['ctrl_radius']}px!important")

    # ---- motion support styles (main-motion.js reveals / drives these) -----------------------
    if c['m_preset'] not in ('auto', 'none'):
        blocks = ','.join(f'{s}' for s in _MAIN_BLOCKS.split(','))
        rules.append('html.mp-motion .main-content .reveal{opacity:1;transform:none}')
        rules.append('html.mp-motion .main-content :is(' + blocks + '):not(.mp-in){opacity:0}')
    if c['m_hover'] in ('lift', 'scale', 'tilt', 'glow'):
        add('html:root:root body [data-mp-card]:hover', 'transform:none')
    if c['m_hover'] == 'glow':
        add('html body [data-mp-card]', 'transition:box-shadow .3s,border-color .3s')
        add('html body [data-mp-card]:hover', 'border-color:rgba(var(--accent-rgb),.55)!important;box-shadow:0 0 0 1px rgba(var(--accent-rgb),.35),0 20px 54px -20px rgba(var(--accent-rgb),.6)!important')
    if c['m_progress']:
        rules.append('.mp-progress{position:fixed;top:0;left:0;right:0;height:3px;transform-origin:0 50%;transform:scaleX(0);'
                     'background:linear-gradient(90deg,var(--accent-secondary),var(--accent-primary));z-index:9999;pointer-events:none}')
    if c['m_spotlight']:
        rules.append('.mp-spot{position:fixed;left:0;top:0;width:560px;height:560px;margin:-280px 0 0 -280px;border-radius:50%;'
                     'background:radial-gradient(circle,rgba(var(--accent-rgb),.13),transparent 64%);pointer-events:none;z-index:0;opacity:0;transition:opacity .35s;will-change:transform}')

    return ('/* main pages design */\n' + '\n'.join(rules) + '\n') if rules else ''

def _main_preview_css() -> str:
    try:
        ov = getattr(flask.g, 'main_override', None)
    except RuntimeError:
        ov = None
    return build_main_css(ov) if ov else ''

@app.route('/main-design.css')
def main_design_css():
    resp = Response(build_main_css(get_main_design()), mimetype='text/css')
    resp.headers['Cache-Control'] = 'public, max-age=31536000, immutable' if request.args.get('v') else 'no-cache'
    return resp

@app.route('/admin/main-pages')
@login_required
@admin_required
def admin_main_pages():
    return render_template('admin/main_pages.html', panel_name=get_setting('site_name', 'ExpelHost Panel'),
                           main_raw=get_main_design(), main_defaults=MAIN_DEFAULTS)

@app.route('/admin/theme/main/save', methods=['POST'])
@login_required
@admin_required
def admin_main_save():
    cfg = _clean_main_cfg(request.get_json(silent=True))
    set_setting('main_design', json.dumps(cfg) if cfg != MAIN_DEFAULTS else '')
    log_activity(current_user.id, 'update_main_design', 'settings')
    return jsonify({'success': True, 'version': get_main_design_version(), 'cfg': get_main_design()})

@app.route('/admin/theme/main/reset', methods=['POST'])
@login_required
@admin_required
def admin_main_reset():
    set_setting('main_design', '')
    log_activity(current_user.id, 'reset_main_design', 'settings')
    return jsonify({'success': True, 'version': get_main_design_version(), 'cfg': dict(MAIN_DEFAULTS)})

@app.route('/admin/theme/main/upload-bg', methods=['POST'])
@login_required
@admin_required
def admin_main_upload_bg():
    file = request.files.get('image')
    if not file or not file.filename:
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if ext not in ('png', 'jpg', 'jpeg', 'webp', 'gif'):
        return jsonify({'success': False, 'error': 'Use a PNG, JPG, WEBP or GIF image'}), 400
    filename = secure_filename(f'main_bg_{int(time.time())}.{ext}')
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'settings', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    if PIL_AVAILABLE and Image and ext != 'gif':
        try:
            img = Image.open(filepath)
            img.thumbnail((2200, 2200), Image.Resampling.LANCZOS)
            if ext in ('jpg', 'jpeg') and img.mode != 'RGB':
                img = img.convert('RGB')
            img.save(filepath, optimize=True, quality=82)
        except Exception:
            pass
    return jsonify({'success': True, 'path': f'/static/uploads/settings/{filename}'})

@app.route('/admin/theme/main/preview', methods=['POST'])
@login_required
@admin_required
def admin_main_preview():
    """Renders a REAL signed-in page (dashboard, My VPS, ports, admin) with the draft design applied."""
    try:
        raw = json.loads(request.form.get('cfg', '') or '{}')
    except Exception:
        raw = {}
    flask.g.main_override = _clean_main_cfg(raw)
    endpoint = _MAIN_PREVIEW_PAGES.get(request.form.get('page', 'dashboard'), 'dashboard')
    return app.view_functions[endpoint]()

@app.route('/admin/settings/upload-header-icon', methods=['POST'])
@login_required
@admin_required
def upload_header_icon():
    if 'icon' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['icon']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'success': False, 'error': 'Invalid file type'}), 400
    
    filename = secure_filename(f"header_icon_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'settings', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    if PIL_AVAILABLE and Image:
        try:
            img = Image.open(filepath)
            img.thumbnail((64, 64), Image.Resampling.LANCZOS)
            img.save(filepath, optimize=True, quality=85)
        except:
            pass
    
    icon_path = f'/static/uploads/settings/{filename}'
    
    set_setting('header_icon', icon_path)
    
    return jsonify({'success': True, 'path': icon_path})

@app.route('/admin/settings/upload-favicon', methods=['POST'])
@login_required
@admin_required
def upload_favicon():
    if 'icon' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['icon']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if ext not in ['ico', 'png']:
        return jsonify({'success': False, 'error': 'Invalid file type. Please upload .ico or .png'}), 400
    
    filename = f"favicon_{int(time.time())}.{ext}"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'settings', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    icon_path = f'/static/uploads/settings/{filename}'
    
    set_setting('favicon', icon_path)
    
    return jsonify({'success': True, 'path': icon_path})

@app.route('/admin/maintenance')
@login_required
@admin_required
def admin_maintenance():
    return render_template('admin/maintenance.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'))

@app.route('/admin/backup', methods=['POST'])
@login_required
@admin_required
def admin_backup():
    backup_name = f"hvm_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    
    try:
        os.makedirs('backups', exist_ok=True)
        backup_path = os.path.join('backups', backup_name)
        
        shutil.copy(DATABASE_PATH, backup_path)
        
        if os.path.exists(f"{DATABASE_PATH}-wal"):
            shutil.copy(f"{DATABASE_PATH}-wal", f"{backup_path}-wal")
        if os.path.exists(f"{DATABASE_PATH}-shm"):
            shutil.copy(f"{DATABASE_PATH}-shm", f"{backup_path}-shm")
        
        log_activity(current_user.id, 'create_backup', 'system', None, {'name': backup_name})
        create_notification(current_user.id, 'success', 'Backup Created', f'Database backup {backup_name} created.')
        return send_file(backup_path, as_attachment=True, download_name=backup_name)
    except Exception as e:
        flash(f'Backup failed: {e}', 'danger')
        return redirect(url_for('admin_maintenance'))

@app.route('/admin/backup/list')
@login_required
@admin_required
def admin_backup_list():
    backups = []
    backup_dir = 'backups'
    if os.path.exists(backup_dir):
        for file in os.listdir(backup_dir):
            if file.endswith('.db'):
                path = os.path.join(backup_dir, file)
                backups.append({
                    'name': file,
                    'size': os.path.getsize(path),
                    'modified': datetime.fromtimestamp(os.path.getmtime(path)).isoformat()
                })
    
    backups.sort(key=lambda x: x['modified'], reverse=True)
    
    return render_template('admin/backup_list.html',
                          panel_name=get_setting('site_name', 'ExpelHost Panel'),
                          backups=backups)

@app.route('/admin/backup/restore/<filename>', methods=['POST'])
@login_required
@admin_required
def admin_backup_restore(filename):
    backup_path = os.path.join('backups', filename)
    
    if not os.path.exists(backup_path):
        return jsonify({'success': False, 'error': 'Backup not found'}), 404
    
    try:
        current_backup = f"hvm_pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        shutil.copy(DATABASE_PATH, os.path.join('backups', current_backup))
        
        shutil.copy(backup_path, DATABASE_PATH)
        
        log_activity(current_user.id, 'restore_backup', 'system', None, {'name': filename})
        create_notification(current_user.id, 'success', 'Backup Restored', f'Database restored from {filename}')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/backup/download/<filename>')
@login_required
@admin_required
def admin_backup_download(filename):
    backup_path = os.path.join('backups', filename)
    
    if not os.path.exists(backup_path):
        flash('Backup not found', 'danger')
        return redirect(url_for('admin_backup_list'))
    
    try:
        return send_file(backup_path, as_attachment=True, download_name=filename)
    except Exception as e:
        flash(f'Failed to download backup: {str(e)}', 'danger')
        return redirect(url_for('admin_backup_list'))

@app.route('/admin/backup/delete/<filename>', methods=['POST'])
@login_required
@admin_required
def admin_backup_delete(filename):
    backup_path = os.path.join('backups', filename)
    
    if not os.path.exists(backup_path):
        return jsonify({'success': False, 'error': 'Backup not found'}), 404
    
    try:
        os.remove(backup_path)
        log_activity(current_user.id, 'delete_backup', 'system', None, {'name': filename})
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/resource-check', methods=['POST'])
@login_required
@admin_required
def admin_resource_check():
    cpu_threshold = int(get_setting('cpu_threshold', 90))
    ram_threshold = int(get_setting('ram_threshold', 90))
    
    suspended_count = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        if vps['status'] == 'running' and not vps['suspended'] and not vps['whitelisted']:
            try:
                stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
                cpu = stats['cpu']
                ram = stats['ram']['pct']
                
                if cpu > cpu_threshold or ram > ram_threshold:
                    reason = f"High resource usage: CPU {cpu:.1f}%, RAM {ram:.1f}%"
                    
                    run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']} --force", node_id=vps['node_id']))
                    
                    history = vps['suspension_history']
                    history.append({
                        'time': datetime.now().isoformat(),
                        'reason': reason,
                        'by': 'Auto Resource Check'
                    })
                    
                    update_vps(vps['id'], suspended=1, status='stopped', suspension_history=history, suspended_reason=reason)
                    suspended_count += 1
                    log_activity(None, 'auto_suspend', 'vps', str(vps['id']), {'reason': reason})
                    create_notification(vps['user_id'], 'warning', 'VPS Auto-Suspended', 
                                      f'Your VPS {vps["container_name"]} has been suspended due to high resource usage.')
                    
                    if socketio:
                        socketio.emit('vps_suspended', {
                            'vps_id': vps['id'],
                            'reason': reason
                        }, room=f'vps_{vps["id"]}')
                        
            except Exception as e:
                logger.error(f"Resource check error for {vps['container_name']}: {e}")
    
    return jsonify({'success': True, 'suspended': suspended_count})

@app.route('/admin/system-info')
@login_required
@admin_required
def admin_system_info():
    """Comprehensive system information page"""
    import platform
    
    try:
        import psutil
        PSUTIL_AVAILABLE = True
    except ImportError:
        PSUTIL_AVAILABLE = False
        psutil = None
    
    # If it's an AJAX request, return JSON
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.args.get('format') == 'json':
        return get_system_info_json()
    
    # Regular page view - get all system info
    system_info = get_system_info_dict()
    
    return render_template('admin/system_info.html',
                         panel_name=get_setting('site_name', 'ExpelHost Panel'),
                         system_info=system_info,
                         psutil_available=PSUTIL_AVAILABLE)

def get_system_info_json():
    """Return system info as JSON for AJAX requests"""
    import platform
    
    try:
        lxc_version = subprocess.run(['lxc', '--version'], capture_output=True, text=True, timeout=5).stdout.strip()
    except:
        lxc_version = None
    
    try:
        python_version = platform.python_version()
    except:
        python_version = None
    
    disk_usage = {}
    for path in ['/', '/var', '/home']:
        if os.path.exists(path):
            try:
                usage = shutil.disk_usage(path)
                disk_usage[path] = {
                    'total': usage.total // (1024**3),
                    'used': usage.used // (1024**3),
                    'free': usage.free // (1024**3)
                }
            except:
                pass
    
    return jsonify({
        'hostname': platform.node(),
        'platform': platform.platform(),
        'python': python_version,
        'uptime': get_host_uptime(),
        'cpu_cores': os.cpu_count(),
        'cpu_percent': get_host_cpu_usage(),
        'memory': get_host_ram_usage(),
        'disk': get_host_disk_usage(),
        'disk_detailed': disk_usage,
        'lxc_version': lxc_version,
        'database_size': os.path.getsize(DATABASE_PATH) // (1024 * 1024) if os.path.exists(DATABASE_PATH) else 0
    })

def get_system_info_dict():
    """Get comprehensive system information as dictionary"""
    import platform
    
    try:
        import psutil
        PSUTIL_AVAILABLE = True
    except ImportError:
        PSUTIL_AVAILABLE = False
        psutil = None
    
    system_info = {}
    
    # Basic system information
    try:
        system_info['hostname'] = platform.node()
        system_info['platform'] = platform.platform()
        system_info['system'] = platform.system()
        system_info['release'] = platform.release()
        system_info['version'] = platform.version()
        system_info['machine'] = platform.machine()
        system_info['processor'] = platform.processor()
        system_info['python_version'] = platform.python_version()
        system_info['python_implementation'] = platform.python_implementation()
    except Exception as e:
        logger.error(f"Error getting basic system info: {e}")
    
    # Uptime
    try:
        system_info['uptime'] = get_host_uptime()
    except:
        system_info['uptime'] = 'Unknown'
    
    # CPU information
    try:
        system_info['cpu_count'] = os.cpu_count()
        system_info['cpu_usage'] = get_host_cpu_usage()
        
        # Try to get detailed CPU info
        if platform.system() == 'Linux':
            try:
                cpu_info_cmd = subprocess.run(['lscpu'], capture_output=True, text=True, timeout=5)
                if cpu_info_cmd.returncode == 0:
                    cpu_lines = cpu_info_cmd.stdout.strip().split('\n')
                    cpu_details = {}
                    for line in cpu_lines:
                        if ':' in line:
                            key, value = line.split(':', 1)
                            cpu_details[key.strip()] = value.strip()
                    system_info['cpu_details'] = cpu_details
            except:
                pass
    except Exception as e:
        logger.error(f"Error getting CPU info: {e}")
    
    # Memory information
    try:
        ram = get_host_ram_usage()
        system_info['memory'] = ram
        
        # Get swap info if available
        if PSUTIL_AVAILABLE:
            swap = psutil.swap_memory()
            system_info['swap'] = {
                'total': swap.total // (1024**2),
                'used': swap.used // (1024**2),
                'free': swap.free // (1024**2),
                'percent': swap.percent
            }
    except Exception as e:
        logger.error(f"Error getting memory info: {e}")
    
    # Disk information
    try:
        system_info['disk'] = get_host_disk_usage()
        
        # Detailed disk usage for multiple paths
        disk_usage = {}
        for path in ['/', '/var', '/home', '/tmp']:
            if os.path.exists(path):
                try:
                    usage = shutil.disk_usage(path)
                    disk_usage[path] = {
                        'total': usage.total // (1024**3),
                        'used': usage.used // (1024**3),
                        'free': usage.free // (1024**3),
                        'percent': (usage.used / usage.total * 100) if usage.total > 0 else 0
                    }
                except:
                    pass
        system_info['disk_detailed'] = disk_usage
        
        # Get disk partitions if psutil available
        if PSUTIL_AVAILABLE:
            partitions = []
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    partitions.append({
                        'device': partition.device,
                        'mountpoint': partition.mountpoint,
                        'fstype': partition.fstype,
                        'total': usage.total // (1024**3),
                        'used': usage.used // (1024**3),
                        'free': usage.free // (1024**3),
                        'percent': usage.percent
                    })
                except:
                    pass
            system_info['partitions'] = partitions
    except Exception as e:
        logger.error(f"Error getting disk info: {e}")
    
    # Network information
    try:
        if PSUTIL_AVAILABLE:
            net_if_addrs = psutil.net_if_addrs()
            network_interfaces = {}
            for interface, addrs in net_if_addrs.items():
                network_interfaces[interface] = []
                for addr in addrs:
                    network_interfaces[interface].append({
                        'family': str(addr.family),
                        'address': addr.address,
                        'netmask': addr.netmask,
                        'broadcast': addr.broadcast
                    })
            system_info['network_interfaces'] = network_interfaces
    except Exception as e:
        logger.error(f"Error getting network info: {e}")
    
    # LXC/LXD information
    try:
        lxc_version = subprocess.run(['lxc', '--version'], capture_output=True, text=True, timeout=5)
        system_info['lxc_version'] = lxc_version.stdout.strip() if lxc_version.returncode == 0 else 'Not installed'
        
        # Get LXC storage pools
        try:
            pools_cmd = subprocess.run(['lxc', 'storage', 'list', '--format', 'json'], 
                                      capture_output=True, text=True, timeout=10)
            if pools_cmd.returncode == 0:
                system_info['lxc_pools'] = json.loads(pools_cmd.stdout)
        except:
            pass
        
        # Get LXC networks
        try:
            networks_cmd = subprocess.run(['lxc', 'network', 'list', '--format', 'json'], 
                                         capture_output=True, text=True, timeout=10)
            if networks_cmd.returncode == 0:
                system_info['lxc_networks'] = json.loads(networks_cmd.stdout)
        except:
            pass
    except:
        system_info['lxc_version'] = 'Not installed'
    
    # OS information
    try:
        if platform.system() == 'Linux' and os.path.exists('/etc/os-release'):
            with open('/etc/os-release', 'r') as f:
                os_release = {}
                for line in f:
                    if '=' in line:
                        key, value = line.strip().split('=', 1)
                        os_release[key] = value.strip('"')
                system_info['os_release'] = os_release
    except Exception as e:
        logger.error(f"Error getting OS info: {e}")
    
    # Database information
    try:
        db_size = os.path.getsize(DATABASE_PATH) // (1024 * 1024) if os.path.exists(DATABASE_PATH) else 0
        system_info['database'] = {
            'path': DATABASE_PATH,
            'size_mb': db_size,
            'exists': os.path.exists(DATABASE_PATH)
        }
        
        # Get database stats
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM users")
            user_count = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM vps")
            vps_count = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM nodes")
            node_count = cur.fetchone()[0]
            
            system_info['database']['stats'] = {
                'users': user_count,
                'vps': vps_count,
                'nodes': node_count
            }
    except Exception as e:
        logger.error(f"Error getting database info: {e}")
    
    # Flask/Application information
    try:
        system_info['app'] = {
            'version': PANEL_VERSION,
            'flask_version': flask.__version__,
            'debug_mode': app.debug,
            'testing_mode': app.testing
        }
    except Exception as e:
        logger.error(f"Error getting app info: {e}")
    
    # Process information
    try:
        if PSUTIL_AVAILABLE:
            process = psutil.Process()
            system_info['process'] = {
                'pid': process.pid,
                'memory_mb': process.memory_info().rss // (1024**2),
                'cpu_percent': process.cpu_percent(interval=0.1),
                'threads': process.num_threads(),
                'create_time': datetime.fromtimestamp(process.create_time()).strftime('%Y-%m-%d %H:%M:%S')
            }
    except Exception as e:
        logger.error(f"Error getting process info: {e}")
    
    # Environment Variables
    try:
        env_vars = {
            'PANEL_NAME': PANEL_NAME,
            'PANEL_VERSION': PANEL_VERSION,
            'PANEL_DEVELOPER': PANEL_DEVELOPER,
            'DATABASE_PATH': DATABASE_PATH,
            'HOST': HOST,
            'PORT': PORT,
            'MAIN_ADMIN_USERNAME': os.getenv('MAIN_ADMIN_USERNAME', 'admin'),
            'MAIN_ADMIN_EMAIL': os.getenv('MAIN_ADMIN_EMAIL', 'admin@localhost'),
            'YOUR_SERVER_IP': YOUR_SERVER_IP,
            'DEFAULT_STORAGE_POOL': DEFAULT_STORAGE_POOL,
            'DEDICATED_DISK': 'on (own disk pool per VPS)' if DEDICATED_DISK else 'off (shared pool)',
            'DEDICATED_POOL_DRIVERS': ','.join(DEDICATED_POOL_DRIVERS),
            'DEBUG_MODE': os.getenv('DEBUG_MODE', 'False'),
            'AUTO_BACKUP_INTERVAL': os.getenv('AUTO_BACKUP_INTERVAL', '3600'),
            'STATS_UPDATE_INTERVAL': os.getenv('STATS_UPDATE_INTERVAL', '5'),
            'PYTHON_VERSION': platform.python_version(),
            'PYTHONPATH': os.getenv('PYTHONPATH', 'Not set'),
            'PATH': os.getenv('PATH', 'Not set')[:200] + '...' if os.getenv('PATH') and len(os.getenv('PATH', '')) > 200 else os.getenv('PATH', 'Not set'),
            'HOME': os.getenv('HOME', 'Not set'),
            'USER': os.getenv('USER', 'Not set'),
            'SHELL': os.getenv('SHELL', 'Not set'),
            'LANG': os.getenv('LANG', 'Not set'),
            'TZ': os.getenv('TZ', 'Not set')
        }
        
        # Add current working directory
        env_vars['CURRENT_DIRECTORY'] = os.getcwd()
        
        # Add Python executable path
        env_vars['PYTHON_EXECUTABLE'] = sys.executable
        
        system_info['environment'] = env_vars
    except Exception as e:
        logger.error(f"Error getting environment variables: {e}")
        system_info['environment'] = {}
    
    return system_info

@app.route('/admin/vacuum', methods=['POST'])
@login_required
@admin_required
def admin_vacuum():
    try:
        with get_db() as conn:
            conn.execute("VACUUM")
        log_activity(current_user.id, 'vacuum_db', 'system')
        create_notification(current_user.id, 'success', 'Database Vacuumed', 'Database has been optimized.')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/logs')
@login_required
@admin_required
def admin_logs():
    """Comprehensive log viewer page"""
    log_type = request.args.get('type', 'hvm')
    lines = int(request.args.get('lines', 100))
    download = request.args.get('download', 'false') == 'true'
    
    log_files = {
        'hvm': 'hvm.log',
        'lxc': '/var/log/lxc/lxc.log',
        'system': '/var/log/syslog',
        'auth': '/var/log/auth.log',
        'kern': '/var/log/kern.log',
        'panel': 'hvm.log'
    }
    
    log_file = log_files.get(log_type, 'hvm.log')
    
    # If it's an AJAX request for log content
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or download:
        try:
            if os.path.exists(log_file):
                with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                    all_lines = f.readlines()
                    last_lines = all_lines[-lines:] if lines > 0 else all_lines
                    log_content = ''.join(last_lines)
                    
                    if download:
                        from datetime import datetime
                        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                        filename = f"{log_type}_logs_{timestamp}.log"
                        response = make_response(log_content)
                        response.headers['Content-Type'] = 'text/plain'
                        response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                        return response
                    
                    return jsonify({
                        'success': True, 
                        'logs': log_content,
                        'file': log_file,
                        'size': os.path.getsize(log_file),
                        'lines_total': len(all_lines),
                        'lines_shown': len(last_lines)
                    })
            else:
                return jsonify({'success': False, 'error': f'Log file not found: {log_file}'})
        except Exception as e:
            logger.error(f"Error reading log file: {e}")
            return jsonify({'success': False, 'error': str(e)})
    
    # Regular page view
    # Get available log files with their info
    available_logs = []
    for name, path in log_files.items():
        if os.path.exists(path):
            try:
                stat = os.stat(path)
                available_logs.append({
                    'name': name,
                    'path': path,
                    'size': stat.st_size,
                    'size_mb': stat.st_size / (1024 * 1024),
                    'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
                })
            except:
                pass
    
    return render_template('admin/logs.html',
                         panel_name=get_setting('site_name', 'ExpelHost Panel'),
                         available_logs=available_logs,
                         current_log=log_type)

# ============================================================================
# Admin - API Management
# ============================================================================

@app.route('/admin/api')
@login_required
@admin_required
def admin_api():
    """API management page"""
    with get_db() as conn:
        cur = conn.cursor()
        
        # Get all API keys
        if current_user.is_main_admin:
            cur.execute('''SELECT ak.*, u.username, u.email 
                          FROM api_keys ak
                          JOIN users u ON ak.user_id = u.id
                          ORDER BY ak.created_at DESC''')
        else:
            cur.execute('''SELECT ak.*, u.username, u.email 
                          FROM api_keys ak
                          JOIN users u ON ak.user_id = u.id
                          WHERE ak.user_id = ?
                          ORDER BY ak.created_at DESC''', (current_user.id,))
        
        api_keys = [dict(row) for row in cur.fetchall()]
        
        # Get users for dropdown (admin only)
        users = []
        if current_user.is_admin:
            cur.execute('SELECT id, username, email FROM users ORDER BY username')
            users = [dict(row) for row in cur.fetchall()]
    
    return render_template('admin/api.html',
                         panel_name=get_setting('site_name', 'ExpelHost Panel'),
                         api_keys=api_keys,
                         users=users)

@app.route('/admin/api/create', methods=['POST'])
@login_required
@admin_required
def admin_api_create():
    """Create new API key"""
    try:
        data = request.get_json() if request.is_json else request.form
        
        name = data.get('name')
        description = data.get('description', '')
        user_id = int(data.get('user_id', current_user.id))
        expires_days = data.get('expires_days')
        
        if not name:
            return jsonify({'success': False, 'error': 'API key name is required'}), 400
        
        # Only admins can create keys for other users
        if not current_user.is_admin and user_id != current_user.id:
            return jsonify({'success': False, 'error': 'Permission denied'}), 403
        
        # Generate API key
        api_key = f"hvmpanel_{secrets.token_urlsafe(48)}"
        
        # Calculate expiration
        expires_at = None
        if expires_days:
            expires_at = (datetime.now() + timedelta(days=int(expires_days))).isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO api_keys 
                          (user_id, key, name, description, is_active, created_at, expires_at)
                          VALUES (?, ?, ?, ?, ?, ?, ?)''',
                       (user_id, api_key, name, description, 1, datetime.now().isoformat(), expires_at))
            conn.commit()
            key_id = cur.lastrowid
        
        log_activity(current_user.id, 'create_api_key', 'api_key', str(key_id), {'name': name})
        
        return jsonify({
            'success': True,
            'message': 'API key created successfully',
            'api_key': api_key,
            'key_id': key_id
        })
    except Exception as e:
        logger.error(f"Error creating API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/api/<int:key_id>/toggle', methods=['POST'])
@login_required
@admin_required
def admin_api_toggle(key_id):
    """Toggle API key active status"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Check ownership
            cur.execute('SELECT user_id, is_active FROM api_keys WHERE id = ?', (key_id,))
            result = cur.fetchone()
            
            if not result:
                return jsonify({'success': False, 'error': 'API key not found'}), 404
            
            if not current_user.is_admin and result['user_id'] != current_user.id:
                return jsonify({'success': False, 'error': 'Permission denied'}), 403
            
            new_status = 0 if result['is_active'] else 1
            cur.execute('UPDATE api_keys SET is_active = ? WHERE id = ?', (new_status, key_id))
            conn.commit()
        
        log_activity(current_user.id, 'toggle_api_key', 'api_key', str(key_id), 
                    {'status': 'active' if new_status else 'inactive'})
        
        return jsonify({
            'success': True,
            'message': f'API key {"activated" if new_status else "deactivated"}',
            'is_active': new_status
        })
    except Exception as e:
        logger.error(f"Error toggling API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/api/<int:key_id>/delete', methods=['POST', 'DELETE'])
@login_required
@admin_required
def admin_api_delete(key_id):
    """Delete API key"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Check ownership
            cur.execute('SELECT user_id FROM api_keys WHERE id = ?', (key_id,))
            result = cur.fetchone()
            
            if not result:
                return jsonify({'success': False, 'error': 'API key not found'}), 404
            
            if not current_user.is_admin and result['user_id'] != current_user.id:
                return jsonify({'success': False, 'error': 'Permission denied'}), 403
            
            cur.execute('DELETE FROM api_keys WHERE id = ?', (key_id,))
            conn.commit()
        
        log_activity(current_user.id, 'delete_api_key', 'api_key', str(key_id))
        
        return jsonify({
            'success': True,
            'message': 'API key deleted successfully'
        })
    except Exception as e:
        logger.error(f"Error deleting API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/emergency-stop-all', methods=['POST'])
@login_required
@admin_required
def admin_emergency_stop_all():
    stopped = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        if vps['status'] == 'running' and not vps['suspended']:
            try:
                run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']} --force", node_id=vps['node_id']))
                update_vps(vps['id'], status='stopped')
                stopped += 1
            except Exception as e:
                logger.error(f"Emergency stop failed for {vps['container_name']}: {e}")
    
    log_activity(current_user.id, 'emergency_stop_all', 'system', None, {'stopped': stopped})
    create_notification(current_user.id, 'warning', 'Emergency Stop', f'Emergency stop completed. {stopped} VPS stopped.')
    return jsonify({'success': True, 'stopped': stopped})

@app.route('/admin/emergency-reboot-all', methods=['POST'])
@login_required
@admin_required
def admin_emergency_reboot_all():
    rebooted = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        if vps['status'] == 'running' and not vps['suspended']:
            try:
                run_sync(execute_lxc(vps['container_name'], f"restart {vps['container_name']}", node_id=vps['node_id']))
                rebooted += 1
            except Exception as e:
                logger.error(f"Emergency reboot failed for {vps['container_name']}: {e}")
    
    log_activity(current_user.id, 'emergency_reboot_all', 'system', None, {'rebooted': rebooted})
    create_notification(current_user.id, 'warning', 'Emergency Reboot', f'Emergency reboot completed. {rebooted} VPS rebooted.')
    return jsonify({'success': True, 'rebooted': rebooted})

@app.route('/admin/clear-suspensions', methods=['POST'])
@login_required
@admin_required
def admin_clear_suspensions():
    cleared = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        if vps['suspended']:
            history = vps.get('suspension_history', [])
            history.append({
                'time': datetime.now().isoformat(),
                'reason': 'Suspension cleared by admin',
                'by': current_user.username
            })
            update_vps(vps['id'], suspended=0, status='stopped', suspended_reason=None, suspension_history=history)
            cleared += 1
            create_notification(vps['user_id'], 'success', 'VPS Unsuspended', f'Your VPS {vps["container_name"]} has been unsuspended.')
    
    log_activity(current_user.id, 'clear_suspensions', 'system', None, {'cleared': cleared})
    return jsonify({'success': True, 'cleared': cleared})

@app.route('/admin/reset-ports', methods=['POST'])
@login_required
@admin_required
def admin_reset_ports():
    recreated = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        try:
            count = run_sync(recreate_port_forwards(vps['container_name']))
            recreated += count
        except Exception as e:
            logger.error(f"Port reset failed for {vps['container_name']}: {e}")
    
    log_activity(current_user.id, 'reset_ports', 'system', None, {'recreated': recreated})
    return jsonify({'success': True, 'recreated': recreated})

@app.route('/admin/node/<int:node_id>')
@login_required
@admin_required
def admin_node_get(node_id):
    node = get_node(node_id)
    if not node:
        return jsonify({'error': 'Node not found'}), 404
    
    return jsonify(node)

@app.route('/admin/nodes/<int:node_id>/check')
@login_required
@admin_required
def admin_node_check(node_id):
    try:
        node = get_node(node_id)
        if not node:
            return jsonify({'success': False, 'error': 'Node not found'}), 404
        
        logger.info(f"Checking node {node_id}: {node['name']}")
        
        # Get node status
        try:
            status = run_sync(get_node_status(node_id))
            logger.info(f"Node {node_id} status: {status.get('status', 'unknown')}")
        except Exception as e:
            logger.error(f"Failed to get status for node {node_id}: {e}")
            status = {'status': 'Error', 'online': False}
        
        # Get host stats
        try:
            stats = run_sync(get_host_stats(node_id))
            logger.info(f"Node {node_id} stats retrieved successfully")
        except Exception as e:
            logger.error(f"Failed to get stats for node {node_id}: {e}")
            stats = {"cpu": 0.0, "ram": {'percent': 0.0}, "disk": {'percent': 'Unknown'}, "uptime": "Unknown"}
        
        # Get VPS count
        try:
            vps_count = get_current_vps_count(node_id)
        except Exception as e:
            logger.error(f"Failed to get VPS count for node {node_id}: {e}")
            vps_count = 0
        
        # Get storage pools
        try:
            pools = run_sync(execute_lxc("", "storage list", node_id=node_id, timeout=10))
        except Exception as e:
            logger.debug(f"Failed to get storage pools for node {node_id}: {e}")
            pools = None
        
        # Get networks
        try:
            networks = run_sync(execute_lxc("", "network list", node_id=node_id, timeout=10))
        except Exception as e:
            logger.debug(f"Failed to get networks for node {node_id}: {e}")
            networks = None
        
        return jsonify({
            'success': True,
            'id': node['id'],
            'name': node['name'],
            'status': status,
            'online': status.get('online', False),
            'stats': stats,
            'vps_count': vps_count,
            'total_vps': node['total_vps'],
            'pools': pools,
            'networks': networks,
            'ip_addresses': node.get('ip_addresses', []),
            'ip_aliases': node.get('ip_aliases', [])
        })
    
    except Exception as e:
        logger.error(f"Error checking node {node_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/nodes/<int:node_id>/view')
@login_required
@admin_required
def admin_node_view(node_id):
    """Detailed node view with comprehensive system information"""
    try:
        node = get_node(node_id)
        if not node:
            flash('Node not found', 'danger')
            return redirect(url_for('admin_nodes'))
        
        # Get node status
        status = run_sync(get_node_status(node_id))
        
        # Get basic stats
        stats = run_sync(get_host_stats(node_id))
        
        # Get VPS count
        vps_count = get_current_vps_count(node_id)
        
        # Get detailed system information
        system_info = {}
        
        if node['is_local']:
            # Local node - get detailed info directly
            try:
                # CPU info
                cpu_info_cmd = "lscpu | grep -E 'Model name|CPU\\(s\\)|Thread|Core|Socket|MHz'"
                cpu_info = subprocess.run(cpu_info_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['cpu_details'] = cpu_info.stdout if cpu_info.returncode == 0 else "N/A"
                
                # Memory info
                mem_info_cmd = "free -h | grep -E 'Mem|Swap'"
                mem_info = subprocess.run(mem_info_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['memory_details'] = mem_info.stdout if mem_info.returncode == 0 else "N/A"
                
                # OS info
                os_info_cmd = "cat /etc/os-release | grep -E 'PRETTY_NAME|VERSION'"
                os_info = subprocess.run(os_info_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['os_details'] = os_info.stdout if os_info.returncode == 0 else "N/A"
                
                # Kernel info
                kernel_cmd = "uname -r"
                kernel_info = subprocess.run(kernel_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['kernel'] = kernel_info.stdout.strip() if kernel_info.returncode == 0 else "N/A"
                
                # Disk info
                disk_cmd = "df -h | grep -E '^/dev/'"
                disk_info = subprocess.run(disk_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['disk_details'] = disk_info.stdout if disk_info.returncode == 0 else "N/A"
                
            except Exception as e:
                logger.error(f"Error getting local system info: {e}")
        else:
            # Remote node - get info via API
            try:
                import requests
                headers = {"X-API-Key": node["api_key"]}
                verify_ssl = bool(node.get('verify_ssl', 1))
                
                # Get system info from node agent
                response = requests.get(f"{node['url']}/api/info", headers=headers, timeout=10, verify=verify_ssl)
                if response.status_code == 200:
                    info = response.json()
                    system_info['version'] = info.get('version', 'N/A')
                    system_info['python_version'] = info.get('python_version', 'N/A')
                
                # Try to get detailed info via execute
                try:
                    cpu_details = run_sync(execute_lxc("", "exec -- lscpu | grep -E 'Model name|CPU\\(s\\)|Thread|Core|Socket|MHz'", node_id=node_id, timeout=10))
                    system_info['cpu_details'] = cpu_details
                except:
                    system_info['cpu_details'] = "N/A"
                
                try:
                    os_details = run_sync(execute_lxc("", "exec -- cat /etc/os-release | grep -E 'PRETTY_NAME|VERSION'", node_id=node_id, timeout=10))
                    system_info['os_details'] = os_details
                except:
                    system_info['os_details'] = "N/A"
                
                try:
                    kernel = run_sync(execute_lxc("", "exec -- uname -r", node_id=node_id, timeout=10))
                    system_info['kernel'] = kernel.strip()
                except:
                    system_info['kernel'] = "N/A"
                    
            except Exception as e:
                logger.error(f"Error getting remote system info: {e}")
        
        # Get storage pools
        try:
            pools = run_sync(execute_lxc("", "storage list", node_id=node_id, timeout=10))
        except:
            pools = None
        
        # Get networks
        try:
            networks = run_sync(execute_lxc("", "network list", node_id=node_id, timeout=10))
        except:
            networks = None
        
        # Get list of VPS on this node
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM vps WHERE node_id = ? ORDER BY created_at DESC', (node_id,))
            vps_list = [dict(row) for row in cur.fetchall()]
        
        return render_template('admin/node_view.html',
                             panel_name=get_setting('site_name', 'ExpelHost Panel'),
                             node=node,
                             status=status,
                             stats=stats,
                             vps_count=vps_count,
                             vps_list=vps_list,
                             system_info=system_info,
                             pools=pools,
                             networks=networks)
    
    except Exception as e:
        logger.error(f"Error viewing node {node_id}: {e}", exc_info=True)
        flash(f'Error loading node details: {str(e)}', 'danger')
        return redirect(url_for('admin_nodes'))

@app.route('/admin/user/create', methods=['POST'])
@login_required
@admin_required
def admin_user_create():
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    is_admin = request.form.get('is_admin') == 'true'
    port_quota = int(request.form.get('port_quota', 5))
    
    if not username or not email or not password:
        return jsonify({'success': False, 'error': 'Missing fields'}), 400
    
    if User.get_by_username(username):
        return jsonify({'success': False, 'error': 'Username exists'}), 400
    
    if User.get_by_email(email):
        return jsonify({'success': False, 'error': 'Email exists'}), 400
    
    password_hash = generate_password_hash(password)
    api_key = generate_api_key()
    now = datetime.now().isoformat()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''INSERT INTO users 
            (username, email, password_hash, is_admin, created_at, last_login, api_key, preferences)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
            (username, email, password_hash, 1 if is_admin else 0, now, now, api_key, '{}'))
        user_id = cur.lastrowid
        
        if port_quota > 0:
            cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)',
                       (user_id, port_quota, 0, now))
        
        conn.commit()
    
    log_activity(current_user.id, 'create_user', 'user', str(user_id), {'username': username})
    create_notification(user_id, 'success', 'Welcome!', f'Your account has been created by an administrator.')
    return jsonify({'success': True, 'user_id': user_id})

@app.route('/admin/user/<int:user_id>/regenerate-api', methods=['POST'])
@login_required
@admin_required
def admin_user_regenerate_api(user_id):
    new_key = generate_api_key()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET api_key = ? WHERE id = ?', (new_key, user_id))
        conn.commit()
    
    log_activity(current_user.id, 'regenerate_user_api', 'user', str(user_id))
    create_notification(user_id, 'warning', 'API Key Regenerated', 'Your API key has been regenerated by an administrator.')
    return jsonify({'success': True, 'api_key': new_key})

@app.route('/admin/users/<int:user_id>/reset-password', methods=['POST'])
@login_required
@admin_required
def admin_user_reset_password(user_id):
    password = request.form.get('password')
    
    if not password or len(password) < 8:
        return jsonify({'success': False, 'error': 'Invalid password'}), 400
    
    password_hash = generate_password_hash(password)
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET password_hash = ? WHERE id = ?', (password_hash, user_id))
        conn.commit()
    
    log_activity(current_user.id, 'reset_user_password', 'user', str(user_id))
    create_notification(user_id, 'warning', 'Password Reset', 'Your password has been reset by an administrator.')
    return jsonify({'success': True})

@app.route('/share/vps/<int:vps_id>', methods=['POST'])
@login_required
def share_vps(vps_id):
    """Share VPS access with another user"""
    try:
        logger.info(f"=== Share VPS Request: VPS ID {vps_id}, User {current_user.id} ===")
        
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
            
        if vps['user_id'] != current_user.id and not current_user.is_admin:
            logger.error(f"Access denied: VPS owner is {vps['user_id']}, requester is {current_user.id}")
            return jsonify({'success': False, 'error': 'Access denied - you are not the owner'}), 403
        
        # Get username from form data or JSON
        username = request.form.get('username') or (request.json.get('username') if request.is_json else None)
        if not username:
            logger.error("No username provided")
            return jsonify({'success': False, 'error': 'Username required'}), 400
        
        logger.info(f"Attempting to share with username: {username}")
        
        # Find user by username
        user = User.get_by_username(username)
        if not user:
            logger.error(f"User '{username}' not found")
            return jsonify({'success': False, 'error': f'User "{username}" not found'}), 404
        
        logger.info(f"Found user: {user.username} (ID: {user.id})")
        
        # Check if trying to share with self
        if user.id == current_user.id or user.id == vps['user_id']:
            logger.error("Attempted to share with self/owner")
            return jsonify({'success': False, 'error': 'Cannot add yourself or the owner to the team'}), 400
        
        # Get current shared_with list
        shared_with = vps.get('shared_with', []) or []
        if not isinstance(shared_with, list):
            shared_with = []
        
        logger.info(f"Current shared_with list: {shared_with}")
        
        # Check if already shared
        if str(user.id) in [str(uid) for uid in shared_with]:
            logger.warning(f"VPS already shared with user {user.id}")
            return jsonify({'success': False, 'error': f'VPS already shared with {username}'}), 400
        
        # Role for the new team member (viewer = read-only, operator = can control)
        role = str(request.form.get('role') or (request.json.get('role') if request.is_json else None) or 'operator').lower()
        if role not in TEAM_ROLES:
            return jsonify({'success': False, 'error': 'Role must be viewer or operator'}), 400

        # Add user to shared list
        shared_with.append(str(user.id))
        logger.info(f"New shared_with list: {shared_with}")
        
        # Update VPS (+ remember the role in metadata)
        meta = dict(vps.get('metadata') or {})
        roles = dict(meta.get('team_roles') or {})
        roles[str(user.id)] = role
        meta['team_roles'] = roles
        update_vps(vps_id, shared_with=shared_with, metadata=meta)
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"After update, shared_with in DB: {updated_vps.get('shared_with', [])}")
        
        # Log and notify
        log_activity(current_user.id, 'share_vps', 'vps', str(vps_id), {'shared_with': user.id, 'username': username, 'role': role})
        create_notification(user.id, 'info', 'VPS Shared', f'{current_user.username} shared VPS {vps["container_name"]} with you as {role}.')
        
        logger.info(f"Successfully shared VPS {vps_id} with user {user.id} ({username})")
        return jsonify({'success': True, 'message': f'{username} added as {role}'})
        
    except Exception as e:
        logger.error(f"Error sharing VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': f'Failed to share VPS: {str(e)}'}), 500

@app.route('/unshare/vps/<int:vps_id>', methods=['POST'])
@login_required
def unshare_vps(vps_id):
    """Remove VPS access from a user"""
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
            
        if vps['user_id'] != current_user.id and not current_user.is_admin:
            return jsonify({'success': False, 'error': 'Access denied - you are not the owner'}), 403
        
        # Get user_id from form data or JSON
        user_id = request.form.get('user_id') or (request.json.get('user_id') if request.is_json else None)
        if not user_id:
            return jsonify({'success': False, 'error': 'User ID required'}), 400
        
        # Get current shared_with list
        shared_with = vps.get('shared_with', []) or []
        if not isinstance(shared_with, list):
            shared_with = []
        
        # Convert to string for comparison
        user_id_str = str(user_id)
        
        # Check if user is in shared list
        if user_id_str not in [str(uid) for uid in shared_with]:
            return jsonify({'success': False, 'error': 'VPS not shared with this user'}), 400
        
        # Remove user from shared list
        shared_with = [uid for uid in shared_with if str(uid) != user_id_str]
        meta = dict(vps.get('metadata') or {})
        roles = dict(meta.get('team_roles') or {})
        roles.pop(user_id_str, None)
        meta['team_roles'] = roles
        update_vps(vps_id, shared_with=shared_with, metadata=meta)
        
        # Log and notify
        log_activity(current_user.id, 'unshare_vps', 'vps', str(vps_id), {'unshared': user_id})
        create_notification(int(user_id), 'info', 'VPS Unshared', f'{current_user.username} removed your access to VPS {vps["container_name"]}.')
        
        logger.info(f"VPS {vps_id} unshared from user {user_id} by {current_user.id}")
        return jsonify({'success': True, 'message': 'Access removed successfully'})
        
    except Exception as e:
        logger.error(f"Error unsharing VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': f'Failed to remove access: {str(e)}'}), 500

# ============================================================================
# API Routes
# ============================================================================
@app.route('/api/ping', methods=['GET'])
def api_ping():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    return jsonify({'status': 'ok', 'time': datetime.now().isoformat()})

@app.route('/api/execute', methods=['POST'])
def api_execute():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.get_json()
    command = data.get('command')
    
    if not command:
        return jsonify({'error': 'Command required'}), 400
    
    try:
        cmd = shlex.split(command)
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        return jsonify({
            'stdout': proc.stdout,
            'stderr': proc.stderr,
            'returncode': proc.returncode
        })
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Command timed out'}), 504
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/get_host_stats', methods=['GET'])
def api_get_host_stats():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    return jsonify({
        'cpu': get_host_cpu_usage(),
        'ram': get_host_ram_usage(),
        'disk': get_host_disk_usage(),
        'uptime': get_host_uptime(),
        'cpu_cores': os.cpu_count()
    })

@app.route('/api/get_container_stats', methods=['POST'])
def api_get_container_stats():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.get_json()
    container = data.get('container')
    
    if not container:
        return jsonify({'error': 'Container name required'}), 400
    
    try:
        status = run_sync(get_container_status(container, node['id']))
        cpu = run_sync(get_container_cpu_pct_local(container, node['id']))
        ram = run_sync(get_container_ram_local(container, node['id']))
        disk = run_sync(get_container_disk_local(container, node['id']))
        uptime = run_sync(get_container_uptime_local(container, node['id']))
        processes = run_sync(get_container_processes_local(container, node['id']))
        network = run_sync(get_container_network_local(container, node['id']))
        
        return jsonify({
            'status': status,
            'cpu': cpu,
            'ram': ram,
            'disk': disk,
            'uptime': uptime,
            'processes': processes,
            'network': network
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Resource Monitor Thread
# ============================================================================
resource_monitor_active = True

def resource_monitor():
    global resource_monitor_active
    backup_interval = AUTO_BACKUP_INTERVAL
    last_backup = time.time()
    last_stats_update = time.time()
    stats_cache = {}
    
    while resource_monitor_active:
        try:
            current_time = time.time()
            
            if current_time - last_stats_update >= 60:
                nodes = get_nodes()
                for node in nodes:
                    try:
                        stats = run_sync(get_host_stats(node['id']))
                        stats_cache[node['id']] = stats
                        
                        cpu = stats.get('cpu', 0)
                        ram = stats.get('ram', {}).get('percent', 0)
                        logger.info(f"Node {node['name']}: CPU {cpu:.1f}%, RAM {ram:.1f}%")
                        
                        cpu_threshold = int(get_setting('cpu_threshold', 90))
                        ram_threshold = int(get_setting('ram_threshold', 90))
                        
                        if cpu > cpu_threshold or ram > ram_threshold:
                            logger.warning(f"Node {node['name']} exceeded thresholds (CPU: {cpu:.1f}%, RAM: {ram:.1f}%).")
                            
                            if socketio:
                                socketio.emit('node_alert', {
                                    'node_id': node['id'],
                                    'node_name': node['name'],
                                    'cpu': cpu,
                                    'ram': ram
                                }, room='admins')
                                
                    except Exception as e:
                        logger.error(f"Error monitoring node {node.get('name', 'Unknown')}: {e}")
                
                last_stats_update = current_time
            
            # Shared hosting: enforce per-account RAM/disk limits every 60s
            if int(current_time) % 60 == 0:
                try:
                    shared_quota_check()
                except Exception as e:
                    logger.error(f"Shared quota check error: {e}")
            
            if int(current_time) % 300 == 0:
                try:
                    vps_list = get_all_vps()
                    for vps in vps_list:
                        if is_vps_whitelisted(vps) or is_vps_suspended(vps):
                            continue
                        if is_shared_vps(vps):
                            continue  # shared VPS never LXC-suspends; accounts are limited individually
                            
                        if vps['status'] == 'running':
                            try:
                                stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
                                cpu = stats.get('cpu', 0)
                                ram = stats.get('ram', {}).get('pct', 0)
                                
                                cpu_threshold = int(get_setting('cpu_threshold', 90))
                                ram_threshold = int(get_setting('ram_threshold', 90))
                                
                                if cpu > cpu_threshold or ram > ram_threshold:
                                    reason = f"Auto-suspended: High resource usage (CPU {cpu:.1f}%, RAM {ram:.1f}%)"
                                    run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']} --force", node_id=vps['node_id']))
                                    
                                    history = vps['suspension_history']
                                    history.append({
                                        'time': datetime.now().isoformat(),
                                        'reason': reason,
                                        'by': 'Auto Monitor'
                                    })
                                    
                                    update_vps(vps['id'], suspended=1, status='stopped', 
                                              suspension_history=history, suspended_reason=reason)
                                    logger.info(f"Auto-suspended {vps['container_name']}: {reason}")
                                    log_activity(None, 'auto_suspend', 'vps', str(vps['id']), {'reason': reason})
                                    create_notification(vps['user_id'], 'warning', 'VPS Auto-Suspended', 
                                                      f'Your VPS {vps["container_name"]} has been suspended due to high resource usage.')
                                    
                                    if socketio:
                                        socketio.emit('vps_suspended', {
                                            'vps_id': vps['id'],
                                            'reason': reason
                                        }, room=f'vps_{vps["id"]}')
                                        
                            except Exception as e:
                                logger.error(f"Auto resource check error for {vps['container_name']}: {e}")
                except Exception as e:
                    logger.error(f"Auto resource check error: {e}")
            
            # Check for expired VPS and auto-suspend them
            if int(current_time) % 600 == 0:  # Check every 10 minutes
                try:
                    with get_db() as conn:
                        cur = conn.cursor()
                        now = datetime.now().isoformat()
                        
                        # Find all VPS that have expired and need auto-suspension
                        cur.execute('''SELECT id, user_id, container_name, node_id, expires_at, expiration_days, hostname, vps_type
                                      FROM vps 
                                      WHERE auto_suspend_enabled = 1 
                                      AND suspended = 0 
                                      AND expires_at IS NOT NULL 
                                      AND expires_at <= ?''', (now,))
                        
                        expired_vps_list = [dict(row) for row in cur.fetchall()]
                        
                        for vps in expired_vps_list:
                            try:
                                # Stop the VPS (shared hosting has no container to stop)
                                if is_shared_vps(vps):
                                    reason = f"Auto-suspended: Shared VPS expired after {vps['expiration_days']} days"
                                else:
                                    run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']} --force", node_id=vps['node_id']))
                                    reason = f"Auto-suspended: VPS expired after {vps['expiration_days']} days"
                                
                                # Update suspension history
                                cur.execute('SELECT suspension_history FROM vps WHERE id = ?', (vps['id'],))
                                history_row = cur.fetchone()
                                history = json.loads(history_row[0]) if history_row and history_row[0] else []
                                history.append({
                                    'time': now,
                                    'reason': reason,
                                    'by': 'Auto Expiration System'
                                })
                                
                                # Update VPS status
                                cur.execute('''UPDATE vps 
                                              SET suspended = 1, status = 'stopped', 
                                              suspended_reason = ?, suspension_history = ?, updated_at = ?
                                              WHERE id = ?''',
                                           (reason, json.dumps(history), now, vps['id']))
                                conn.commit()
                                
                                logger.info(f"Auto-suspended expired VPS: {vps['container_name']}")
                                log_activity(None, 'auto_suspend_expired', 'vps', str(vps['id']), 
                                           {'reason': reason, 'expiration_days': vps['expiration_days']})
                                
                                create_notification(vps['user_id'], 'warning', 'VPS Expired and Suspended', 
                                                  f'Your VPS {vps["hostname"]} has been suspended because it expired after {vps["expiration_days"]} days. Contact admin for renewal.')
                                
                                if socketio:
                                    socketio.emit('vps_expired', {
                                        'vps_id': vps['id'],
                                        'container_name': vps['container_name'],
                                        'reason': reason
                                    }, room=f'user_{vps["user_id"]}')
                                    
                            except Exception as e:
                                logger.error(f"Failed to auto-suspend expired VPS {vps['container_name']}: {e}")
                        
                        # Send warning notifications for VPS expiring soon (3 days before)
                        warning_date = (datetime.now() + timedelta(days=3)).isoformat()
                        cur.execute('''SELECT id, user_id, container_name, expires_at, expiration_days, hostname
                                      FROM vps 
                                      WHERE auto_suspend_enabled = 1 
                                      AND suspended = 0 
                                      AND expires_at IS NOT NULL 
                                      AND expires_at <= ? 
                                      AND expires_at > ?''', (warning_date, now))
                        
                        expiring_soon = [dict(row) for row in cur.fetchall()]
                        
                        for vps in expiring_soon:
                            try:
                                expires_dt = datetime.fromisoformat(vps['expires_at'])
                                days_left = (expires_dt - datetime.now()).days
                                
                                create_notification(vps['user_id'], 'info', 'VPS Expiring Soon', 
                                                  f'Your VPS {vps["hostname"]} will expire in {days_left} days. Contact admin for renewal.',
                                                  expires_in=86400)  # Notification expires in 1 day
                                
                            except Exception as e:
                                logger.error(f"Failed to send expiration warning for VPS {vps['container_name']}: {e}")
                                
                except Exception as e:
                    logger.error(f"Auto expiration check error: {e}")
            
            if get_setting('backup_enabled', '1') == '1' and current_time - last_backup > backup_interval:
                backup_name = f"hvm_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                backup_path = os.path.join('backups', backup_name)
                try:
                    os.makedirs('backups', exist_ok=True)
                    shutil.copy(DATABASE_PATH, backup_path)
                    if os.path.exists(f"{DATABASE_PATH}-wal"):
                        shutil.copy(f"{DATABASE_PATH}-wal", f"{backup_path}-wal")
                    if os.path.exists(f"{DATABASE_PATH}-shm"):
                        shutil.copy(f"{DATABASE_PATH}-shm", f"{backup_path}-shm")
                    logger.info(f"Database backup created: {backup_name}")
                    
                    backup_retention = int(get_setting('backup_retention', '7'))
                    backups = sorted([f for f in os.listdir('backups') if f.endswith('.db')])
                    while len(backups) > backup_retention:
                        old_backup = os.path.join('backups', backups.pop(0))
                        os.remove(old_backup)
                        if os.path.exists(f"{old_backup}-wal"):
                            os.remove(f"{old_backup}-wal")
                        if os.path.exists(f"{old_backup}-shm"):
                            os.remove(f"{old_backup}-shm")
                        logger.info(f"Removed old backup: {old_backup}")
                    
                    last_backup = current_time
                except Exception as e:
                    logger.error(f"Failed to create DB backup: {e}")
            
            try:
                with get_db() as conn:
                    cur = conn.cursor()
                    cur.execute('DELETE FROM notifications WHERE expires_at IS NOT NULL AND expires_at < ?',
                               (datetime.now().isoformat(),))
                    if cur.rowcount > 0:
                        logger.info(f"Cleaned {cur.rowcount} expired notifications")
            except Exception as e:
                logger.error(f"Failed to clean notifications: {e}")
            
            time.sleep(30)
        except Exception as e:
            logger.error(f"Error in resource monitor: {e}")
            time.sleep(60)

# ============================================================================
# Error Handlers
# ============================================================================
@app.errorhandler(404)
def not_found_error(error):
    if request.is_json or request.headers.get('Content-Type') == 'application/json':
        return jsonify({'success': False, 'error': 'Not found'}), 404
    return render_template('errors/404.html', panel_name=get_setting('site_name', 'ExpelHost Panel')), 404

@app.errorhandler(500)
def internal_error(error):
    if request.is_json or request.headers.get('Content-Type') == 'application/json':
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    return render_template('errors/500.html', panel_name=get_setting('site_name', 'ExpelHost Panel')), 500

@app.errorhandler(403)
def forbidden_error(error):
    if request.is_json or request.headers.get('Content-Type') == 'application/json':
        return jsonify({'success': False, 'error': 'Forbidden'}), 403
    return render_template('errors/403.html', panel_name=get_setting('site_name', 'ExpelHost Panel')), 403

@app.errorhandler(401)
def unauthorized_error(error):
    if request.is_json or request.headers.get('Content-Type') == 'application/json':
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    flash('Please log in to access this page', 'warning')
    return redirect(url_for('login'))

# ============================================================================
# Static file serving
# ============================================================================
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/favicon.ico')
def favicon():
    favicon_path = get_setting('favicon', '/static/img/favicon.ico')
    if favicon_path.startswith('/static/'):
        return send_from_directory('static', favicon_path.replace('/static/', ''))
    return send_from_directory('static/img', 'favicon.ico')

# ============================================================================
# Health check endpoint
# ============================================================================
@app.route('/health')
def health_check():
    try:
        with get_db() as conn:
            conn.execute('SELECT 1')
        db_status = 'ok'
    except:
        db_status = 'error'
    
    try:
        lxc_check = subprocess.run(['lxc', '--version'], capture_output=True, text=True, timeout=5)
        lxc_status = 'ok' if lxc_check.returncode == 0 else 'error'
    except:
        lxc_status = 'error'
    
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'database': db_status,
        'lxc': lxc_status,
        'version': PANEL_VERSION,
        'uptime': get_host_uptime()
    })

@app.route('/api/test/vps/<int:vps_id>')
@login_required
def test_vps_data(vps_id):
    """Test endpoint to check VPS data"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'error': 'VPS not found'}), 404
    
    return jsonify({
        'vps_id': vps['id'],
        'container_name': vps['container_name'],
        'suspended': vps.get('suspended'),
        'suspended_type': str(type(vps.get('suspended'))),
        'whitelisted': vps.get('whitelisted'),
        'whitelisted_type': str(type(vps.get('whitelisted'))),
        'os_version': vps.get('os_version'),
        'status': vps.get('status'),
        'is_suspended_check': is_vps_suspended(vps),
        'is_whitelisted_check': is_vps_whitelisted(vps)
    })

# ============================================================================
# Template filters
# ============================================================================
@app.template_filter('relative_time')
def relative_time_filter(dt):
    return relativeTime(dt)

@app.template_filter('parse_datetime')
def parse_datetime_filter(dt_string):
    """Parse ISO datetime string to datetime object"""
    if not dt_string:
        return None
    try:
        return datetime.fromisoformat(dt_string)
    except:
        return None

@app.template_filter('json_loads')
def json_loads_filter(s):
    if s:
        try:
            return json.loads(s)
        except:
            return {}
    return {}

@app.template_filter('get_os_icon')
def get_os_icon_filter(icon_name):
    icons = {
        'ubuntu': 'fab fa-ubuntu',
        'debian': 'fab fa-debian',
        'centos': 'fab fa-centos',
        'alpine': 'fas fa-mountain',
        'fedora': 'fab fa-fedora',
        'rocky': 'fas fa-mountain',
        'default': 'fab fa-linux'
    }
    return icons.get(icon_name, icons['default'])
    
@app.template_filter('format_bytes')
def format_bytes_filter(bytes):
    if not bytes:
        return '0 B'
    
    bytes = float(bytes)
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024.0:
            return f"{bytes:.1f} {unit}"
        bytes /= 1024.0
    return f"{bytes:.1f} PB"

@app.template_filter('truncate')
def truncate_filter(s, length=50):
    if not s:
        return ""

    s = str(s)

    if len(s) <= length:
        return s

    return s[:length] + "..."

# ============================================================================
# Scheduled Power Actions (admin-managed)
#   - default rule: restart every VPS daily at 04:00 (all 7 days, weekends
#     included - there is NO weekend stop rule)
#   - admins can add / edit / disable / delete / "run now" from /admin/schedules
# ============================================================================
POWER_ACTIONS = ('restart', 'stop', 'start')
SCHEDULE_GRACE_MINUTES = 10      # still run if the panel was down at the exact minute
SCHEDULE_STAGGER_SECONDS = 2     # pause between VPS so a node is not hammered
DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']   # index == datetime.weekday()
power_scheduler_active = True


def migrate_power_schedules():
    """Create the power_schedules table and seed the default 04:00 daily reboot once."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS power_schedules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            action TEXT NOT NULL DEFAULT 'restart',
            run_time TEXT NOT NULL DEFAULT '04:00',
            days TEXT NOT NULL DEFAULT '0,1,2,3,4,5,6',
            target TEXT NOT NULL DEFAULT 'all',
            exclude_vps TEXT DEFAULT '',
            enabled INTEGER NOT NULL DEFAULT 1,
            last_run_at TEXT,
            last_result TEXT,
            created_by INTEGER,
            created_at TEXT NOT NULL
        )''')
        cur.execute("SELECT value FROM settings WHERE key = 'power_schedule_seeded'")
        if not cur.fetchone():
            cur.execute('SELECT COUNT(*) FROM power_schedules')
            if cur.fetchone()[0] == 0:
                cur.execute('''INSERT INTO power_schedules
                    (name, action, run_time, days, target, exclude_vps, enabled, created_at)
                    VALUES (?, 'restart', '04:00', '0,1,2,3,4,5,6', 'all', '', 1, ?)''',
                    ('Daily reboot 04:00', datetime.now().isoformat()))
            cur.execute('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
                        ('power_schedule_seeded', '1', datetime.now().isoformat()))
        conn.commit()


def _parse_days(value) -> set:
    out = set()
    for part in str(value or '').split(','):
        part = part.strip()
        if part.isdigit() and 0 <= int(part) <= 6:
            out.add(int(part))
    return out


def _parse_id_set(value) -> set:
    return {int(p) for p in str(value or '').replace(' ', '').split(',') if p.isdigit()}


def _normalize_hhmm(value) -> Optional[str]:
    m = re.fullmatch(r'([01]?\d|2[0-3]):([0-5]\d)', str(value or '').strip())
    return f"{int(m.group(1)):02d}:{m.group(2)}" if m else None


def _days_label(days: set) -> str:
    if len(days) == 7:
        return 'Every day'
    if not days:
        return 'Never'
    return ', '.join(DAY_NAMES[d] for d in sorted(days))


def _next_run_at(sch: Dict, now: Optional[datetime] = None) -> Optional[datetime]:
    if not sch.get('enabled'):
        return None
    now = now or datetime.now()
    days = _parse_days(sch.get('days'))
    hhmm = _normalize_hhmm(sch.get('run_time'))
    if not days or not hhmm:
        return None
    h, m = map(int, hhmm.split(':'))
    for offset in range(0, 8):
        cand = (now + timedelta(days=offset)).replace(hour=h, minute=m, second=0, microsecond=0)
        if cand > now and cand.weekday() in days:
            return cand
    return None


def get_power_schedules() -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM power_schedules ORDER BY run_time, id')
        return [dict(r) for r in cur.fetchall()]


def get_schedule_targets(sch: Dict) -> List[Dict]:
    """Dedicated, non-suspended VPS a schedule applies to (shared hosting is always-on)."""
    excluded = _parse_id_set(sch.get('exclude_vps'))
    targets = []
    for v in get_all_vps():
        if is_shared_vps(v) or is_vps_suspended(v) or v['id'] in excluded:
            continue
        if str(sch.get('target') or 'all') != 'all' and str(v['id']) != str(sch['target']):
            continue
        targets.append(v)
    return targets


def _run_power_action(vps: Dict, action: str) -> Tuple[str, str]:
    """Run one power action on one VPS. Returns (status, message): ok | skipped | failed."""
    name, node_id, vps_id = vps['container_name'], vps['node_id'], vps['id']
    try:
        live = vps.get('status')
        try:
            stats = run_sync(get_container_stats(name, node_id)) or {}
            if stats.get('status') in ('running', 'stopped', 'frozen'):
                live = stats['status']
        except Exception:
            pass  # fall back to the status stored in the DB
        if live == 'frozen':
            return 'skipped', 'VPS is frozen'
        if action in ('restart', 'stop') and live != 'running':
            return 'skipped', 'VPS is not running'
        if action == 'start' and live == 'running':
            return 'skipped', 'VPS is already running'

        if action == 'restart':
            run_sync(execute_lxc(name, f"restart {name}", node_id=node_id))
        elif action == 'stop':
            run_sync(execute_lxc(name, f"stop {name}", node_id=node_id))
        else:
            run_sync(execute_lxc(name, f"start {name}", node_id=node_id))

        if action in ('restart', 'start'):
            run_sync(apply_internal_permissions(name, node_id))
            try:
                run_sync(recreate_port_forwards(name))
            except Exception as pf_err:
                logger.warning(f"Port forward recreation failed for {name}: {pf_err}")
            update_vps(vps_id, status='running', last_started=datetime.now().isoformat())
            new_status = 'running'
        else:
            update_vps(vps_id, status='stopped', last_stopped=datetime.now().isoformat())
            new_status = 'stopped'

        if socketio:
            socketio.emit('vps_status_change', {'vps_id': vps_id, 'status': new_status}, room=f'vps_{vps_id}')
        return 'ok', f'{action} completed'
    except Exception as e:
        logger.error(f"Scheduled {action} failed for {name}: {e}")
        return 'failed', str(e)[:200]


def execute_power_schedule(sch: Dict, trigger: str = 'schedule') -> Dict:
    """Apply a schedule to all of its target VPS. Safe to call from any thread."""
    counts = {'ok': 0, 'skipped': 0, 'failed': 0}
    action = sch['action'] if sch.get('action') in POWER_ACTIONS else 'restart'
    notify = get_setting('power_schedule_notify', '1') == '1'
    verb = {'restart': 'restarted', 'stop': 'stopped', 'start': 'started'}[action]
    targets = get_schedule_targets(sch)
    logger.info(f"Power schedule '{sch.get('name')}' ({trigger}): {action} on {len(targets)} VPS")

    for vps in targets:
        status, msg = _run_power_action(vps, action)
        counts[status] += 1
        if status in ('ok', 'failed'):
            log_activity(None, f'scheduled_{action}_vps', 'vps', str(vps['id']),
                         {'schedule': sch.get('name'), 'trigger': trigger, 'status': status,
                          'message': msg})
            if status == 'ok' and notify:
                create_notification(vps['user_id'], 'info', 'Scheduled maintenance',
                                    f"VPS {vps.get('hostname') or vps['container_name']} was {verb} "
                                    f"by the scheduled task \"{sch.get('name')}\".")
            elif status == 'failed':
                create_notification(vps['user_id'], 'error', 'Scheduled maintenance failed',
                                    f"Scheduled {action} of VPS {vps.get('hostname') or vps['container_name']} failed: {msg}")
            time.sleep(SCHEDULE_STAGGER_SECONDS)

    summary = (f"{datetime.now().strftime('%Y-%m-%d %H:%M')} ({trigger}): "
               f"{counts['ok']} {verb}, {counts['skipped']} skipped, {counts['failed']} failed")
    try:
        with get_db() as conn:
            conn.execute('UPDATE power_schedules SET last_result = ? WHERE id = ?', (summary, sch['id']))
            conn.commit()
    except Exception as e:
        logger.error(f"Could not store schedule result: {e}")
    return counts


def run_due_power_schedules(now: Optional[datetime] = None) -> int:
    """Start every enabled schedule that is due right now. Returns how many were started."""
    now = now or datetime.now()
    started = 0
    for sch in get_power_schedules():
        if not sch['enabled']:
            continue
        hhmm = _normalize_hhmm(sch['run_time'])
        if not hhmm or now.weekday() not in _parse_days(sch['days']):
            continue
        h, m = map(int, hhmm.split(':'))
        due_at = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if now < due_at or now - due_at > timedelta(minutes=SCHEDULE_GRACE_MINUTES):
            continue
        # Atomic claim: only one worker may start this occurrence
        with get_db() as conn:
            cur = conn.execute(
                'UPDATE power_schedules SET last_run_at = ? WHERE id = ? '
                'AND (last_run_at IS NULL OR last_run_at < ?)',
                (now.isoformat(), sch['id'], due_at.isoformat()))
            conn.commit()
            claimed = cur.rowcount == 1
        if claimed:
            started += 1
            threading.Thread(target=execute_power_schedule, args=(sch, 'schedule'), daemon=True).start()
    return started


def power_scheduler_loop():
    time.sleep(15)
    logger.info("Power scheduler started")
    while power_scheduler_active:
        try:
            run_due_power_schedules()
        except Exception as e:
            logger.error(f"Power scheduler error: {e}")
        time.sleep(30)


def get_schedules_for_vps(vps: Dict) -> List[Dict]:
    """Enabled schedules that will touch this VPS (for display on the VPS page)."""
    if is_shared_vps(vps):
        return []
    out = []
    for sch in get_power_schedules():
        if not sch['enabled']:
            continue
        if str(sch['target']) != 'all' and str(sch['target']) != str(vps['id']):
            continue
        if vps['id'] in _parse_id_set(sch['exclude_vps']):
            continue
        nxt = _next_run_at(sch)
        out.append({'name': sch['name'], 'action': sch['action'], 'run_time': sch['run_time'],
                    'days_label': _days_label(_parse_days(sch['days'])),
                    'next_run': nxt.strftime('%a %d %b, %H:%M') if nxt else '-'})
    return out


@app.route('/admin/schedules')
@login_required
@admin_required
def admin_schedules():
    schedules = get_power_schedules()
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT v.id, v.hostname, v.container_name, v.vps_type, u.username
                       FROM vps v LEFT JOIN users u ON u.id = v.user_id
                       ORDER BY v.container_name''')
        vps_choices = [dict(r) for r in cur.fetchall() if (r['vps_type'] or 'dedicated') != 'shared']
        names = {v['id']: (v['hostname'] or v['container_name']) for v in vps_choices}
        cur.execute('''SELECT a.created_at, a.action, a.resource_id, a.details, v.hostname, v.container_name
                       FROM activity_logs a LEFT JOIN vps v ON v.id = CAST(a.resource_id AS INTEGER)
                       WHERE a.action IN ('scheduled_restart_vps','scheduled_stop_vps','scheduled_start_vps')
                       ORDER BY a.created_at DESC LIMIT 30''')
        recent = []
        for r in cur.fetchall():
            try:
                d = json.loads(r['details']) if r['details'] else {}
            except Exception:
                d = {}
            recent.append({'created_at': r['created_at'], 'action': r['action'].replace('scheduled_', '').replace('_vps', ''),
                           'vps': r['hostname'] or r['container_name'] or f"#{r['resource_id']}",
                           'schedule': d.get('schedule', ''), 'trigger': d.get('trigger', ''),
                           'status': d.get('status', 'ok'), 'message': d.get('message', '')})
    rows = []
    for s in schedules:
        days = _parse_days(s['days'])
        nxt = _next_run_at(s)
        s['days_set'] = sorted(days)
        s['days_label'] = _days_label(days)
        s['next_run'] = nxt.strftime('%a %d %b %Y, %H:%M') if nxt else '-'
        t = str(s['target'])
        s['target_label'] = 'All VPS' if t == 'all' else (names.get(int(t), f"VPS #{t}") if t.isdigit() else 'All VPS')
        s['affected'] = len(get_schedule_targets(s))
        rows.append(s)
    return render_template('admin/power_schedules.html',
                           panel_name=get_setting('site_name', 'ExpelHost Panel'),
                           schedules=rows, vps_choices=vps_choices, recent=recent,
                           day_names=DAY_NAMES,
                           notify=get_setting('power_schedule_notify', '1') == '1',
                           server_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))


@app.route('/admin/schedules/save', methods=['POST'])
@login_required
@admin_required
def admin_schedules_save():
    data = request.get_json(silent=True) or {}
    action = str(data.get('action', 'restart')).lower()
    run_time = _normalize_hhmm(data.get('run_time'))
    days = sorted({int(d) for d in (data.get('days') or []) if str(d).isdigit() and 0 <= int(d) <= 6})
    target = str(data.get('target', 'all')).strip() or 'all'
    exclude = ','.join(str(i) for i in sorted(_parse_id_set(data.get('exclude_vps'))))
    name = (str(data.get('name') or '').strip() or f"Scheduled {action}")[:60]
    if action not in POWER_ACTIONS:
        return jsonify({'success': False, 'error': 'Invalid action'}), 400
    if not run_time:
        return jsonify({'success': False, 'error': 'Time must be HH:MM (24-hour)'}), 400
    if not days:
        return jsonify({'success': False, 'error': 'Select at least one day'}), 400
    if target != 'all':
        if not target.isdigit() or not get_vps_by_id(int(target)):
            return jsonify({'success': False, 'error': 'Selected VPS does not exist'}), 400
    enabled = 1 if data.get('enabled', True) else 0
    days_csv = ','.join(str(d) for d in days)
    sid = data.get('id')
    with get_db() as conn:
        cur = conn.cursor()
        if sid:
            cur.execute('''UPDATE power_schedules SET name=?, action=?, run_time=?, days=?, target=?,
                           exclude_vps=?, enabled=? WHERE id=?''',
                        (name, action, run_time, days_csv, target, exclude, enabled, int(sid)))
            if cur.rowcount == 0:
                return jsonify({'success': False, 'error': 'Schedule not found'}), 404
        else:
            cur.execute('''INSERT INTO power_schedules (name, action, run_time, days, target, exclude_vps,
                           enabled, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)''',
                        (name, action, run_time, days_csv, target, exclude, enabled,
                         current_user.id, datetime.now().isoformat()))
        conn.commit()
    log_activity(current_user.id, 'save_power_schedule', 'schedule', str(sid or cur.lastrowid),
                 {'name': name, 'action': action, 'time': run_time, 'days': days_csv, 'target': target})
    return jsonify({'success': True})


@app.route('/admin/schedules/<int:schedule_id>/toggle', methods=['POST'])
@login_required
@admin_required
def admin_schedules_toggle(schedule_id):
    with get_db() as conn:
        cur = conn.execute('UPDATE power_schedules SET enabled = 1 - enabled WHERE id = ?', (schedule_id,))
        conn.commit()
        if cur.rowcount == 0:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404
    log_activity(current_user.id, 'toggle_power_schedule', 'schedule', str(schedule_id))
    return jsonify({'success': True})


@app.route('/admin/schedules/<int:schedule_id>/delete', methods=['POST'])
@login_required
@admin_required
def admin_schedules_delete(schedule_id):
    with get_db() as conn:
        conn.execute('DELETE FROM power_schedules WHERE id = ?', (schedule_id,))
        conn.commit()
    log_activity(current_user.id, 'delete_power_schedule', 'schedule', str(schedule_id))
    return jsonify({'success': True})


@app.route('/admin/schedules/<int:schedule_id>/run', methods=['POST'])
@login_required
@admin_required
def admin_schedules_run_now(schedule_id):
    with get_db() as conn:
        row = conn.execute('SELECT * FROM power_schedules WHERE id = ?', (schedule_id,)).fetchone()
    if not row:
        return jsonify({'success': False, 'error': 'Schedule not found'}), 404
    sch = dict(row)
    count = len(get_schedule_targets(sch))
    threading.Thread(target=execute_power_schedule, args=(sch, 'manual'), daemon=True).start()
    log_activity(current_user.id, 'run_power_schedule', 'schedule', str(schedule_id), {'targets': count})
    return jsonify({'success': True, 'targets': count})


@app.route('/admin/schedules/settings', methods=['POST'])
@login_required
@admin_required
def admin_schedules_settings():
    data = request.get_json(silent=True) or {}
    set_setting('power_schedule_notify', '1' if data.get('notify') else '0')
    return jsonify({'success': True})


# ============================================================================
# Team access roles for shared (non shared-hosting) VPS
#   viewer   - can open the VPS page and see status / resource usage only
#   operator - viewer + start/stop/restart, console, SSH/SSHX, files
#   owner / admin - everything (reinstall, rename, notes, manage the team)
# Roles live in vps.metadata['team_roles'] = {user_id: role}. Users that were
# shared before this feature existed have no entry and keep full "operator" use.
# ============================================================================
TEAM_ROLES = ('viewer', 'operator')
_ROLE_RANK = {'viewer': 1, 'operator': 2, 'owner': 3, 'admin': 3}
_VIEWER_ENDPOINTS = {'vps_detail', 'vps_stats', 'vps_suspended_page'}
_OWNER_ONLY_ENDPOINTS = {'vps_reinstall', 'vps_reinstall_status', 'vps_rename', 'vps_notes'}


def get_team_roles(vps: Dict) -> Dict[str, str]:
    roles = (vps.get('metadata') or {}).get('team_roles') or {}
    return {str(k): v for k, v in roles.items()} if isinstance(roles, dict) else {}


def get_vps_role(vps: Optional[Dict], user=None) -> Optional[str]:
    """'admin' | 'owner' | 'operator' | 'viewer' | None (no access)."""
    user = user or current_user
    if not vps or not getattr(user, 'is_authenticated', False):
        return None
    if getattr(user, 'is_admin', False):
        return 'admin'
    if vps['user_id'] == user.id:
        return 'owner'
    if str(user.id) in [str(u) for u in (vps.get('shared_with') or [])]:
        role = get_team_roles(vps).get(str(user.id), 'operator')
        return role if role in TEAM_ROLES else 'operator'
    if user_has_shared_access(vps['id'], user.id):
        return 'operator'
    return None


def role_at_least(role: Optional[str], needed: str) -> bool:
    return _ROLE_RANK.get(role or '', 0) >= _ROLE_RANK[needed]


def can_manage_team(vps: Dict) -> bool:
    return bool(vps) and not is_shared_vps(vps) and role_at_least(get_vps_role(vps), 'owner')


@app.before_request
def enforce_vps_team_roles():
    """Central gate: viewers are read-only, operators cannot reinstall/rename."""
    ep = request.endpoint or ''
    if not ep.startswith('vps_') or not request.view_args or 'vps_id' not in request.view_args:
        return None
    if not current_user.is_authenticated:
        return None
    vps_id = request.view_args['vps_id']
    vps = get_vps_by_id(vps_id)
    if not vps or is_shared_vps(vps):
        return None            # shared hosting uses per-account permissions
    role = get_vps_role(vps)
    if role in (None, 'admin', 'owner'):
        return None            # no access -> the route's own check answers; full roles pass
    denied = None
    if role == 'viewer' and ep not in _VIEWER_ENDPOINTS:
        denied = 'Viewer access is read-only. Ask the owner for the Operator role.'
    elif role == 'operator' and ep in _OWNER_ONLY_ENDPOINTS:
        denied = 'Only the VPS owner can do this.'
    if not denied:
        return None
    if request.method == 'GET' and 'text/html' in request.headers.get('Accept', ''):
        flash(denied, 'danger')
        return redirect(url_for('vps_detail', vps_id=vps_id))
    return jsonify({'success': False, 'error': denied}), 403


@app.route('/vps/<int:vps_id>/team/role', methods=['POST'])
@login_required
def vps_team_set_role(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    if not can_manage_team(vps):
        return jsonify({'success': False, 'error': 'Only the owner can manage the team'}), 403
    data = request.get_json(silent=True) or request.form
    uid = str(data.get('user_id', '')).strip()
    role = str(data.get('role', '')).strip().lower()
    if role not in TEAM_ROLES:
        return jsonify({'success': False, 'error': 'Role must be viewer or operator'}), 400
    if uid not in [str(u) for u in (vps.get('shared_with') or [])]:
        return jsonify({'success': False, 'error': 'User is not on this VPS team'}), 400
    meta = dict(vps.get('metadata') or {})
    roles = dict(meta.get('team_roles') or {})
    roles[uid] = role
    meta['team_roles'] = roles
    update_vps(vps_id, metadata=meta)
    log_activity(current_user.id, 'team_role_changed', 'vps', str(vps_id), {'user_id': uid, 'role': role})
    try:
        create_notification(int(uid), 'info', 'VPS role changed',
                            f"Your role on VPS {vps['container_name']} is now {role}.")
    except Exception:
        pass
    return jsonify({'success': True})



# ============================================================================
# Main entry point
# ============================================================================
if __name__ == "__main__":
    init_db()
    migrate_discord_auth()  # Run Discord auth migration
    migrate_shared_hosting()  # Ensure vps.vps_type + shared_accounts exist
    migrate_power_schedules()  # Scheduled power actions (default: daily reboot 04:00)

    # Re-mount every shared account's own disk (a restart/recreate of the panel host unmounts them)
    def _shared_startup_heal():
        try:
            if os.geteuid() != 0:
                return
            r = subprocess.run(['bash', '-c', shared_hosting.mount_disks_script()],
                               capture_output=True, text=True, timeout=120)
            res = shared_hosting.parse(r.stdout)
            for rec in res.get('records', []):
                if rec and rec[0] == 'mounted':
                    logger.info(f"Shared hosting: re-mounted private disk of {rec[1]}")
            subprocess.run(['bash', '-c', shared_hosting.shell_refresh_script()], capture_output=True, timeout=30)
        except Exception as e:
            logger.warning(f"Shared hosting startup heal failed: {e}")
    threading.Thread(target=_shared_startup_heal, daemon=True).start()
    logger.info(f"{PANEL_NAME} v{PANEL_VERSION} starting...")
    
    os.makedirs('static/uploads/profiles', exist_ok=True)
    os.makedirs('static/uploads/settings', exist_ok=True)
    os.makedirs('static/uploads/os_icons', exist_ok=True)
    os.makedirs('static/img', exist_ok=True)
    os.makedirs('templates', exist_ok=True)
    os.makedirs('templates/admin', exist_ok=True)
    os.makedirs('templates/errors', exist_ok=True)
    os.makedirs('backups', exist_ok=True)
    
    monitor_thread = threading.Thread(target=resource_monitor, daemon=True)
    monitor_thread.start()
    threading.Thread(target=power_scheduler_loop, daemon=True).start()
    
    logger.info(f"Starting server on {HOST}:{PORT}")
    logger.info(f"SocketIO available: {SOCKETIO_AVAILABLE}")
    
    if DEBUG_MODE:
        if socketio:
            socketio.run(app, host=HOST, port=PORT, debug=True, allow_unsafe_werkzeug=True)
        else:
            app.run(host=HOST, port=PORT, debug=True, threaded=True)
    else:
        # Production mode
        if socketio:
            # Flask-SocketIO has its own production server (eventlet or gevent)
            # which properly handles both HTTP and WebSocket connections
            logger.info("Starting with SocketIO support (production mode)")
            logger.info("Using Flask-SocketIO's built-in production server")
            logger.info("For best performance, ensure eventlet or gevent is installed:")
            logger.info("  pip install eventlet  OR  pip install gevent gevent-websocket")
            socketio.run(app, host=HOST, port=PORT, debug=False, allow_unsafe_werkzeug=True)
        elif HYPERCORN_AVAILABLE and ASGIREF_AVAILABLE:
            # Only use Hypercorn if SocketIO is not available
            from asgiref.wsgi import WsgiToAsgi
            
            config = HyperConfig()
            config.bind = [f"{HOST}:{PORT}"]
            config.use_reloader = False
            config.errorlog = logging.getLogger('hvm_panel')
            config.accesslog = logging.getLogger('hvm_panel')
            config.workers = 4
            
            try:
                logger.info("Starting with Hypercorn (ASGI mode, no SocketIO)")
                asgi_app = WsgiToAsgi(app)
                asyncio.run(serve(asgi_app, config))
            except KeyboardInterrupt:
                logger.info("Shutting down...")
                resource_monitor_active = False
                sys.exit(0)
        else:
            logger.warning("Running with Flask development server (not recommended for production)")
            app.run(host=HOST, port=PORT, debug=False, threaded=True)
