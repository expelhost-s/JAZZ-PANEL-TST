#!/usr/bin/env python3
"""
HVM Panel - Shared Hosting engine (NO LXD / LXC required)

Shared hosting runs isolated per-user accounts directly on a plain Linux
server (the panel host itself for local nodes, or any server running the
node agent for remote nodes).  Every panel user that is granted access to a
shared VPS gets:

  * a dedicated Linux system user + home directory (file isolation: other
    users can never read/write/see each other's files)
  * RAM / CPU limits enforced through systemd user slices
  * disk limits monitored by the panel - the account is suspended when it
    exceeds its quota (the rest of the shared VPS keeps working)
  * a restricted web console / SFTP session confined to their home directory
  * a per-user "reinstall" that wipes ONLY that user's files - never the
    whole server and never another user's files
  * no OS selection / OS changes - shared hosting reuses the server's OS

Everything here is implemented with plain Linux tools (useradd, systemd,
du, ps, find).  Operations run either directly on the panel host (local
node) or through the node agent's existing /api/execute endpoint (remote
node), so no changes to the node agent are required.
"""

import asyncio
import logging
import shlex
from typing import Any, Dict, List, Optional

logger = logging.getLogger('hvm_panel')

# ---------------------------------------------------------------------------
# Shell helpers
# ---------------------------------------------------------------------------

def _q(value: Any) -> str:
    """Shell-quote a value for embedding into a script."""
    return shlex.quote(str(value))


# Root guard shared by every script: scripts must run as root to manage
# system users.  We always exit 0 so the node agent returns HTTP 200 and the
# Python side can read the HVM|err| line.
_ROOT_GUARD = """\
[ "$(id -u)" = "0" ] || { echo "HVM|err|root privileges required to manage shared hosting"; echo "HVM|done|0"; exit 0; }
"""

# Restricted login shell installed on the node.  It drops the user into an
# interactive bash confined to their home directory.
_SHELL_BIN = '/usr/local/bin/hvm-shell'
_RCFILE = '/usr/local/etc/hvm-shellrc'

_SHELL_INSTALL = """\
mkdir -p /usr/local/bin /usr/local/etc
cat > __SHELL_BIN__ <<'SHEOF'
#!/bin/bash
# HVM shared hosting restricted shell (managed by HVM Panel)
HVM_USER="$(id -un 2>/dev/null)"
export HOME="$(getent passwd "$HVM_USER" 2>/dev/null | cut -d: -f6)"
if [ $# -gt 0 ]; then
  # non-interactive use (ssh host cmd, "$SHELL --version" as run by neofetch, scp ...)
  # must NEVER open an interactive shell - that is what froze the web console
  [ -d "$HOME" ] && cd "$HOME" 2>/dev/null
  export SHELL=/bin/bash PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
  exec /bin/bash "$@"
fi
if [ $# -eq 0 ] && [ -f "/etc/hvm-shared/$HVM_USER.limits" ] && command -v sudo >/dev/null 2>&1; then
  sudo -n /usr/local/bin/hvm-cgroup $$ >/dev/null 2>&1
fi
if [ $# -eq 0 ] && [ -t 0 ] && [ -f "/etc/hvm-shared/$HVM_USER.proot" ] && [ -x /usr/local/bin/hvm-proot ]; then
  /usr/local/bin/hvm-proot; HVM_RC=$?
  [ "$HVM_RC" -eq 97 ] || exit "$HVM_RC"
fi
if [ $# -eq 0 ] && [ -t 0 ] && [ -f "/etc/hvm-shared/$HVM_USER.iso" ] && command -v sudo >/dev/null 2>&1; then
  sudo /usr/local/bin/hvm-enter; HVM_RC=$?
  [ "$HVM_RC" -eq 97 ] || exit "$HVM_RC"
fi
[ -d "$HOME" ] || cd /
cd "$HOME" 2>/dev/null
export SHELL=/bin/bash
export EDITOR=nano
export PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
if [ -t 0 ]; then
  exec /bin/bash --rcfile __RCFILE__ -i
else
  exec /bin/bash --rcfile __RCFILE__ -i < /dev/null
fi
SHEOF
chmod 755 __SHELL_BIN__
cat > __RCFILE__ <<'RCEOF'
# HVM shared hosting shell profile
export PS1='\\u@shared:\\w\\$ '
export PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
[ -d "$HOME" ] && cd "$HOME" 2>/dev/null
hvm_confine() {
  case "$PWD" in
    "$HOME"|"$HOME"/*) return 0 ;;
    *) builtin cd "$HOME" 2>/dev/null; echo "hvm-shell: your session is confined to your home directory"; return 1 ;;
  esac
}
cd() { builtin cd "$@" || return $?; hvm_confine; }
sudo() { command sudo -n "$@" || echo "(host-mode account: only apt/dpkg are allowed with sudo - reinstall this shared VPS to get a private root container)" >&2; }
apt() { command sudo /usr/bin/apt "$@"; }
apt-get() { command sudo /usr/bin/apt-get "$@"; }
apt-cache() { command sudo /usr/bin/apt-cache "$@"; }
dpkg() { command sudo /usr/bin/dpkg "$@"; }
alias su='echo "su is not available on shared hosting"'
# neofetch can never freeze the terminal: bounded runtime + terminal state restored afterwards
neofetch() { SHELL=/bin/bash command timeout --foreground -s KILL 25 neofetch "$@"; local rc=$?; printf '\\033[0m\\033[?25h\\033[?7h'; stty sane 2>/dev/null; return $rc; }
RCEOF
chmod 644 __RCFILE__
"""

# sshd drop-in so shared accounts can authenticate from the panel console
# (password auth is enabled ONLY for hvm* users, everything else untouched).
_SSHD_SETUP = """\
mkdir -p /etc/ssh/sshd_config.d 2>/dev/null
cat > /etc/ssh/sshd_config.d/99-hvm-shared.conf <<'SEOF'
Match Group hvmshared
    PasswordAuthentication yes
    X11Forwarding no
    AllowTcpForwarding no
    PermitTunnel no
    GatewayPorts no
SEOF
if [ -f /etc/ssh/sshd_config ]; then
  grep -qE '^[[:space:]]*Include[[:space:]]+/etc/ssh/sshd_config.d/' /etc/ssh/sshd_config 2>/dev/null || echo 'Include /etc/ssh/sshd_config.d/*.conf' >> /etc/ssh/sshd_config
  if command -v sshd >/dev/null 2>&1 && ! sshd -t >/dev/null 2>&1; then
    echo "HVM|warn|sshd config test failed - console SSH may not work until sshd config is fixed"
    rm -f /etc/ssh/sshd_config.d/99-hvm-shared.conf
  else
    systemctl reload ssh >/dev/null 2>&1 || systemctl reload sshd >/dev/null 2>&1 || service ssh reload >/dev/null 2>&1 || service sshd reload >/dev/null 2>&1 || true
    systemctl is-active --quiet ssh 2>/dev/null || systemctl is-active --quiet sshd 2>/dev/null || echo "HVM|warn|sshd is not running - install/enable openssh-server for console access"
  fi
else
  echo "HVM|warn|no /etc/ssh/sshd_config found - install openssh-server for console access"
fi
# Best effort: hide other users' processes from shared users
grep -q 'hidepid=2' /proc/mounts 2>/dev/null || mount -o remount,hidepid=2 /proc >/dev/null 2>&1 || true
"""

_ISO_GLOBAL = r'''
# ---- isolated per-user root filesystem (systemd-nspawn, NO LXD) ----
ISO_OK=0
if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
  if ! command -v systemd-nspawn >/dev/null 2>&1 || ! command -v debootstrap >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq >/dev/null 2>&1
    apt-get install -y -qq debootstrap systemd-container >/dev/null 2>&1
  fi
  if command -v systemd-nspawn >/dev/null 2>&1 && command -v debootstrap >/dev/null 2>&1; then
    BT=/opt/hvm-shared/.base-rootfs.tar.gz
    if [ ! -s "$BT" ]; then
      . /etc/os-release
      SUITE="${VERSION_CODENAME:-}"
      case "$ID" in
        ubuntu) MIRROR=http://archive.ubuntu.com/ubuntu ;;
        *) MIRROR=http://deb.debian.org/debian ;;
      esac
      TMPR=$(mktemp -d /opt/hvm-shared/.build.XXXXXX)
      if [ -n "$SUITE" ] && debootstrap --variant=minbase --include=systemd,systemd-sysv,dbus,sudo,nano,curl,wget,ca-certificates,iproute2,procps,iputils-ping,apt-utils,less,gnupg "$SUITE" "$TMPR" "$MIRROR" >/var/log/hvm-debootstrap.log 2>&1; then
        tar -C "$TMPR" -czf "$BT" . && ISO_OK=1
      else
        echo "HVM|warn|debootstrap failed (see /var/log/hvm-debootstrap.log) - falling back to shared host mode"
      fi
      rm -rf "$TMPR"
    else
      ISO_OK=1
    fi
  else
    echo "HVM|warn|could not install systemd-container/debootstrap - falling back to shared host mode"
  fi
else
  echo "HVM|warn|systemd not available - isolated filesystems disabled, falling back to shared host mode"
fi
mkdir -p /etc/hvm-shared
cat > /usr/local/bin/hvm-enter <<'ENTEOF'
#!/bin/bash
# Enter the calling shared account's private container (root inside it).
U="${SUDO_USER:-}"
[ -n "$U" ] && id -nG "$U" 2>/dev/null | tr ' ' '\n' | grep -qx hvmshared || { echo "denied"; exit 97; }
[ -f "/etc/hvm-shared/$U.iso" ] || { echo "no container for this account"; exit 97; }
# self-heal: the container's "/" must be world-searchable or non-root users inside it (_apt, www-data, ...) get "Permission denied"
read -r _RAM _CPU _R < "/etc/hvm-shared/$U.iso" 2>/dev/null
[ -n "$_R" ] && [ -d "$_R" ] && chmod 755 "$_R"
SVC="hvm-ct-$U.service"
systemctl is-active --quiet "$SVC" || systemctl start "$SVC"
CP=""
for i in $(seq 1 30); do
  MP=$(systemctl show -p MainPID --value "$SVC" 2>/dev/null)
  [ -n "$MP" ] && [ "$MP" != 0 ] && CP=$(pgrep -P "$MP" 2>/dev/null | head -1)
  [ -n "$CP" ] && break
  sleep 1
done
[ -n "$CP" ] || { echo "container failed to start - using host shell (journalctl -u $SVC)"; exit 97; }
nsenter -t "$CP" -a /bin/true >/dev/null 2>&1 || { echo "cannot enter container - using host shell"; exit 97; }
exec nsenter -t "$CP" -a env -i TERM="${TERM:-xterm}" HOME=/root LANG=C.UTF-8 PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin /bin/bash -l
ENTEOF
chmod 755 /usr/local/bin/hvm-enter
'''

_ISO_ACCOUNT = r'''
  rm -f "/etc/hvm-shared/$U.iso"
  if [ "$ISO_OK" = "1" ]; then
    R="$H/rootfs"
    systemctl stop "hvm-ct-$U.service" >/dev/null 2>&1
    if [ ! -e "$R/etc/os-release" ]; then
      mkdir -p "$R" && tar -C "$R" -xzf /opt/hvm-shared/.base-rootfs.tar.gz
    fi
    if [ -e "$R/etc/os-release" ]; then
      echo "$U" > "$R/etc/hostname"
      echo "127.0.0.1 localhost $U" > "$R/etc/hosts"
      echo "root:$PW" | chroot "$R" chpasswd >/dev/null 2>&1
      # apt: run as root (no _apt sandbox permission errors) + full repositories
      mkdir -p "$R/etc/apt/apt.conf.d"
      echo 'APT::Sandbox::User "root";' > "$R/etc/apt/apt.conf.d/99hvm-nosandbox"
      OSID=$(. /etc/os-release; echo "$ID"); OSSUITE=$(. /etc/os-release; echo "$VERSION_CODENAME")
      if [ -n "$OSSUITE" ]; then
        if [ "$OSID" = "ubuntu" ]; then
          rm -f "$R/etc/apt/sources.list.d/ubuntu.sources"
          printf 'deb http://archive.ubuntu.com/ubuntu %s main restricted universe multiverse\ndeb http://archive.ubuntu.com/ubuntu %s-updates main restricted universe multiverse\ndeb http://security.ubuntu.com/ubuntu %s-security main restricted universe multiverse\n' "$OSSUITE" "$OSSUITE" "$OSSUITE" > "$R/etc/apt/sources.list"
        else
          printf 'deb http://deb.debian.org/debian %s main contrib non-free\ndeb http://deb.debian.org/debian %s-updates main contrib non-free\ndeb http://security.debian.org/debian-security %s-security main contrib non-free\n' "$OSSUITE" "$OSSUITE" "$OSSUITE" > "$R/etc/apt/sources.list"
        fi
      fi
      chown -R root:root "$R/var/lib/apt" "$R/var/cache/apt" >/dev/null 2>&1
      rm -rf "$R/var/lib/apt/lists/"* >/dev/null 2>&1
      rm -f "$R/etc/resolv.conf"
      chmod 755 "$R"
      mkdir -p "$H/public_html" "$R/srv/public_html"
      cat > "/etc/systemd/system/hvm-ct-$U.service" <<UNITEOF
[Unit]
Description=HVM shared hosting container $U
After=network.target

[Service]
ExecStartPre=-/usr/local/bin/hvm-fake-gen $R $H $U
ExecStartPre=/bin/sh -c '[ -s $H/.meminfo ] || cat /proc/meminfo > $H/.meminfo; [ -s $H/.cpuinfo ] || cat /proc/cpuinfo > $H/.cpuinfo'
ExecStart=/usr/bin/systemd-nspawn --quiet --boot --register=no --keep-unit -D $R --bind=$H/public_html:/srv/public_html --bind-ro=$H/.meminfo:/proc/meminfo --bind-ro=$H/.cpuinfo:/proc/cpuinfo --resolv-conf=replace-host
KillMode=mixed
Restart=on-failure
Delegate=yes
MemoryMax=${RAM}M
MemorySwapMax=0
CPUQuota=$((CPU * 100))%
TasksMax=4096

[Install]
WantedBy=multi-user.target
UNITEOF
      systemctl daemon-reload >/dev/null 2>&1
      systemctl enable "hvm-ct-$U.service" >/dev/null 2>&1
      echo "$RAM $CPU $R" > "/etc/hvm-shared/$U.iso"
      systemctl start "hvm-ct-$U.service" >/dev/null 2>&1
      echo "HVMREC|iso|$U|1"
    else
      echo "HVM|warn|could not create private filesystem for $U - using shared host mode"
    fi
  fi
'''

_DISK_GLOBAL = r'''
# ---- separate disk helpers (one ext4 volume per shared account) ----
hvm_prepare_loop() {
  [ -e /dev/loop-control ] || mknod /dev/loop-control c 10 237 >/dev/null 2>&1
  modprobe loop >/dev/null 2>&1
  for i in $(seq 0 63); do [ -e "/dev/loop$i" ] || mknod "/dev/loop$i" b 7 "$i" >/dev/null 2>&1; done
}
hvm_mount_disk() {   # usage: hvm_mount_disk USER HOME IMG SIZE_GB
  local U="$1" H="$2" IMG="$3" GB="$4" LD ERR
  if ! command -v mkfs.ext4 >/dev/null 2>&1 || ! command -v losetup >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq >/dev/null 2>&1; apt-get install -y -qq e2fsprogs mount util-linux >/dev/null 2>&1
  fi
  command -v mkfs.ext4 >/dev/null 2>&1 || { echo "HVM|warn|separate disk: mkfs.ext4 is not installed (apt install e2fsprogs)"; return 1; }
  hvm_prepare_loop
  mkdir -p "$(dirname "$IMG")" "$H"
  if [ ! -f "$IMG" ]; then
    truncate -s "${GB}G" "$IMG" 2>/dev/null || { echo "HVM|warn|separate disk: not enough space to create ${GB}G image for $U"; return 1; }
    mkfs.ext4 -F -q -m 0 -L "${U:0:16}" "$IMG" >/dev/null 2>&1 || { rm -f "$IMG"; echo "HVM|warn|separate disk: mkfs.ext4 failed for $U"; return 1; }
  fi
  LD=$(losetup -f --show "$IMG" 2>/dev/null)
  if [ -n "$LD" ]; then
    ERR=$(mount -o noatime "$LD" "$H" 2>&1) || { losetup -d "$LD" >/dev/null 2>&1; LD=""; }
  fi
  if [ -z "$LD" ]; then
    ERR=$(mount -o loop,noatime "$IMG" "$H" 2>&1) || {
      echo "HVM|warn|separate disk for $U could not be mounted: $(echo "$ERR" | head -c 200 | tr '\n' ' ') - the panel container needs --privileged (or --cap-add SYS_ADMIN + --device /dev/loop-control) to give each account its own disk"
      return 1
    }
  fi
  grep -qF "$IMG" /etc/fstab 2>/dev/null || echo "$IMG $H ext4 loop,noatime,nofail 0 0" >> /etc/fstab
  return 0
}
'''

_CG_GLOBAL = r'''
# ---- real per-account RAM/CPU limits via cgroup v2 (works inside Docker, no systemd needed) ----
cat > /usr/local/bin/hvm-cgroup <<'CGEOF'
#!/bin/bash
U="${SUDO_USER:-}"; PID="$1"
[ -n "$U" ] && [[ "$PID" =~ ^[0-9]+$ ]] || exit 1
[ "$(stat -c %U "/proc/$PID" 2>/dev/null)" = "$U" ] || exit 1
[ -d /run/systemd/system ] && exit 0
read -r RAM CPU DISK < "/etc/hvm-shared/$U.limits" 2>/dev/null || exit 0
CG=/sys/fs/cgroup
[ -f "$CG/cgroup.controllers" ] || exit 0
if [ ! -d "$CG/hvm" ]; then
  mkdir -p "$CG/init" 2>/dev/null
  for p in $(cat "$CG/cgroup.procs" 2>/dev/null); do echo "$p" > "$CG/init/cgroup.procs" 2>/dev/null; done
  echo "+cpu +memory +pids" > "$CG/cgroup.subtree_control" 2>/dev/null
  mkdir -p "$CG/hvm" 2>/dev/null
  echo "+cpu +memory +pids" > "$CG/hvm/cgroup.subtree_control" 2>/dev/null
fi
D="$CG/hvm/$U"
mkdir -p "$D" 2>/dev/null || exit 0
echo $((RAM * 1024 * 1024)) > "$D/memory.max" 2>/dev/null
echo 0 > "$D/memory.swap.max" 2>/dev/null
echo "$((CPU * 100000)) 100000" > "$D/cpu.max" 2>/dev/null
echo 4096 > "$D/pids.max" 2>/dev/null
for p in $(pgrep -u "$U" 2>/dev/null) $PID; do echo "$p" > "$D/cgroup.procs" 2>/dev/null; done
exit 0
CGEOF
chmod 755 /usr/local/bin/hvm-cgroup
'''

# per-account limits file (read by the private system to show its own RAM / by hvm-cgroup)
_LIMITS_HEAL = r'''
mkdir -p /etc/hvm-shared
for U in $(getent group hvmshared 2>/dev/null | cut -d: -f4 | tr ',' ' '); do
  N=$(id -u "$U" 2>/dev/null); [ -n "$N" ] || continue
  F="/etc/systemd/system/user-${N}.slice.d/10-hvm-limits.conf"
  RAMV=$(sed -n 's/^MemoryMax=\([0-9]*\)M.*/\1/p' "$F" 2>/dev/null | head -1)
  CPQ=$(sed -n 's/^CPUQuota=\([0-9]*\)%.*/\1/p' "$F" 2>/dev/null | head -1)
  IMGF="/opt/hvm-shared/disks/$U.img"
  DSK=$(( $(stat -c %s "$IMGF" 2>/dev/null || echo 0) / 1073741824 ))
  if [ -n "$RAMV" ] && [ ! -f "/etc/hvm-shared/$U.limits" ]; then
    echo "$RAMV $(( ${CPQ:-100} / 100 )) $DSK" > "/etc/hvm-shared/$U.limits"; chmod 644 "/etc/hvm-shared/$U.limits"
  fi
  SF="/etc/sudoers.d/hvm-$U"
  if [ -f "$SF" ] && ! grep -q hvm-cgroup "$SF"; then
    sed 's#/usr/local/bin/hvm-enter,#/usr/local/bin/hvm-enter, /usr/local/bin/hvm-cgroup,#' "$SF" > "$SF.tmp"; chmod 440 "$SF.tmp"
    if visudo -cf "$SF.tmp" >/dev/null 2>&1; then mv -f "$SF.tmp" "$SF"; else rm -f "$SF.tmp"; fi
  fi
done
'''

_PROOT_SETUP = r'''
# ---- no-systemd fallback: rootless private filesystem with proot (works inside Docker) ----
PROOT_OK=0
if [ "$ISO_OK" != "1" ]; then
  export DEBIAN_FRONTEND=noninteractive
  command -v proot >/dev/null 2>&1 || { apt-get update -qq >/dev/null 2>&1; apt-get install -y -qq proot curl ca-certificates >/dev/null 2>&1; }
  if command -v proot >/dev/null 2>&1 && PROOT_NO_SECCOMP=1 proot -0 true >/dev/null 2>&1; then
    PBT=/opt/hvm-shared/.proot-base.tar.gz
    mkdir -p /opt/hvm-shared
    if [ ! -s "$PBT" ]; then
      OSID=$(. /etc/os-release; echo "$ID"); OSVER=$(. /etc/os-release; echo "$VERSION_ID")
      ARCHN=$(dpkg --print-architecture 2>/dev/null)
      if [ "$OSID" = "ubuntu" ]; then
        BASEURL="https://cdimage.ubuntu.com/ubuntu-base/releases/$OSVER/release"
        FN=$(curl -fsSL --max-time 60 "$BASEURL/" 2>/dev/null | grep -o "ubuntu-base-[0-9.]*-base-$ARCHN.tar.gz" | sort -uV | tail -1)
        if [ -n "$FN" ]; then
          curl -fsSL --max-time 900 -o "$PBT.tmp" "$BASEURL/$FN" && mv -f "$PBT.tmp" "$PBT"
        fi
      fi
      if [ ! -s "$PBT" ]; then
        echo "HVM|warn|could not download the base system for private filesystems - using shared host mode"
      fi
    fi
    [ -s "$PBT" ] && PROOT_OK=1
  else
    echo "HVM|warn|proot is not usable on this server - using shared host mode"
  fi
fi
'''

_PROOT_BIN = r'''
mkdir -p /etc/hvm-shared
cat > /usr/local/bin/hvm-proot <<'PREOF'
#!/bin/bash
# Enter this account's private root filesystem (runs as the account itself, fake root via proot)
U=$(id -un)
read -r R < "/etc/hvm-shared/$U.proot" 2>/dev/null
[ -n "$R" ] && [ -d "$R/etc" ] || exit 97
H=$(dirname "$R")
export PROOT_NO_SECCOMP=1 PROOT_TMP_DIR="$H/tmp"
mkdir -p "$PROOT_TMP_DIR" "$H/public_html" "$R/srv/public_html" "$H/logs"
# ---- dedicated-style view: the account sees ITS OWN disk as "/" and ITS OWN RAM ----
read -r LRAM LCPU LDISK < "/etc/hvm-shared/$U.limits" 2>/dev/null
LRAM=${LRAM:-512}
_FRAM=""; read -r _FRAM _ _ < "/etc/hvm-shared/$U.fake" 2>/dev/null; [ -n "$_FRAM" ] && LRAM=$((_FRAM * 1024))
MI="$H/.meminfo"
hvm_genmem() {
  local tot used free
  tot=$((LRAM * 1024))
  if [ -r "/sys/fs/cgroup/hvm/$U/memory.current" ]; then used=$(( $(cat "/sys/fs/cgroup/hvm/$U/memory.current") / 1024 ))
  else used=$(ps -u "$U" -o rss= 2>/dev/null | awk '{s+=$1} END {print s+0}'); fi
  [ "$used" -gt "$tot" ] && used=$tot
  free=$((tot - used))
  printf 'MemTotal:       %d kB\nMemFree:        %d kB\nMemAvailable:   %d kB\nBuffers:               0 kB\nCached:                0 kB\nSwapCached:            0 kB\nSwapTotal:             0 kB\nSwapFree:              0 kB\nShmem:                 0 kB\n' "$tot" "$free" "$free" > "$MI.tmp" && mv -f "$MI.tmp" "$MI"
}
hvm_genmem
mkdir -p "$R/usr/local/bin" "$R/root"
cat > "$R/usr/local/bin/df" <<'DFEOF'
#!/bin/sh
# shows this account's own disk as "/" (like a dedicated VPS), not the host's mounts
n=$#; i=0
while [ $i -lt $n ]; do a="$1"; shift; case "$a" in -*) set -- "$@" "$a";; esac; i=$((i+1)); done
/usr/bin/df "$@" / | awk 'NR==1{print;next}{m=match($0,/^[^ ]+/);L=RLENGTH;s=sprintf("%-" L "s","/dev/vda");r=substr($0,L+1);sub(/[^ ]+$/,"/",r);print s r}'
DFEOF
printf '#!/bin/sh\ncat /etc/hostname\n' > "$R/usr/local/bin/hostname"
printf '#!/bin/sh\nexit 0\n' > "$R/usr/local/bin/lesspipe"
chmod 755 "$R/usr/local/bin/df" "$R/usr/local/bin/hostname" "$R/usr/local/bin/lesspipe"
/usr/local/bin/hvm-fake-gen "$R" "$H" "$U" >/dev/null 2>&1
CB=(); [ -s "$H/.cpuinfo" ] && CB=(-b "$H/.cpuinfo:/proc/cpuinfo")
: > "$R/root/.hushlogin"
if ! grep -q hvm-prompt "$R/root/.bashrc" 2>/dev/null; then
  cat >> "$R/root/.bashrc" <<'BRC'

# hvm-prompt: show the account name instead of the host name
PS1="${PS1//\\h/$(cat /etc/hostname 2>/dev/null)}"
BRC
fi
PR=(proot -0 -r "$R" --link2symlink -b /dev -b /proc -b "$MI:/proc/meminfo" "${CB[@]}" -b /sys -b "$H/public_html:/srv/public_html" -w /root)
EV=(/usr/bin/env -i HOME=/root TERM="${TERM:-xterm}" LANG=C.UTF-8 PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin)
DP="$H/.hvm-daemon.pid"
if ! { [ -f "$DP" ] && kill -0 "$(cat "$DP" 2>/dev/null)" 2>/dev/null; }; then
  setsid nohup "${PR[@]}" "${EV[@]}" /bin/bash -c 'command -v tmux >/dev/null 2>&1 && tmux new-session -d -s main; exec sleep infinity' >/dev/null 2>&1 </dev/null &
  echo $! > "$DP"
  sleep 1
fi
MP="$H/.hvm-mem.pid"
if ! { [ -f "$MP" ] && kill -0 "$(cat "$MP" 2>/dev/null)" 2>/dev/null; }; then
  export U LRAM MI; export -f hvm_genmem
  setsid nohup bash -c 'while pgrep -u "$U" -x proot >/dev/null 2>&1; do hvm_genmem; sleep 3; done' >/dev/null 2>&1 </dev/null &
  echo $! > "$MP"
fi
if ! "${PR[@]}" "${EV[@]}" /bin/true >"$H/logs/proot-test.log" 2>&1; then
  PR=(proot -0 -r "$R" -b /dev -b /proc -b "$MI:/proc/meminfo" "${CB[@]}" -b "$H/public_html:/srv/public_html" -w /root)
  if ! "${PR[@]}" "${EV[@]}" /bin/true >"$H/logs/proot-test.log" 2>&1; then
    unset PROOT_NO_SECCOMP
    if ! "${PR[@]}" "${EV[@]}" /bin/true >"$H/logs/proot-test.log" 2>&1; then
      echo "private filesystem cannot start - using host shell"
      echo "reason: $(head -c 300 "$H/logs/proot-test.log" | tr '\n' ' ')"
      grep -qi 'ptrace' "$H/logs/proot-test.log" && echo "hint: the panel container needs --cap-add SYS_PTRACE (or --privileged) for proot"
      exit 97
    fi
  fi
fi
if [ -x "$R/usr/bin/tmux" ]; then
  "${PR[@]}" "${EV[@]}" /usr/bin/tmux new-session -A -s main && exit 0
fi
exec "${PR[@]}" "${EV[@]}" /bin/bash -l
PREOF
chmod 755 /usr/local/bin/hvm-proot
'''


_FAKE_GLOBAL = r'''
# ---- display view for shared VPS: Host/kernel identity + RAM/CPU/disk shown inside the private system ----
# (cosmetic only; real cgroup/disk limits stay enforced)
mkdir -p /etc/hvm-shared /usr/local/bin

# live /proc/meminfo content for one account (total = fake RAM if set, else the real limit)
cat > /usr/local/bin/hvm-meminfo-gen <<'MIEOF'
#!/bin/bash
# usage: hvm-meminfo-gen USER HOME   -> rewrites HOME/.meminfo IN PLACE (keeps the bind-mount inode)
U="$1"; H="$2"; MI="$H/.meminfo"
FR=""; LR=""
[ -r "/etc/hvm-shared/$U.fake" ] && read -r FR _ _ < "/etc/hvm-shared/$U.fake"
[ -r "/etc/hvm-shared/$U.limits" ] && read -r LR _ _ < "/etc/hvm-shared/$U.limits"
if [ -n "$FR" ]; then TOT=$((FR * 1048576)); elif [ -n "$LR" ]; then TOT=$((LR * 1024)); else
  [ -s "$MI" ] || cat /proc/meminfo > "$MI" 2>/dev/null; exit 0
fi
USED=""
for f in "/sys/fs/cgroup/system.slice/hvm-ct-$U.service/memory.current" "/sys/fs/cgroup/hvm/$U/memory.current"; do
  [ -r "$f" ] && { USED=$(( $(cat "$f") / 1024 )); break; }
done
[ -n "$USED" ] || USED=$(ps -u "$U" -o rss= 2>/dev/null | awk '{s+=$1} END {print s+0}')
[ "$USED" -gt "$TOT" ] && USED=$TOT
FREE=$((TOT - USED))
printf 'MemTotal:       %d kB\nMemFree:        %d kB\nMemAvailable:   %d kB\nBuffers:               0 kB\nCached:                0 kB\nSwapCached:            0 kB\nSwapTotal:             0 kB\nSwapFree:              0 kB\nShmem:                 0 kB\nSReclaimable:          0 kB\n' "$TOT" "$FREE" "$FREE" > "$MI.tmp" && cat "$MI.tmp" > "$MI"
rm -f "$MI.tmp"
chmod 644 "$MI" 2>/dev/null
exit 0
MIEOF
chmod 755 /usr/local/bin/hvm-meminfo-gen

cat > /usr/local/bin/hvm-meminfo-loop <<'MLEOF'
#!/bin/bash
# keeps the shown RAM usage live while the account's container runs
U="$1"; H="$2"
while systemctl is-active --quiet "hvm-ct-$U.service"; do /usr/local/bin/hvm-meminfo-gen "$U" "$H"; sleep 3; done
MLEOF
chmod 755 /usr/local/bin/hvm-meminfo-loop

cat > /usr/local/bin/hvm-fake-gen <<'FKEOF'
#!/bin/bash
# usage: hvm-fake-gen ROOT HOME USER
# writes, for the account's private system:  Host + kernel identity wrappers (neofetch / uname),
# /proc/cpuinfo + /proc/meminfo source files, and fake nproc / lscpu / df when fake resources are set.
R="$1"; H="$2"; U="$3"; B="$R/usr/local/bin"
[ -d "$R/etc" ] || exit 0
mkdir -p "$B" 2>/dev/null
FR=""; FC=""; FD=""; LR=""; LC=""
[ -r "/etc/hvm-shared/$U.fake" ] && read -r FR FC FD < "/etc/hvm-shared/$U.fake"
[ -r "/etc/hvm-shared/$U.limits" ] && read -r LR LC _ < "/etc/hvm-shared/$U.limits"

# ---- identity (Host / kernel), set with:  jazz-panel identity  ->  /etc/hvm-shared/identity ----
IH=$(sed -n 's/^HOST=//p' /etc/hvm-shared/identity 2>/dev/null | head -n1 | tr -cd 'A-Za-z0-9 ._()+-')
IK=$(sed -n 's/^KERNEL=//p' /etc/hvm-shared/identity 2>/dev/null | head -n1 | tr -cd 'A-Za-z0-9._+~-')
if [ -n "$IH" ]; then printf '%s\n' "$IH" > "$R/etc/hvm-host"; else rm -f "$R/etc/hvm-host"; fi
if [ -n "$IK" ]; then printf '%s\n' "$IK" > "$R/etc/hvm-kernel"; else rm -f "$R/etc/hvm-kernel"; fi
cat > "$B/neofetch" <<'NFEOF'
#!/bin/sh
# hvm-identity: neofetch shows the configured Host name
REAL=""
for p in /usr/bin/neofetch /bin/neofetch /snap/bin/neofetch; do [ -x "$p" ] && { REAL="$p"; break; }; done
[ -n "$REAL" ] || { echo "neofetch: not installed (run: apt update && apt install -y neofetch)" >&2; exit 127; }
HOSTV=$(cat /etc/hvm-host 2>/dev/null)
[ -n "$HOSTV" ] || exec "$REAL" "$@"
"$REAL" "$@" | sed -e "s/\(Host[^:]*: \)[^\x1b]*/\1${HOSTV}/"
NFEOF
cat > "$B/uname" <<'UNEOF'
#!/bin/sh
# hvm-identity: uname shows the configured kernel release
UN=/usr/bin/uname; [ -x "$UN" ] || UN=/bin/uname
K=$(cat /etc/hvm-kernel 2>/dev/null)
[ -n "$K" ] || exec "$UN" "$@"
REL=$("$UN" -r)
[ "$REL" = "$K" ] && exec "$UN" "$@"
E=$(printf '%s' "$REL" | sed 's/[][\.*^$/]/\\&/g')
"$UN" "$@" | sed "s/$E/$K/g"
UNEOF
chmod 755 "$B/neofetch" "$B/uname"

# ---- CPU count: fake value if set, else the account's real core limit ----
EC="$FC"; [ -n "$EC" ] || EC="$LC"
if [ -n "$EC" ] && [ "$EC" -ge 1 ] 2>/dev/null; then
  TB=$(mktemp)
  sed -n '1,/^$/p' /proc/cpuinfo > "$TB" 2>/dev/null
  [ -s "$TB" ] || printf 'processor\t: 0\nvendor_id\t: GenuineIntel\nmodel name\t: Intel(R) Xeon(R) Platinum 8375C CPU @ 2.90GHz\ncpu MHz\t\t: 2900.000\n\n' > "$TB"
  grep -q '^$' "$TB" || echo >> "$TB"
  M=$(awk -F': ' '/model name/{print $2; exit}' "$TB")
  for ((i=0;i<EC;i++)); do
    sed -e "s/^processor.*/processor\t: $i/" -e "s/^core id.*/core id\t\t: $i/" -e "s/^apicid.*/apicid\t\t: $i/" \
        -e "s/^initial apicid.*/initial apicid\t: $i/" -e "s/^siblings.*/siblings\t: $EC/" -e "s/^cpu cores.*/cpu cores\t: $EC/" "$TB"
  done > "$H/.cpuinfo.tmp"
  rm -f "$TB"
  cat "$H/.cpuinfo.tmp" > "$H/.cpuinfo"; rm -f "$H/.cpuinfo.tmp"
  chmod 644 "$H/.cpuinfo" 2>/dev/null
  printf '#!/bin/sh\n# hvm-fake\necho %s\n' "$EC" > "$B/nproc"
  printf '#!/bin/sh\n# hvm-fake\ncat <<EOF\nArchitecture:        x86_64\nCPU op-mode(s):      32-bit, 64-bit\nByte Order:          Little Endian\nCPU(s):              %s\nOn-line CPU(s) list: 0-%s\nThread(s) per core:  1\nCore(s) per socket:  %s\nSocket(s):           1\nModel name:          %s\nHypervisor vendor:   KVM\nVirtualization type: full\nEOF\n' "$EC" "$((EC-1))" "$EC" "$M" > "$B/lscpu"
  chmod 755 "$B/nproc" "$B/lscpu"
else
  [ -s "$H/.cpuinfo" ] || cat /proc/cpuinfo > "$H/.cpuinfo" 2>/dev/null
fi
/usr/local/bin/hvm-meminfo-gen "$U" "$H"

# ---- fake disk size ----
if [ -n "$FD" ]; then
rm -f "$B/df"
cat > "$B/df" <<DFEOF
#!/bin/sh
# hvm-fake
HF=0; for a in "\$@"; do case "\$a" in -h|--human-readable) HF=1;; esac; done
/usr/bin/df -k / | awk -v S=$((FD * 1048576)) -v HF=\$HF 'function h(k){ if(k>=1073741824)return sprintf("%.1fT",k/1073741824); if(k>=1048576)return sprintf("%.0fG",k/1048576); if(k>=1024)return sprintf("%.0fM",k/1024); return k "K" }
NR==1{ if(HF) print "Filesystem      Size  Used Avail Use% Mounted on"; else print "Filesystem     1K-blocks     Used Available Use% Mounted on"; next }
{ u=\$3; a=S-u; if(a<0)a=0; p=(S?int(u*100/S):0);
  if(HF) printf "%-15s %5s %5s %5s %3d%% /\n","/dev/vda",h(S),h(u),h(a),p; else printf "%-14s %9d %8d %9d %3d%% /\n","/dev/vda",S,u,a,p }'
DFEOF
chmod 755 "$B/df"
else
  grep -qs '# hvm-fake' "$B/df" && rm -f "$B/df"
fi
exit 0
FKEOF
chmod 755 /usr/local/bin/hvm-fake-gen

# nspawn: make the container's /proc/meminfo + /proc/cpuinfo come from the generated files
hvm_view_units() {   # usage: hvm_view_units USER ROOT HOME
  local U="$1" R="$2" H="$3" UF="/etc/systemd/system/hvm-ct-$1.service"
  [ -f "$UF" ] || return 0
  if ! grep -q 'proc/meminfo' "$UF"; then
    sed -i -e "s#^ExecStart=\(/usr/bin/systemd-nspawn .*\)\$#ExecStartPre=-/usr/local/bin/hvm-fake-gen $R $H $U\nExecStartPre=/bin/sh -c '[ -s $H/.meminfo ] || cat /proc/meminfo > $H/.meminfo; [ -s $H/.cpuinfo ] || cat /proc/cpuinfo > $H/.cpuinfo'\nExecStart=\1 --bind-ro=$H/.meminfo:/proc/meminfo --bind-ro=$H/.cpuinfo:/proc/cpuinfo#" "$UF"
  fi
  cat > "/etc/systemd/system/hvm-view-$U.service" <<VUEOF
[Unit]
Description=HVM shared hosting live RAM view $U
PartOf=hvm-ct-$U.service
After=hvm-ct-$U.service

[Service]
ExecStart=/usr/local/bin/hvm-meminfo-loop $U $H

[Install]
WantedBy=hvm-ct-$U.service
VUEOF
  systemctl daemon-reload >/dev/null 2>&1
  systemctl enable "hvm-view-$U.service" >/dev/null 2>&1
  systemctl is-active --quiet "hvm-ct-$U.service" && systemctl start "hvm-view-$U.service" >/dev/null 2>&1
  return 0
}
'''

# self-heal for accounts created by an older panel: new identity/resource view without reinstalling the VPS
_VIEW_HEAL = r'''
for U in $(getent group hvmshared 2>/dev/null | cut -d: -f4 | tr ',' ' '); do
  _R=""
  [ -f "/etc/hvm-shared/$U.iso" ] && read -r _ _ _R < "/etc/hvm-shared/$U.iso"
  [ -z "$_R" ] && [ -f "/etc/hvm-shared/$U.proot" ] && read -r _R < "/etc/hvm-shared/$U.proot"
  [ -n "$_R" ] && [ -d "$_R/etc" ] || continue
  _H=$(dirname "$_R")
  if [ -f "/etc/hvm-shared/$U.iso" ]; then
    /usr/local/bin/hvm-fake-gen "$_R" "$_H" "$U" >/dev/null 2>&1
    hvm_view_units "$U" "$_R" "$_H"
  elif command -v runuser >/dev/null 2>&1; then
    runuser -u "$U" -- /usr/local/bin/hvm-fake-gen "$_R" "$_H" "$U" >/dev/null 2>&1
  fi
done
'''

_FAKE_ACCOUNT = r'''
__FAKE_WRITE__
[ -f "/etc/hvm-shared/$U.fake" ] && chmod 644 "/etc/hvm-shared/$U.fake"
_A=""; _B=""; _RT=""
[ -f "/etc/hvm-shared/$U.iso" ] && read -r _A _B _RT < "/etc/hvm-shared/$U.iso"
[ -z "$_RT" ] && [ -f "/etc/hvm-shared/$U.proot" ] && read -r _RT < "/etc/hvm-shared/$U.proot"
if [ -n "$_RT" ] && [ -d "$_RT/etc" ]; then
  /usr/local/bin/hvm-fake-gen "$_RT" "$H" "$U"
  [ -f "/etc/hvm-shared/$U.iso" ] && hvm_view_units "$U" "$_RT" "$H"
fi
'''

_PROOT_GLOBAL = _PROOT_SETUP + _PROOT_BIN

_PROOT_ACCOUNT = r'''
  if [ "$ISO_OK" != "1" ] && [ "$PROOT_OK" = "1" ]; then
    R="$H/rootfs"
    rm -f "/etc/hvm-shared/$U.proot"
    pkill -KILL -u "$U" >/dev/null 2>&1
    if [ ! -e "$R/etc/os-release" ]; then
      rm -rf "$R"; mkdir -p "$R"; chown "$U:$GID_N" "$R"
      runuser -u "$U" -- tar -xpzf /opt/hvm-shared/.proot-base.tar.gz -C "$R" --no-same-owner --exclude='./dev/*' >/dev/null 2>&1
    fi
    if [ -e "$R/etc/os-release" ]; then
      OSID=$(. /etc/os-release; echo "$ID"); OSSUITE=$(. /etc/os-release; echo "$VERSION_CODENAME")
      echo "$U" > "$R/etc/hostname"
      echo "127.0.0.1 localhost $U" > "$R/etc/hosts"
      rm -f "$R/etc/resolv.conf"; cp /etc/resolv.conf "$R/etc/resolv.conf" 2>/dev/null
      mkdir -p "$R/etc/apt/apt.conf.d" "$R/usr/local/bin" "$R/srv/public_html" "$R/root"
      echo 'APT::Sandbox::User "root";' > "$R/etc/apt/apt.conf.d/99hvm-nosandbox"
      echo 'Dpkg::Options { "--force-unsafe-io"; };' > "$R/etc/apt/apt.conf.d/99hvm-dpkg"
      if [ "$OSID" = "ubuntu" ] && [ -n "$OSSUITE" ]; then
        rm -f "$R/etc/apt/sources.list.d/ubuntu.sources"
        printf 'deb http://archive.ubuntu.com/ubuntu %s main restricted universe multiverse\ndeb http://archive.ubuntu.com/ubuntu %s-updates main restricted universe multiverse\ndeb http://security.ubuntu.com/ubuntu %s-security main restricted universe multiverse\n' "$OSSUITE" "$OSSUITE" "$OSSUITE" > "$R/etc/apt/sources.list"
      fi
      # you are already (fake) root inside: make "sudo" a harmless pass-through
      printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do case "$1" in -*) shift;; *) break;; esac; done\nexec "$@"\n' > "$R/usr/local/bin/sudo"
      chmod 755 "$R/usr/local/bin/sudo"
      printf 'set -g status off\nset -g history-limit 20000\nset -g default-terminal "xterm-256color"\n' > "$R/root/.tmux.conf"
      chown -R "$U:$GID_N" "$R" >/dev/null 2>&1
      if [ ! -x "$R/usr/bin/tmux" ]; then
        runuser -u "$U" -- env PROOT_NO_SECCOMP=1 PROOT_TMP_DIR="$H/tmp" timeout 900 proot -0 -r "$R" --link2symlink -b /dev -b /proc -b /sys -w /root \
          /usr/bin/env -i HOME=/root PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin DEBIAN_FRONTEND=noninteractive \
          /bin/bash -c 'apt-get update -qq && apt-get install -y -qq --no-install-recommends tmux nano curl wget ca-certificates iproute2 procps iputils-ping less gnupg lsb-release' >"$H/logs/provision.log" 2>&1
      fi
      echo "$R" > "/etc/hvm-shared/$U.proot"
      chmod 644 "/etc/hvm-shared/$U.proot"
      echo "HVMREC|iso|$U|proot"
    else
      echo "HVM|warn|could not create private filesystem for $U - using shared host mode"
    fi
  fi
'''

# Per account creation.  Values are injected by the Python side.
_ACCOUNT_CREATE = """\
U=__USER__
PW=__PASS__
RAM=__RAM__
CPU=__CPU__
DISK=__DISK__
FULL=__FULL__
H="__BASE__/$U"
if ! getent passwd "$U" >/dev/null 2>&1; then
  useradd -m -d "$H" -s __SHELL_BIN__ "$U" >/dev/null 2>&1 || { echo "HVM|err|useradd failed for $U"; }
else
  usermod -d "$H" -s __SHELL_BIN__ "$U" >/dev/null 2>&1
  mkdir -p "$H"
fi
echo "$U:$PW" | chpasswd >/dev/null 2>&1
usermod -aG hvmshared "$U" >/dev/null 2>&1
SF="/etc/sudoers.d/hvm-$U"
if [ "$FULL" = "1" ]; then
  command -v sudo >/dev/null 2>&1 || DEBIAN_FRONTEND=noninteractive apt-get install -y sudo >/dev/null 2>&1
  mkdir -p /etc/sudoers.d
  printf '%s ALL=(root) NOPASSWD: /usr/local/bin/hvm-enter, /usr/local/bin/hvm-cgroup, /usr/bin/apt, /usr/bin/apt-get, /usr/bin/apt-cache, /usr/bin/dpkg\\n' "$U" > "$SF.tmp"
  chmod 440 "$SF.tmp"
  if command -v visudo >/dev/null 2>&1 && visudo -cf "$SF.tmp" >/dev/null 2>&1; then mv -f "$SF.tmp" "$SF"; else rm -f "$SF.tmp"; echo "HVM|warn|sudo/visudo unavailable - apt will not work for $U"; fi
else
  rm -f "$SF"
fi
UID_N=$(id -u "$U" 2>/dev/null)
GID_N=$(id -g "$U" 2>/dev/null)
if [ -n "$UID_N" ]; then
  # ---- dedicated disk: every account gets its own ext4 volume of exactly DISK GB ----
  IMG="/opt/hvm-shared/disks/$U.img"
  if mountpoint -q "$H" 2>/dev/null; then
    CUR=$(stat -c %s "$IMG" 2>/dev/null || echo 0); WANT=$((DISK * 1024 * 1024 * 1024))
    if [ "$WANT" -gt "$CUR" ] && [ -f "$IMG" ]; then
      truncate -s "$WANT" "$IMG" && LD=$(findmnt -no SOURCE "$H" 2>/dev/null) && losetup -c "$LD" >/dev/null 2>&1 && resize2fs "$LD" >/dev/null 2>&1
    fi
    echo "HVMREC|disk|$U|${DISK}"
  else
    if hvm_mount_disk "$U" "$H" "$IMG" "$DISK"; then
      echo "HVMREC|disk|$U|${DISK}"
    else
      echo "HVM|warn|using quota monitoring (no separate disk) for $U"
    fi
  fi
  mkdir -p "$H/public_html" "$H/logs" "$H/tmp"
  if [ ! -f "$H/README.txt" ]; then
    { echo "Shared hosting account: $U"
      echo "Put your website files inside public_html/."
      echo "Limits: ${RAM}MB RAM / ${CPU} CPU / ${DISK}GB disk"
    } > "$H/README.txt"
  fi
  chown "$U:$GID_N" "$H" "$H/public_html" "$H/logs" "$H/tmp" "$H/README.txt" >/dev/null 2>&1
  chmod 750 "$H"
  if [ -d /etc/systemd/system ]; then
    mkdir -p "/etc/systemd/system/user-${UID_N}.slice.d"
    printf '[Slice]\\nMemoryMax=%sM\\nMemorySwapMax=0\\nCPUQuota=%s%%\\nTasksMax=4096\\n' "$RAM" "$((CPU * 100))" > "/etc/systemd/system/user-${UID_N}.slice.d/10-hvm-limits.conf"
    systemctl daemon-reload >/dev/null 2>&1
  fi
  if command -v setquota >/dev/null 2>&1; then
    FSD=$(df --output=target "$H" 2>/dev/null | tail -1)
    if [ -n "$FSD" ]; then
      setquota -u "$U" $((DISK * 1024 * 1024)) $((DISK * 1024 * 1024)) 0 0 "$FSD" >/dev/null 2>&1
    fi
  fi
  echo "$RAM $CPU $DISK" > "/etc/hvm-shared/$U.limits"; chmod 644 "/etc/hvm-shared/$U.limits"
  __FAKE_PRE__
  __ISO_ACCOUNT__
  __FAKE_ACCOUNT__
  echo "HVMREC|account|$U|$UID_N|$H"
else
  echo "HVM|err|could not resolve system user $U"
fi
"""


def setup_script(base_name: str, accounts: List[Dict[str, Any]]) -> str:
    """Build the script that provisions (or extends) a shared VPS."""
    base_dir = f"/opt/hvm-shared/{base_name}"
    parts = [_ROOT_GUARD]
    parts.append(f"BASE={_q(base_dir)}")
    parts.append('mkdir -p "$BASE" || { echo "HVM|err|cannot create $BASE"; echo "HVM|done|0"; exit 0; }')
    parts.append('chmod 711 "$BASE"')
    parts.append('getent group hvmshared >/dev/null 2>&1 || groupadd hvmshared >/dev/null 2>&1 || true')
    parts.append(_SHELL_INSTALL.replace('__SHELL_BIN__', _SHELL_BIN).replace('__RCFILE__', _RCFILE))
    parts.append(_SSHD_SETUP)
    parts.append(_DISK_GLOBAL)
    parts.append(_ISO_GLOBAL)
    parts.append(_FAKE_GLOBAL)
    parts.append(_PROOT_GLOBAL)
    parts.append(_CG_GLOBAL)
    parts.append(_LIMITS_HEAL)
    parts.append(_VIEW_HEAL)
    for acc in accounts:
        fk = acc.get('fake')
        if fk:
            fw = 'echo "%d %d %d" > "/etc/hvm-shared/$U.fake"' % (int(fk['ram_gb']), int(fk['cpu']), int(fk['disk_gb']))
        elif acc.get('fake_off'):
            fw = 'rm -f "/etc/hvm-shared/$U.fake"'
        else:
            fw = ''
        # the fake values must be on disk BEFORE the container starts (its /proc view is built at start)
        fw_pre = fw
        snippet = (_ACCOUNT_CREATE.replace('__ISO_ACCOUNT__', _ISO_ACCOUNT + _PROOT_ACCOUNT)
                   .replace('__FAKE_PRE__', fw_pre)
                   .replace('__FAKE_ACCOUNT__', _FAKE_ACCOUNT.replace('__FAKE_WRITE__', fw))
                   .replace('__USER__', _q(acc['system_user']))
                   .replace('__PASS__', _q(acc['password']))
                   .replace('__RAM__', _q(int(acc['ram_mb'])))
                   .replace('__CPU__', _q(int(acc['cpu'])))
                   .replace('__DISK__', _q(int(acc['disk_gb'])))
                   .replace('__FULL__', '1' if acc.get('full_perms', True) else '0')
                   .replace('__BASE__', _q(base_dir))
                   .replace('__SHELL_BIN__', _q(_SHELL_BIN)))
        parts.append(snippet)
    parts.append('echo "HVM|done|1"')
    return '\n'.join(parts)


def shell_refresh_script() -> str:
    """Re-install the restricted login shell on an existing node (picks up
    fixes without having to reinstall any shared VPS)."""
    return '\n'.join([
        _ROOT_GUARD,
        _SHELL_INSTALL.replace('__SHELL_BIN__', _SHELL_BIN).replace('__RCFILE__', _RCFILE),
        _FAKE_GLOBAL,
        _PROOT_BIN,
        _CG_GLOBAL,
        _LIMITS_HEAL,
        _VIEW_HEAL,
        'echo "HVM|done|1"',
    ])


def mount_disks_script() -> str:
    """Mount every per-account disk image that is not mounted yet (needed
    after a reboot / container restart, where /etc/fstab is not replayed)."""
    return '\n'.join([
        _ROOT_GUARD,
        _DISK_GLOBAL,
        'hvm_prepare_loop',
        'for IMG in /opt/hvm-shared/disks/*.img; do',
        '  [ -f "$IMG" ] || continue',
        '  U=$(basename "$IMG" .img)',
        '  H=$(getent passwd "$U" 2>/dev/null | cut -d: -f6)',
        '  [ -n "$H" ] || continue',
        '  mountpoint -q "$H" 2>/dev/null && continue',
        '  mkdir -p "$H"',
        '  LD=$(losetup -f --show "$IMG" 2>/dev/null)',
        '  if [ -n "$LD" ]; then mount -o noatime "$LD" "$H" >/dev/null 2>&1 || { losetup -d "$LD" >/dev/null 2>&1; mount -o loop,noatime "$IMG" "$H" >/dev/null 2>&1; }',
        '  else mount -o loop,noatime "$IMG" "$H" >/dev/null 2>&1; fi',
        '  mountpoint -q "$H" 2>/dev/null && echo "HVMREC|mounted|$U"',
        'done',
        'echo "HVM|done|1"',
    ])


def wipe_script(system_user: str) -> str:
    """Reinstall for ONE shared account: kill its processes and delete only
    its files, then recreate a fresh home directory skeleton."""
    return '\n'.join([
        _ROOT_GUARD,
        f"U={_q(system_user)}",
        'H=$(getent passwd "$U" 2>/dev/null | cut -d: -f6)',
        '[ -n "$H" ] || { echo "HVM|err|unknown system user $U"; echo "HVM|done|0"; exit 0; }',
        # 1) stop everything this user is running
        'systemctl stop "hvm-ct-$U.service" >/dev/null 2>&1',
        'pkill -KILL -u "$U" >/dev/null 2>&1',
        'sleep 1',
        'pkill -KILL -u "$U" >/dev/null 2>&1',
        # 2) wipe ONLY this user's files (home stays, other users untouched)
        'rm -f "/etc/hvm-shared/$U.iso" "/etc/hvm-shared/$U.proot"',
        'if [ -d "$H" ]; then rm -rf "$H"/* "$H"/.[!.]* >/dev/null 2>&1; fi',
        # 3) fresh skeleton
        'mkdir -p "$H/public_html" "$H/logs" "$H/tmp"',
        '{ echo "Fresh shared hosting account: $U"; echo "Your previous files were removed by reinstall."; } > "$H/README.txt"',
        'chown "$U:$(id -g "$U")" "$H" "$H/public_html" "$H/logs" "$H/tmp" "$H/README.txt" >/dev/null 2>&1',
        'chmod 750 "$H"',
        'echo "HVM|done|1"',
    ])


def kill_script(system_user: str) -> str:
    """Stop (kill) all processes belonging to one shared account."""
    return '\n'.join([
        _ROOT_GUARD,
        f"U={_q(system_user)}",
        'getent passwd "$U" >/dev/null 2>&1 || { echo "HVM|err|unknown system user $U"; echo "HVM|done|0"; exit 0; }',
        'systemctl stop "hvm-ct-$U.service" >/dev/null 2>&1',
        'pkill -TERM -u "$U" >/dev/null 2>&1',
        'sleep 2',
        'pkill -KILL -u "$U" >/dev/null 2>&1',
        'echo "HVM|done|1"',
    ])


def start_script(system_user: str) -> str:
    """Start the account's private container (no-op for host-mode accounts)."""
    return '\n'.join([
        _ROOT_GUARD,
        f"U={_q(system_user)}",
        '[ -f "/etc/hvm-shared/$U.iso" ] && systemctl start "hvm-ct-$U.service" >/dev/null 2>&1',
        'echo "HVM|done|1"',
    ])


def suspend_script(system_user: str) -> str:
    """Suspend one shared account: kill its processes and lock the password
    so no console/SFTP login is possible until an admin resumes it."""
    return '\n'.join([
        _ROOT_GUARD,
        f"U={_q(system_user)}",
        'getent passwd "$U" >/dev/null 2>&1 || { echo "HVM|err|unknown system user $U"; echo "HVM|done|0"; exit 0; }',
        'systemctl stop "hvm-ct-$U.service" >/dev/null 2>&1',
        'pkill -KILL -u "$U" >/dev/null 2>&1',
        'usermod -L "$U" >/dev/null 2>&1',
        'echo "HVM|done|1"',
    ])


def resume_script(system_user: str) -> str:
    """Resume a suspended shared account (unlock password)."""
    return '\n'.join([
        _ROOT_GUARD,
        f"U={_q(system_user)}",
        'getent passwd "$U" >/dev/null 2>&1 || { echo "HVM|err|unknown system user $U"; echo "HVM|done|0"; exit 0; }',
        'usermod -U "$U" >/dev/null 2>&1',
        '[ -f "/etc/hvm-shared/$U.iso" ] && systemctl start "hvm-ct-$U.service" >/dev/null 2>&1',
        'echo "HVM|done|1"',
    ])


# ---------------------------------------------------------------------------
# SSHX (shareable live terminal) for shared accounts
# ---------------------------------------------------------------------------
# sshx runs as the account's own unprivileged system user (never root), from
# its home directory, so the shared terminal is confined exactly like the
# panel web console.  Output goes to $HOME/tmp/.sshx.out which the panel polls.

_SSHX_ENV = """\
U={user}
H=$(getent passwd "$U" 2>/dev/null | cut -d: -f6)
[ -n "$H" ] && [ -d "$H" ] || {{ echo "HVM|err|unknown system user or missing home for $U"; echo "HVM|done|0"; exit 0; }}
OUT="$H/tmp/.sshx.out"
mkdir -p "$H/tmp" 2>/dev/null; chown "$U:$(id -g "$U")" "$H/tmp" 2>/dev/null
hvm_as_user() {{
  if command -v runuser >/dev/null 2>&1; then runuser -u "$U" -- "$@"
  elif command -v setpriv >/dev/null 2>&1; then setpriv --reuid="$U" --regid="$(id -g "$U")" --init-groups "$@"
  else su -s /bin/sh "$U" -c "$(printf '%q ' "$@")"; fi
}}
"""


def sshx_start_script(system_user: str) -> str:
    """Kill any previous sshx of this account and start a fresh one."""
    return '\n'.join([
        _ROOT_GUARD,
        _SSHX_ENV.format(user=_q(system_user)),
        'pkill -x -u "$U" sshx >/dev/null 2>&1; sleep 1',
        'pkill -KILL -x -u "$U" sshx >/dev/null 2>&1',
        'rm -f "$OUT"; : > "$OUT"; chown "$U:$(id -g "$U")" "$OUT" 2>/dev/null; chmod 600 "$OUT"',
        'if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then',
        '  echo "HVM|err|neither curl nor wget is installed on the node"; echo "HVM|done|0"; exit 0',
        'fi',
        # `setsid` + nohup keep the tunnel alive after this script exits
        'INNER=\'cd "$HOME" 2>/dev/null; export HOME PATH="/usr/local/bin:/usr/bin:/bin"; '
        'if command -v curl >/dev/null 2>&1; then curl -sSf https://sshx.io/get | sh -s run; '
        'else wget -qO- https://sshx.io/get | sh -s run; fi\'',
        # SHELL=hvm-shell makes the sshx terminal behave exactly like the panel web console:
        # it drops into the account's PRIVATE container / proot root (not the node's host shell).
        'SHX=/usr/local/bin/hvm-shell; [ -x "$SHX" ] || SHX=/bin/bash',
        'HOME="$H" hvm_as_user env HOME="$H" USER="$U" LOGNAME="$U" SHELL="$SHX" '
        'setsid nohup sh -c "$INNER" </dev/null >"$OUT" 2>&1 &',
        'sleep 1',
        'echo "HVM|done|1"',
    ])


def sshx_status_script(system_user: str) -> str:
    """Report whether sshx is running plus the (base64) tail of its output."""
    return '\n'.join([
        _ROOT_GUARD,
        _SSHX_ENV.format(user=_q(system_user)),
        'if pgrep -x -u "$U" sshx >/dev/null 2>&1; then RUN=1; else RUN=0; fi',
        'B64=$( [ -f "$OUT" ] && tail -c 6000 "$OUT" 2>/dev/null | base64 -w0 2>/dev/null )',
        'echo "HVMREC|sshx|$RUN|$B64"',
        'echo "HVM|done|1"',
    ])


def sshx_stop_script(system_user: str) -> str:
    """Stop the account's sshx tunnel and remove its output file."""
    return '\n'.join([
        _ROOT_GUARD,
        _SSHX_ENV.format(user=_q(system_user)),
        'pkill -x -u "$U" sshx >/dev/null 2>&1; sleep 1; pkill -KILL -x -u "$U" sshx >/dev/null 2>&1',
        'pkill -u "$U" -f "sshx.io/get" >/dev/null 2>&1',
        'rm -f "$OUT"',
        'echo "HVM|done|1"',
    ])


def remove_script(system_users: List[str], base_name: str) -> str:
    """Delete shared accounts (system users + homes + limits) and clean up
    the shared VPS base directory."""
    base_dir = f"/opt/hvm-shared/{base_name}"
    lines = [_ROOT_GUARD, f"BASE={_q(base_dir)}"]
    for user in system_users:
        lines.extend([
            f"U={_q(user)}",
            'pkill -KILL -u "$U" >/dev/null 2>&1',
            'rm -f "/etc/sudoers.d/hvm-$U" 2>/dev/null',
            'systemctl stop "hvm-ct-$U.service" >/dev/null 2>&1; systemctl disable "hvm-ct-$U.service" >/dev/null 2>&1; rm -f "/etc/systemd/system/hvm-ct-$U.service" "/etc/hvm-shared/$U.iso" "/etc/hvm-shared/$U.proot" "/etc/hvm-shared/$U.limits"',
            'H=$(getent passwd "$U" 2>/dev/null | cut -d: -f6)',
            'if [ -n "$H" ] && mountpoint -q "$H" 2>/dev/null; then LDV=$(findmnt -no SOURCE "$H" 2>/dev/null); umount "$H" 2>/dev/null || umount -l "$H" 2>/dev/null; [ -n "$LDV" ] && losetup -d "$LDV" >/dev/null 2>&1; fi',
            'if [ -f "/opt/hvm-shared/disks/$U.img" ]; then sed -i "\\|/opt/hvm-shared/disks/$U.img|d" /etc/fstab 2>/dev/null; rm -f "/opt/hvm-shared/disks/$U.img"; fi',
            'UID_N=$(id -u "$U" 2>/dev/null)',
            'if [ -n "$UID_N" ]; then',
            '  userdel -r "$U" >/dev/null 2>&1 || userdel "$U" >/dev/null 2>&1',
            '  rm -rf "/etc/systemd/system/user-${UID_N}.slice.d" 2>/dev/null',
            '  systemctl daemon-reload >/dev/null 2>&1',
            'fi',
        ])
    lines.extend([
        'rm -rf "$BASE" >/dev/null 2>&1',
        'echo "HVM|done|1"',
    ])
    return '\n'.join(lines)


def stats_script(system_user: str) -> str:
    """Report usage for one shared account (disk KB, memory KB, CPU %,
    process count, lock state, uid)."""
    return '\n'.join([
        f"U={_q(system_user)}",
        'H=$(getent passwd "$U" 2>/dev/null | cut -d: -f6)',
        '[ -n "$H" ] || { echo "HVM|err|unknown system user $U"; echo "HVM|done|0"; exit 0; }',
        'DK=$(du -sk "$H" 2>/dev/null | awk \'{print $1}\'); DK=${DK:-0}',
        'if mountpoint -q "$H" 2>/dev/null; then DKD=$(df -k --output=used "$H" 2>/dev/null | tail -1 | tr -d " "); [ -n "$DKD" ] && DK=$DKD; fi',
        'MK=$(ps -o rss= -u "$U" 2>/dev/null | awk \'{s+=$1} END {print s+0}\'); MK=${MK:-0}',
        'if [ -f "/etc/hvm-shared/$U.iso" ]; then MB=$(systemctl show -p MemoryCurrent --value "hvm-ct-$U.service" 2>/dev/null); case "$MB" in \'\'|*[!0-9]*) MK=0;; *) MK=$((MB/1024));; esac; fi',
        'CP=$(ps -o %cpu= -u "$U" 2>/dev/null | awk \'{s+=$1} END {print s+0}\'); CP=${CP:-0}',
        'PR=$(ps -u "$U" --no-headers 2>/dev/null | wc -l); PR=${PR:-0}',
        'LK=$(passwd -S "$U" 2>/dev/null | awk \'{print $2}\'); LK=${LK:-0}',
        'UIDN=$(id -u "$U" 2>/dev/null); UIDN=${UIDN:-0}',
        'echo "HVMREC|stats|$DK|$MK|$CP|$PR|$LK|$UIDN"',
        'echo "HVM|done|1"',
    ])


# ---------------------------------------------------------------------------
# Output parsing
# ---------------------------------------------------------------------------

def parse(raw: str) -> Dict[str, Any]:
    """Parse the HVM| / HVMREC| structured output of a script."""
    out: Dict[str, Any] = {"ok": False, "records": [], "warn": [], "err": [], "log": []}
    for line in (raw or '').splitlines():
        line = line.strip()
        if line.startswith('HVMREC|'):
            out["records"].append(line.split('|')[2:])
        elif line.startswith('HVM|'):
            parts = line.split('|')
            if len(parts) >= 3:
                key, val = parts[1], '|'.join(parts[2:])
                if key == 'done':
                    out["ok"] = val == '1'
                elif key == 'err':
                    out["err"].append(val)
                elif key == 'warn':
                    out["warn"].append(val)
                else:
                    out["log"].append([key, val])
    return out


def ensure_ok(result: Dict[str, Any], what: str) -> Dict[str, Any]:
    """Raise a readable exception when a script reported an error."""
    if not result.get("ok") or result.get("err"):
        detail = '; '.join(result.get("err") or []) or 'unknown error'
        raise Exception(f"{what} failed: {detail}")
    return result


# ---------------------------------------------------------------------------
# Runner: local node (direct bash) or remote node (agent /api/execute)
# ---------------------------------------------------------------------------

async def run(node: Dict[str, Any], script: str, timeout: int = 300) -> Dict[str, Any]:
    """Execute a shared-hosting script on the given node and parse output."""
    raw = ""
    stderr = ""

    if node.get('is_local'):
        proc = await asyncio.create_subprocess_exec(
            'bash', '-c', script,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise Exception("Shared hosting operation timed out")
        raw = out.decode('utf-8', errors='replace') if out else ""
        stderr = err.decode('utf-8', errors='replace') if err else ""
    else:
        import requests
        url = f"{node['url']}/api/execute"
        payload = {"command": "bash -c " + shlex.quote(script), "timeout": timeout}
        headers = {"X-API-Key": node.get('api_key') or ''}
        verify = bool(node.get('verify_ssl', 1))
        try:
            response = requests.post(url, json=payload, headers=headers,
                                     timeout=timeout + 10, verify=verify)
        except Exception as e:
            raise Exception(f"Could not reach node {node.get('name', '?')}: {e}")
        try:
            data = response.json()
        except Exception:
            raise Exception(f"Node {node.get('name', '?')} returned an invalid response (HTTP {response.status_code})")
        raw = data.get('stdout') or ''
        stderr = data.get('stderr') or ''
        if not data.get('success') and 'HVM|' not in raw:
            raise Exception(stderr.strip() or f"Node command failed (HTTP {response.status_code})")

    result = parse(raw)
    if stderr.strip():
        result['stderr'] = stderr.strip()
    return result


def stats_to_dict(record: List[str]) -> Optional[Dict[str, Any]]:
    """Convert a HVMREC|stats record into a dict."""
    try:
        return {
            "disk_kb": int(float(record[0])),
            "mem_kb": int(float(record[1])),
            "cpu": float(record[2]),
            "procs": int(float(record[3])),
            "locked": record[4],
            "uid": int(float(record[5])),
        }
    except (IndexError, ValueError):
        return None
